package in.ind.mds.exception;

import org.springframework.http.HttpStatus;

public class ApplicationServiceExecption extends Exception {

	private static final long serialVersionUID = 746599251911336916L;

	private String errorMessage;

	private HttpStatus status;

	public ApplicationServiceExecption(final String errorMessage) {
		super(errorMessage);
		this.errorMessage = errorMessage;
	}

	public ApplicationServiceExecption(final String errorMessage, final HttpStatus status) {
		super(errorMessage);
		this.errorMessage = errorMessage;
		this.status = status;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public HttpStatus getStatus() {
		return status;
	}

	public void setStatus(HttpStatus status) {
		this.status = status;
	}

}