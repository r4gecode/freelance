/**
 * 
 */
package in.ind.mds.enums;

/**
 * @author mds-arockia
 *
 */
public enum Months {

	JANUARY(0,31),FEBRUARY(1,28),MARCH(2,31),APRIL(3,30),MAY(4,31),JUNE(5,30),JULY(6,31),AUGUST(7,31),SEPTEMBER(8,30),OCTOBER(9,31),NOVEMBER(10,30),DECEMBER(11,31);
	
	private Integer count;
	private Integer days;

	/**
	 * @return the count
	 */
	public Integer getCount() {
		return count;
	}
	
	/**
	 * @return the days
	 */
	public Integer getDays() {
		return days;
	}

	/**
	 * @param count
	 * @param days
	 */
	private Months(Integer count, Integer days) {
		this.count = count;
		this.days = days;
	}

}
