/**
 * 
 */
package in.ind.mds.enums;

/**
 * @author mds-arockia
 *
 */
public enum RunningHourTypes {

	DAILYBASIS(0, "Daily Basis"),SHARINGDATES(1, "Sharing Dates"),COUNTERBASIS(2, "Counter Basis");
	
	private Integer count;
	private String name;
	
	/**
	 * @return the count
	 */
	public Integer getCount() {
		return count;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param count
	 * @param name
	 */
	private RunningHourTypes(Integer count, String name) {
		this.count = count;
		this.name = name;
	}

}
