/**
 * 
 */
package in.ind.mds.enums;

/**
 * @author mds-arockia
 *
 */
public enum FreequencyTypes {
	
	HOURS(0, "Hours"),DAYS(1, "Days"),WEEKS(2, "Weeks"),MONTHS(3, "Months"),YEARS(4, "Years"),RANGEHOURS(5, "RangeHours");

	private Integer count;
	private String names;
	
	/**
	 * @return the count
	 */
	public Integer getCount() {
		return count;
	}
	/**
	 * @return the names
	 */
	public String getNames() {
		return names;
	}
	
	/**
	 * @param count
	 * @param names
	 */
	private FreequencyTypes(Integer count, String names) {
		this.count = count;
		this.names = names;
	}
	
	

}
