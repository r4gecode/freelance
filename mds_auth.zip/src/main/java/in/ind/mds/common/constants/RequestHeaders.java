package in.ind.mds.common.constants;

public enum RequestHeaders {
	AUTHORIZATION(SecurityConstants.AUTHORIZATION), CACHE_CONTROL(SecurityConstants.CACHE_CONTROL), CONTENT_TYPE(
			SecurityConstants.CONTENT_TYPE), USER_NAME(SecurityConstants.USER_NAME);

	private String type;

	RequestHeaders(String type) {
		this.type = type;
	}

	public String getType() {
		return this.type;
	}
}
