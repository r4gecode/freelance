package in.ind.mds.common.constants;

public class AppConstants {

	public static final String RUN_TIME_EXCEPTION = "RUN_TIME_EXCEPTION";
	public static final String TRANSACTION_STATUS = "TRANSACTION_STATUS";
	public static final String MDS_APP_CONTEXT_ROOT ="/mds";
	public static final String HTTP= "http://";
	public static final String USER_NAME = "Username";
	public static final String DATE_FORMAT = "MM/dd/yyyy";
}
