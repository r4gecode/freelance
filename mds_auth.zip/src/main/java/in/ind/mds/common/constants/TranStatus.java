package in.ind.mds.common.constants;

public enum TranStatus {

	SUCCESS("Success"), 
	FAIL("Fail"), 
	UNAUTHORIZED("Unauthorized"),
	INTERNAL_SERVER_ERROR("Internal Server Error");

	TranStatus(String value) {
		this.value = value;
	}

	private String value;

	public String getValue() {
		return value;
	}

}
