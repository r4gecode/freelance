package in.ind.mds.common.constants;

import java.util.Arrays;
import java.util.List;

public class SecurityConstants {
	public static final String JWT_TOKEN_HEADER_PARAM = "Authorization";
	public static final String FORM_BASED_LOGIN_ENTRY_POINT = "/mds/auth/login";
	public static final String TOKEN_BASED_AUTH_ENTRY_POINT = "/mds/**";
	public static final String TOKEN_REFRESH_ENTRY_POINT = "/mds/auth/token";

	public static final String SECRET = "MDSAPP";
	public static final long EXPIRATION_TIME = 864_000_000; // 10 days
	public static final String TOKEN_PREFIX = "Bearer";
	public static final String[] ORIGINS = { "*" };

	public static final List<String> ORIGIN_LIST = Arrays.asList(ORIGINS);
	
	public static final String ADMIN_USER_NAME = "ADMIN";
	public static final String ADMIN_PASSWORD = "ADMIN";
	
	public static final String TOKEN_GEN_URL = "/genTokenForCurrentUser";
	public static final String AUTHORIZATION = "Authorization";
	public static final String CACHE_CONTROL = "Cache-Control";
	public static final String CONTENT_TYPE = "Content-Type";
	public static final String USER_NAME = "Username";
	
	public static final String GET = "GET";
	public static final String POST = "POST";
	public static final String DELETE = "DELETE";
	public static final String PUT = "PUT";
	public static final String PATCH = "PATCH";
	public static final String HEAD = "HEAD";
}
