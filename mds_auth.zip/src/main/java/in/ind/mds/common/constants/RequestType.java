package in.ind.mds.common.constants;

public enum RequestType {

	GET(SecurityConstants.GET), POST(SecurityConstants.POST), PUT(SecurityConstants.PUT), DELETE(
			SecurityConstants.DELETE), PATCH(SecurityConstants.PATCH), HEAD(SecurityConstants.HEAD);

	private String type;

	RequestType(String type) {
		this.type = type;
	}

	public String getType() {
		return this.type;
	}
}
