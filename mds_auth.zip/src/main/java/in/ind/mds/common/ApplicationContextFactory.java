package in.ind.mds.common;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.annotation.Configuration;

import in.ind.mds.security.JWTAuthenticationService;
@Configuration
public class ApplicationContextFactory implements ApplicationContextAware {

	private static ApplicationContext applicationCntxt;

	@Override
	public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
		applicationCntxt = applicationContext;
	}

	public ApplicationContext getApplicationContext() {
		return applicationCntxt;
	}
	
	public static JWTAuthenticationService getTokenAuthenticationService(){
		return applicationCntxt.getBean(JWTAuthenticationService.class);
	}
	
	/*@Bean("CodeDescCachedValues")
	public static CodeValCache getCodeValDesc(){
		return applicationCntxt.getBean(CodeValCache.class);
	}*/
}
