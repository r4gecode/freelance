package in.ind.mds.serviceImpl;

import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import in.ind.mds.dto.CountryDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.repo.dao.CountryDao;
import in.ind.mds.repo.entity.Country;
import in.ind.mds.service.CountryService;
import in.ind.mds.service.SyncDataService;
import in.ind.mds.util.BeanTransformerUtil;
import in.ind.mds.util.CommonUtil;
import in.ind.mds.util.DBUtil;

@Service("TST_MSSQL_COUNTRY")
public class CountryServiceImpl implements CountryService
{
	private static final Logger LOGGER = LoggerFactory.getLogger(CountryServiceImpl.class);
	
	@Autowired
	private BeanTransformerUtil<Country, CountryDto> mapEntityToDto;

	@Autowired
	private BeanTransformerUtil<CountryDto, Country> mapDtoToEntity;
	
	@Autowired
	private CountryDao countryDao;
	
	@Autowired
	private DBUtil dbUtil;
	
	@Autowired
	@Qualifier("TST_MSSQL_SYNC")
	private SyncDataService syncDataService;
	
	@Autowired
	private CommonUtil<CountryDto> commonUtil;
	
	@Override
	public CountryDto getCountryId(final String countryId)throws Exception
	{
		LOGGER.debug("CountryServiceImpl--getByCountryId--Start");
		
		commonUtil.stringNullValidator(countryId, "CountryId");
		
		Country country=countryDao.findByIdAndStatusNot(countryId,commonUtil.getSoftDeleteStatus());
		if(country == null)
			throw new ApplicationServiceExecption("Country not found",HttpStatus.NOT_FOUND);
		
		final CountryDto dto=mapEntityToDto.transformBO(country,CountryDto.class);
		LOGGER.debug("CountryServiceImpl--getByCountryId--End");
		return dto;
		
		
	}
	
	@Override
	public CountryDto findByCountryName(String countryName)throws Exception
	{
		LOGGER.debug("CountryServiceImpl--getByName--Start");
		
		commonUtil.stringNullValidator(countryName, "CountryName");
		
		Country country=countryDao.findByCountryNameAndStatusNot(countryName, commonUtil.getSoftDeleteStatus());
		
		if(country==null) 
			throw new ApplicationServiceExecption("CountryName not Found",HttpStatus.NOT_FOUND);
		
		
		CountryDto dto=mapEntityToDto.transformBO(country, CountryDto.class);
		
		LOGGER.debug("CountryServiceImpl--getByName--End");
		
		return dto;
				
		
		
	}
	
	public List<CountryDto> findAll()throws Exception
	{
		LOGGER.debug("CounrtyServiceImpl--findAll--Start");
		List<Country> country=countryDao.findAllCountry();
		
		if(country.size() == 0)
			throw new ApplicationServiceExecption("Country not Found",HttpStatus.NOT_FOUND);
		
		List<CountryDto> dto=mapEntityToDto.transformListOfBO(country,CountryDto.class);
		
		LOGGER.debug("CountryServiceImpl--findAll--End");
		return dto;
		
		
	}
	
	@Override
	public CountryDto add(CountryDto countryDto) throws Exception {
		LOGGER.debug("CountryServiceImpl -- add -- Start");
		// final String errorMessage = validator.validateAdd(userDto);
		// if (errorMessage != null) {
		// throw new GaurageServiceException(errorMessage, HttpStatus.BAD_REQUEST);
		// }
		/*Optional<Country> existingCountry = countryDao.findById(countryDto.getId());
		if (existingCountry.isPresent()) {
			throw new ApplicationServiceExecption("Country exist", HttpStatus.BAD_REQUEST);
		}*/
		commonUtil.stringNullValidator(countryDto.getCountryName(), countryDto.getCountryCode(), "Country Name and Code");
		List<Country> countries = countryDao.uniqueCheckForAdd(countryDto.getCountryName(), countryDto.getCountryCode());
		if(countries.size() != 0)
			throw new ApplicationServiceExecption("Country already exist", HttpStatus.BAD_REQUEST);
		
		Country country = mapDtoToEntity.transformBO(countryDto, Country.class);
		
		String seqName = dbUtil.getNextSequence(country.getClass());
		if(seqName != null) {
			country.setId(seqName);
		}
		country.setInsertTime(new Date());
		country.setUpdateTime(new Date());
		country.setStatus(commonUtil.getActiveStatus());
		country = countryDao.save(country);
		syncDataService.syncCreation(country);
		LOGGER.debug("CountryServiceImpl -- add -- End");
		return mapEntityToDto.transformBO(country, CountryDto.class);
	}
	
	
	
	@Override
	public List<CountryDto> softDeleteCountry(List<String> countryIds) throws Exception {
		LOGGER.debug("CountryServiceImpl -- delete -- Start");
		// final String errorMessage = validator.validateAdd(userDto);
		// if (errorMessage != null) {
		// throw new GaurageServiceException(errorMessage, HttpStatus.BAD_REQUEST);
		// }
		commonUtil.stringNullValidator(countryIds.toArray(), "CountryId");
		List<Country> countryList = countryDao.findByIdInAndStatusNot(countryIds, commonUtil.getSoftDeleteStatus());
		if (countryList.size() < countryIds.size()) 
			throw new ApplicationServiceExecption("Country not found", HttpStatus.BAD_REQUEST);
		
		List<CountryDto> existingCountryDtoList = mapEntityToDto.transformListOfBO(countryList, CountryDto.class);
		for (Country country : countryList) {
			country.setStatus(commonUtil.getSoftDeleteStatus());
			country.setUpdateTime(new Date());
		}
		countryDao.saveAll(countryList);
		Integer count = 0;
		for (Country country : countryList) {
			syncDataService.syncUpdate(mapDtoToEntity.transformBO(existingCountryDtoList.get(count), Country.class), country);
			count++;
		}
		countryList = countryDao.findAllCountry();
		LOGGER.debug("CountryServiceImpl -- delete -- End");
		return mapEntityToDto.transformListOfBO(countryList, CountryDto.class);
	}

	@Override
	public CountryDto updateCountry(CountryDto countryDto) throws Exception {
		LOGGER.debug("CountryServiceImpl -- update -- Start");
		// final String errorMessage = validator.validateAdd(userDto);
		// if (errorMessage != null) {
		// throw new GaurageServiceException(errorMessage, HttpStatus.BAD_REQUEST);
		// }
		
		commonUtil.stringNullValidator(countryDto.getCountryName(), countryDto.getCountryCode(), countryDto.getId(), "Country Id, Name and Code");
		List<Country> countries = countryDao.uniqueCheckForUpdate(countryDto.getCountryName(), countryDto.getCountryCode(), countryDto.getId());
		if(countries.size() != 0)
			throw new ApplicationServiceExecption("Country already exist", HttpStatus.BAD_REQUEST);
		
		Country country = countryDao.findByIdAndStatusNot(countryDto.getId(), commonUtil.getSoftDeleteStatus());
		if (country == null) 
			throw new ApplicationServiceExecption("Country not found", HttpStatus.BAD_REQUEST);
		
		CountryDto existingCountry = mapEntityToDto.transformBO(country, CountryDto.class);
		Country countryEntity = mapDtoToEntity.transformBO(countryDto, Country.class);
		countryEntity.setUpdateTime(new Date());
		countryEntity = countryDao.saveAndFlush(countryEntity);
		syncDataService.syncUpdate(mapDtoToEntity.transformBO(existingCountry, Country.class), country);
		LOGGER.debug("CountryServiceImpl -- update -- End");
		return mapEntityToDto.transformBO(countryEntity, CountryDto.class);
	}

	}
