package in.ind.mds.serviceImpl;

import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import in.ind.mds.dto.JobCategoryDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.repo.dao.JobCategoryDao;
import in.ind.mds.repo.entity.JobCategory;
import in.ind.mds.service.JobCategoryService;
import in.ind.mds.service.SyncDataService;
import in.ind.mds.util.BeanTransformerUtil;
import in.ind.mds.util.CommonUtil;
import in.ind.mds.util.DBUtil;

@Service("TST_MSSQL_JOB_CATEGORY")

public class JobCategoryServiceImpl implements JobCategoryService {
	private static final Logger LOGGER = LoggerFactory.getLogger(JobCategoryServiceImpl.class);

	@Autowired
	private BeanTransformerUtil<JobCategory, JobCategoryDto> mapEntityToDto;

	@Autowired
	private BeanTransformerUtil<JobCategoryDto, JobCategory> mapDtoToEntity;

	@Autowired
	@Qualifier("TST_MSSQL_SYNC")
	private SyncDataService syncDataService;
	/*
	 * @Autowired private UserValidator validator;
	 */
	@Autowired
	private CommonUtil<JobCategoryDto> commonUtil;

	@Autowired
	private JobCategoryDao jobCategoryDao;

	@Autowired
	private DBUtil dbUtil;

	public JobCategoryDto findByJobCtgyIdAndJobCtgyName(final String jobCtgyId, final String jobCtgyName)
			throws Exception {
		LOGGER.debug("JobCategoryServiceImpl -- getByJobCtgyIdAndJobCtgyName -- Start");
		commonUtil.stringNullValidator(jobCtgyId, jobCtgyName, "JobCtgyId and JobCtgyName");

		JobCategory jobCategory = jobCategoryDao.findByIdAndJobCtgyNameAndStatusNot(jobCtgyId, jobCtgyName,
				commonUtil.getSoftDeleteStatus());

		if (jobCategory == null)
			throw new ApplicationServiceExecption("JobCategory not found", HttpStatus.NOT_FOUND);

		final JobCategoryDto dto = mapEntityToDto.transformBO(jobCategory, JobCategoryDto.class);
		LOGGER.debug("JobCategoryServiceImpl -- getByJobCtgyNameAndJobCtgyDescription -- End");
		return dto;
	}

	public JobCategoryDto getByJobCtgyId(final String jobCtgyId) throws Exception {
		LOGGER.debug("JobCategoryServiceImpl -- getByJobCtgyId -- Start");

		commonUtil.stringNullValidator(jobCtgyId, "JobCtgyId");

		final JobCategory jobCategory = jobCategoryDao.findByIdAndStatusNot(jobCtgyId,
				commonUtil.getSoftDeleteStatus());

		if (jobCategory == null)
			throw new ApplicationServiceExecption("Error jobCategory not found", HttpStatus.NOT_FOUND);

		/*
		 * Date date = user.getServerTime(); Date currentDate = new
		 * Date(System.currentTimeMillis());
		 * 
		 * if (date.before(currentDate) || date.after(currentDate)) {
		 * user.setServerTime(currentDate); userDao.save(user); }
		 */
		final JobCategoryDto dto = mapEntityToDto.transformBO(jobCategory, JobCategoryDto.class);

		LOGGER.debug("JobCategoryServiceImpl -- getByJobCtgyId -- End");
		return dto;
	}

	@Override
	public JobCategoryDto findByJobCtgyName(final String jobCtgyName) throws Exception {
		LOGGER.debug("JobCategoryServiceImpl -- getByJobCtgyName -- Start");

		commonUtil.stringNullValidator(jobCtgyName, "JobCtgyName");

		final JobCategory jobCategory = jobCategoryDao.findByJobCtgyNameAndStatusNot(jobCtgyName,
				commonUtil.getSoftDeleteStatus());

		if (jobCategory == null)
			throw new ApplicationServiceExecption("Error jobCategory not found", HttpStatus.NOT_FOUND);

		/*
		 * Date date = user.getServerTime(); Date currentDate = new
		 * Date(System.currentTimeMillis());
		 * 
		 * if (date.before(currentDate) || date.after(currentDate)) {
		 * user.setServerTime(currentDate); userDao.save(user); }
		 */
		final JobCategoryDto dto = mapEntityToDto.transformBO(jobCategory, JobCategoryDto.class);

		LOGGER.debug("JobCategoryServiceImpl -- getByJobCtgyName -- End");
		return dto;
	}

	@Override
	public List<JobCategoryDto> findAll() throws Exception {
		LOGGER.debug("JobCategoryServiceImpl -- findByJobCategoryType -- Start");
		List<JobCategory> jobCategory = jobCategoryDao.findAllJobCategory();

		if (jobCategory.size() == 0)
			throw new ApplicationServiceExecption("JobCategory not found", HttpStatus.NOT_FOUND);

		final List<JobCategoryDto> dto = mapEntityToDto.transformListOfBO(jobCategory, JobCategoryDto.class);
		LOGGER.debug("JobCategoryServiceImpl -- findByJobCategoryType -- End");
		return dto;
	}

	@Override
	public JobCategoryDto add(JobCategoryDto jobCategoryDto) throws Exception {
		LOGGER.debug("JobCategoryServiceImpl -- add -- Start");
		// final String errorMessage = validator.validateAdd(userDto);
		// if (errorMessage != null) {
		// throw new GaurageServiceException(errorMessage, HttpStatus.BAD_REQUEST);
		// }
		/*
		 * Optional<JobCategory> existingJobCategory =
		 * jobCategoryDao.findById(jobCategoryDto.getId()); if
		 * (existingJobCategory.isPresent()) { throw new
		 * ApplicationServiceExecption("JobCategory exist", HttpStatus.BAD_REQUEST); }
		 */
		commonUtil.stringNullValidator(jobCategoryDto.getJobCtgyName(), "JobCtgyName");
		JobCategory jobCategory = jobCategoryDao.findByJobCtgyNameAndStatusNot(jobCategoryDto.getJobCtgyName(),
				commonUtil.getSoftDeleteStatus());
		if (jobCategory != null)
			throw new ApplicationServiceExecption("JobCategory already exist", HttpStatus.BAD_REQUEST);

		jobCategory = mapDtoToEntity.transformBO(jobCategoryDto, JobCategory.class);
		String seqName = dbUtil.getNextSequence(jobCategory.getClass());
		if (seqName != null) {
			jobCategory.setId(seqName);
		}
		jobCategory.setInsertTime(new Date());
		jobCategory.setUpdateTime(new Date());
		jobCategory.setStatus(commonUtil.getActiveStatus());
		jobCategory = jobCategoryDao.save(jobCategory);
		syncDataService.syncCreation(jobCategory);
		LOGGER.debug("JobCategoryServiceImpl -- add -- End");
		return mapEntityToDto.transformBO(jobCategory, JobCategoryDto.class);
	}

	@Override
	public List<JobCategoryDto> softDeleteJobCategory(List<String> ctgyIds) throws Exception {
		LOGGER.debug("JobCategoryServiceImpl -- softdelete -- Start");
		// final String errorMessage = validator.validateAdd(userDto);
		// if (errorMessage != null) {
		// throw new GaurageServiceException(errorMessage, HttpStatus.BAD_REQUEST);
		// }
		commonUtil.stringNullValidator(ctgyIds.toArray(), "CtgyId");
		List<JobCategory> existingJobCategoryList = jobCategoryDao.findByIdInAndStatusNot(ctgyIds,
				commonUtil.getSoftDeleteStatus());
		if (existingJobCategoryList.size() < ctgyIds.size())
			throw new ApplicationServiceExecption("JobCategory not found", HttpStatus.BAD_REQUEST);

		List<JobCategoryDto> existingJobCategoryDtoList = mapEntityToDto.transformListOfBO(existingJobCategoryList,
				JobCategoryDto.class);
		for (JobCategory jobCategory : existingJobCategoryList) {
			jobCategory.setStatus(commonUtil.getSoftDeleteStatus());
			jobCategory.setUpdateTime(new Date());
		}
		jobCategoryDao.saveAll(existingJobCategoryList);
		Integer count = 0;
		for (JobCategory jobCategory : existingJobCategoryList) {
			syncDataService.syncUpdate(mapDtoToEntity.transformBO(existingJobCategoryDtoList.get(count), JobCategory.class), jobCategory);
			count++;
		}
		existingJobCategoryList = jobCategoryDao.findAllJobCategory();
		LOGGER.debug("JobCategoryServiceImpl -- softdelete -- End");
		return mapEntityToDto.transformListOfBO(existingJobCategoryList, JobCategoryDto.class);
	}

	@Override
	public JobCategoryDto updateJobCategory(JobCategoryDto jobCategoryDto) throws Exception {
		LOGGER.debug("JobCategoryServiceImpl -- update -- Start");
		// final String errorMessage = validator.validateAdd(userDto);
		// if (errorMessage != null) {
		// throw new GaurageServiceException(errorMessage, HttpStatus.BAD_REQUEST);
		// }
		commonUtil.stringNullValidator(jobCategoryDto.getId(), jobCategoryDto.getJobCtgyName(),
				"JobCategory Id and Name");
		JobCategory existingJobCategory = jobCategoryDao.findByJobCtgyNameAndStatusNotAndIdNot(
				jobCategoryDto.getJobCtgyName(), commonUtil.getSoftDeleteStatus(), jobCategoryDto.getId());
		if (existingJobCategory != null)
			throw new ApplicationServiceExecption("JobCategory already exist", HttpStatus.BAD_REQUEST);

		existingJobCategory = jobCategoryDao.findByIdAndStatusNot(jobCategoryDto.getId(),
				commonUtil.getSoftDeleteStatus());
		if (existingJobCategory == null)
			throw new ApplicationServiceExecption("JobCategory not found", HttpStatus.BAD_REQUEST);

		JobCategoryDto existingJobCategoryDto = mapEntityToDto.transformBO(existingJobCategory, JobCategoryDto.class);
		JobCategory jobCategory = mapDtoToEntity.transformBO(jobCategoryDto, JobCategory.class);
		jobCategory.setUpdateTime(new Date());
		jobCategory = jobCategoryDao.saveAndFlush(jobCategory);
		syncDataService.syncUpdate(mapDtoToEntity.transformBO(existingJobCategoryDto, JobCategory.class), jobCategory);
		LOGGER.debug("JobCategoryServiceImpl -- update -- End");
		return mapEntityToDto.transformBO(jobCategory, JobCategoryDto.class);
	}

}
