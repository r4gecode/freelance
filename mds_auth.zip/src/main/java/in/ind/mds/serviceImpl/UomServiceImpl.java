package in.ind.mds.serviceImpl;

import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import in.ind.mds.dto.UomDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.repo.dao.UomDao;
import in.ind.mds.repo.entity.Uom;
import in.ind.mds.service.SyncDataService;
import in.ind.mds.service.UomService;
import in.ind.mds.util.BeanTransformerUtil;
import in.ind.mds.util.CommonUtil;
import in.ind.mds.util.DBUtil;

@Service("TST_MSSQL_UOM")
public class UomServiceImpl implements UomService 
{
	private static final Logger LOGGER = LoggerFactory.getLogger(UomServiceImpl.class);

	@Autowired
	private BeanTransformerUtil<Uom, UomDto> mapEntityToDto;

	@Autowired
	private BeanTransformerUtil<UomDto, Uom> mapDtoToEntity;
	
	@Autowired
	private UomDao uomDao;
	
	@Autowired
	private DBUtil dbUtil;

	@Autowired
	@Qualifier("TST_MSSQL_SYNC")
	private SyncDataService syncDataService;
	
	@Autowired
	private CommonUtil<UomDto> commonUtill;
	
	@Override
	public UomDto getUomId(String uomId) throws Exception 
	{
		LOGGER.debug("UomServiceImpl--getUomId--Start");
		commonUtill.stringNullValidator(uomId, "UomId");
		Uom uom = uomDao.findByIdAndStatusNot(uomId, commonUtill.getSoftDeleteStatus());
		if(uom == null)
			throw new ApplicationServiceExecption("Unit Of Measure not exits",HttpStatus.NOT_FOUND);

		UomDto dto=mapEntityToDto.transformBO(uom, UomDto.class);

		LOGGER.debug("UomServiceImpl--getUomId--End");
		return dto;
	}

	@Override
	public UomDto findByMeasureName(String measureName) throws Exception 
	{
		LOGGER.debug("UomServiceImpl--getMeasureName--Start");
		commonUtill.stringNullValidator(measureName, "MeasureName");
		Uom uom = uomDao.findByMeasureNameAndStatusNot(measureName, commonUtill.getSoftDeleteStatus());
		
		if(uom == null)
			throw new ApplicationServiceExecption("UOM not exits",HttpStatus.NOT_FOUND);
		
		UomDto dto=mapEntityToDto.transformBO(uom, UomDto.class);
		
		LOGGER.debug("UomServiceImpl--getMeasureName--End");
			return dto;
	}

	@Override
	public List<UomDto> findAll() throws Exception {
		LOGGER.debug("UomServiceImpl--findAll--Start");
		List<Uom> uom = uomDao.findAllUom();
		if(uom.size() == 0)
			throw new ApplicationServiceExecption("Uom not exits",HttpStatus.NOT_FOUND);
		
		List<UomDto> dto=mapEntityToDto.transformListOfBO(uom, UomDto.class);
		
		LOGGER.debug("UomServiceImpl--findAll--End");
		return dto;
	}

	@Override
	public UomDto add(UomDto uomDto) throws Exception {
		
		LOGGER.debug("UomServiceImpl -- add -- Start");
		// final String errorMessage = validator.validateAdd(userDto);
		// if (errorMessage != null) {
		// throw new GaurageServiceException(errorMessage, HttpStatus.BAD_REQUEST);
		// }
		/*Optional<Uom> existingUom = uomDao.findById(uomDto.getId());
		if (existingUom.isPresent()) {
			throw new ApplicationServiceExecption("Uom exist", HttpStatus.BAD_REQUEST);
		}*/
		commonUtill.stringNullValidator(uomDto.getMeasureName(), "MeasureName");
		Uom uom = uomDao.findByMeasureNameAndStatusNot(uomDto.getMeasureName(), commonUtill.getSoftDeleteStatus());
		if(uom != null)
			throw new ApplicationServiceExecption("Uom already exist", HttpStatus.BAD_REQUEST);
		
		uom = mapDtoToEntity.transformBO(uomDto, Uom.class);
		
		String seqName = dbUtil.getNextSequence(uom.getClass());
		if(seqName != null) {
			uom.setId(seqName);
		}
		uom.setInsertTime(new Date());
		uom.setUpdateTime(new Date());
		uom.setStatus(commonUtill.getActiveStatus());
		uom=uomDao.save(uom);
		syncDataService.syncCreation(uom);
		LOGGER.debug("CountryServiceImpl -- add -- End");
	
		return mapEntityToDto.transformBO(uom, UomDto.class);
	}

	@Override
	public void softDeleteUom(String uomId) throws Exception {
		LOGGER.debug("UomServiceImpl -- delete -- Start");
		// final String errorMessage = validator.validateAdd(userDto);
		// if (errorMessage != null) {
		// throw new GaurageServiceException(errorMessage, HttpStatus.BAD_REQUEST);
		// }
		commonUtill.stringNullValidator(uomId, "UomId");
		Uom existingUom = uomDao.findByIdAndStatusNot(uomId, commonUtill.getSoftDeleteStatus());
		if (existingUom == null) 
			throw new ApplicationServiceExecption("Uom not found", HttpStatus.BAD_REQUEST);
		
		UomDto existingUomDto = mapEntityToDto.transformBO(existingUom, UomDto.class);
		existingUom.setStatus(commonUtill.getSoftDeleteStatus());
		uomDao.saveAndFlush(existingUom);
		syncDataService.syncUpdate(mapDtoToEntity.transformBO(existingUomDto, Uom.class), existingUom);
		LOGGER.debug("UomServiceImpl -- delete -- End");

		
	}

	@Override
	public UomDto updateUom(UomDto uomDto) throws Exception {
		LOGGER.debug("UomServiceImpl -- update -- Start");
		// final String errorMessage = validator.validateAdd(userDto);
		// if (errorMessage != null) {
		// throw new GaurageServiceException(errorMessage, HttpStatus.BAD_REQUEST);
		// }
		commonUtill.stringNullValidator(uomDto.getId(), uomDto.getMeasureName(), "Uom Id and MeasureName");
		Uom uom = uomDao.findByMeasureNameAndStatusNotAndIdNot(uomDto.getMeasureName(), commonUtill.getSoftDeleteStatus(), uomDto.getId());
		if(uom != null)
			throw new ApplicationServiceExecption("Uom already exist", HttpStatus.BAD_REQUEST);
		
		uom = uomDao.findByIdAndStatusNot(uomDto.getId(), commonUtill.getSoftDeleteStatus());
		if (uom == null) 
			throw new ApplicationServiceExecption("Uom not found", HttpStatus.BAD_REQUEST);
		
		UomDto existingUom = mapEntityToDto.transformBO(uom, UomDto.class);
		Uom uomEntity = mapDtoToEntity.transformBO(uomDto, Uom.class);
		uomEntity.setUpdateTime(new Date());
		uomDao.saveAndFlush(uomEntity);
		syncDataService.syncUpdate(mapDtoToEntity.transformBO(existingUom, Uom.class), uomEntity);
		LOGGER.debug("UomServiceImpl -- update -- End");
		return mapEntityToDto.transformBO(uomEntity, UomDto.class);
	}

	@Override
	public List<UomDto> multipleSoftDelete(List<String> uomIds) throws Exception {
		LOGGER.debug("UomServiceImpl -- multipleDelete -- Start");
		commonUtill.stringNullValidator(uomIds.toArray(), "UomId");
		List<Uom> existingUomsList = uomDao.findByIdInAndStatusNot(uomIds, commonUtill.getSoftDeleteStatus());
		if (existingUomsList.size() < uomIds.size()) 
			throw new ApplicationServiceExecption("Uom not found", HttpStatus.BAD_REQUEST);
		
		List<UomDto> existingUomDtoList = mapEntityToDto.transformListOfBO(existingUomsList, UomDto.class);

		for (Uom port : existingUomsList) {
			port.setStatus(commonUtill.getSoftDeleteStatus());
			port.setUpdateTime(new Date());
		}
		existingUomsList=uomDao.saveAll(existingUomsList);
		Integer count = 0;
		for (Uom uom : existingUomsList) {
			syncDataService.syncUpdate(mapDtoToEntity.transformBO(existingUomDtoList.get(count), Uom.class), uom);
			count++;
		}
		List<Uom> uomList = uomDao.findAllUom();
		LOGGER.debug("UomServiceImpl -- multipleDelete -- End");
		return mapEntityToDto.transformListOfBO(uomList, UomDto.class);
	}

	}
	
	


