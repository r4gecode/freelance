package in.ind.mds.serviceImpl;

import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import in.ind.mds.dto.InventoryDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.repo.dao.InventoryDao;
import in.ind.mds.repo.entity.Inventory;
import in.ind.mds.service.InventoryService;
import in.ind.mds.service.SyncDataService;
import in.ind.mds.util.BeanTransformerUtil;
import in.ind.mds.util.CommonUtil;
import in.ind.mds.util.DBUtil;

@Service("TST_MSSQL_INVENTORY")

public class InventoryServiceImpl implements InventoryService {
	private static final Logger LOGGER = LoggerFactory.getLogger(InventoryServiceImpl.class);

	@Autowired
	private BeanTransformerUtil<Inventory, InventoryDto> mapEntityToDto;

	@Autowired
	private BeanTransformerUtil<InventoryDto, Inventory> mapDtoToEntity;

	@Autowired
	@Qualifier("TST_MSSQL_SYNC")
	private SyncDataService syncDataService;
	/*
	 * @Autowired private UserValidator validator;
	 */
	 @Autowired
	 private CommonUtil<InventoryDto> commonUtil;

	@Autowired
	private InventoryDao inventoryDao;

	@Autowired
	private DBUtil dbUtil;

	public InventoryDto findByInventoryCodeAndInventoryName(final String inventoryCode, final String inventoryName)
			throws Exception {
		LOGGER.debug("InventoryServiceImpl -- getByInventoryCodeAndInventoryName -- Start");
		commonUtil.stringNullValidator(inventoryCode, inventoryName, "InventoryCode and InventoryName");

		Inventory inventory = inventoryDao.findByInventoryCodeAndInventoryNameAndStatusNot(inventoryCode, inventoryName, commonUtil.getSoftDeleteStatus());

		if (inventory == null) 
			throw new ApplicationServiceExecption("Inventory not found", HttpStatus.NOT_FOUND);
		
		final InventoryDto dto = mapEntityToDto.transformBO(inventory, InventoryDto.class);
		LOGGER.debug("InventoryServiceImpl -- getByInventoryCodeAndInventoryName -- End");
		return dto;
	}

	public InventoryDto getByInventoryId(final String inventoryId) throws Exception {
		LOGGER.debug("InventoryServiceImpl -- getByInventoryId -- Start");

		commonUtil.stringNullValidator(inventoryId, "InventoryId");

		final Inventory inventory = inventoryDao.findByIdAndStatusNot(inventoryId, commonUtil.getSoftDeleteStatus());

		if (inventory == null) 
			throw new ApplicationServiceExecption("Error Inventory not found", HttpStatus.NOT_FOUND);
		
		/*
		 * Date date = user.getServerTime(); Date currentDate = new
		 * Date(System.currentTimeMillis());
		 * 
		 * if (date.before(currentDate) || date.after(currentDate)) {
		 * user.setServerTime(currentDate); userDao.save(user); }
		 */
		final InventoryDto dto = mapEntityToDto.transformBO(inventory, InventoryDto.class);

		LOGGER.debug("InventoryServiceImpl -- getByInventoryId -- End");
		return dto;
	}

	@Override
	public InventoryDto findByInventoryName(final String inventoryName) throws Exception {
		LOGGER.debug("InventoryServiceImpl -- getByInventoryName -- Start");

		commonUtil.stringNullValidator(inventoryName, "InventoryName");

		final Inventory inventory = inventoryDao.findByInventoryNameAndStatusNot(inventoryName, commonUtil.getSoftDeleteStatus());

		if (inventory == null) 
			throw new ApplicationServiceExecption("Error inventory not found", HttpStatus.NOT_FOUND);
		
		/*
		 * Date date = user.getServerTime(); Date currentDate = new
		 * Date(System.currentTimeMillis());
		 * 
		 * if (date.before(currentDate) || date.after(currentDate)) {
		 * user.setServerTime(currentDate); userDao.save(user); }
		 */
		final InventoryDto dto = mapEntityToDto.transformBO(inventory, InventoryDto.class);

		LOGGER.debug("InventoryServiceImpl -- getByInventoryName -- End");
		return dto;
	}

	public List<InventoryDto> findAll() throws Exception {
		LOGGER.debug("InventoryServiceImpl -- findByInventoryType -- Start");
		List<Inventory> inventory = inventoryDao.findAllInventory();

		if (inventory.size() == 0) 
			throw new ApplicationServiceExecption("Inventory not found", HttpStatus.NOT_FOUND);
		
		final List<InventoryDto> dto = mapEntityToDto.transformListOfBO(inventory, InventoryDto.class);
		LOGGER.debug("InventoryServiceImpl -- findByInventoryType -- End");
		return dto;
	}

	@Override
	public InventoryDto add(InventoryDto inventoryDto) throws Exception {
		LOGGER.debug("InventoryServiceImpl -- add -- Start");
		// final String errorMessage = validator.validateAdd(userDto);
		// if (errorMessage != null) {
		// throw new GaurageServiceException(errorMessage, HttpStatus.BAD_REQUEST);
		// }
		/*
		 * Optional<Inventory> existingInventory =
		 * inventoryDao.findById(inventoryDto.getId()); if
		 * (existingInventory.isPresent()) { throw new
		 * ApplicationServiceExecption("Inventory exist", HttpStatus.BAD_REQUEST); }
		 */
		final Inventory inventory = mapDtoToEntity.transformBO(inventoryDto, Inventory.class);
		String seqName = dbUtil.getNextSequence(inventory.getClass());
		if (seqName != null) {
			inventory.setId(seqName);
		}
		inventory.setInsertTime(new Date());
		inventory.setUpdateTime(new Date());
		inventory.setStatus(commonUtil.getActiveStatus());
		inventoryDao.save(inventory);
		syncDataService.syncCreation(inventory);
		LOGGER.debug("InventoryServiceImpl -- add -- End");
		return inventoryDto;
	}

	@Override
	public void softDeleteInventory(String inventoryId) throws Exception {
		LOGGER.debug("InventoryServiceImpl -- delete -- Start");
		// final String errorMessage = validator.validateAdd(userDto);
		// if (errorMessage != null) {
		// throw new GaurageServiceException(errorMessage, HttpStatus.BAD_REQUEST);
		// }
		commonUtil.stringNullValidator(inventoryId, "InventoryId");
		Inventory existingInventory = inventoryDao.findByIdAndStatusNot(inventoryId, commonUtil.getSoftDeleteStatus());
		if (existingInventory == null) 
			throw new ApplicationServiceExecption("Inventory not found", HttpStatus.BAD_REQUEST);
		
		InventoryDto existingInventoryDto = mapEntityToDto.transformBO(existingInventory, InventoryDto.class);
		existingInventory.setStatus(commonUtil.getSoftDeleteStatus());
		inventoryDao.saveAndFlush(existingInventory);
		syncDataService.syncUpdate(mapDtoToEntity.transformBO(existingInventoryDto, Inventory.class), existingInventory);
		LOGGER.debug("InventoryServiceImpl -- delete -- End");
	}

	@Override
	public InventoryDto updateInventory(InventoryDto inventoryDto) throws Exception {
		LOGGER.debug("InventoryServiceImpl -- update -- Start");
		// final String errorMessage = validator.validateAdd(userDto);
		// if (errorMessage != null) {
		// throw new GaurageServiceException(errorMessage, HttpStatus.BAD_REQUEST);
		// }
		commonUtil.stringNullValidator(inventoryDto.getId(), "InventoryId");
		Inventory existingInventory = inventoryDao.findByIdAndStatusNot(inventoryDto.getId(), commonUtil.getSoftDeleteStatus());
		if (existingInventory == null) 
			throw new ApplicationServiceExecption("Inventory not found", HttpStatus.BAD_REQUEST);
		
		InventoryDto existingInventoryDto = mapEntityToDto.transformBO(existingInventory, InventoryDto.class);
		 Inventory inventory = mapDtoToEntity.transformBO(inventoryDto, Inventory.class);
		inventoryDao.saveAndFlush(inventory);
		syncDataService.syncUpdate(mapDtoToEntity.transformBO(existingInventoryDto, Inventory.class), inventory);
		LOGGER.debug("InventoryServiceImpl -- update -- End");
		return inventoryDto;
	}
}
