/**
 * 
 */
package in.ind.mds.serviceImpl;

import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import in.ind.mds.dto.ActivityTypeDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.repo.dao.ActivityTypeDao;
import in.ind.mds.repo.entity.ActivityType;
import in.ind.mds.service.ActivityTypeService;
import in.ind.mds.service.SyncDataService;
import in.ind.mds.util.BeanTransformerUtil;
import in.ind.mds.util.CommonUtil;
import in.ind.mds.util.DBUtil;

/**
 * @author mds-arockia
 *
 */
@Service("TST_MSSQL_ACTIVITY_TYPE")
public class ActivityTypeServiceImpl implements ActivityTypeService{

	private static final Logger LOGGER = LoggerFactory.getLogger(ActivityTypeServiceImpl.class);

	@Autowired
	private BeanTransformerUtil<ActivityType, ActivityTypeDto> mapEntityToDto;

	@Autowired
	private BeanTransformerUtil<ActivityTypeDto, ActivityType> mapDtoToEntity;

	@Autowired
	@Qualifier("TST_MSSQL_SYNC")
	private SyncDataService syncDataService;
	
	@Autowired
	private ActivityTypeDao activityTypeDao;
	
	@Autowired
	private DBUtil dbUtil;
	
	@Autowired
	private CommonUtil<ActivityTypeDto> commonUtil;
	
	@Override
	public ActivityTypeDto add(ActivityTypeDto activityTypeDto) throws Exception {
		LOGGER.debug("ActivityTypeServiceImpl -- add -- start");
		commonUtil.stringNullValidator(activityTypeDto.getActivityName(), "ActivityType Name");
		ActivityType activityType = activityTypeDao.findByActivityNameAndStatusNot(activityTypeDto.getActivityName(), commonUtil.getSoftDeleteStatus());
		if(activityType != null)
			throw new ApplicationServiceExecption("Activity Name already exist", HttpStatus.BAD_REQUEST);
		
		activityType = mapDtoToEntity.transformBO(activityTypeDto, ActivityType.class);
		String seqName = dbUtil.getNextSequence(activityType.getClass());
		if(seqName != null)
			activityType.setId(seqName);
		
		activityType.setInsertedBy(0);
		activityType.setInsertTime(new Date());
		activityType.setUpdatedBy(0);
		activityType.setUpdateTime(new Date());
		activityType.setStatus(commonUtil.getActiveStatus());
		activityType = activityTypeDao.save(activityType);
		syncDataService.syncCreation(activityType);
		LOGGER.debug("ActivityTypeServiceImpl -- add -- end");
		return mapEntityToDto.transformBO(activityType, ActivityTypeDto.class);
	}

	@Override
	public ActivityTypeDto update(ActivityTypeDto activityTypeDto) throws Exception {
		LOGGER.debug("ActivityTypeServiceImpl -- update -- start");
		commonUtil.stringNullValidator(activityTypeDto.getActivityName(), activityTypeDto.getId(), "ActivityType Name And Id");
		ActivityType activityType = activityTypeDao.findByActivityNameAndStatusNotAndIdNot(activityTypeDto.getActivityName(), commonUtil.getSoftDeleteStatus(), activityTypeDto.getId());
		if(activityType != null)
			throw new ApplicationServiceExecption("Activity Name already exist", HttpStatus.BAD_REQUEST);
		
		activityType = activityTypeDao.findByIdAndStatusNot(activityTypeDto.getId(), commonUtil.getSoftDeleteStatus());
		if(activityType == null)
			throw new ApplicationServiceExecption("Activity Type not found", HttpStatus.BAD_REQUEST);
		
		ActivityTypeDto existingActivityDto = mapEntityToDto.transformBO(activityType, ActivityTypeDto.class);
		activityType = mapDtoToEntity.transformBO(activityTypeDto, ActivityType.class);
		activityType.setUpdatedBy(0);
		activityType.setUpdateTime(new Date());
		activityType = activityTypeDao.save(activityType);
		syncDataService.syncUpdate(mapDtoToEntity.transformBO(existingActivityDto, ActivityType.class), activityType);
		LOGGER.debug("ActivityTypeServiceImpl -- update -- end");
		return mapEntityToDto.transformBO(activityType, ActivityTypeDto.class);
	}

	@Override
	public List<ActivityTypeDto> softDelete(List<String> ids) throws Exception {
		LOGGER.debug("ActivityTypeServiceImpl -- softDelete -- start");
		commonUtil.stringNullValidator(ids.toArray(), "ActivityType Id");
		List<ActivityType> activityTypeList = activityTypeDao.findByIdInAndStatusNot(ids, commonUtil.getSoftDeleteStatus());
		if(activityTypeList.size() < ids.size())
			throw new ApplicationServiceExecption("Activity Type not found");
		
		List<ActivityTypeDto> activityTypeDtoList = mapEntityToDto.transformListOfBO(activityTypeList, ActivityTypeDto.class);
		for (ActivityType activityType : activityTypeList) {
			activityType.setStatus(commonUtil.getSoftDeleteStatus());
			activityType.setUpdateTime(new Date());
		}
		activityTypeList = activityTypeDao.saveAll(activityTypeList);
		Integer count = 0;
		for (ActivityType activityType : activityTypeList) {
			syncDataService.syncUpdate(mapDtoToEntity.transformBO(activityTypeDtoList.get(count), ActivityType.class), activityType);
			count++;
		}
		activityTypeList = activityTypeDao.findAllActivityType();
		LOGGER.debug("ActivityTypeServiceImpl -- softDelete -- end");
		return mapEntityToDto.transformListOfBO(activityTypeList, ActivityTypeDto.class);
	}

	@Override
	public List<ActivityTypeDto> findAllActivityType() throws Exception {
		LOGGER.debug("ActivityTypeServiceImpl -- findAllActivityType -- start");
		List<ActivityType> activityTypeList = activityTypeDao.findAllActivityType();
		if(activityTypeList.size() == 0)
			throw new ApplicationServiceExecption("Activity Type not found");
		
		LOGGER.debug("ActivityTypeServiceImpl -- findAllActivityType -- end");
		return mapEntityToDto.transformListOfBO(activityTypeList, ActivityTypeDto.class);
	}

}
