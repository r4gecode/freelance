package in.ind.mds.serviceImpl;

import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import in.ind.mds.dto.ComponentMainDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.repo.dao.ComponentMainDao;
import in.ind.mds.repo.entity.ComponentMain;
import in.ind.mds.service.ComponentMainService;
import in.ind.mds.service.SyncDataService;
import in.ind.mds.util.BeanTransformerUtil;
import in.ind.mds.util.CommonUtil;
import in.ind.mds.util.DBUtil;

@Service("TST_MSSQL_COMPONENT_MAIN")

public class ComponentMainServiceImpl implements ComponentMainService {
	private static final Logger LOGGER = LoggerFactory.getLogger(ComponentMainServiceImpl.class);

	@Autowired
	private BeanTransformerUtil<ComponentMain, ComponentMainDto> mapEntityToDto;

	@Autowired
	private BeanTransformerUtil<ComponentMainDto, ComponentMain> mapDtoToEntity;

	@Autowired
	@Qualifier("TST_MSSQL_SYNC")
	private SyncDataService syncDataService;
	/*
	 * @Autowired private UserValidator validator;
	 */
	@Autowired
	private CommonUtil<ComponentMainDto> commonUtil;

	@Autowired
	private ComponentMainDao componentMainDao;

	@Autowired
	private DBUtil dbUtil;

	public ComponentMainDto findByGroupNameAndGroupCode(final String groupName, final String groupCode)
			throws Exception {
		LOGGER.debug("ComponentMainImpl -- getByGroupNameAndGroupCode -- Start");
		commonUtil.stringNullValidator(groupName, groupCode, "GroupName and GroupCode");

		ComponentMain componentMain = componentMainDao.findByGroupNameAndGroupCodeAndStatusNot(groupName, groupCode,
				commonUtil.getSoftDeleteStatus());

		if (componentMain == null) {
			throw new ApplicationServiceExecption("ComponentMain not found", HttpStatus.NOT_FOUND);
		}
		final ComponentMainDto dto = mapEntityToDto.transformBO(componentMain, ComponentMainDto.class);
		LOGGER.debug("ComponentMainServiceImpl -- getByGroupNameAndGroupCode -- End");
		return dto;
	}

	public ComponentMainDto getByGroupId(final String groupId) throws Exception {
		LOGGER.debug("ComponentMainServiceImpl -- getByGroupId -- Start");

		commonUtil.stringNullValidator(groupId, "GroupId");

		ComponentMain componentMain = componentMainDao.findByIdAndStatusNot(groupId, commonUtil.getSoftDeleteStatus());

		if (componentMain == null)
			throw new ApplicationServiceExecption("Error componentMain not found", HttpStatus.NOT_FOUND);

		/*
		 * Date date = user.getServerTime(); Date currentDate = new
		 * Date(System.currentTimeMillis());
		 * 
		 * if (date.before(currentDate) || date.after(currentDate)) {
		 * user.setServerTime(currentDate); userDao.save(user); }
		 */
		final ComponentMainDto dto = mapEntityToDto.transformBO(componentMain, ComponentMainDto.class);

		LOGGER.debug("ComponentMainImpl -- getByGroupId -- End");
		return dto;
	}

	@Override
	public ComponentMainDto findByGroupCode(final String groupCode) throws Exception {
		LOGGER.debug("ComponentMainImpl -- getByGroupCode -- Start");

		commonUtil.stringNullValidator(groupCode, "GroupCode");

		final ComponentMain componentMain = componentMainDao.findByGroupCodeAndStatusNot(groupCode,
				commonUtil.getSoftDeleteStatus());

		if (componentMain == null) {
			throw new ApplicationServiceExecption("Error ComponentMain not found", HttpStatus.NOT_FOUND);
		}
		/*
		 * Date date = user.getServerTime(); Date currentDate = new
		 * Date(System.currentTimeMillis());
		 * 
		 * if (date.before(currentDate) || date.after(currentDate)) {
		 * user.setServerTime(currentDate); userDao.save(user); }
		 */
		final ComponentMainDto dto = mapEntityToDto.transformBO(componentMain, ComponentMainDto.class);

		LOGGER.debug("ComponentMainImpl -- getByGroupCode -- End");
		return dto;
	}

	public List<ComponentMainDto> findAll() throws Exception {
		LOGGER.debug("ComponentMainServiceImpl -- findByComponentMainType -- Start");
		List<ComponentMain> componentMain = componentMainDao.findAllComponentMain();

		if (componentMain.size() == 0)
			throw new ApplicationServiceExecption("ComponentMain not found", HttpStatus.NOT_FOUND);

		final List<ComponentMainDto> dto = mapEntityToDto.transformListOfBO(componentMain, ComponentMainDto.class);
		LOGGER.debug("ComponentMainServiceImpl -- findByComponentMainType -- End");
		return dto;
	}

	@Override
	public ComponentMainDto add(ComponentMainDto componentMainDto) throws Exception {
		LOGGER.debug("ComponentMainServiceImpl -- add -- Start");
		// final String errorMessage = validator.validateAdd(userDto);
		// if (errorMessage != null) {
		// throw new GaurageServiceException(errorMessage, HttpStatus.BAD_REQUEST);
		// }

		/*
		 * Optional<ComponentMain> existingComponentMain =
		 * componentMainDao.findById(componentMainDto.getId()); if
		 * (existingComponentMain.isPresent()) { throw new
		 * ApplicationServiceExecption("ComponentMain exist", HttpStatus.BAD_REQUEST); }
		 */
		commonUtil.stringNullValidator(componentMainDto.getGroupName(), componentMainDto.getGroupCode(),
				"Group Name and Code");
		List<ComponentMain> componentMainList = componentMainDao.uniqueCheckForAdd(componentMainDto.getGroupName(),
				componentMainDto.getGroupCode());
		if (componentMainList.size() != 0)
			throw new ApplicationServiceExecption("Component aleady exist", HttpStatus.BAD_REQUEST);

		ComponentMain componentMain = mapDtoToEntity.transformBO(componentMainDto, ComponentMain.class);

		String seqName = dbUtil.getNextSequence(componentMain.getClass());
		if (seqName != null)
			componentMain.setId(seqName);

		componentMain.setInsertTime(new Date());
		componentMain.setUpdateTime(new Date());
		componentMain.setStatus(commonUtil.getActiveStatus());
		componentMain = componentMainDao.save(componentMain);
		syncDataService.syncCreation(componentMain);
		LOGGER.debug("ComponentMainServiceImpl -- add -- End");
		return mapEntityToDto.transformBO(componentMain, ComponentMainDto.class);
	}

	public List<ComponentMainDto> softDeleteComponentMain(List<String> groupIds) throws Exception {
		LOGGER.debug("ComponentMainImpl -- delete -- Start");
		// final String errorMessage = validator.validateAdd(userDto);
		// if (errorMessage != null) {
		// throw new GaurageServiceException(errorMessage, HttpStatus.BAD_REQUEST);
		// }
		commonUtil.stringNullValidator(groupIds.toArray(), "GroupId");
		List<ComponentMain> existingComponentMainList = componentMainDao.findByIdInAndStatusNot(groupIds,
				commonUtil.getSoftDeleteStatus());
		if (existingComponentMainList.size() < groupIds.size())
			throw new ApplicationServiceExecption("ComponentMain not found", HttpStatus.BAD_REQUEST);

		List<ComponentMainDto> existingComponentMainDtoList = mapEntityToDto
				.transformListOfBO(existingComponentMainList, ComponentMainDto.class);
		for (ComponentMain componentMain : existingComponentMainList) {
			componentMain.setStatus(commonUtil.getSoftDeleteStatus());
			componentMain.setUpdateTime(new Date());
		}
		componentMainDao.saveAll(existingComponentMainList);
		Integer count = 0;
		for (ComponentMain componentMain : existingComponentMainList) {
			syncDataService.syncUpdate(mapDtoToEntity.transformBO(existingComponentMainDtoList.get(count), ComponentMain.class),componentMain);
			count++;
		}
		existingComponentMainList = componentMainDao.findAllComponentMain();
		LOGGER.debug("ComponentMainServiceImpl -- delete -- End");
		return mapEntityToDto.transformListOfBO(existingComponentMainList, ComponentMainDto.class);
	}

	@Override
	public ComponentMainDto updateComponentMain(ComponentMainDto componentMainDto) throws Exception {
		LOGGER.debug("ComponentMainServiceImpl -- update -- Start");
		// final String errorMessage = validator.validateAdd(userDto);
		// if (errorMessage != null) {
		// throw new GaurageServiceException(errorMessage, HttpStatus.BAD_REQUEST);
		// }
		commonUtil.stringNullValidator(componentMainDto.getGroupName(), componentMainDto.getGroupCode(),
				componentMainDto.getId(), "Group Id, Name and Code");
		List<ComponentMain> componentMainList = componentMainDao.uniqueCheckForUpdate(componentMainDto.getGroupName(),
				componentMainDto.getGroupCode(), componentMainDto.getId());
		if (componentMainList.size() != 0)
			throw new ApplicationServiceExecption("Component aleady exist", HttpStatus.BAD_REQUEST);

		ComponentMain componentMain = componentMainDao.findByIdAndStatusNot(componentMainDto.getId(),
				commonUtil.getSoftDeleteStatus());
		if (componentMain == null)
			throw new ApplicationServiceExecption("ComponentMain not found", HttpStatus.BAD_REQUEST);

		ComponentMainDto existingComponentMainDto = mapEntityToDto.transformBO(componentMain, ComponentMainDto.class);
		componentMain = mapDtoToEntity.transformBO(componentMainDto, ComponentMain.class);
		componentMain.setUpdateTime(new Date());
		componentMain = componentMainDao.saveAndFlush(componentMain);
		syncDataService.syncUpdate(mapDtoToEntity.transformBO(existingComponentMainDto, ComponentMain.class),
				componentMain);
		LOGGER.debug("ComponentMainServiceImpl -- update -- End");
		return mapEntityToDto.transformBO(componentMain, ComponentMainDto.class);
	}

}
