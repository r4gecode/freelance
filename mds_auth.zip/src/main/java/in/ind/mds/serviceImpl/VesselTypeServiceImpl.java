package in.ind.mds.serviceImpl;

import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import in.ind.mds.dto.OwnerDto;
import in.ind.mds.dto.VesselTypeDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.repo.dao.VesselTypeDao;
import in.ind.mds.repo.entity.VesselType;
import in.ind.mds.service.SyncDataService;
import in.ind.mds.service.VesselTypeService;
import in.ind.mds.util.BeanTransformerUtil;
import in.ind.mds.util.CommonUtil;
import in.ind.mds.util.DBUtil;

@Service("TST_MSSQL_VESSEL_TYPE")

public class VesselTypeServiceImpl implements VesselTypeService {

	private static final Logger LOGGER = LoggerFactory.getLogger(VesselTypeServiceImpl.class);

	@Autowired
	private BeanTransformerUtil<VesselType, VesselTypeDto> mapEntityToDto;

	@Autowired
	private BeanTransformerUtil<VesselTypeDto, VesselType> mapDtoToEntity;

	@Autowired
	@Qualifier("TST_MSSQL_SYNC")
	private SyncDataService syncDataService;
	/*
	 * @Autowired private UserValidator validator;
	 */
	@Autowired
	private CommonUtil<VesselTypeDto> commonUtil;

	@Autowired
	private VesselTypeDao vesselTypeDao;
	
	@Autowired
	private DBUtil dbUtil;

	@Override
	public VesselTypeDto getVesselTypeId(String vesselTypeId) throws Exception {
		LOGGER.debug("VesselTypeServiceImpl -- getVesselTypeId -- Start");
		commonUtil.stringNullValidator(vesselTypeId, "VesselTypeId");
		VesselType vesselType = vesselTypeDao.findByIdAndStatusNot(vesselTypeId, commonUtil.getSoftDeleteStatus());

		if (vesselType == null) 
			throw new ApplicationServiceExecption("VesselType not found", HttpStatus.NOT_FOUND);
		
		final VesselTypeDto dto = mapEntityToDto.transformBO(vesselType, VesselTypeDto.class);
		LOGGER.debug("VesselServiceImpl -- getVesselTypeId -- End");
		return dto;
	}

	@Override
	public VesselTypeDto findByVesselTypeName(String vesselTypeName) throws Exception {
		LOGGER.debug("VesselTypeServiceImpl -- findByVesselTypeName -- Start");
		commonUtil.stringNullValidator(vesselTypeName, "VesselTypeName");
		VesselType vesselType = vesselTypeDao.findByVesselTypeNameAndStatusNot(vesselTypeName, commonUtil.getSoftDeleteStatus());

		if (vesselType == null) 
			throw new ApplicationServiceExecption("VesselType not found", HttpStatus.NOT_FOUND);
		
		final VesselTypeDto dto = mapEntityToDto.transformBO(vesselType, VesselTypeDto.class);
		LOGGER.debug("VesselServiceImpl -- findByVesselTypeName -- End");
		return dto;
	}

	@Override
	public List<VesselTypeDto> findAll() throws Exception {
		LOGGER.debug("VesselTypeServiceImpl -- findAll -- Start");
		List<VesselType> vesselType = vesselTypeDao.findAllVesselType();

		if (vesselType.size() == 0) 
			throw new ApplicationServiceExecption("VesselType not found", HttpStatus.NOT_FOUND);
		
		final List<VesselTypeDto> dto = mapEntityToDto.transformListOfBO(vesselType, VesselTypeDto.class);
		LOGGER.debug("VesselTypeServiceImpl -- findAll -- End");
		return dto;
	}
	
	public VesselTypeDto add(VesselTypeDto vesselTypeDto) throws Exception {
		LOGGER.debug("VesselTypeServiceImpl -- add -- Start");
		// final String errorMessage = validator.validateAdd(userDto);
		// if (errorMessage != null) {
		// throw new GaurageServiceException(errorMessage, HttpStatus.BAD_REQUEST);
		// }
		/*Optional<VesselType> existingVesselType = vesselTypeDao.findById(vesselTypeDto.getId());
		if (existingVesselType.isPresent()) {
			throw new ApplicationServiceExecption("VesselType exist", HttpStatus.BAD_REQUEST);
		}*/
		commonUtil.stringNullValidator(vesselTypeDto.getVesselTypeName(), "VesselTypeName");
		VesselType vesselType = vesselTypeDao.findByVesselTypeNameAndStatusNot(vesselTypeDto.getVesselTypeName(), commonUtil.getSoftDeleteStatus());
		if(vesselType != null)
			throw new ApplicationServiceExecption("VesselType already exist", HttpStatus.BAD_REQUEST);
		
		vesselType = mapDtoToEntity.transformBO(vesselTypeDto, VesselType.class);
		String seqName = dbUtil.getNextSequence(vesselType.getClass());
		if(seqName != null) {
			vesselType.setId(seqName);
		}
		vesselType.setInsertTime(new Date());
		vesselType.setUpdateTime(new Date());
		vesselType.setStatus(commonUtil.getActiveStatus());
		vesselType=vesselTypeDao.save(vesselType);
		syncDataService.syncCreation(vesselType);
		LOGGER.debug("VesselTypeServiceImpl -- add -- End");
		return mapEntityToDto.transformBO(vesselType, VesselTypeDto.class);
	}
	
	@Override
	public List<VesselTypeDto> softDeleteVesselType(List<String> vesselTypeIds) throws Exception {
		LOGGER.debug("PortServiceImpl -- softDelete -- Start");
		commonUtil.stringNullValidator(vesselTypeIds.toArray(), "VesselLTypeId");
		List<VesselType> existingVesselTypes = vesselTypeDao.findByIdInAndStatusNot(vesselTypeIds, commonUtil.getSoftDeleteStatus());
		List<VesselTypeDto> existingVesselTypeDtos = mapEntityToDto.transformListOfBO(existingVesselTypes, VesselTypeDto.class);
		if (existingVesselTypes.size() < vesselTypeIds.size()) 
			throw new ApplicationServiceExecption("Vessel Type not found", HttpStatus.BAD_REQUEST);
		
		for (VesselType vesselType : existingVesselTypes) {
			vesselType.setStatus(commonUtil.getSoftDeleteStatus());
		}
		existingVesselTypes = vesselTypeDao.saveAll(existingVesselTypes);
		
		int count = 0;
		for (VesselType vesselType : existingVesselTypes) {
			syncDataService.syncUpdate(mapDtoToEntity.transformBO(existingVesselTypeDtos.get(count),VesselType.class), vesselType);
			count++;
		}
		LOGGER.debug("VesselTypeServiceImpl -- softDelete -- End");
		existingVesselTypes = vesselTypeDao.findAllVesselType();
		return mapEntityToDto.transformListOfBO(existingVesselTypes, VesselTypeDto.class);
	}

	@Override
	public VesselTypeDto updateVesselType(VesselTypeDto vesselTypeDto) throws Exception {
		LOGGER.debug("VesselTypeServiceImpl -- update -- Start");
		// final String errorMessage = validator.validateAdd(userDto);
		// if (errorMessage != null) {
		// throw new GaurageServiceException(errorMessage, HttpStatus.BAD_REQUEST);
		// }
		commonUtil.stringNullValidator(vesselTypeDto.getId(), vesselTypeDto.getVesselTypeName(), "Vessel Id and Name");
		VesselType vesselType = vesselTypeDao.findByVesselTypeNameAndStatusNotAndIdNot(vesselTypeDto.getVesselTypeName(), commonUtil.getSoftDeleteStatus(), vesselTypeDto.getId());
		if(vesselType != null)
			throw new ApplicationServiceExecption("VesselType already exist", HttpStatus.BAD_REQUEST);
		
		vesselType = vesselTypeDao.findByIdAndStatusNot(vesselTypeDto.getId(), commonUtil.getSoftDeleteStatus());
		if (vesselType == null) 
			throw new ApplicationServiceExecption("VesselType not found", HttpStatus.BAD_REQUEST);
		
		VesselTypeDto existingVesselType = mapEntityToDto.transformBO(vesselType, VesselTypeDto.class);
		VesselType vesselTypeEntity = mapDtoToEntity.transformBO(vesselTypeDto, VesselType.class);
		vesselTypeEntity.setUpdateTime(new Date());
		vesselTypeEntity=vesselTypeDao.saveAndFlush(vesselTypeEntity);
		syncDataService.syncUpdate(mapDtoToEntity.transformBO(existingVesselType, VesselType.class), vesselTypeEntity);
		LOGGER.debug("VesselTypeServiceImpl -- update -- End");
		return mapEntityToDto.transformBO(vesselTypeEntity, VesselTypeDto.class);
	}
}
