/**
 * 
 */
package in.ind.mds.serviceImpl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import in.ind.mds.dto.AttachmentDto;
import in.ind.mds.dto.CrewActivityDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.repo.dao.CrewActivityDao;
import in.ind.mds.repo.entity.CrewActivity;
import in.ind.mds.repo.entity.Staff;
import in.ind.mds.service.AttachmentService;
import in.ind.mds.service.CrewActivityService;
import in.ind.mds.service.SyncDataService;
import in.ind.mds.util.BeanTransformerUtil;
import in.ind.mds.util.CommonUtil;
import in.ind.mds.util.DBUtil;

/**
 * @author dharani
 *
 */

@Service("TST_MSSQL_CREW_ACTIVITY")
public class CrewActivityServiceImpl implements CrewActivityService {

	private static final Logger LOGGER = LoggerFactory.getLogger(CrewActivityServiceImpl.class);

	@Autowired
	private BeanTransformerUtil<CrewActivity, CrewActivityDto> mapEntityToDto;

	@Autowired
	private BeanTransformerUtil<CrewActivityDto, CrewActivity> mapDtoToEntity;

	@Autowired
	@Qualifier("TST_MSSQL_SYNC")
	private SyncDataService syncDataService;

	@Autowired
	private CommonUtil<CrewActivityDto> commonUtil;

	@Autowired
	private CrewActivityDao crewActivityDao;

	@Autowired
	@Qualifier("TST_MSSQL_ATTACHEMENT")
	private AttachmentService attachmentService;

	@Autowired
	private DBUtil dbUtil;

	@Override
	public List<CrewActivityDto> add(Staff staff, List<CrewActivityDto> crewActivityDtoList,
			MultipartFile[] attachmentFiles) throws Exception {
		LOGGER.debug("CrewActivityerviceImpl---add---Start.....");
		crewActivityDtoList = addCrewActivity(staff, crewActivityDtoList, attachmentFiles);
		LOGGER.debug("CrewActivityServicImpl -- add -- end");
		return crewActivityDtoList;
	}

	@Override
	public List<CrewActivityDto> update(Staff staff, List<CrewActivityDto> crewActivityDtoList,
			MultipartFile[] attachmentFiles) throws Exception {
		List<CrewActivityDto> crewActivityDtoListForAdd = new ArrayList<>();
		List<CrewActivityDto> crewActivityDtoListForUpdate = new ArrayList<>();
		for (CrewActivityDto crewActivityDto : crewActivityDtoList) {
			if (crewActivityDto.getId() == null)
				crewActivityDtoListForAdd.add(crewActivityDto);
			else
				crewActivityDtoListForUpdate.add(crewActivityDto);
		}
		if (!crewActivityDtoListForAdd.isEmpty())
			crewActivityDtoList = addCrewActivity(staff, crewActivityDtoList, attachmentFiles);

		List<String> crewActivityIds = crewActivityDtoListForUpdate.stream().map(i -> i.getId())
				.collect(Collectors.toList());
		List<CrewActivity> crewActivityList = crewActivityDao.findByIdInAndStatusNot(crewActivityIds,
				commonUtil.getSoftDeleteStatus());
		if (crewActivityList.size() < crewActivityIds.size())
			throw new ApplicationServiceExecption("Activity not found");

		List<CrewActivityDto> existingCrewActivityDtoList = mapEntityToDto.transformListOfBO(crewActivityList,
				CrewActivityDto.class);
		crewActivityList = mapDtoToEntity.transformListOfBO(crewActivityDtoListForUpdate, CrewActivity.class);
		for (CrewActivity crewActivity : crewActivityList) {
			crewActivity.setUpdateTime(new Date());
		}
		/**********************delete and add attachments of CrewActivity********start**********/
		List<CrewActivityDto> returncrewActivityDtoList = mapEntityToDto.transformListOfBO(crewActivityList,
				CrewActivityDto.class);
		Integer count = 0;
		for (CrewActivityDto crewActivityDto : crewActivityDtoListForUpdate) {
			if(!crewActivityDto.getSoftDeleteDocPaths().isEmpty())
				attachmentService.softDeleteByPathList(crewActivityDto.getSoftDeleteDocPaths());
			
			List<MultipartFile> thisAttachmentFiles = new ArrayList<>();
			for (String crewActivityDoc : crewActivityDto.getActivityDoc()) {
				Integer index = 0;
				// Integer removeAttachmentIndex = null;
				for (MultipartFile attachment : attachmentFiles) {
					if (crewActivityDoc.equals(attachment.getOriginalFilename())) {
						thisAttachmentFiles.add(attachment);
						// removeAttachmentIndex = index;
					}
					index++;
				}
				// ArrayUtils.remove(attachmentFiles, removeAttachmentIndex);
			}
			AttachmentDto attachmentDto = new AttachmentDto();
			attachmentDto.setRecordId(crewActivityDtoList.get(count).getId());
			attachmentDto.setAttachmentOrigin(
					dbUtil.getTableName((mapDtoToEntity.transformBO(crewActivityDto, CrewActivity.class)).getClass()));
			attachmentDto.setAttachmentType(crewActivityDto.getActivityDocFieldName());
			List<String> staffPicPathList = attachmentService.add(attachmentDto, thisAttachmentFiles);
			returncrewActivityDtoList.get(count).setActivityDoc(staffPicPathList);
			count++;
		}
		/**********************delete and add attachments of CrewActivity********end**********/
		crewActivityDao.saveAll(crewActivityList);
		count = 0;
		for (CrewActivity crewActivity : crewActivityList) {
			syncDataService.syncUpdate(
					mapDtoToEntity.transformBO(existingCrewActivityDtoList.get(count), CrewActivity.class),
					crewActivity);
			count++;
		}
		crewActivityDtoList.addAll(crewActivityDtoListForUpdate);
		LOGGER.debug("CrewActivityServicImpl -- update -- end");

		return crewActivityDtoList;
	}

	@Override
	public List<CrewActivityDto> findByStaff(Staff staff) throws Exception {
		LOGGER.debug("CRewActivityServicImpl -- findByStaff -- start");
		List<CrewActivityDto> crewActivityDtoList = new ArrayList<>();
		List<CrewActivity> crewActivityList = crewActivityDao.findByStaffAndStatusNot(staff,
				commonUtil.getSoftDeleteStatus());
		if (crewActivityList.isEmpty())
			return crewActivityDtoList;

		crewActivityDtoList = mapEntityToDto.transformListOfBO(crewActivityList, CrewActivityDto.class);
		String attachmentOrigin = dbUtil.getTableName(crewActivityList.get(0).getClass());
		for (CrewActivityDto crewActivityDto : crewActivityDtoList) {
			AttachmentDto attachmentDto = new AttachmentDto();
			attachmentDto.setAttachmentOrigin(attachmentOrigin);
			attachmentDto.setRecordId(crewActivityDto.getId());
			attachmentDto.setAttachmentType(crewActivityDto.getActivityDocFieldName());
			crewActivityDto.setActivityDoc(attachmentService.findAttachments(attachmentDto));

		}
		LOGGER.debug("CrewActivityServicImpl -- findByStaff -- end");
		return crewActivityDtoList;

	}

	@Override
	public void softDeleteByStaff(Staff staff) throws Exception {
		LOGGER.debug("CrewActivityServicImpl -- softDelete -- start");
		List<CrewActivity> crewActivityList = crewActivityDao.findByStaffAndStatusNot(staff,
				commonUtil.getSoftDeleteStatus());
		List<CrewActivityDto> crewActivityDtoList = mapEntityToDto.transformListOfBO(crewActivityList,
				CrewActivityDto.class);
		for (CrewActivity crewActivity : crewActivityList) {
			crewActivity.setUpdateTime(new Date());
			crewActivity.setStatus(commonUtil.getSoftDeleteStatus());
		}
		Integer count = 0;
		for (CrewActivity crewActivity : crewActivityList) {
			syncDataService.syncUpdate(mapDtoToEntity.transformBO(crewActivityDtoList.get(count), CrewActivity.class),
					crewActivity);
			attachmentService.softDelete(crewActivity.getId(), dbUtil.getTableName(crewActivity.getClass()));
			count++;
		}
		LOGGER.debug("CrewActivityServicImpl -- softDelete -- end");
	}

	@Override
	public void softDelete(List<String> ids) throws Exception {
		LOGGER.debug("CrewActivityServicImpl -- softDelete -- start");
		commonUtil.stringNullValidator(ids.toArray(), "crewActivity Id");
		List<CrewActivity> crewActivityList = crewActivityDao.findByIdInAndStatusNot(ids,
				commonUtil.getSoftDeleteStatus());
		if (crewActivityList.size() < ids.size())
			throw new ApplicationServiceExecption("Activity not found");

		List<CrewActivityDto> crewActivityDtoList = mapEntityToDto.transformListOfBO(crewActivityList,
				CrewActivityDto.class);
		for (CrewActivity crewActivity : crewActivityList) {
			crewActivity.setUpdateTime(new Date());
			crewActivity.setStatus(commonUtil.getSoftDeleteStatus());
		}
		Integer count = 0;
		for (CrewActivity crewActivity : crewActivityList) {
			syncDataService.syncUpdate(mapDtoToEntity.transformBO(crewActivityDtoList.get(count), CrewActivity.class),
					crewActivity);
			attachmentService.softDelete(crewActivity.getId(), dbUtil.getTableName(crewActivity.getClass()));
			count++;
		}
		LOGGER.debug("CrewActivityServicImpl -- softDelete -- end");
	}

	public List<CrewActivityDto> addCrewActivity(Staff staff, List<CrewActivityDto> crewActivityDtoList,
			MultipartFile[] attachmentFiles) throws Exception {
		LOGGER.debug("CrewActivityServicImpl -- addCrewActivityMethod -- start");
		List<CrewActivity> crewActivityList = mapDtoToEntity.transformListOfBO(crewActivityDtoList, CrewActivity.class);
		for (CrewActivity crewActivity : crewActivityList) {
			String seqName = dbUtil.getNextSequence(crewActivity.getClass());
			if (seqName != null)
				crewActivity.setId(seqName);

			crewActivity.setStaff(staff);
			crewActivity.setInsertTime(new Date());
			crewActivity.setUpdateTime(new Date());
			crewActivity.setStatus(commonUtil.getActiveStatus());
		}
		crewActivityDao.saveAll(crewActivityList);
		for (CrewActivity crewActivity : crewActivityList) {
			syncDataService.syncCreation(crewActivity);
		}
		List<CrewActivityDto> returncrewActivityDtoList = mapEntityToDto.transformListOfBO(crewActivityList,
				CrewActivityDto.class);
		Integer count = 0;
		for (CrewActivityDto crewActivityDto : crewActivityDtoList) {
			List<MultipartFile> thisAttachmentFiles = new ArrayList<>();
			for (String crewActivityDoc : crewActivityDto.getActivityDoc()) {
				Integer index = 0;
				// Integer removeAttachmentIndex = null;
				for (MultipartFile attachment : attachmentFiles) {
					if (crewActivityDoc.equals(attachment.getOriginalFilename())) {
						thisAttachmentFiles.add(attachment);
						// removeAttachmentIndex = index;
					}
					index++;
				}
				// ArrayUtils.remove(attachmentFiles, removeAttachmentIndex);
			}
			AttachmentDto attachmentDto = new AttachmentDto();
			attachmentDto.setRecordId(crewActivityDtoList.get(count).getId());
			attachmentDto.setAttachmentOrigin(
					dbUtil.getTableName((mapDtoToEntity.transformBO(crewActivityDto, CrewActivity.class)).getClass()));
			attachmentDto.setAttachmentType(crewActivityDto.getActivityDocFieldName());
			List<String> staffPicPathList = attachmentService.add(attachmentDto, thisAttachmentFiles);
			returncrewActivityDtoList.get(count).setActivityDoc(staffPicPathList);
			count++;
		}
		LOGGER.debug("CrewActivityServicImpl -- addCrewActivityMethod -- end");
		return returncrewActivityDtoList;
	}

}
