package in.ind.mds.serviceImpl;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import in.ind.mds.dto.AuthenticationDto;
import in.ind.mds.dto.AuthorizationDto;
import in.ind.mds.dto.RoleDto;
import in.ind.mds.dto.RoleMenuDto;
import in.ind.mds.dto.UserDto;
import in.ind.mds.dto.UserRoleDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.security.JWTAuthenticationService;
import in.ind.mds.security.auth.request.AuthRequestView;
import in.ind.mds.security.auth.request.LoginRequestView;
import in.ind.mds.service.AuthHandlerService;

@Service("TST_MSSQL_AUTH")
public class AuthHandlerServiceImpl implements AuthHandlerService {

	private static final String HAS_ACCESS = "X";
	private static final Logger LOGGER = LoggerFactory.getLogger(AuthHandlerServiceImpl.class);
	private static final String CLASSNAME = "AuthHandlerServiceImpl";
	
	private static final String ADD_ACCESS = "add";
	private static final String UPDT_ACCESS = "update";
	private static final String DEL_ACCESS = "delete";
	private static final String VIEW_ACCESS = "view";
	private static final String EMAIL_ACCESS = "email";

	@Autowired
	private JWTAuthenticationService tokenAuthenticationService;

	@Autowired
	private UserServiceImpl userService;

	@Autowired
	private UserRoleServiceImpl userRoleService;
	
	@Autowired
	private RoleMenuServiceImpl roleMenuService;

	@Override
	public AuthenticationDto authenticateUser(LoginRequestView requestView) throws ApplicationServiceExecption {

		String methodName = "authenticateUser";

		AuthenticationDto loginResponse = null;
		String jwtToken = null;
		if (null != requestView) {
			try {
				UserDto user = userService.getActiveUserByUserNameAndPassword(requestView.getUsername(),
						requestView.getPassword());
				if (null == user) {
					throw new ApplicationServiceExecption("User not found", HttpStatus.NOT_FOUND);
				} else {
					UserRoleDto userRole = userRoleService.findByUserId(user);
					if (userRole == null) {
						throw new ApplicationServiceExecption("UserRole not found", HttpStatus.NOT_FOUND);
					} else {
						RoleDto role = userRole.getRole();
						//role.getRoleName();
						//role.getRoleCode();
						loginResponse = new AuthenticationDto();
						loginResponse.setUserName(user.getUserName());
						loginResponse.setLoginID(user.getUserLoginId());
						loginResponse.setUserShortName(user.getUserShortName());
						loginResponse.setUserTitle(user.getUserTitle());
						loginResponse.setUserType(user.getUserType());
						loginResponse.setUserRole(role.getRoleName());
						loginResponse.setUserRoleID(role.getId());

						jwtToken = generateJWTToken(requestView);
						loginResponse.setAuthToken(jwtToken);
						LOGGER.info("Token Generated - " + jwtToken);
					}
				}

			} catch (Exception exception) {
				LOGGER.error(getErrorMessage(methodName, exception));
				throw new ApplicationServiceExecption(exception.getMessage(), HttpStatus.EXPECTATION_FAILED);
			}
		}
		return loginResponse;
	}

	@Override
	public AuthorizationDto authorizeUser(AuthRequestView requestView) throws ApplicationServiceExecption {

		String methodName = "authorizeUser";

		AuthorizationDto authResponse = null;
		if (null != requestView) {
			try {
				List<RoleMenuDto> roleMenuList = roleMenuService.findByRoleId(requestView.getUserRoleId());
				if (CollectionUtils.isEmpty(roleMenuList)) {
					throw new ApplicationServiceExecption("Menu not found", HttpStatus.NOT_FOUND);
				} else {
						authResponse = new AuthorizationDto();
						authResponse.setUserName(requestView.getUsername());
						authResponse.setFirstName(requestView.getUserFirstName());
						authResponse.setLastName(requestView.getUserLastName());
						authResponse.setUserFullName(requestView.getUserFirstName()+" "+requestView.getUserLastName());
						authResponse.setUserRole(requestView.getUserRole());
						authResponse.setAccessMap(prepareAccessMap(roleMenuList));
				}
			} catch (Exception exception) {
				LOGGER.error(getErrorMessage(methodName, exception));
				throw new ApplicationServiceExecption(exception.getMessage(), HttpStatus.EXPECTATION_FAILED);
			}
		}
		return authResponse;
	}

	@Override
	public String generateJWTToken(LoginRequestView loginRequestView) {
		String authResponse = null;
		String jwtToken = tokenAuthenticationService.addAuthentication(loginRequestView.getUsername());
		if (!StringUtils.isEmpty(jwtToken))
			authResponse = jwtToken;

		return authResponse;
	}
	
	private static Map<String, Map<String,Boolean>> prepareAccessMap(List<RoleMenuDto> roleMenuList) throws ApplicationServiceExecption{
		final String methodName = "prepareAccessMap";
		Map<String,Map<String,Boolean>> menuAccessMap = new LinkedHashMap<>();
		Map<String,Boolean> accessMap = null;
		try{
		for(RoleMenuDto roleMenu : roleMenuList){
			accessMap = new LinkedHashMap<>();
			accessMap.put(ADD_ACCESS, decodeAccessLevel(roleMenu.getAddAccess()));
			accessMap.put(UPDT_ACCESS, decodeAccessLevel(roleMenu.getUpdAccess()));
			accessMap.put(DEL_ACCESS, decodeAccessLevel(roleMenu.getDelAccess()));
			accessMap.put(VIEW_ACCESS, decodeAccessLevel(roleMenu.getViewAccess()));
			accessMap.put(EMAIL_ACCESS, decodeAccessLevel(roleMenu.getEmailAccess()));
			menuAccessMap.put(roleMenu.getMenu().getMenuDesc(),accessMap);
		}
		}catch(Exception ex){
			LOGGER.error(getErrorMessage(methodName, ex));
			throw new ApplicationServiceExecption(ex.getMessage(), HttpStatus.EXPECTATION_FAILED);
		}finally{
			accessMap = null;
		}
		return menuAccessMap;
	}

	private static String getErrorMessage(String methodName, Exception e) {
		return "Error Occurred in className:" + CLASSNAME + " and methodName: " + methodName + "  Exception: "
				+ e.getMessage();
	}
	
	private static Boolean decodeAccessLevel(String accessLvl){
		
		Boolean hasAccess = false;
		if(!StringUtils.isEmpty(accessLvl) && accessLvl.equalsIgnoreCase(HAS_ACCESS)){
				hasAccess = Boolean.TRUE;
		}
		return hasAccess;
	}
}
