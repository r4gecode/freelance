/**
 * 
 */
package in.ind.mds.serviceImpl;

import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import in.ind.mds.dto.CompanyCurrencyDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.repo.dao.CompanyCurrencyDao;
import in.ind.mds.repo.dao.CompanyDao;
import in.ind.mds.repo.entity.Company;
import in.ind.mds.repo.entity.CompanyCurrency;
import in.ind.mds.repo.entity.GlobalCurrency;
import in.ind.mds.service.CompanyCurrencyService;
import in.ind.mds.service.SyncDataService;
import in.ind.mds.util.BeanTransformerUtil;
import in.ind.mds.util.CommonUtil;
import in.ind.mds.util.DBUtil;

/**
 * @author mds-arockia
 *
 */
@Service("TST_MSSQL_COMPANY_CURRENCY")
public class CompanyCurrencyServiceImpl implements CompanyCurrencyService {

	private static final Logger LOGGER = LoggerFactory.getLogger(CompanyCurrencyServiceImpl.class);

	@Autowired
	private BeanTransformerUtil<CompanyCurrency, CompanyCurrencyDto> mapEntityToDto;

	@Autowired
	private BeanTransformerUtil<CompanyCurrencyDto, CompanyCurrency> mapDtoToEntity;

	@Autowired
	@Qualifier("TST_MSSQL_SYNC")
	private SyncDataService syncDataService;

	@Autowired
	private CompanyCurrencyDao companyCurrencyDao;
	
	@Autowired
	private CompanyDao companyDao;

	@Autowired
	private DBUtil dbUtil;

	@Autowired
	private CommonUtil<CompanyCurrencyDto> commonUtil;

	@Override
	public List<CompanyCurrencyDto> add(List<CompanyCurrencyDto> companyCurrencyDtos) throws Exception {
		LOGGER.debug("CompanyCurrencyServiceImpl -- add -- Start");

		List<CompanyCurrency> companyCurrencyList = mapDtoToEntity.transformListOfBO(companyCurrencyDtos,
				CompanyCurrency.class);
		for (CompanyCurrency companyCurrency : companyCurrencyList) {
			String seqName = dbUtil.getNextSequence(companyCurrency.getClass());
			if (seqName != null) {
				companyCurrency.setId(seqName);
			}
			companyCurrency.setInsertTime(new Date());
			companyCurrency.setUpdateTime(new Date());
			companyCurrency.setStatus(commonUtil.getActiveStatus());
		}

		companyCurrencyList = companyCurrencyDao.saveAll(companyCurrencyList);
		for (CompanyCurrency companyCurrency : companyCurrencyList) {
			syncDataService.syncCreation(companyCurrency);
		}
		CompanyCurrency firstCompanyCurrency = companyCurrencyList.get(0);
		List<CompanyCurrency> returnCompanyCurrency = companyCurrencyDao.findByCompanyAndStatusNotAndCurrencyNot(firstCompanyCurrency.getCompany(), commonUtil.getSoftDeleteStatus(), firstCompanyCurrency.getBaseCurrency());
		LOGGER.debug("CompanyCurrencyServiceImpl -- add -- End");
		return mapEntityToDto.transformListOfBO(returnCompanyCurrency, CompanyCurrencyDto.class);
	}
	
	@Override
	public List<CompanyCurrencyDto> findByCompanyId(String companyId) throws Exception {
		LOGGER.debug("CompanyCurrencyServiceImpl -- findByCompanyId -- start");
		Company company = companyDao.findByIdAndStatusNot(companyId, commonUtil.getSoftDeleteStatus());
		//List<CompanyCurrency> baseCurrencyList = companyCurrencyDao.findBaseCurrencyByCompanyAndStatusNot(company, commonUtil.getSoftDeleteStatus());
		List<CompanyCurrency> companyCurrencyList = companyCurrencyDao.findBaseCurrencyByCompanyAndStatusNot(company, commonUtil.getSoftDeleteStatus());

		//List<CompanyCurrency> companyCurrencyList = companyCurrencyDao.findByCompanyAndStatusNotAndCurrencyNot(company, commonUtil.getSoftDeleteStatus(), baseCurrency);
		LOGGER.debug("CompanyCurrencyServiceImpl -- findByCompanyId -- end");
		return mapEntityToDto.transformListOfBO(companyCurrencyList, CompanyCurrencyDto.class);
	}

	@Override
	public List<CompanyCurrencyDto> softDelete(List<String> companyCurrencyIds) throws Exception{
		LOGGER.debug("CompanyCurrencyServiceImpl -- softDelete -- Start");
		List<CompanyCurrency> companyCurrencyList = companyCurrencyDao.findByIdInAndStatusNot(companyCurrencyIds, commonUtil.getSoftDeleteStatus());
		if(companyCurrencyList.size() < companyCurrencyIds.size())
			throw new ApplicationServiceExecption("CompanyCurrencyId not found",HttpStatus.BAD_REQUEST);
		
		List<CompanyCurrencyDto> companyCurrencyDtoList = mapEntityToDto.transformListOfBO(companyCurrencyList, CompanyCurrencyDto.class);
		for (CompanyCurrency companyCurrency : companyCurrencyList) {
			companyCurrency.setStatus(commonUtil.getSoftDeleteStatus());
			companyCurrency.setUpdateTime(new Date());
		}
		
		companyCurrencyList = companyCurrencyDao.saveAll(companyCurrencyList);
		Integer count = 0;
		for (CompanyCurrency companyCurrency : companyCurrencyList) {
			CompanyCurrencyDto existingCompanyDto = companyCurrencyDtoList.get(count);
			syncDataService.syncUpdate(mapDtoToEntity.transformBO(existingCompanyDto, CompanyCurrency.class), companyCurrency);
			count++;
		}
		CompanyCurrency firstCompanyCurrency = companyCurrencyList.get(0);
		List<CompanyCurrency> returnCompanyCurrency = companyCurrencyDao.findByCompanyAndStatusNotAndCurrencyNot(firstCompanyCurrency.getCompany(), commonUtil.getSoftDeleteStatus(), firstCompanyCurrency.getBaseCurrency());
		LOGGER.debug("CompanyCurrencyServiceImpl -- softDelete -- End");
		return mapEntityToDto.transformListOfBO(returnCompanyCurrency, CompanyCurrencyDto.class);
	}

	@Override
	public List<CompanyCurrencyDto> updateBaseCurrency(String companyId, String baseCurrencyId) throws Exception {
		LOGGER.debug("CompanyCurrencyServiceImpl -- udpate -- Start");
		Company company = companyDao.findByIdAndStatusNot(companyId, commonUtil.getSoftDeleteStatus());
		List<CompanyCurrency> companyCurrencyList = companyCurrencyDao.findByCompanyAndStatusNot(company, commonUtil.getSoftDeleteStatus());
		List<CompanyCurrencyDto> companyCurrencyDtoList = mapEntityToDto.transformListOfBO(companyCurrencyList, CompanyCurrencyDto.class);
		//CompanyCurrency baseCompanyCurrency = companyCurrencyDao.findByIdAndStatusNot(baseCurrencyId, commonUtil.getSoftDeleteStatus());
		//GlobalCurrency baseCurrency = baseCompanyCurrency.getCurrency();
		for (CompanyCurrency companyCurrency : companyCurrencyList) {
			//companyCurrency.setBaseCurrency(baseCurrency);
			companyCurrency.setUpdateTime(new Date());
		}
		companyCurrencyList = companyCurrencyDao.saveAll(companyCurrencyList);
		Integer count = 0;
		for (CompanyCurrency companyCurrency : companyCurrencyList) {
			CompanyCurrencyDto existigCompanyCurrency = companyCurrencyDtoList.get(count);
			syncDataService.syncUpdate(mapDtoToEntity.transformBO(existigCompanyCurrency, CompanyCurrency.class), companyCurrency);
			count++;
		}
		CompanyCurrency firstCompanyCurrency = companyCurrencyList.get(0);
		List<CompanyCurrency> returnCompanyCurrency = companyCurrencyDao.findByCompanyAndStatusNotAndCurrencyNot(company, commonUtil.getSoftDeleteStatus(), firstCompanyCurrency.getBaseCurrency());
		LOGGER.debug("CompanyCurrencyServiceImpl -- add -- End");
		return mapEntityToDto.transformListOfBO(returnCompanyCurrency, CompanyCurrencyDto.class);
	}

}
