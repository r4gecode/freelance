/**
 * 
 */
package in.ind.mds.serviceImpl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import in.ind.mds.dto.AttachmentDto;
import in.ind.mds.dto.AttendanceDto;
import in.ind.mds.dto.BankAccountDto;
import in.ind.mds.dto.DrillCompletionDto;
import in.ind.mds.dto.OfficeReviewDto;
import in.ind.mds.dto.ScheduledJobDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.repo.dao.OfficeReviewDao;
import in.ind.mds.repo.dao.ScheduledJobDao;
import in.ind.mds.repo.entity.Attendance;
import in.ind.mds.repo.entity.BankAccount;
import in.ind.mds.repo.entity.DrillCompletion;
import in.ind.mds.repo.entity.OfficeReview;
import in.ind.mds.repo.entity.ScheduledJob;
import in.ind.mds.service.AttachmentService;
import in.ind.mds.service.OfficeReviewService;
import in.ind.mds.service.SyncDataService;
import in.ind.mds.util.BeanTransformerUtil;
import in.ind.mds.util.CommonUtil;
import in.ind.mds.util.DBUtil;

/**
 * @author shalini
 *
 */
@Service("TST_MSSQL_OFFICE_REVIEW")
public class OfficeReviewServiceImpl implements OfficeReviewService {

	private static final Logger LOGGER = LoggerFactory.getLogger(OfficeReviewServiceImpl.class);

	@Autowired
	private BeanTransformerUtil<OfficeReview, OfficeReviewDto> mapEntityToDto;

	@Autowired
	private BeanTransformerUtil<OfficeReviewDto, OfficeReview> mapDtoToEntity;

	@Autowired
	@Qualifier("TST_MSSQL_SYNC")
	private SyncDataService syncDataService;

	@Autowired
	private OfficeReviewDao officeReviewDao;

	@Autowired
	@Qualifier("TST_MSSQL_ATTACHEMENT")
	private AttachmentService attachmentService;

	@Autowired
	private DBUtil dbUtil;

	@Autowired
	private CommonUtil<OfficeReviewDto> commonUtil;

	@Override
	public OfficeReviewDto add(String officeReviewDetails, MultipartFile[] attachmentFiles) throws Exception {
		LOGGER.debug("OfficeReviewServiceImpl -- add -- start");
		OfficeReviewDto officeReviewDto = commonUtil.stringJsonToEntity(officeReviewDetails, OfficeReviewDto.class);
		OfficeReview officeReview = mapDtoToEntity.transformBO(officeReviewDto, OfficeReview.class);
		String seqName = dbUtil.getNextSequence(officeReview.getClass());
		if (seqName != null)
			officeReview.setId(seqName);

		officeReview.setInsertTime(new Date());
		officeReview.setUpdateTime(new Date());
		officeReview.setStatus(commonUtil.getActiveStatus());
		AttachmentDto attachmentDto = new AttachmentDto();
		attachmentDto.setRecordId(officeReview.getId());
		attachmentDto.setAttachmentOrigin(dbUtil.getTableName(officeReview.getClass()));
		attachmentDto.setAttachmentType(officeReviewDto.getOfficeReviewAtchFieldName());
		List<String> attachmentPathList = attachmentService.add(attachmentDto, Arrays.asList(attachmentFiles));
		officeReviewDao.save(officeReview);
		syncDataService.syncCreation(officeReview);
		officeReviewDto = mapEntityToDto.transformBO(officeReview, OfficeReviewDto.class);
		officeReviewDto.setOfficeReviewAtch(attachmentPathList);
		LOGGER.debug("OfficeReviewServiceImpl -- add -- end");
		return officeReviewDto;
	}

	@Override
	public OfficeReviewDto update(String officeReviewDetails, MultipartFile[] attachmentFiles) throws Exception {
		LOGGER.debug("OfficeReviewServiceImpl -- update -- start");
		OfficeReviewDto officeReviewDto = commonUtil.stringJsonToEntity(officeReviewDetails, OfficeReviewDto.class);
		commonUtil.stringNullValidator(officeReviewDto.getId());
		OfficeReview officeReview = officeReviewDao.findByIdAndStatusNot(officeReviewDto.getId(),
				commonUtil.getSoftDeleteStatus());
		if (officeReview == null)
			throw new ApplicationServiceExecption("OfficeReview not found", HttpStatus.BAD_REQUEST);

		OfficeReviewDto existingOfficeReviewDto = mapEntityToDto.transformBO(officeReview, OfficeReviewDto.class);
		officeReview = mapDtoToEntity.transformBO(officeReviewDto, OfficeReview.class);
		officeReview.setUpdateTime(new Date());
		officeReviewDao.save(officeReview);
		syncDataService.syncUpdate(mapDtoToEntity.transformBO(existingOfficeReviewDto, OfficeReview.class),
				officeReview);
		AttachmentDto attachmentDto = new AttachmentDto();
		attachmentDto.setAttachmentOrigin(dbUtil.getTableName(officeReview.getClass()));
		attachmentDto.setRecordId(officeReview.getId());
		attachmentDto.setAttachmentType(officeReviewDto.getOfficeReviewAtchFieldName());
		List<String> attachmentPathList = attachmentService.findAttachments(attachmentDto);
		officeReviewDto.setOfficeReviewAtch(attachmentPathList);
		LOGGER.debug("OfficeReviewServiceImpl -- update -- end");
		return officeReviewDto;
	}

	@Override
	public OfficeReviewDto findById(String id) throws Exception {
		LOGGER.debug("OfficeReviewServiceImpl -- findById -- start");
		commonUtil.stringNullValidator(id, "OfficeReview Id");
		OfficeReview officeReview = officeReviewDao.findByIdAndStatusNot(id, commonUtil.getSoftDeleteStatus());
		if (officeReview == null)
			throw new ApplicationServiceExecption("OfficeReview not found", HttpStatus.BAD_REQUEST);

		OfficeReviewDto officeReviewDto = (OfficeReviewDto) mapEntityToDto.transformBO(officeReview, OfficeReviewDto.class);
		AttachmentDto attachmentDto = new AttachmentDto();
		attachmentDto.setAttachmentOrigin(dbUtil.getTableName(officeReview.getClass()));
		attachmentDto.setRecordId(officeReview.getId());
		attachmentDto.setAttachmentType(((OfficeReviewDto) officeReviewDto).getOfficeReviewAtchFieldName());
		List<String> attachmentPathList = attachmentService.findAttachments(attachmentDto);
		((OfficeReviewDto) officeReviewDto).setOfficeReviewAtch(attachmentPathList);
		LOGGER.debug("OfficeReviewServiceImpl -- findById -- end");
		return officeReviewDto;
	}

	@Override
	public List<OfficeReviewDto> findAll() throws Exception {
		LOGGER.debug("OfficeReviewServiceImpl -- findAll -- start");
		List<OfficeReview> officeReviewList = officeReviewDao.findAllOfficeReview();
		if (officeReviewList.isEmpty())
			throw new ApplicationServiceExecption("No OfficeReview  found", HttpStatus.BAD_REQUEST);

		LOGGER.debug("OfficeReviewServiceImpl -- findAll -- end");
		return mapEntityToDto.transformListOfBO(officeReviewList, OfficeReviewDto.class);
	}

	@Override
	public List<OfficeReviewDto> softDelete(List<String> ids) throws Exception {
		LOGGER.debug("OfficeReviewServiceImpl -- softDelete -- start");
		commonUtil.stringNullValidator(ids.toArray(), "Scheduled Id");
		List<OfficeReview> officeReviewList = officeReviewDao.findByIdInAndStatusNot(ids,
				commonUtil.getSoftDeleteStatus());
		if (officeReviewList.size() < ids.size())
			throw new ApplicationServiceExecption("OfficeReview  not found", HttpStatus.BAD_REQUEST);

		List<OfficeReviewDto> officeReviewDtoList = mapEntityToDto.transformListOfBO(officeReviewList,
				OfficeReviewDto.class);
		for (OfficeReview officeReview : officeReviewList) {
			officeReview.setUpdateTime(new Date());
			officeReview.setStatus(commonUtil.getSoftDeleteStatus());
		}
		officeReviewDao.saveAll(officeReviewList);
		Integer count = 0;
		for (OfficeReview officeReview : officeReviewList) {
			syncDataService.syncUpdate(mapDtoToEntity.transformBO(officeReviewDtoList.get(count), OfficeReview.class),
					officeReview);
			count++;
		}
		officeReviewList = officeReviewDao.findAllOfficeReview();
		LOGGER.debug("OfficeReviewServiceImpl -- softDelete -- end");
		return mapEntityToDto.transformListOfBO(officeReviewList, OfficeReviewDto.class);
	}

	@Override
	public List<OfficeReviewDto> addAll(String id, String origin,List<OfficeReviewDto> officeReviewList, MultipartFile[] attachmentFiles)
			throws Exception {
		LOGGER.debug("OfficeReviewServiceImpl -- addAll -- start");
		List<OfficeReview> officeReview = mapDtoToEntity.transformListOfBO(officeReviewList, OfficeReview.class);
		for (OfficeReview officereview : officeReview) {
			String seqName = dbUtil.getNextSequence(officereview.getClass());
			if (seqName != null)
				officereview.setId(seqName);
			officereview.setOfficeOrigin(origin);
			officereview.setRecordId(id);
			officereview.setInsertTime(new Date());
			officereview.setUpdateTime(new Date());
			officereview.setStatus(commonUtil.getActiveStatus());
		}
			List<OfficeReviewDto> returnlist=mapEntityToDto.transformListOfBO(officeReview,OfficeReviewDto.class);
			Integer count=0;
			for(OfficeReviewDto officeReviewDto :officeReviewList) {
				List<MultipartFile> thisAttachmentFiles=new ArrayList<>();
				for(String offcReviewAtch : officeReviewDto.getOfficeReviewAtch()) {
					for(MultipartFile attachment : attachmentFiles) {
						if(offcReviewAtch.equals(attachment.getOriginalFilename())) {
							thisAttachmentFiles.add(attachment);
						}
					}
				}
			
			AttachmentDto attachmentDto = new AttachmentDto();
			attachmentDto.setRecordId(officeReview.get(count).getId());
			attachmentDto.setAttachmentOrigin(dbUtil.getTableName((mapDtoToEntity.transformBO(officeReviewDto, OfficeReview.class)).getClass()));
			attachmentDto.setAttachmentType(officeReviewDto.getOfficeReviewAtchFieldName());
			List<String> attachmentPathList = attachmentService.add(attachmentDto,thisAttachmentFiles);
			returnlist.get(count).setOfficeReviewAtch(attachmentPathList);
			count++;
			}
			officeReviewDao.saveAll(officeReview);
			for(OfficeReview officeReviews :officeReview) {
			syncDataService.syncCreation(officeReviews);
			
		}
		LOGGER.debug("OfficeReviewServiceImpl -- addAll -- end");

		return returnlist;
	}

	@Override
	public List<OfficeReviewDto> findByMaster(String officeReviewRecId,String officeOrigin) throws Exception {
		LOGGER.debug("OfficeReviewServiceImpl -- findByDrillCompletion -- start");
		List<OfficeReviewDto> officeReviewDtoLists = new ArrayList<>();
		List<OfficeReview> officeReviewlist = new ArrayList<>();

		/*String officeReviewRecId = drillCompletion.getId();
		String officeOrigin=dbUtil.getTableName(drillCompletion.getClass());*/
		
			List<OfficeReview> officeReviewList=officeReviewDao.findByRecordIdAndOfficeOriginAndStatusNot(officeReviewRecId,officeOrigin, commonUtil.getSoftDeleteStatus());
			if(officeReviewList==null) {
				throw new ApplicationServiceExecption("OfficeReview Not Found",HttpStatus.NOT_FOUND);
				
			}
			List<OfficeReviewDto> officeReviewDto=mapEntityToDto.transformListOfBO(officeReviewList, OfficeReviewDto.class);
			officeReviewDtoLists.addAll(officeReviewDto);
		
				if(officeReviewlist.isEmpty())
			return officeReviewDtoLists;
		
		officeReviewDtoLists = mapEntityToDto.transformListOfBO(officeReviewlist, OfficeReviewDto.class);
		String attachmentOrigin = dbUtil.getTableName(officeReviewlist.get(0).getClass());
		for (OfficeReviewDto officeReviewdto : officeReviewDtoLists) {
			AttachmentDto attachmentDto = new AttachmentDto();
			attachmentDto.setAttachmentOrigin(attachmentOrigin);
			attachmentDto.setRecordId(officeReviewdto.getId());
			attachmentDto.setAttachmentType(officeReviewdto.getOfficeReviewAtchFieldName());
			officeReviewdto.setOfficeReviewAtch(attachmentService.findAttachments(attachmentDto));
		}
		LOGGER.debug("OfficeReviewServiceImpl -- findByDrillCompletion -- end");
		return officeReviewDtoLists;
	}

	@Override
	public void softDeleteByMaster(String id, String origin) throws Exception {
		LOGGER.debug("OfficeReviewServiceImpl -- softDeleteByDrillCompl -- start");
		
		List<OfficeReview> officeReviewList = new ArrayList<OfficeReview>();
		List<String> ids=new ArrayList<String>();

		//for(DrillCompletionDto drillCompletionDto:drillCompletion) {
			//String id=drillCompletionDto.getId();
			//String origin=dbUtil.getTableName(drillCompletionDto.getClass());
			List<OfficeReview> officeReviewlist=officeReviewDao.findByRecordIdAndOfficeOriginAndStatusNot(id, origin, commonUtil.getSoftDeleteStatus());
			
			for(OfficeReview officeReview:officeReviewlist) {
				String offcId=officeReview.getId();
				ids.add(offcId);
				officeReviewList.add(officeReview);
			}
			//List<OfficeReviewDto> returnlist=softDelete(ids);
		
		List<OfficeReviewDto> officeReviewDtoList = mapEntityToDto.transformListOfBO(officeReviewList, OfficeReviewDto.class);
		for (OfficeReview officeReview : officeReviewList) {
			officeReview.setUpdateTime(new Date());
			officeReview.setStatus(commonUtil.getSoftDeleteStatus());
		}
		Integer count = 0;
		for (OfficeReview officeReview : officeReviewList) {
			syncDataService.syncUpdate(mapDtoToEntity.transformBO(officeReviewDtoList.get(count), OfficeReview.class), officeReview);
			attachmentService.softDelete(officeReview.getId(), dbUtil.getTableName(officeReview.getClass()));
			count++;
		}
		LOGGER.debug("OfficeReviewServiceImpl -- softDeleteByDrillCompl -- end");		
	}

	@Override
	public List<OfficeReviewDto> updateAll(String id, String origin,List<OfficeReviewDto> officeReviewDtoList, MultipartFile[] multipartFiles) throws Exception {
		LOGGER.debug("OfficeReviewServicImpl -- updateAll -- start");
		List<OfficeReviewDto> officeReviewDtoListForAdd = new ArrayList<>();
		List<OfficeReviewDto> officeReviewListForUpdate = new ArrayList<>();
		for (OfficeReviewDto officeReviewDto : officeReviewDtoList) {
			if(officeReviewDto.getId() == null)
				officeReviewDtoListForAdd.add(officeReviewDto);
			else
				officeReviewListForUpdate.add(officeReviewDto);
		}
		if(!officeReviewDtoListForAdd.isEmpty())
			officeReviewDtoList = addAll( id,origin,officeReviewDtoListForAdd, multipartFiles);
		
		List<String> officeReviewIds = officeReviewListForUpdate.stream().map(i -> i.getId()).collect(Collectors.toList());
		List<OfficeReview> officeReviewList = officeReviewDao.findByIdInAndStatusNot(officeReviewIds, commonUtil.getSoftDeleteStatus());
		if(officeReviewList.size() <officeReviewIds.size())
			throw new ApplicationServiceExecption("officeReview not found");
		
		List<OfficeReviewDto> existingOfficeReviewDtoList = mapEntityToDto.transformListOfBO(officeReviewList, OfficeReviewDto.class);
		officeReviewList = mapDtoToEntity.transformListOfBO(officeReviewListForUpdate, OfficeReview.class);
		for (OfficeReview officeReview : officeReviewList) {
			officeReview.setUpdateTime(new Date());
		}
		
		/**********************delete and add attachments of OfficeReview********start**********/
		List<OfficeReviewDto> returnOfficeReviewDtoListForUpdate = mapEntityToDto.transformListOfBO(officeReviewList, OfficeReviewDto.class);
		Integer count = 0;
		for (OfficeReviewDto officeReviewDto : officeReviewListForUpdate) {
			if(!officeReviewDto.getSoftDeleteDocPaths().isEmpty()) 
				attachmentService.softDeleteByPathList(officeReviewDto.getSoftDeleteDocPaths());
			
			List<MultipartFile> thisAttachmentFiles = new ArrayList<>();
				for (String officeReviewDoc :officeReviewDto.getOfficeReviewAtch()) {
					for (MultipartFile attachment : multipartFiles) {
						if(officeReviewDoc.equals(attachment.getOriginalFilename())) {
							thisAttachmentFiles.add(attachment); 
						}
											}
				}
			AttachmentDto attachmentDto = new AttachmentDto();
			attachmentDto.setRecordId(officeReviewList.get(count).getId());
			attachmentDto.setAttachmentOrigin(dbUtil.getTableName((mapDtoToEntity.transformBO(officeReviewDto, OfficeReview.class)).getClass()));
			attachmentDto.setAttachmentType(officeReviewDto.getOfficeReviewAtchFieldName());
			List<String> officeReviewPicPathList = attachmentService.add(attachmentDto, thisAttachmentFiles);
			returnOfficeReviewDtoListForUpdate.get(count).setOfficeReviewAtch(officeReviewPicPathList);
			count++;
		}
		/**********************delete and add attachments of BankAccount********end**********/
		
		officeReviewDao.saveAll(officeReviewList);
         count = 0;
		for (OfficeReview officeReview : officeReviewList) {
			syncDataService.syncUpdate(mapDtoToEntity.transformBO(existingOfficeReviewDtoList.get(count), OfficeReview.class), officeReview);
			count++;
		}
		officeReviewDtoList.addAll(mapEntityToDto.transformListOfBO(officeReviewList, OfficeReviewDto.class));
		LOGGER.debug("OfficeReviewServicImpl -- update -- end");
		return officeReviewDtoList;
	}
}
