package in.ind.mds.serviceImpl;

import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import in.ind.mds.dto.PortDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.repo.dao.PortDao;
import in.ind.mds.repo.entity.Port;
import in.ind.mds.service.PortService;
import in.ind.mds.service.SyncDataService;
import in.ind.mds.util.BeanTransformerUtil;
import in.ind.mds.util.CommonUtil;
import in.ind.mds.util.DBUtil;

@Service("TST_MSSQL_PORT")
public class PortServiceImpl implements PortService {

	private static final Logger LOGGER = LoggerFactory.getLogger(PortServiceImpl.class);

	@Autowired
	private BeanTransformerUtil<Port, PortDto> mapEntityToDto;

	@Autowired
	private BeanTransformerUtil<PortDto, Port> mapDtoToEntity;
	
	@Autowired
	@Qualifier("TST_MSSQL_SYNC")
	private SyncDataService syncDataService;
	/*
	 * @Autowired private UserValidator validator;
	 */
	 @Autowired
	 private CommonUtil<PortDto> commonUtil;

	@Autowired
	private PortDao portDao;

	@Autowired
	private DBUtil dbUtil;

	@Override
	public PortDto getByPortId(String portId) throws Exception {
		LOGGER.debug("PortServiceImpl -- getByPortId -- Start");
		commonUtil.stringNullValidator(portId, "PortId");
		Port port = portDao.findByIdAndStatusNot(portId, commonUtil.getSoftDeleteStatus());

		if (port == null) 
			throw new ApplicationServiceExecption("Port not found", HttpStatus.NOT_FOUND);
		
		final PortDto dto = mapEntityToDto.transformBO(port, PortDto.class);
		LOGGER.debug("PortServiceImpl -- getByPortId -- End");
		return dto;
	}

	@Override
	public PortDto findByPortName(String portName) throws Exception {
		LOGGER.debug("PortServiceImpl -- findByPortName -- Start");
		commonUtil.stringNullValidator(portName, "PortName");
		Port port = portDao.findByPortNameAndStatusNot(portName, commonUtil.getSoftDeleteStatus());

		if (port == null) 
			throw new ApplicationServiceExecption("Port not found", HttpStatus.NOT_FOUND);
		
		final PortDto dto = mapEntityToDto.transformBO(port, PortDto.class);
		LOGGER.debug("PortServiceImpl -- findByPortName -- End");
		return dto;
	}

	@Override
	public List<PortDto> findAll() throws Exception {
		LOGGER.debug("PortServiceImpl -- findAll -- Start");
		List<Port> port = portDao.findAllPort();

		if (port.size() == 0) 
			throw new ApplicationServiceExecption("Port not found", HttpStatus.NOT_FOUND);
		
		final List<PortDto> dto = mapEntityToDto.transformListOfBO(port, PortDto.class);
		LOGGER.debug("PortServiceImpl -- findAll -- End");
		return dto;
	}

	@Override
	public PortDto add(PortDto portDto) throws Exception {
		LOGGER.debug("PortServiceImpl -- add -- Start");
		// final String errorMessage = validator.validateAdd(userDto);
		// if (errorMessage != null) {
		// throw new GaurageServiceException(errorMessage, HttpStatus.BAD_REQUEST);
		// }
		/*if(portDto.getId() != null) {
			Optional<Port> existingPort = portDao.findById(portDto.getId());
			if (existingPort.isPresent()) {
				throw new ApplicationServiceExecption("Port exist", HttpStatus.BAD_REQUEST);
			}
		}*/
		commonUtil.stringNullValidator(portDto.getPortName(), "PortName");
		Port port = portDao.findByPortNameAndStatusNot(portDto.getPortName(), commonUtil.getSoftDeleteStatus());
		if(port != null)
			throw new ApplicationServiceExecption("Port already exist", HttpStatus.BAD_REQUEST);
		
		port = mapDtoToEntity.transformBO(portDto, Port.class);

		String seqName = dbUtil.getNextSequence(port.getClass());
		if (seqName != null) {
			port.setId(seqName);
		}
		port.setInsertTime(new Date());
		port.setUpdateTime(new Date());
		port.setStatus(commonUtil.getActiveStatus());
		portDao.save(port);
		syncDataService.syncCreation(port);
		LOGGER.debug("PortServiceImpl -- add -- End");
		return portDto;
	}

	@Override
	public void softDeletePort(String portId) throws Exception {
		LOGGER.debug("PortServiceImpl -- delete -- Start");
		commonUtil.stringNullValidator(portId, "PortId");
		Port existingPort = portDao.findByIdAndStatusNot(portId, commonUtil.getSoftDeleteStatus());
		if (existingPort == null) 
			throw new ApplicationServiceExecption("Port not found", HttpStatus.BAD_REQUEST);
		
		PortDto existingPortDto = mapEntityToDto.transformBO(existingPort, PortDto.class);
		existingPort.setStatus(commonUtil.getSoftDeleteStatus());
		portDao.saveAndFlush(existingPort);
		syncDataService.syncUpdate(mapDtoToEntity.transformBO(existingPortDto, Port.class), existingPort);
		LOGGER.debug("PortServiceImpl -- delete -- End");
	}
	
	@Override
	public List<PortDto> multipleSoftDelete(List<String> portIds) throws Exception {
		LOGGER.debug("PortServiceImpl -- multipleDelete -- Start");
		commonUtil.stringNullValidator(portIds.toArray(), "PortId");
		List<Port> existingPorts = portDao.findByIdInAndStatusNot(portIds, commonUtil.getSoftDeleteStatus());
		
		if (existingPorts.size() < portIds.size()) 
			throw new ApplicationServiceExecption("Port not found", HttpStatus.BAD_REQUEST);
		List<PortDto> existingPortDtos = mapEntityToDto.transformListOfBO(existingPorts, PortDto.class);
		for (Port port : existingPorts) {
			port.setStatus(commonUtil.getSoftDeleteStatus());
			port.setUpdateTime(new Date());
		}
		existingPorts = portDao.saveAll(existingPorts);
		
		int count = 0;
		for (Port port : existingPorts) {
			syncDataService.syncUpdate(mapDtoToEntity.transformBO(existingPortDtos.get(count),Port.class), port);
			count++;
		}
		List<Port> portlist=portDao.findAllPort();
		LOGGER.debug("PortServiceImpl -- multipleDelete -- End");
		return mapEntityToDto.transformListOfBO(existingPorts, PortDto.class);
	}

	@Override
	public PortDto updatePort(PortDto portDto) throws Exception {
		LOGGER.debug("PortServiceImpl -- update -- Start");
		//final String errorMessage = validator.validateAdd(userDto);
		// if (errorMessage != null) {
		// throw new GaurageServiceException(errorMessage, HttpStatus.BAD_REQUEST);
		// }
		commonUtil.stringNullValidator(portDto.getId(), portDto.getPortName(), "Port Id and Name");
		Port existingPort = portDao.findByPortNameAndStatusNotAndIdNot(portDto.getPortName(), commonUtil.getSoftDeleteStatus(), portDto.getId()); 
		if(existingPort != null)
			throw new ApplicationServiceExecption("Port already exist", HttpStatus.BAD_REQUEST);
		 
		existingPort = portDao.findByIdAndStatusNot(portDto.getId(), commonUtil.getSoftDeleteStatus());
		 if(existingPort == null)  
			 throw new ApplicationServiceExecption("Port not found", HttpStatus.BAD_REQUEST); 
		 
		 PortDto currentPort  = mapEntityToDto.transformBO(existingPort, PortDto.class);
		  Port port = mapDtoToEntity.transformBO(portDto, Port.class); 
		 portDao.saveAndFlush(port);
		 syncDataService.syncUpdate(mapDtoToEntity.transformBO(currentPort, Port.class), port);
		 LOGGER.debug("PortServiceImpl -- update -- End");
		 
		return portDto;
	}


}