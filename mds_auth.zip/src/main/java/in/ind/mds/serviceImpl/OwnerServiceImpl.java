package in.ind.mds.serviceImpl;

import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import in.ind.mds.dto.OwnerDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.repo.dao.OwnerDao;
import in.ind.mds.repo.entity.Owner;
import in.ind.mds.service.OwnerService;
import in.ind.mds.service.SyncDataService;
import in.ind.mds.util.BeanTransformerUtil;
import in.ind.mds.util.CommonUtil;
import in.ind.mds.util.DBUtil;

@Service("TST_MSSQL_OWNER")
public class OwnerServiceImpl implements OwnerService {

	private static final Logger LOGGER = LoggerFactory.getLogger(OwnerServiceImpl.class);

	@Autowired
	private BeanTransformerUtil<Owner, OwnerDto> mapEntityToDto;

	@Autowired
	private BeanTransformerUtil<OwnerDto, Owner> mapDtoToEntity;

	@Autowired
	@Qualifier("TST_MSSQL_SYNC")
	private SyncDataService syncDataService;
	/*
	 * @Autowired private UserValidator validator;
	 */
	@Autowired
	private CommonUtil<OwnerDto> commonUtil;

	@Autowired
	private OwnerDao ownerDao;
	
	@Autowired
	private DBUtil dbUtil;
	
	public OwnerDto findByOwnerIdAndOwnerName(final String ownerId, final String ownerName)throws Exception
	{
		LOGGER.debug("OwnerServiceImpl -- getByIdAndName -- Start");
		commonUtil.stringNullValidator(ownerId, ownerName, "OwnerId and OwnerName");
		
		Owner owner = ownerDao.findByIdAndOwnerNameAndStatusNot(ownerId,ownerName, commonUtil.getSoftDeleteStatus());
		if (owner == null) 
			throw new ApplicationServiceExecption("Owner not found", HttpStatus.NOT_FOUND);
		
		final OwnerDto dto = mapEntityToDto.transformBO(owner, OwnerDto.class);
		LOGGER.debug("OwnerServiceImpl -- getByOwnerIdAndOwnerName -- End");
		return dto;
	}

	@Override
	public OwnerDto getByOwnerId(String ownerId) throws Exception {
		LOGGER.debug("OwnerServiceImpl -- getByOwnerId -- Start");
		commonUtil.stringNullValidator(ownerId, "OwnerId");
		Owner owner = ownerDao.findByIdAndStatusNot(ownerId, commonUtil.getSoftDeleteStatus());
		if (owner == null) 
			throw new ApplicationServiceExecption("Owner not found", HttpStatus.NOT_FOUND);
		
		final OwnerDto dto = mapEntityToDto.transformBO(owner, OwnerDto.class);
		LOGGER.debug("OwnerServiceImpl -- getByOwnerId -- End");
		return dto;
	}

	@Override
	public OwnerDto findByOwnerName(String ownerName) throws Exception {
		LOGGER.debug("OwnerServiceImpl -- findByOwnerName -- Start");
		commonUtil.stringNullValidator(ownerName, "OwnerName");
		Owner owner = ownerDao.findByOwnerNameAndStatusNot(ownerName, commonUtil.getSoftDeleteStatus());

		if (owner == null) 
			throw new ApplicationServiceExecption("Owner not found", HttpStatus.NOT_FOUND);
		
		final OwnerDto dto = mapEntityToDto.transformBO(owner, OwnerDto.class);
		LOGGER.debug("OwnerServiceImpl -- findByOwnerName -- End");
		return dto;
	}

	@Override
	public List<OwnerDto> findAll() throws Exception {
		LOGGER.debug("OwnerServiceImpl -- findAll -- Start");
		List<Owner> owner = ownerDao.findAllOwners();
		if (owner.size() == 0) 
			throw new ApplicationServiceExecption("Owner not found", HttpStatus.NOT_FOUND);
		
		final List<OwnerDto> dto = mapEntityToDto.transformListOfBO(owner, OwnerDto.class);
		LOGGER.debug("OwnerServiceImpl -- findAll -- End");
		return dto;
	}
	@Override
	public OwnerDto add(OwnerDto ownerDto) throws Exception {
		LOGGER.debug("OwnerServiceImpl -- add -- Start");
		// final String errorMessage = validator.validateAdd(userDto);
		// if (errorMessage != null) {
		// throw new GaurageServiceException(errorMessage, HttpStatus.BAD_REQUEST);
		// }
		/*Optional<Owner> existingOwner = ownerDao.findById(ownerDto.getId());
		if (existingOwner.isPresent()) {
			throw new ApplicationServiceExecption("Owner exist", HttpStatus.BAD_REQUEST);
		}*/
		commonUtil.stringNullValidator(ownerDto.getOwnerName(), "Owner Name");
		Owner owner = ownerDao.findByOwnerNameAndStatusNot(ownerDto.getOwnerName(), commonUtil.getSoftDeleteStatus());
		if(owner != null)
			throw new ApplicationServiceExecption("Owner already exist", HttpStatus.BAD_REQUEST);
		
		owner = mapDtoToEntity.transformBO(ownerDto, Owner.class);
		String seqName = dbUtil.getNextSequence(owner.getClass());
		if(seqName != null) {
			owner.setId(seqName);
		}
		owner.setInsertTime(new Date());
		owner.setUpdateTime(new Date());
		owner.setStatus(commonUtil.getActiveStatus());
		owner = ownerDao.save(owner);
		syncDataService.syncCreation(owner);
		LOGGER.debug("OwnerServiceImpl -- add -- End");
		return mapEntityToDto.transformBO(owner, OwnerDto.class);
	}
	
	
	@Override
	public List<OwnerDto> softDeleteOwner(List<String> ownerIds) throws Exception {
		LOGGER.debug("OwnerServiceImpl -- delete -- Start");
		// final String errorMessage = validator.validateAdd(userDto);
		// if (errorMessage != null) {
		// throw new GaurageServiceException(errorMessage, HttpStatus.BAD_REQUEST);
		// }
		commonUtil.stringNullValidator(ownerIds.toArray(), "OwnerId");
		List<Owner> existingOwnerList = ownerDao.findByIdInAndStatusNot(ownerIds, commonUtil.getSoftDeleteStatus());
		if (existingOwnerList.size() < ownerIds.size()) 
			throw new ApplicationServiceExecption("Owner not found", HttpStatus.BAD_REQUEST);
		
		List<OwnerDto> existingOwnerDtoList = mapEntityToDto.transformListOfBO(existingOwnerList, OwnerDto.class);
		for (Owner owner : existingOwnerList) {
			owner.setStatus(commonUtil.getSoftDeleteStatus());
			owner.setUpdateTime(new Date());
		}
		existingOwnerList = ownerDao.saveAll(existingOwnerList);
		Integer count = 0;
		for (Owner owner : existingOwnerList) {
			syncDataService.syncUpdate(mapDtoToEntity.transformBO(existingOwnerDtoList.get(count), Owner.class), owner);
			count++;
		}
		List<Owner> ownerList = ownerDao.findAllOwners();
		LOGGER.debug("OwnerServiceImpl -- delete -- End");
		return mapEntityToDto.transformListOfBO(ownerList, OwnerDto.class);
	}

	@Override
	public OwnerDto updateOwner(OwnerDto ownerDto) throws Exception {
		LOGGER.debug("OwnerServiceImpl -- update -- Start");
		// final String errorMessage = validator.validateAdd(userDto);
		// if (errorMessage != null) {
		// throw new GaurageServiceException(errorMessage, HttpStatus.BAD_REQUEST);
		// }
		commonUtil.stringNullValidator(ownerDto.getId(),ownerDto.getOwnerName(), "Owner Id and Name");
		Owner owner = ownerDao.findByOwnerNameAndStatusNotAndIdNot(ownerDto.getOwnerName(), commonUtil.getSoftDeleteStatus(), ownerDto.getId());
		if(owner != null)
			throw new ApplicationServiceExecption("Owner already exist", HttpStatus.BAD_REQUEST);
		
		owner = ownerDao.findByIdAndStatusNot(ownerDto.getId(), commonUtil.getSoftDeleteStatus());
		if (owner == null) 
			throw new ApplicationServiceExecption("Owner not found", HttpStatus.BAD_REQUEST);

		OwnerDto existingOwner = mapEntityToDto.transformBO(owner, OwnerDto.class);
		Owner ownerEntity = mapDtoToEntity.transformBO(ownerDto, Owner.class);
		ownerEntity.setUpdateTime(new Date());
		ownerEntity = ownerDao.saveAndFlush(ownerEntity);
		syncDataService.syncUpdate(mapDtoToEntity.transformBO(existingOwner, Owner.class), ownerEntity);
		LOGGER.debug("OwnerServiceImpl -- update -- End");
		return mapEntityToDto.transformBO(ownerEntity, OwnerDto.class);
	}


	
}
