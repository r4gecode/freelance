/**
 * 
 */
package in.ind.mds.serviceImpl;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.databind.ObjectMapper;

import in.ind.mds.dto.AttendanceDto;
import in.ind.mds.dto.DrillSchedulerDto;
import in.ind.mds.dto.OfficeReviewDto;

import in.ind.mds.dto.ShipBoardTrainingDto;

import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.repo.dao.ShipBoardTrainingDao;
import in.ind.mds.repo.entity.DrillScheduler;
import in.ind.mds.repo.entity.ShipBoardTraining;
import in.ind.mds.service.AttachmentService;
import in.ind.mds.service.AttendanceService;
import in.ind.mds.service.OfficeReviewService;
import in.ind.mds.service.ShipBoardTrainingService;
import in.ind.mds.service.SyncDataService;
import in.ind.mds.util.BeanTransformerUtil;
import in.ind.mds.util.CommonUtil;
import in.ind.mds.util.DBUtil;

/**
 * @author dharani
 *
 */

@Service("TST_MSSQL_SHIPBOARD_TRAINING")
public class ShipBoardTrainingServiceImpl implements ShipBoardTrainingService{
	
	private static final Logger LOGGER = LoggerFactory.getLogger(ShipBoardTrainingServiceImpl.class);

	@Autowired
	private BeanTransformerUtil<ShipBoardTraining, ShipBoardTrainingDto> mapEntityToDto;

	@Autowired
	private BeanTransformerUtil<ShipBoardTrainingDto, ShipBoardTraining> mapDtoToEntity;

	@Autowired
	@Qualifier("TST_MSSQL_SYNC")
	private SyncDataService syncDataService;

	@Autowired
	private CommonUtil<ShipBoardTrainingDto> commonUtil;

	@Autowired
	private ShipBoardTrainingDao shipBoardTrainingDao;

	@Autowired
	@Qualifier("TST_MSSQL_ATTACHEMENT")
	private AttachmentService attachmentService;

	@Autowired
	private DBUtil dbUtil;
	
	@Autowired
	@Qualifier("TST_MSSQL_OFFICE_REVIEW")
	private OfficeReviewService officeReviewService;
	
	@Autowired
	@Qualifier("TST_MSSQL_ATTENDANCE")
	private AttendanceService attendanceService;
	
	

	
	@Override
	public ShipBoardTrainingDto add(String shipBoardTrainingDto,Map<String, MultipartFile[]> attachments) throws Exception {
		LOGGER.debug("ShipBoardTrainingServiceImpl -- add -- Start");
	//ShipBoardTrainingDto shipBoardTrainingDtoList=shipBoardTrainingDtoList.getShipBoardTrainingDto();
		ObjectMapper mapper = new ObjectMapper();
	
			ShipBoardTrainingDto shipBoardTrainingDtoList = mapper.readValue(shipBoardTrainingDto, ShipBoardTrainingDto.class);
	
			//commonUtil.stringNullValidator(shipBoardTrainingDtoList.getTopic(), shipBoardTrainingDtoList.getConductedBy(),shipBoardTrainingDtoList.getConductedDate(), " Topic and conductedBy and conductedDate");
/*			List<ShipBoardTraining> existingShipBoardTrainingList=shipBoardTrainingDao.findByTopicAndConductedByAndConductedDateAndStatusNot(shipBoardTrainingDtoList.getVessel(),shipBoardTrainingDtoList.getTopic(),shipBoardTrainingDtoList.getConductedDate(),commonUtil.getSoftDeleteStatus());
			if(!(existingShipBoardTrainingList.isEmpty()))
				throw new ApplicationServiceExecption("ShipBoardTraining already exist", HttpStatus.BAD_REQUEST);
*/						
			ShipBoardTraining shipBoardTraining= mapDtoToEntity.transformBO(shipBoardTrainingDtoList, ShipBoardTraining.class);
			String seqName = dbUtil.getNextSequence(shipBoardTraining.getClass());
			
			if(seqName != null) 
				shipBoardTraining.setId(seqName);
			
			shipBoardTraining.setInsertTime(new Date());
			shipBoardTraining.setUpdateTime(new Date());
			shipBoardTraining.setStatus(commonUtil.getActiveStatus());
			shipBoardTraining=shipBoardTrainingDao.save(shipBoardTraining);
			syncDataService.syncCreation(shipBoardTraining);
			
			ShipBoardTrainingDto shipBoardTrainingDtos = null;
			shipBoardTrainingDtos = mapEntityToDto.transformBO(shipBoardTraining, ShipBoardTrainingDto.class);
			String id=shipBoardTraining.getId();
			String origin=dbUtil.getTableName(shipBoardTraining.getClass());
			//shipBoardTrainingDto.setShipBoardTrainingDto(shipBoardTrainingDto);
			/***********OfficeReview*****start****/
	List<OfficeReviewDto> officeReviewDtoList = officeReviewService.addAll(id,origin,shipBoardTrainingDtoList.getOfficeReviewDtoList(), attachments.get("officeReviewAtch"));
			shipBoardTrainingDtos.setOfficeReviewDtoList(officeReviewDtoList);
			
			/***********Attendance*****start****/
			List<AttendanceDto> attendanceDtoList = attendanceService.addAll(id,origin,shipBoardTrainingDtoList.getAttendanceDtoList());
			shipBoardTrainingDtos.setAttendanceDtoList(attendanceDtoList);
			
			LOGGER.debug("ShipBoardTrainingServiceImpl -- add -- End");
			return shipBoardTrainingDtos;
			
	}


	
	@Override
	public ShipBoardTrainingDto update(String shipBoardTrainingDto,Map<String, MultipartFile[]> attachments) throws Exception {
		LOGGER.debug("ShipBoardTrainingServiceImpl -- updateStaff -- Start");
	
	
		ObjectMapper mapper = new ObjectMapper();

		ShipBoardTrainingDto shipBoardTrainingDtoList = mapper.readValue(shipBoardTrainingDto, ShipBoardTrainingDto.class);
		commonUtil.stringNullValidator(shipBoardTrainingDtoList.getTopic(),shipBoardTrainingDtoList.getConductedDate(),shipBoardTrainingDtoList.getVessel(), "Topic and ConductedDate and vessel ");
		//List<ShipBoardTraining> existingShipBoardTrainingList=shipBoardTrainingDao.findByTopicAndConductedByAndConductedDateAndStatusNot(shipBoardTrainingDtoList.getVessel(),shipBoardTrainingDtoList.getTopic(),shipBoardTrainingDtoList.getConductedDate(),commonUtil.getSoftDeleteStatus());	
		/*if(!existingShipBoardTrainingList.isEmpty())
			throw new ApplicationServiceExecption("ShipBoardTraining already exist", HttpStatus.BAD_REQUEST);*/
		
		ShipBoardTraining shipBoardTraining = shipBoardTrainingDao.findByIdAndStatusNot(shipBoardTrainingDtoList.getId(), commonUtil.getSoftDeleteStatus());
		if (shipBoardTrainingDto == null) 
			throw new ApplicationServiceExecption("ShipboardTraining not found", HttpStatus.BAD_REQUEST);

		ShipBoardTrainingDto existingShipboardTrainingDto = mapEntityToDto.transformBO(shipBoardTraining, ShipBoardTrainingDto.class);
		shipBoardTraining = mapDtoToEntity.transformBO(shipBoardTrainingDtoList, ShipBoardTraining.class);
		shipBoardTraining.setUpdateTime(new Date());
		shipBoardTrainingDao.saveAndFlush(shipBoardTraining);
		syncDataService.syncUpdate(mapDtoToEntity.transformBO(existingShipboardTrainingDto, ShipBoardTraining.class), shipBoardTraining);
		
		String id=shipBoardTraining.getId();
		String origin=dbUtil.getTableName(shipBoardTraining.getClass());
		
		/**********************OFFICE REVIEW ********************/
		List<String> officeIds = shipBoardTrainingDtoList.getOfficeIds();
		if(!officeIds.isEmpty())
			officeReviewService.softDelete(officeIds);
		
		List<OfficeReviewDto> officeReviewDtoList = shipBoardTrainingDtoList.getOfficeReviewDtoList();
		officeReviewDtoList = officeReviewService.updateAll(id,origin,officeReviewDtoList, attachments.get("officeReviewAtch"));
		shipBoardTrainingDtoList.setOfficeReviewDtoList(officeReviewDtoList);
		/**********************ATTENDANCE  ********************/
		List<String> attendanceIds = shipBoardTrainingDtoList.getAttendanceIds();
		if(!attendanceIds.isEmpty())
			attendanceService.softDelete(attendanceIds);
		
		List<AttendanceDto> attendanceDtoList = shipBoardTrainingDtoList.getAttendanceDtoList();
				attendanceDtoList = attendanceService.updateAll(id,origin,attendanceDtoList );
				shipBoardTrainingDtoList.setOfficeReviewDtoList(officeReviewDtoList);
		return shipBoardTrainingDtoList;
	}

	@Override
	public ShipBoardTrainingDto findById(String id) throws Exception {
			LOGGER.debug("ShipBoardServiceImpl -- FindById -- Start");
			ShipBoardTrainingDto shipBoardTrainingDto = new ShipBoardTrainingDto();
			commonUtil.stringNullValidator(id,"Id");
			ShipBoardTraining shipBoardTraining=shipBoardTrainingDao.findByIdAndStatusNot(id, commonUtil.getSoftDeleteStatus());
			if (shipBoardTraining == null) 
				throw new ApplicationServiceExecption("shipBoardTraining not found", HttpStatus.NOT_FOUND);
			String recId=shipBoardTraining.getId();
			String origin=dbUtil.getTableName(shipBoardTraining.getClass());
			
			ShipBoardTrainingDto shipBoardTrainingDtoList = mapEntityToDto.transformBO(shipBoardTraining, ShipBoardTrainingDto.class);
			/*****************Attendance***************start****************/
			shipBoardTrainingDtoList.setAttendanceDtoList(attendanceService.findByMaster(recId, origin));
			/*****************CrewActivity***************start****************/
			shipBoardTrainingDtoList.setOfficeReviewDtoList(officeReviewService.findByMaster(recId,origin));
			/*****************CrewMedicalReport***************start****************/
			LOGGER.debug("ShipBoardTrainingServiceImpl -- getByStaffId -- End");
			return shipBoardTrainingDtoList;
	}

	@Override
	public List<ShipBoardTrainingDto> findAll() throws Exception {
		LOGGER.debug("ShipBoardTrainingServiceImpl -- findAll -- start");
		List<ShipBoardTraining> shipTrainingList = shipBoardTrainingDao.findAll();
		if (shipTrainingList.isEmpty())
			throw new ApplicationServiceExecption("shipTrainingList not found", HttpStatus.BAD_REQUEST);
		
		LOGGER.debug("shipTrainingListServiceImpl -- findAll -- end");
		return mapEntityToDto.transformListOfBO(shipTrainingList, ShipBoardTrainingDto.class);
	
		
	}

	@Override
	public List<ShipBoardTrainingDto> softDelete(List<String> ids) throws Exception {
		LOGGER.debug("ShipBoardTrainingImpl -- softDelete -- Start");
		commonUtil.stringNullValidator(ids, "Ids");
		
		List<ShipBoardTraining> existingShipBoardTrainingList = shipBoardTrainingDao.findByIdInAndStatusNot(ids, commonUtil.getSoftDeleteStatus());
		if (existingShipBoardTrainingList.size() < ids.size()) 
			throw new ApplicationServiceExecption("ShipBoardTraining not found", HttpStatus.BAD_REQUEST);
		
		List<ShipBoardTrainingDto> existingShipBoardTrainingDtoList = mapEntityToDto.transformListOfBO(existingShipBoardTrainingList, ShipBoardTrainingDto.class);
		for(ShipBoardTraining shipBoardTraining : existingShipBoardTrainingList)
		{
			shipBoardTraining.setStatus(commonUtil.getSoftDeleteStatus());
			shipBoardTraining.setUpdateTime(new Date());
		}
		existingShipBoardTrainingList=shipBoardTrainingDao.saveAll(existingShipBoardTrainingList);
		Integer count=0;
		for(ShipBoardTraining shipBoardTraining : existingShipBoardTrainingList)
		{
			String id=shipBoardTraining.getId();
			String origin=dbUtil.getTableName(shipBoardTraining.getClass());
			syncDataService.syncUpdate(mapDtoToEntity.transformBO(existingShipBoardTrainingDtoList.get(count), ShipBoardTraining.class), shipBoardTraining);
			attachmentService.softDelete(shipBoardTraining.getId(), dbUtil.getTableName(shipBoardTraining.getClass()));
			officeReviewService.softDeleteByMaster(id, origin);
			attendanceService.softDeleteByMaster(id, origin);
			count++;
		}
	
	List<ShipBoardTraining> shipBoardTrainingList = shipBoardTrainingDao.findAll();
	LOGGER.debug("ShipBoardTrainingServiceImpl -- softDelete -- End");
	return mapEntityToDto.transformListOfBO(shipBoardTrainingList, ShipBoardTrainingDto.class); 
	
}

}

