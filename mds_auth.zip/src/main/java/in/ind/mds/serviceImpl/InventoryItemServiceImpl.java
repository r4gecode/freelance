/**
 * 
 */
package in.ind.mds.serviceImpl;

import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import in.ind.mds.dto.InventoryItemDto;
import in.ind.mds.dto.QuantityUpdDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.repo.dao.InventoryItemDao;
import in.ind.mds.repo.dao.QuantityUpdDao;
import in.ind.mds.repo.entity.InventoryItem;
import in.ind.mds.repo.entity.QuantityUpd;
import in.ind.mds.service.InventoryItemService;
import in.ind.mds.service.SyncDataService;
import in.ind.mds.util.BeanTransformerUtil;
import in.ind.mds.util.CommonUtil;
import in.ind.mds.util.DBUtil;

/**
 * @author DeveloperShalini
 *
 */
@Service("TST_MSSQL_INVENTORY_ITEM")
public class InventoryItemServiceImpl implements InventoryItemService {

	private static final Logger LOGGER = LoggerFactory.getLogger(InventoryItemServiceImpl.class);

	@Autowired
	private BeanTransformerUtil<QuantityUpd, QuantityUpdDto> mapEntityToDto;

	@Autowired
	private BeanTransformerUtil<QuantityUpdDto, QuantityUpd> mapDtoToEntity;

	@Autowired
	private BeanTransformerUtil<InventoryItem, InventoryItemDto> mapEntityToDtoInventoryItem;

	@Autowired
	private BeanTransformerUtil<InventoryItemDto, InventoryItem> mapDtoToEntityInventoryItem;

	@Autowired
	@Qualifier("TST_MSSQL_SYNC")
	private SyncDataService syncDataService;

	@Autowired
	private QuantityUpdDao quantityUpdDao;

	@Autowired
	private InventoryItemDao inventoryItemDao;

	@Autowired
	private DBUtil dbUtil;

	@Autowired
	private CommonUtil<QuantityUpdDto> commonUtil;

	@Override
	public List<QuantityUpdDto> updateQuantity(QuantityUpdDto quantityUpdDto) throws Exception {
		LOGGER.debug("InventoryItemServiceImpl -- updateQuantity -- start");
		QuantityUpd quantityUpd = mapDtoToEntity.transformBO(quantityUpdDto, QuantityUpd.class);
		String seqName = dbUtil.getNextSequence(quantityUpd.getClass());
		if (seqName != null)
			quantityUpd.setId(seqName);

		quantityUpd.setInsertedBy(0);
		quantityUpd.setInsertTime(new Date());
		quantityUpd.setUpdatedBy(0);
		quantityUpd.setUpdateTime(new Date());
		quantityUpd.setStatus(commonUtil.getActiveStatus());
		quantityUpd = quantityUpdDao.save(quantityUpd);
		syncDataService.syncCreation(quantityUpd);

		InventoryItem inventoryItem = inventoryItemDao.findByIdAndStatusNot(quantityUpd.getInventoryItem().getId(),
				commonUtil.getSoftDeleteStatus());
		InventoryItemDto inventoryItemDto = mapEntityToDtoInventoryItem.transformBO(inventoryItem,
				InventoryItemDto.class);
		Float currentQuantity = (quantityUpd.getActivityType().getDirection().equals("P"))
				? (inventoryItem.getCurrQty() + quantityUpd.getQuantity())
				: (inventoryItem.getCurrQty() - quantityUpd.getQuantity());
		if (currentQuantity < 0)
			throw new ApplicationServiceExecption("Existing quantity is lesser than updating quantity",
					HttpStatus.BAD_REQUEST);

		inventoryItem.setCurrQty(currentQuantity);
		inventoryItem.setUpdatedBy(0);
		inventoryItem.setUpdateTime(new Date());
		inventoryItem = inventoryItemDao.save(inventoryItem);
		syncDataService.syncUpdate(mapDtoToEntityInventoryItem.transformBO(inventoryItemDto, InventoryItem.class),
				inventoryItem);
		List<QuantityUpd> quantityUpdList = quantityUpdDao.findAllQuantityUpdByInventoryItem(inventoryItem.getId());
		LOGGER.debug("InventoryItemServiceImpl -- updateQuantity -- end");
		return mapEntityToDto.transformListOfBO(quantityUpdList, QuantityUpdDto.class);
	}

	@Override
	public List<QuantityUpdDto> findAllQuantityUpdByInventoryItem(String inventoryItemId) throws Exception {
		LOGGER.debug("InventoryItemServiceImpl -- findQuantityUpdByInventoryItem -- start");
		List<QuantityUpd> quantityUpdList = quantityUpdDao.findAllQuantityUpdByInventoryItem(inventoryItemId);
		if (quantityUpdList.isEmpty())
			throw new ApplicationServiceExecption("QuantityUpd is empty");

		LOGGER.debug("InventoryItemServiceImpl -- findQuantityUpdByInventoryItem -- end");
		return mapEntityToDto.transformListOfBO(quantityUpdList, QuantityUpdDto.class);
	}

	@Override
	public List<InventoryItemDto> findAllInventoryItem() throws Exception {
		LOGGER.debug("InventoryItemServiceImpl -- findAllInventoryItem -- start");
		List<InventoryItem> inventoryItemList = inventoryItemDao.findAllInventoryItem();
		if (inventoryItemList.isEmpty())
			throw new ApplicationServiceExecption("Inventory items not found");

		LOGGER.debug("InventoryItemServiceImpl -- findAllInventoryItem -- end");
		return mapEntityToDtoInventoryItem.transformListOfBO(inventoryItemList, InventoryItemDto.class);
	}

	@Override
	public List<InventoryItemDto> softDeleteInventoryItem(List<String> ids) throws Exception {
		LOGGER.debug("InventoryItemServiceImpl -- softDeleteInventoryItem -- start");
		commonUtil.stringNullValidator(ids.toArray(), "InventoryItem Id");
		List<InventoryItem> inventoryItemList = inventoryItemDao.findByIdInAndStatusNot(ids,
				commonUtil.getSoftDeleteStatus());
		if (inventoryItemList.size() < ids.size())
			throw new ApplicationServiceExecption("InventoryItem id not found");

		List<InventoryItemDto> inventoryItemDtoList = mapEntityToDtoInventoryItem.transformListOfBO(inventoryItemList,
				InventoryItemDto.class);
		for (InventoryItem inventoryItem : inventoryItemList) {
			inventoryItem.setStatus(commonUtil.getSoftDeleteStatus());
			inventoryItem.setUpdateTime(new Date());
		}
		inventoryItemList = inventoryItemDao.saveAll(inventoryItemList);
		Integer count = 0;
		for (InventoryItem inventoryItem : inventoryItemList) {
			syncDataService.syncUpdate(mapDtoToEntityInventoryItem.transformBO(inventoryItemDtoList.get(count), InventoryItem.class), inventoryItem);
			count++;
		}
		inventoryItemList = inventoryItemDao.findAllInventoryItem();
		if (inventoryItemList.isEmpty())
			throw new ApplicationServiceExecption("Inventory items not found");
		LOGGER.debug("InventoryItemServiceImpl -- softDeleteInventoryItem -- end");
		return mapEntityToDtoInventoryItem.transformListOfBO(inventoryItemList, InventoryItemDto.class);
	}

}
