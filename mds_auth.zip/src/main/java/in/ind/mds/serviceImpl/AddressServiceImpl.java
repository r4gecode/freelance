package in.ind.mds.serviceImpl;

import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import in.ind.mds.dto.AddressDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.repo.dao.AddressDao;
import in.ind.mds.repo.entity.Address;
import in.ind.mds.service.AddressService;
import in.ind.mds.service.SyncDataService;
import in.ind.mds.util.BeanTransformerUtil;
import in.ind.mds.util.CommonUtil;
import in.ind.mds.util.DBUtil;


@Service("TST_MSSQL_ADDRESS")
public class AddressServiceImpl implements AddressService {

	private static final Logger LOGGER = LoggerFactory.getLogger(AddressServiceImpl.class);

	@Autowired
	private BeanTransformerUtil<Address, AddressDto> mapEntityToDto;

	@Autowired
	private BeanTransformerUtil<AddressDto, Address> mapDtoToEntity;

	@Autowired
	@Qualifier("TST_MSSQL_SYNC")
	private SyncDataService syncDataService;
	
	@Autowired
	private AddressDao addressDao;
	
	@Autowired
	private CommonUtil<AddressDto> commonUtil;
	
	@Autowired
	private DBUtil dbUtil;

	@Override
	public AddressDto getByAddressId(String addressId) throws Exception {
		LOGGER.debug("AddressServiceImpl -- getByAddressId -- Start");
		commonUtil.stringNullValidator(addressId, "AddressId");
		Address address = addressDao.findByIdAndStatusNot(addressId, commonUtil.getSoftDeleteStatus()); 
		if (address == null) {
			throw new ApplicationServiceExecption("Address not found", HttpStatus.NOT_FOUND);
		}
		final AddressDto dto = mapEntityToDto.transformBO(address, AddressDto.class);
		LOGGER.debug("AddressServiceImpl -- getByAddressId -- End");
		return dto;
	}

	@Override
	public AddressDto findByAddressType(String addressType) throws Exception {
		LOGGER.debug("AddressServiceImpl -- findByAddressType -- Start");
		commonUtil.stringNullValidator(addressType, "AddressType");
		Address address = addressDao.findByAddressTypeAndStatusNot(addressType,commonUtil.getSoftDeleteStatus());
		if (address == null) {
			throw new ApplicationServiceExecption("Address not found", HttpStatus.NOT_FOUND);
		}
		final AddressDto dto = mapEntityToDto.transformBO(address, AddressDto.class);
		LOGGER.debug("AddressServiceImpl -- findByAddressType -- End");
		return dto;
	}

	@Override
	public List<AddressDto> findAll() throws Exception {
		LOGGER.debug("AddressServiceImpl -- findAll -- Start");
		List<Address> address = addressDao.findAllAddress();
		if (address.size() == 0) {
			throw new ApplicationServiceExecption("Address not found", HttpStatus.NOT_FOUND);
		}
		final List<AddressDto> dto = mapEntityToDto.transformListOfBO(address, AddressDto.class);
		LOGGER.debug("AddressServiceImpl -- findByAddressType -- End");
		return dto;
	}

	@Override
	public AddressDto add(AddressDto addressDto) throws Exception {
		LOGGER.debug("AddressServiceImpl -- add -- Start");
		Address address = mapDtoToEntity.transformBO(addressDto, Address.class);
		String seqName = dbUtil.getNextSequence(address.getClass());
		if(seqName != null) {
			address.setId(seqName);
		}
		address.setInsertTime(new Date());
		address.setUpdateTime(new Date());
		address.setStatus(commonUtil.getActiveStatus());
		address = addressDao.save(address);
		syncDataService.syncCreation(address);
		LOGGER.debug("AddressServiceImpl -- add -- End");
		return mapEntityToDto.transformBO(address, AddressDto.class);
	}
	
	
	@Override
	public List<AddressDto> softDeleteAddress(List<String> addressIds) throws Exception {
		LOGGER.debug("AddressServiceImpl -- delete -- Start");
		commonUtil.stringNullValidator(addressIds.toArray(), "AddressId");
		List<Address> existingAddressList = addressDao.findByIdInAndStatusNot(addressIds, commonUtil.getSoftDeleteStatus());
		if (existingAddressList.size() <  addressIds.size()) 
			throw new ApplicationServiceExecption("Address not found", HttpStatus.BAD_REQUEST);

		List<AddressDto> existingAddressDtoList = mapEntityToDto.transformListOfBO(existingAddressList, AddressDto.class);
		for (Address address : existingAddressList) {
			address.setStatus(commonUtil.getSoftDeleteStatus());
			address.setUpdateTime(new Date());
		}
		addressDao.saveAll(existingAddressList);
		Integer count = 0;
		for (Address address : existingAddressList) {
			syncDataService.syncUpdate(mapDtoToEntity.transformBO(existingAddressDtoList.get(count), Address.class), address);
			count++;
		}
		existingAddressList = addressDao.findAllAddress();
		LOGGER.debug("AddressServiceImpl -- delete -- End");
		return mapEntityToDto.transformListOfBO(existingAddressList, AddressDto.class);
	}

	@Override
	public AddressDto updateAddress(AddressDto addressDto) throws Exception {
		LOGGER.debug("AddressServiceImpl -- update -- Start");
		// final String errorMessage = validator.validateAdd(userDto);
		// if (errorMessage != null) {
		// throw new GaurageServiceException(errorMessage, HttpStatus.BAD_REQUEST);
		// }
		commonUtil.stringNullValidator(addressDto.getId(), "AddressId");
		Address existingAddress = addressDao.findByIdAndStatusNot(addressDto.getId(),commonUtil.getSoftDeleteStatus());
		if (existingAddress == null) 
			throw new ApplicationServiceExecption("Address not found", HttpStatus.BAD_REQUEST);

		AddressDto existingAddressDto = mapEntityToDto.transformBO(existingAddress, AddressDto.class);
		Address address = mapDtoToEntity.transformBO(addressDto, Address.class);
		address.setUpdateTime(new Date());
		address = addressDao.saveAndFlush(address);
		syncDataService.syncUpdate(mapDtoToEntity.transformBO(existingAddressDto, Address.class), address);
		LOGGER.debug("AddressServiceImpl -- update -- End");
		return mapEntityToDto.transformBO(address, AddressDto.class);
	}
}
