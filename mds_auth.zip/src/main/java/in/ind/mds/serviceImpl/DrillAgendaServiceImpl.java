/**
 * 
 */
package in.ind.mds.serviceImpl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import in.ind.mds.dto.AttachmentDto;
import in.ind.mds.dto.DrillAgendaDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.repo.dao.DrillAgendaDao;
import in.ind.mds.repo.entity.DrillAgenda;
import in.ind.mds.repo.entity.DrillScheduler;
import in.ind.mds.service.AttachmentService;
import in.ind.mds.service.DrillAgendaService;
import in.ind.mds.service.SyncDataService;
import in.ind.mds.util.BeanTransformerUtil;
import in.ind.mds.util.CommonUtil;
import in.ind.mds.util.DBUtil;

/**
 * @author Hinaya
 *
 */
@Service("TST_MSSQL_DRILL_AGENDA")
public class DrillAgendaServiceImpl implements DrillAgendaService {

	private static final Logger LOGGER = LoggerFactory.getLogger(DrillAgendaServiceImpl.class);

	@Autowired
	private BeanTransformerUtil<DrillAgenda, DrillAgendaDto> mapEntityToDto;

	@Autowired
	private BeanTransformerUtil<DrillAgendaDto, DrillAgenda> mapDtoToEntity;

	@Autowired
	@Qualifier("TST_MSSQL_SYNC")
	private SyncDataService syncDataService;

	@Autowired
	private CommonUtil<DrillAgendaDto> commonUtil;

	@Autowired
	private DrillAgendaDao drillAgendaDao;

	@Autowired
	@Qualifier("TST_MSSQL_ATTACHEMENT")
	private AttachmentService attachmentService;

	@Autowired
	private DBUtil dbUtil;

	@Override
	public List<DrillAgendaDto> add(DrillScheduler drillScheduler, List<DrillAgendaDto> drillAgendaDtoList,
			MultipartFile[] attachmentFiles) throws Exception {
		LOGGER.debug("DrillAgendaServiceImpl -- add -- start");
		drillAgendaDtoList = addDrillAgenda(drillScheduler, drillAgendaDtoList, attachmentFiles);
		LOGGER.debug("DrillAgendaServiceImpl -- add -- end");
		return drillAgendaDtoList;
	}

	private List<DrillAgendaDto> addDrillAgenda(DrillScheduler drillScheduler, List<DrillAgendaDto> drillAgendaDtoList,
			MultipartFile[] attachmentFiles) throws Exception {
		LOGGER.debug("DrillAgendaServiceImpl -- addDrillSchedulerMethod -- start");
		List<DrillAgenda> drillAgendaList = mapDtoToEntity.transformListOfBO(drillAgendaDtoList, DrillAgenda.class);
		for (DrillAgenda drillAgenda : drillAgendaList) {
			String seqName = dbUtil.getNextSequence(drillAgenda.getClass());
			if (seqName != null)
				drillAgenda.setId(seqName);

			drillAgenda.setDrillScheduler(drillScheduler);
			drillAgenda.setInsertTime(new Date());
			drillAgenda.setUpdateTime(new Date());
			drillAgenda.setStatus(commonUtil.getActiveStatus());
		}
		List<DrillAgendaDto> returnDrillAgendaDtoList = mapEntityToDto.transformListOfBO(drillAgendaList, DrillAgendaDto.class);
		Integer count = 0;
		for (DrillAgendaDto drillAgendaDto : drillAgendaDtoList) {
			List<MultipartFile> thisAttachmentFiles = new ArrayList<>();
			for (String drillAgendaDocs : drillAgendaDto.getDrillAgendaDocs()) {
				// Integer index = 0;
				// Integer removeAttachmentIndex = null;
				for (MultipartFile attachment : attachmentFiles) {
					if (drillAgendaDocs.equals(attachment.getOriginalFilename())) {
						thisAttachmentFiles.add(attachment);
						// removeAttachmentIndex = index;
					}
					// index++;
				}
				// ArrayUtils.remove(attachmentFiles, removeAttachmentIndex);
			}
			AttachmentDto attachmentDto = new AttachmentDto();
			attachmentDto.setRecordId(drillAgendaList.get(count).getId());
			attachmentDto.setAttachmentOrigin(
					dbUtil.getTableName((mapDtoToEntity.transformBO(drillAgendaDto, DrillAgenda.class)).getClass()));
			attachmentDto.setAttachmentType(drillAgendaDto.getDrillAgendaDocFieldName());
			List<String> drillSchedulerDocPathList = attachmentService.add(attachmentDto, thisAttachmentFiles);
			returnDrillAgendaDtoList.get(count).setDrillAgendaDocs(drillSchedulerDocPathList);
			count++;
		}
		drillAgendaDao.saveAll(drillAgendaList);
		for (DrillAgenda drillAgenda : drillAgendaList) {
			syncDataService.syncCreation(drillAgenda);
		}
		LOGGER.debug("DrillAgendaServiceImpl -- addDrillSchedulerMethod -- end");
		return returnDrillAgendaDtoList;
	}

	@Override
	public List<DrillAgendaDto> update(DrillScheduler drillScheduler, List<DrillAgendaDto> drillAgendaDtoList,
			MultipartFile[] attachmentFiles) throws Exception {
		LOGGER.debug("BankAccountServicImpl -- update -- start");
		List<DrillAgendaDto> drillAgendaDtoListForAdd = new ArrayList<>();
		List<DrillAgendaDto> drillAgendaListForUpdate = new ArrayList<>();
		for (DrillAgendaDto drillAgendaDto : drillAgendaDtoList) {
			if(drillAgendaDto.getId() == null)
				drillAgendaDtoListForAdd.add(drillAgendaDto);
			else
				drillAgendaListForUpdate.add(drillAgendaDto);
		}
		if(!drillAgendaDtoListForAdd.isEmpty())
			drillAgendaDtoList = addDrillAgenda(drillScheduler, drillAgendaDtoListForAdd, attachmentFiles);
		
		List<String> drillAgendaIds = drillAgendaListForUpdate.stream().map(i -> i.getId()).collect(Collectors.toList());
		List<DrillAgenda> drillAgendaList = drillAgendaDao.findByIdInAndStatusNot(drillAgendaIds, commonUtil.getSoftDeleteStatus());
		if(drillAgendaList.size() < drillAgendaIds.size())
			throw new ApplicationServiceExecption("Drill Agenda not found");
		
		List<DrillAgendaDto> existingDrillAgendaDtoList = mapEntityToDto.transformListOfBO(drillAgendaList, DrillAgendaDto.class);
		drillAgendaList = mapDtoToEntity.transformListOfBO(drillAgendaListForUpdate, DrillAgenda.class);
		for (DrillAgenda drillAgenda : drillAgendaList) {
			drillAgenda.setUpdateTime(new Date());
		}
		
		
		/**********************delete and add attachments of DrillAgenda********start**********/
		List<DrillAgendaDto> returnDrillAgendaDtoListForUpdate = mapEntityToDto.transformListOfBO(drillAgendaList, DrillAgendaDto.class);
		Integer count = 0;
		for (DrillAgendaDto drillAgendaDto : drillAgendaListForUpdate) {
			if(!drillAgendaDto.getSoftDeleteDocPaths().isEmpty()) 
				attachmentService.softDeleteByPathList(drillAgendaDto.getSoftDeleteDocPaths());
			
			List<MultipartFile> thisAttachmentFiles = new ArrayList<>();
				for (String drillAgendaDoc : drillAgendaDto.getDrillAgendaDocs()) {
					//Integer index = 0;
					//Integer removeAttachmentIndex = null;
					for (MultipartFile attachment : attachmentFiles) {
						if(drillAgendaDoc.equals(attachment.getOriginalFilename())) {
							thisAttachmentFiles.add(attachment); 
							//removeAttachmentIndex = index;
						}
						//index++;
					}
					//ArrayUtils.remove(attachmentFiles, removeAttachmentIndex);
				}
			AttachmentDto attachmentDto = new AttachmentDto();
			attachmentDto.setRecordId(drillAgendaList.get(count).getId());
			attachmentDto.setAttachmentOrigin(dbUtil.getTableName((mapDtoToEntity.transformBO(drillAgendaDto, DrillAgenda.class)).getClass()));
			attachmentDto.setAttachmentType(drillAgendaDto.getDrillAgendaDocFieldName());
			List<String> drillAgendaDocPathList = attachmentService.add(attachmentDto, thisAttachmentFiles);
			returnDrillAgendaDtoListForUpdate.get(count).setDrillAgendaDocs(drillAgendaDocPathList);
			count++;
		}
		/**********************delete and add attachments of BankAccount********end**********/
		
		drillAgendaDao.saveAll(drillAgendaList);
		count = 0;
		for (DrillAgenda drillAgenda : drillAgendaList) {
			syncDataService.syncUpdate(mapDtoToEntity.transformBO(existingDrillAgendaDtoList.get(count), DrillAgenda.class), drillAgenda);
			count++;
		}
		drillAgendaDtoList.addAll(returnDrillAgendaDtoListForUpdate);
		LOGGER.debug("BankAccountServicImpl -- update -- end");
		return drillAgendaDtoList;
	}

	@Override
	public List<DrillAgendaDto> findByDrillScheduler(DrillScheduler drillScheduler) throws Exception {
		LOGGER.debug("BankAccountServicImpl -- findByStaff -- start");
		List<DrillAgendaDto> drillAgendaDtoList = new ArrayList<>();
		List<DrillAgenda> drillAgendaList = drillAgendaDao.findByDrillSchedulerAndStatusNot(drillScheduler, commonUtil.getSoftDeleteStatus());
		if(drillAgendaList.isEmpty())
			return drillAgendaDtoList;
		
		drillAgendaDtoList = mapEntityToDto.transformListOfBO(drillAgendaList, DrillAgendaDto.class);
		String attachmentOrigin = dbUtil.getTableName(drillAgendaList.get(0).getClass());
		for (DrillAgendaDto drillAgendaDto : drillAgendaDtoList) {
			AttachmentDto attachmentDto = new AttachmentDto();
			attachmentDto.setAttachmentOrigin(attachmentOrigin);
			attachmentDto.setRecordId(drillAgendaDto.getId());
			attachmentDto.setAttachmentType(drillAgendaDto.getDrillAgendaDocFieldName());
			drillAgendaDto.setDrillAgendaDocs(attachmentService.findAttachments(attachmentDto));
		}
		LOGGER.debug("BankAccountServicImpl -- findByDrillScheduler -- end");
		return drillAgendaDtoList;
	}

	@Override
	public void softDeleteByDrillScheduler(DrillScheduler drillScheduler) throws Exception {
		LOGGER.debug("DrillAgendaServiceImpl -- softDelete -- start");
		List<DrillAgenda> drillAgendaList = drillAgendaDao.findByDrillSchedulerAndStatusNot(drillScheduler, commonUtil.getSoftDeleteStatus());
		List<DrillAgendaDto> drillAgendaDtoList = mapEntityToDto.transformListOfBO(drillAgendaList, DrillAgendaDto.class);
		for (DrillAgenda drillAgenda : drillAgendaList) {
			drillAgenda.setUpdateTime(new Date());
			drillAgenda.setStatus(commonUtil.getSoftDeleteStatus());
		}
		Integer count = 0;
		for (DrillAgenda drillAgenda : drillAgendaList) {
			syncDataService.syncUpdate(mapDtoToEntity.transformBO(drillAgendaDtoList.get(count), DrillAgenda.class), drillAgenda);
			attachmentService.softDelete(drillAgenda.getId(), dbUtil.getTableName(drillAgenda.getClass()));
			count++;
		}
		LOGGER.debug("DrillAgendaServiceImpl -- softDelete -- end");
	}

	@Override
	public void softDelete(List<String> ids) throws Exception {
		LOGGER.debug("DrillAgendaServiceImpl -- softDelete -- start");
		commonUtil.stringNullValidator(ids.toArray(), "DrillAgenda Id");
		List<DrillAgenda> drillAgendaList = drillAgendaDao.findByIdInAndStatusNot(ids, commonUtil.getSoftDeleteStatus());
		if(drillAgendaList.size() <  ids.size())
			throw new ApplicationServiceExecption("DrillAgenda not found");
		
		List<DrillAgendaDto> drillAgendaDtoList = mapEntityToDto.transformListOfBO(drillAgendaList, DrillAgendaDto.class);
		for (DrillAgenda drillAgenda : drillAgendaList) {
			drillAgenda.setUpdateTime(new Date());
			drillAgenda.setStatus(commonUtil.getSoftDeleteStatus());
		}
		Integer count = 0;
		for (DrillAgenda drillAgenda : drillAgendaList) {
			syncDataService.syncUpdate(mapDtoToEntity.transformBO(drillAgendaDtoList.get(count), DrillAgenda.class), drillAgenda);
			attachmentService.softDelete(drillAgenda.getId(), dbUtil.getTableName(drillAgenda.getClass()));
			count++;
		}
	LOGGER.debug("DrillAgendaServiceImpl -- softDelete -- end");
}

}
