package in.ind.mds.serviceImpl;

import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.StringTokenizer;
import java.util.stream.Stream;

import javax.transaction.Transactional;

import org.apache.tomcat.util.http.fileupload.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.repo.dao.SyncDataDao;
import in.ind.mds.repo.dao.SyncEventDao;
import in.ind.mds.repo.entity.SyncData;
import in.ind.mds.repo.entity.SyncEvent;
import in.ind.mds.service.SyncEventService;
import in.ind.mds.util.ApplicationPropertiesUtil;
import in.ind.mds.util.CommonUtil;
import in.ind.mds.util.DBUtil;
import net.lingala.zip4j.core.ZipFile;
import net.lingala.zip4j.exception.ZipException;
import net.lingala.zip4j.model.ZipParameters;
import net.lingala.zip4j.util.Zip4jConstants;

@Service("TST_MSSQL_SYNCEVENT")
public class SyncEventServiceImpl implements SyncEventService {
	private static final Logger LOGGER = LoggerFactory.getLogger(SyncEventServiceImpl.class);

	private static final String fileExtn="mdssync";
	@Autowired
	private SyncDataDao syncDataDao;

	@Autowired
	private SyncEventDao syncEventDao;

	@Autowired
	private DBUtil dbUtil;

	@Autowired
	private ApplicationPropertiesUtil configProperties;
	
	/**
	 * Method to create sync event first
	 * 1. get prev max seq + 1 and extract till latest
	 * 2. If previous seq is 0, extract all available
	 * **/
	@Override
	public SyncEvent syncEventCreation(String senderId, String receiverId, String syncType, String syncMode) throws Exception {
		LOGGER.debug("SyncEventServiceImpl -- syncEventCreation -- Start");
		//Get min and max sequence numbers
		List<Object> sequences = getMinMaxSequences(receiverId);
		Object[] sequenceArr = null;
		int minSeq = -1;
		int maxSeq = -1;
		SyncEvent syncEvent = null;
		if (sequences != null && !sequences.isEmpty()) {
			sequenceArr = (Object[]) sequences.get(0);
			if (sequenceArr != null && sequenceArr.length >0
					&& sequenceArr[0] != null) {
				minSeq = (Integer)sequenceArr[0];
				maxSeq = (Integer)sequenceArr[1];
			} 
		} else {
			throw new ApplicationServiceExecption("Can't find export data for the selected Vessel",
					HttpStatus.EXPECTATION_FAILED);
		}
		
		//Create sync event
		if (minSeq > 0 && maxSeq > 0) {
			int packetNo = syncEventDao.calculatePacketNo(receiverId);
			LOGGER.debug("SyncEventServiceImpl -- syncEventCreation -- End");
			syncEvent = populateData(packetNo, syncType, minSeq, maxSeq, receiverId,syncMode);
			syncEventDao.save(syncEvent);
		} else {
			throw new ApplicationServiceExecption("Can't find export data for the selected Vessel",
					HttpStatus.EXPECTATION_FAILED);
		}
	 return syncEvent;
	}

	private List<Object> getMinMaxSequences(String receiverId) {
		String status = "Sent";
		List<Object> sequenceNos = syncEventDao.fromSeqToSeqEvent(receiverId, status);

		return sequenceNos;
	}
	
	private SyncEvent populateData(int packetNo, String syncType, int fromSeq, int toSeq, String receiverId, String syncMode) {
		SyncEvent syncEvent = new SyncEvent();
		syncEvent.setFromSeq(fromSeq);
		syncEvent.setToSeq(toSeq);
		syncEvent.setSyncPacketNo(packetNo);
		syncEvent.setSyncCompletionTime(new Date());
		syncEvent.setExportCount(4);
		syncEvent.setSyncStatus("Sent");
		syncEvent.setSyncMode(syncMode);
		syncEvent.setSyncType(syncType);
		syncEvent.setSenderId("Office");
		syncEvent.setReceiverId(receiverId);
		syncEvent.setSyncFileName("DT_OFF_TO_" + receiverId + "_" + new Date());
		return syncEvent;
	}

	private void process(String str) throws Exception {
		System.out.println(str);
		int count = 0;
		String jsonData = null;
		String entityClassName = null;
		String action = null;
		ObjectMapper mapper = new ObjectMapper();
		mapper.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
		mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);

		String[] strArray = StringUtils.split(str, "|");
		StringTokenizer tokenizer = new StringTokenizer(str, "|");

		for (String data : strArray) {
			System.out.println("split data-->" + data);
		}

		while (tokenizer.hasMoreTokens()) {

			if (count == 1) {
				// System.out.println("class name==>"+tokenizer.nextToken());
				entityClassName = tokenizer.nextToken();
			} else if (count == 2) {
				jsonData = tokenizer.nextToken();
			} else {
				action= tokenizer.nextToken();
			}
			count++;

		}
		if(!jsonData.startsWith("{")) {
			jsonData = "{"+jsonData+"}";
		}
		System.out.println("json ==>" + jsonData);
		System.out.println("entity==>" + entityClassName);
		Object obj = mapper.readValue(jsonData, Class.forName(entityClassName));
		if("A".equals(action)) {
			dbUtil.saveEntity(obj);
		}else {
			dbUtil.updateEntity(obj);
		}
		
		System.out.println(obj);
		// Call Entity manager save : do not flush or commit
	}

	@Override
	public boolean syncEventImport(String path) throws Exception {
		unCompressPasswordProtectedFiles(path);
		try (Stream<String> lines = Files.lines(Paths.get(path), Charset.defaultCharset())) {
			lines.forEachOrdered(line -> {
				try {
					process(line);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			});
			return true;
		}
	}

	@Transactional(rollbackOn = Exception.class)
	@Override
	public String exportSyncDataList(String senderId, String receiverId, String syncType) throws Exception {
		LOGGER.debug("SyncServiceImpl -- exportSyncDataList -- Start");
		List<SyncData> syncDataList 	= null;
		StringBuilder syncDataOutput 	= null;
		StringBuilder syncEventOutput 	= null;
		
		LocalDateTime now = LocalDateTime.now(); // 2015-11-19T19:42:19.224
		// start of a day
		now.with(LocalTime.MIN); // 2015-11-19T00:00
		now.with(LocalTime.MIDNIGHT); // 2015-11-19T00:00
		// end of a day
		now.with(LocalTime.MAX);

		//Create Sync Event
		SyncEvent event = syncEventCreation(senderId,receiverId, syncType,"export");
		
		if(event != null) {
			//Get sync event data and perform export
			syncDataList = syncDataDao.retrieveSyncData(event.getFromSeq(), event.getToSeq());

			if (syncDataList == null) {
				throw new ApplicationServiceExecption("SyncData Not available for export :", HttpStatus.EXPECTATION_FAILED);
			}			
		}


		/*
		 * String listString = syncDataList.stream().map(Object::toString)
		 * .collect(Collectors.joining("| "));
		 */
		syncDataOutput = new StringBuilder();
		for (SyncData data : syncDataList) {
			syncDataOutput.append(data.getAction() + "|" +data.getEntityClassName() + "|"+ data.getSyncData().trim());
			syncDataOutput.append("\n");
		}


		syncEventOutput = new StringBuilder();
		syncEventOutput.append(event.getSyncType() + "|" + event.getToSeq() + "|"
					+ event.getSenderId() + "|" + event.getReceiverId() + "|" + event.getSyncPacketNo()
					+ "|" + event.getFromSeq() + "|" + event.getSyncMode() + "|" + event.getDbVersion()
					+ "|" + event.getConfirmedSeqNo() + "|" + event.getConfirmedPacketNo());
		
		String fileName = generateExportFile(syncDataOutput, syncEventOutput,  event);
		
		event.setSyncFileName(fileName);
		syncEventDao.save(event);
		LOGGER.debug("SyncServiceImpl -- exportSyncDataList -- End");
		return fileName;
	}

	
	private String generateExportFile(StringBuilder syncDataOutput, StringBuilder syncEventOutput, SyncEvent event)
			throws IOException, UnsupportedEncodingException, Exception {
		Path jsonPath;
		Path eventDataPath;
		String folderRootPath = configProperties.syncRootFolder();
		String zipPath 		  = configProperties.syncRootFolder();
		String dateFormat	  = configProperties.dateFormat();
		String zipFileName 	  = null;
		String inputFolderName = "input";
		ArrayList<File> filesList = null;

		//Clear the input folder
		FileUtils.cleanDirectory(new File(folderRootPath+"\\"+"export"+"\\"+inputFolderName)); 
		//TODO : change sequence  001 to dynamic one based on file size
		jsonPath = Paths.get(folderRootPath, "export",inputFolderName, event.getSenderId()+"_"+event.getReceiverId()+"_"+"001"+"_"+CommonUtil.getUTCTimeString(dateFormat) + ".json");
		eventDataPath = Paths.get(folderRootPath,  "export",inputFolderName, event.getSenderId()+"_"+event.getReceiverId()+"_"+"001"+"_"+ CommonUtil.getUTCTimeString(dateFormat)+ ".txt");

		//boolean isReadble = Files.isReadable(jsonPath);
		Files.deleteIfExists(jsonPath);
		Files.deleteIfExists(eventDataPath);
		Files.createFile(jsonPath);
		Files.createFile(eventDataPath);
		Files.write(jsonPath, syncDataOutput.toString().getBytes("UTF-8"));
		Files.write(eventDataPath, syncEventOutput.toString().getBytes("UTF-8"));

		try {
			filesList = new ArrayList<File>();
			filesList.add(jsonPath.toFile());
			filesList.add(eventDataPath.toFile());
			zipFileName = compressWithPassword(filesList, zipPath, event);
		} catch (ZipException e) {
			// TODO Store exception and throw back error id
			e.printStackTrace();
			throw new ApplicationServiceExecption("Zip file creation failed :", HttpStatus.EXPECTATION_FAILED);
		}
		return zipFileName;
	}

	private String compressWithPassword(ArrayList<File> filesList, String zipPath, SyncEvent event) throws Exception {
		String dateFormat	  = configProperties.dateFormat();
		String destPath = zipPath +"\\"+"export"+ "\\"+"input"+"\\"+event.getSenderId()+"_"+event.getReceiverId()+"_"+"001"+"_"+event.getSyncPacketNo()+"_"+CommonUtil.getUTCTimeString(dateFormat)+"."+fileExtn;
		String archivePath = zipPath +"\\"+"export"+ "\\"+"archive"+"\\"+event.getSenderId()+"_"+event.getReceiverId()+"_"+"001"+"_"+event.getSyncPacketNo()+"_"+CommonUtil.getUTCTimeString(dateFormat)+"."+fileExtn;
		System.out.println("Destination " + destPath);
		ZipFile zipFile = new ZipFile(destPath);
		// Setting parameters
		ZipParameters zipParameters = new ZipParameters();
		zipParameters.setCompressionMethod(Zip4jConstants.COMP_DEFLATE);
		zipParameters.setCompressionLevel(Zip4jConstants.DEFLATE_LEVEL_ULTRA);
		zipParameters.setEncryptFiles(true);
		zipParameters.setEncryptionMethod(Zip4jConstants.ENC_METHOD_AES);
		zipParameters.setAesKeyStrength(Zip4jConstants.AES_STRENGTH_256);
		// TODO : Setting password
		zipParameters.setPassword("test");
		zipFile.addFiles(filesList, zipParameters);
		Files.move(Paths.get(destPath), Paths.get(archivePath), StandardCopyOption.REPLACE_EXISTING);
		for(File file : filesList) {
			file.delete();
		}
		return  new File(archivePath).getCanonicalPath();
	}

	private String unCompressPasswordProtectedFiles(String sourcePath) throws Exception {
		String destPath = getFileName(sourcePath);
		System.out.println("Destination " + destPath);
		ZipFile zipFile = new ZipFile(sourcePath);
		// If it is encrypted then provide password
		if (zipFile.isEncrypted()) {
			zipFile.setPassword("test");
		}
		zipFile.extractAll(destPath);
		
		return destPath;
	}

	private String getFileName(String filePath) {
		// Get the folder name from the zipped file by removing .zip extension
		return filePath.substring(0, filePath.lastIndexOf("."));
	}
	
	/***
	 * 1. Unzip the file : password protected
	 * 2. Perform validation - check the sequence is correct or not
	 * 3. Check previous imports are successful or not
	 * 4. Check for any pending packets
	 * 5. Import all data and commit
	 * **/
	@Transactional(rollbackOn = Exception.class)
	@Override
	public String importSyncData(String path, String receiverId, String syncType) throws Exception {
		
		processFiles(path, receiverId, syncType);
		
		return null;
	}

		

	private void processFiles(String path, String receiverId, String syncType) throws Exception {
		String zipPath = configProperties.syncRootFolder();
		String importPath = zipPath + "\\" + "import" + "\\" + "input" + "\\";

		Path configFilePath = Paths.get(importPath);
		// String unzippedFolder = null;
		// Read all the import files
		Files.list(configFilePath).filter(Files::isRegularFile).filter(s -> s.toString().endsWith("mdssync"))
				.forEach(line -> {
					try {
						System.out.println(line);
						// Process one by one file
						// Unzip
						String unzippedFolder = unCompressPasswordProtectedFiles(line.toString());
						validateAndProcessFile(unzippedFolder);
						//Remove Folder 
						//Move zip to archive and Remove zip file from input folder
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				});

	}
	
	private void validateAndProcessFile(String folderPath) throws Exception {
		Path configFilePath = Paths.get(folderPath);
		Files.list(configFilePath).filter(Files::isRegularFile).filter(s -> s.toString().endsWith("json"))
				.forEach(line -> {
					try {
						System.out.println(line);
						// TODO : Validate
						//TODO : Create Sync Event
						//syncEvent = populateData(packetNo, syncType, minSeq, maxSeq, receiverId,syncMode);
						//syncEventDao.save(syncEvent);
						// Process
						processFile(line);
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				});
	}
	
	public boolean processFile(Path filePath) throws Exception {
		try (Stream<String> lines = Files.lines(filePath, Charset.defaultCharset())) {
			lines.forEachOrdered(line -> {
				try {
					process(line);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			});
			return true;
		}
	}	
}
