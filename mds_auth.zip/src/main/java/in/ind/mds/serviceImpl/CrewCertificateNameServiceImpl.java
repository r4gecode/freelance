/**
 * 
 */
package in.ind.mds.serviceImpl;

import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import in.ind.mds.dto.CrewCertificateNameDto;
import in.ind.mds.dto.FleetDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.repo.dao.CrewCertificateNameDao;
import in.ind.mds.repo.dao.FleetDao;
import in.ind.mds.repo.entity.CrewCertificateName;
import in.ind.mds.repo.entity.Fleet;
import in.ind.mds.service.CrewCertificateNameService;
import in.ind.mds.service.SyncDataService;
import in.ind.mds.util.BeanTransformerUtil;
import in.ind.mds.util.CommonUtil;
import in.ind.mds.util.DBUtil;

/**
 * @author mds_kiruthika
 *
 */
@Service("TST_MSSQL_CREW_CERTIFICATE_NAME")
public class CrewCertificateNameServiceImpl implements CrewCertificateNameService {

	private static final Logger LOGGER = LoggerFactory.getLogger(CrewCertificateNameServiceImpl.class);

	@Autowired
	private BeanTransformerUtil<CrewCertificateName, CrewCertificateNameDto> mapEntityToDto;

	@Autowired
	private BeanTransformerUtil<CrewCertificateNameDto, CrewCertificateName> mapDtoToEntity;

	@Autowired
	@Qualifier("TST_MSSQL_SYNC")
	private SyncDataService syncDataService;

	@Autowired
	private CrewCertificateNameDao crewCertificateNameDao;

	@Autowired
	private DBUtil dbUtil;

	@Autowired
	private CommonUtil<CrewCertificateNameDao> commonUtil;
	
	@Override
	public CrewCertificateNameDto add(CrewCertificateNameDto certificateNameDto) throws Exception {
		// TODO Auto-generated method stub
		LOGGER.debug("CrewCertificateNameServiceImpl -- add -- Start");
		
		commonUtil.stringNullValidator(certificateNameDto.getCertificateName(), "CertificateName");
		CrewCertificateName crewCertificateName = crewCertificateNameDao.findByCertificateNameAndStatusNot(certificateNameDto.getCertificateName(), commonUtil.getSoftDeleteStatus());
		if (crewCertificateName != null)
			throw new ApplicationServiceExecption("Crew Certificate Name already exist", HttpStatus.BAD_REQUEST);

		crewCertificateName = mapDtoToEntity.transformBO(certificateNameDto, CrewCertificateName.class);
		String seqName = dbUtil.getNextSequence(crewCertificateName.getClass());
		if (seqName != null) {
			crewCertificateName.setId(seqName);
		}
		crewCertificateName.setInsertTime(new Date());
		crewCertificateName.setUpdateTime(new Date());
		crewCertificateName.setStatus(commonUtil.getActiveStatus());
		crewCertificateName = crewCertificateNameDao.save(crewCertificateName);
		syncDataService.syncCreation(crewCertificateName);
		LOGGER.debug("CrewCertificateNameServiceImpl -- add -- End");
		return mapEntityToDto.transformBO(crewCertificateName, CrewCertificateNameDto.class);
	}

	
	@Override
	public CrewCertificateNameDto findByCertificateNameId(String certificateId) throws Exception {
		// TODO Auto-generated method stub
		LOGGER.debug("CrewCertificateNameServiceImpl -- add -- Start");

		commonUtil.stringNullValidator(certificateId, "CertificateId");
		CrewCertificateName crewCertificateName = crewCertificateNameDao.findByIdAndStatusNot(certificateId, commonUtil.getSoftDeleteStatus());
		if (crewCertificateName == null)
			throw new ApplicationServiceExecption("Crew Certificate Name not found", HttpStatus.NOT_FOUND);
		
		LOGGER.debug("CrewCertificateNameServiceImpl -- add -- End");

		return mapEntityToDto.transformBO(crewCertificateName, CrewCertificateNameDto.class);

	}

	
	@Override
	public List<CrewCertificateNameDto> findAllCrewCertificate() throws Exception {
		// TODO Auto-generated method stub
		LOGGER.debug("CrewCertificateNameServiceImpl -- add -- Start");

		List<CrewCertificateName> crewCertificateNames = crewCertificateNameDao.findAllCrewCertificate();
		if (crewCertificateNames.size() == 0)
			throw new ApplicationServiceExecption("Crew Certificate Name not found", HttpStatus.NOT_FOUND);

		LOGGER.debug("CrewCertificateNameServiceImpl -- add -- End");
		return mapEntityToDto.transformListOfBO(crewCertificateNames, CrewCertificateNameDto.class);
		
	}

	
	@Override
	public List<CrewCertificateNameDto> softDeleteCertificateName(List<String> cerNameIds) throws Exception {
		// TODO Auto-generated method stub
		LOGGER.debug("CrewCertificateNameServiceImpl -- add -- Start");

		commonUtil.stringNullValidator(cerNameIds.toArray(), "CertificateId");
		List<CrewCertificateName> existingCertificateNameList = crewCertificateNameDao.findByIdInAndStatusNot(cerNameIds, commonUtil.getSoftDeleteStatus());
		if (existingCertificateNameList.size() < cerNameIds.size())
			throw new ApplicationServiceExecption("Crew Certificate Name  not found", HttpStatus.NOT_FOUND);

		List<CrewCertificateNameDto> existingCerNameDtoList = mapEntityToDto.transformListOfBO(existingCertificateNameList, CrewCertificateNameDto.class);
		for (CrewCertificateName crewCertificateName : existingCertificateNameList) {
			crewCertificateName.setStatus(commonUtil.getSoftDeleteStatus());
			crewCertificateName.setUpdateTime(new Date());
		}
		existingCertificateNameList = crewCertificateNameDao.saveAll(existingCertificateNameList);
		Integer count = 0;
		for (CrewCertificateName crewCertificateName  : existingCertificateNameList) {
			syncDataService.syncUpdate(mapDtoToEntity.transformBO(existingCerNameDtoList.get(count), CrewCertificateName.class), crewCertificateName);
			count++;
		}
		existingCertificateNameList = crewCertificateNameDao.findAllCrewCertificate();
		LOGGER.debug("CrewCertificateNameServiceImpl -- add -- End");
		return mapEntityToDto.transformListOfBO(existingCertificateNameList, CrewCertificateNameDto.class);
	}

	@Override
	public CrewCertificateNameDto updateCertificateName(CrewCertificateNameDto certificateNameDto) throws Exception {
		// TODO Auto-generated method stub
		LOGGER.debug("CrewCertificateNameServiceImpl -- add -- Start");

		commonUtil.stringNullValidator(certificateNameDto.getCertificateName(), certificateNameDto.getId(), "Fleet Id and Name");
		CrewCertificateName crewCertificateName = crewCertificateNameDao.findByCertificateNameAndStatusNotAndIdNot(certificateNameDto.getCertificateName(),
				commonUtil.getSoftDeleteStatus(), certificateNameDto.getId());
		if (crewCertificateName != null)
			throw new ApplicationServiceExecption("Crew Certificate Name  already exist", HttpStatus.BAD_REQUEST);

		crewCertificateName = crewCertificateNameDao.findByIdAndStatusNot(certificateNameDto.getId(), commonUtil.getSoftDeleteStatus());
		if (crewCertificateName == null)
			throw new ApplicationServiceExecption("Crew Certificate Name  not found", HttpStatus.NOT_FOUND);

		CrewCertificateNameDto existingCertificateNameDto = mapEntityToDto.transformBO(crewCertificateName, CrewCertificateNameDto.class);
		CrewCertificateName crewCertificateNameEntity = mapDtoToEntity.transformBO(certificateNameDto, CrewCertificateName.class);
		crewCertificateNameEntity.setUpdateTime(new Date());
		crewCertificateNameEntity = crewCertificateNameDao.saveAndFlush(crewCertificateNameEntity);
		syncDataService.syncUpdate(mapDtoToEntity.transformBO(existingCertificateNameDto, CrewCertificateName.class), crewCertificateNameEntity);
		LOGGER.debug("CrewCertificateNameServiceImpl -- add -- End");
		return mapEntityToDto.transformBO(crewCertificateNameEntity, CrewCertificateNameDto.class);
		
	}

}
