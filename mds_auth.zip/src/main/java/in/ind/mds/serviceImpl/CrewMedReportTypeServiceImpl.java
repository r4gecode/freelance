/**
 * 
 */
package in.ind.mds.serviceImpl;

import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import in.ind.mds.dto.CrewMedReportTypeDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.repo.dao.CrewMedReportTypeDao;
import in.ind.mds.repo.entity.CrewMedReportType;
import in.ind.mds.service.CrewMedReportTypeService;
import in.ind.mds.service.SyncDataService;
import in.ind.mds.util.BeanTransformerUtil;
import in.ind.mds.util.CommonUtil;
import in.ind.mds.util.DBUtil;

/**
 * @author mds-arockia
 *
 */
@Service("TST_MSSQL_CREW_MED_REPORT_TYPE")
public class CrewMedReportTypeServiceImpl implements CrewMedReportTypeService {

	private static final Logger LOGGER = LoggerFactory.getLogger(CrewMedReportTypeServiceImpl.class);

	@Autowired
	private BeanTransformerUtil<CrewMedReportType, CrewMedReportTypeDto> mapEntityToDto;

	@Autowired
	private BeanTransformerUtil<CrewMedReportTypeDto, CrewMedReportType> mapDtoToEntity;

	@Autowired
	@Qualifier("TST_MSSQL_SYNC")
	private SyncDataService syncDataService;

	@Autowired
	private CrewMedReportTypeDao crewMedReportTypeDao;

	@Autowired
	private DBUtil dbUtil;

	@Autowired
	private CommonUtil<CrewMedReportTypeDto> commonUtil;

	@Override
	public CrewMedReportTypeDto add(CrewMedReportTypeDto crewMedReportTypeDto) throws Exception {
		LOGGER.debug("CrewMedReportTypeServiceImpl -- add -- start");
		commonUtil.stringNullValidator(crewMedReportTypeDto.getName(), "CrewMedReportType Name");
		List<CrewMedReportType> crewMedReportTypeList = crewMedReportTypeDao
				.findByNameAndStatusNot(crewMedReportTypeDto.getName(), commonUtil.getSoftDeleteStatus());
		if (!crewMedReportTypeList.isEmpty())
			throw new ApplicationServiceExecption("CrewMedReportType already exist", HttpStatus.BAD_REQUEST);

		CrewMedReportType crewMedReportType = mapDtoToEntity.transformBO(crewMedReportTypeDto, CrewMedReportType.class);
		String seqName = dbUtil.getNextSequence(crewMedReportType.getClass());
		if (seqName != null)
			crewMedReportType.setId(seqName);

		crewMedReportType.setInsertTime(new Date());
		crewMedReportType.setUpdateTime(new Date());
		crewMedReportType.setStatus(commonUtil.getActiveStatus());
		crewMedReportTypeDao.save(crewMedReportType);
		syncDataService.syncCreation(crewMedReportType);
		LOGGER.debug("CrewMedReportTypeServiceImpl -- add -- end");
		return mapEntityToDto.transformBO(crewMedReportType, CrewMedReportTypeDto.class);
	}

	@Override
	public CrewMedReportTypeDto update(CrewMedReportTypeDto crewMedReportTypeDto) throws Exception {
		LOGGER.debug("CrewMedReportTypeServiceImpl -- update -- start");
		commonUtil.stringNullValidator(crewMedReportTypeDto.getName(), crewMedReportTypeDto.getId(), "CrewMedReportType Id and Name");
		List<CrewMedReportType> crewMedReportTypeList = crewMedReportTypeDao.findByNameAndStatusNotAndIdNot(
				crewMedReportTypeDto.getName(), commonUtil.getSoftDeleteStatus(), crewMedReportTypeDto.getId());
		if (!crewMedReportTypeList.isEmpty())
			throw new ApplicationServiceExecption("CrewMedReportType already exist");

		CrewMedReportType existingCrewMedReportType = crewMedReportTypeDao
				.findByIdAndStatusNot(crewMedReportTypeDto.getId(), commonUtil.getSoftDeleteStatus());
		if (existingCrewMedReportType == null)
			throw new ApplicationServiceExecption("CrewMedReportType not found", HttpStatus.BAD_REQUEST);

		CrewMedReportTypeDto existingCrewMedReportTypeDto = mapEntityToDto.transformBO(existingCrewMedReportType,
				CrewMedReportTypeDto.class);
		CrewMedReportType crewMedReportType = mapDtoToEntity.transformBO(crewMedReportTypeDto, CrewMedReportType.class);
		crewMedReportType.setUpdateTime(new Date());
		crewMedReportTypeDao.save(crewMedReportType);
		syncDataService.syncUpdate(mapDtoToEntity.transformBO(existingCrewMedReportTypeDto, CrewMedReportType.class),
				crewMedReportType);
		LOGGER.debug("CrewMedReportTypeServiceImpl -- update -- end");
		return mapEntityToDto.transformBO(crewMedReportType, CrewMedReportTypeDto.class);
	}

	@Override
	public CrewMedReportTypeDto findById(String id) throws Exception {
		LOGGER.debug("CrewMedReportTypeServiceImpl -- findById -- start");
		commonUtil.stringNullValidator(id, "CrewMedReportType Id");
		CrewMedReportType crewMedReportType = crewMedReportTypeDao.findByIdAndStatusNot(id,
				commonUtil.getSoftDeleteStatus());
		if (crewMedReportType == null)
			throw new ApplicationServiceExecption("CrewMedReportType not found", HttpStatus.BAD_REQUEST);

		LOGGER.debug("CrewMedReportTypeServiceImpl -- findById -- end");
		return mapEntityToDto.transformBO(crewMedReportType, CrewMedReportTypeDto.class);
	}

	@Override
	public List<CrewMedReportTypeDto> softDelete(List<String> ids) throws Exception {
		LOGGER.debug("CrewMedReportTypeServiceImpl -- softDelete -- start");
		commonUtil.stringNullValidator(ids.toArray(), "CrewMedReportType Id");
		List<CrewMedReportType> crewMedReportTypeList = crewMedReportTypeDao.findByIdInAndStatusNot(ids,				commonUtil.getSoftDeleteStatus());

		if (crewMedReportTypeList.size() < ids.size())
			throw new ApplicationServiceExecption("CrewMedReportType not found");

		List<CrewMedReportTypeDto> crewMedReportTypeDtoList = mapEntityToDto.transformListOfBO(crewMedReportTypeList, CrewMedReportTypeDto.class);
		for (CrewMedReportType crewMedReportType : crewMedReportTypeList) {
			crewMedReportType.setUpdateTime(new Date());
			crewMedReportType.setStatus(commonUtil.getSoftDeleteStatus());
		}
		crewMedReportTypeDao.saveAll(crewMedReportTypeList);
		Integer count = 0;
		for (CrewMedReportType crewMedReportType : crewMedReportTypeList) {
			syncDataService.syncUpdate(mapDtoToEntity.transformBO(crewMedReportTypeDtoList.get(count), CrewMedReportType.class), crewMedReportType);
			count++;
		}
		crewMedReportTypeList = crewMedReportTypeDao.findAllCrewMedReportType();
		LOGGER.debug("CrewMedReportTypeServiceImpl -- softDelete -- end");
		return mapEntityToDto.transformListOfBO(crewMedReportTypeList, CrewMedReportTypeDto.class);
	}

	@Override
	public List<CrewMedReportTypeDto> findAll() throws Exception {
		LOGGER.debug("CrewMedReportTypeServiceImpl -- findAll -- start");
		List<CrewMedReportType> crewMedReportTypeList = crewMedReportTypeDao.findAllCrewMedReportType();
		if(crewMedReportTypeList.isEmpty())
			throw new ApplicationServiceExecption("CrewMedReportType not found", HttpStatus.BAD_REQUEST);
		LOGGER.debug("CrewMedReportTypeServiceImpl -- findAll -- end");
		return mapEntityToDto.transformListOfBO(crewMedReportTypeList, CrewMedReportTypeDto.class);
	}

}
