/**
 * 
 */
package in.ind.mds.serviceImpl;

import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import in.ind.mds.dto.CompanyDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.repo.dao.CompanyDao;
import in.ind.mds.repo.entity.Company;
import in.ind.mds.service.CompanyService;
import in.ind.mds.service.SyncDataService;
import in.ind.mds.util.BeanTransformerUtil;
import in.ind.mds.util.CommonUtil;
import in.ind.mds.util.DBUtil;

/**
 * @author mds-arockia
 *
 */
@Service("TST_MSSQL_COMPANY")
public class CompanyServiceImpl implements CompanyService{

	private static final Logger LOGGER = LoggerFactory.getLogger(CompanyServiceImpl.class);

	@Autowired
	private BeanTransformerUtil<Company, CompanyDto> mapEntityToDto;

	@Autowired
	private BeanTransformerUtil<CompanyDto, Company> mapDtoToEntity;

	@Autowired
	@Qualifier("TST_MSSQL_SYNC")
	private SyncDataService syncDataService;
	
	@Autowired
	private CompanyDao companyDao;
	
	@Autowired
	private DBUtil dbUtil;
	
	@Autowired
	private CommonUtil<CompanyDto> commonUtil;
	
	@Override
	public CompanyDto add(CompanyDto companyDto) throws Exception {
		LOGGER.debug("CompanyServiceImpl -- add -- Start");
		commonUtil.stringNullValidator(companyDto.getCompanyName(), "CompanyName");
		Company company = companyDao.findByCompanyNameAndStatusNot(companyDto.getCompanyName(), commonUtil.getSoftDeleteStatus());
		if(company != null)
			throw new ApplicationServiceExecption("Company already exist", HttpStatus.BAD_REQUEST);
		
		company = mapDtoToEntity.transformBO(companyDto, Company.class);
		String seqName = dbUtil.getNextSequence(company.getClass());
		if(seqName != null) {
			company.setId(seqName);
		}
		company.setInsertTime(new Date());
		company.setUpdateTime(new Date());
		company.setLicenseActive("Y");
		company.setStatus(commonUtil.getActiveStatus());
		companyDao.save(company);
		syncDataService.syncCreation(company);
		LOGGER.debug("CompanyServiceImpl -- add -- End");
		return mapEntityToDto.transformBO(company, CompanyDto.class);
	}

	@Override
	public CompanyDto findByCompanyId(String companyId) throws Exception {
		LOGGER.debug("CompanyServiceImpl -- findByCompanyId -- Start");
		commonUtil.stringNullValidator(companyId, "CompanyId");
		Company company = companyDao.findByIdAndStatusNot(companyId, commonUtil.getSoftDeleteStatus()); 
		if (company == null) 
			throw new ApplicationServiceExecption("Company not found", HttpStatus.NOT_FOUND);
		
		final CompanyDto dto = mapEntityToDto.transformBO(company, CompanyDto.class);
		LOGGER.debug("CompanyServiceImpl -- findByCompnayId -- End");
		return dto;
	}

	@Override
	public List<CompanyDto> findAll() throws Exception {
		LOGGER.debug("CompanyServiceImpl -- findAll -- Start");
		List<Company> company = companyDao.findAllCompany();
		if (company.size() == 0) {
			throw new ApplicationServiceExecption("Company not found", HttpStatus.NOT_FOUND);
		}
		final List<CompanyDto> dto = mapEntityToDto.transformListOfBO(company, CompanyDto.class);
		LOGGER.debug("CompanyServiceImpl -- findAll -- End");
		return dto;
	}

	@Override
	public List<CompanyDto> SoftDeleteCompany(List<String> companyIds) throws Exception {
		LOGGER.debug("CompanyServiceImpl -- softDeleteCompany -- Start");
		commonUtil.stringNullValidator(companyIds.toArray(), "CompanyId");
		List<Company> existingCompanyList = companyDao.findByIdInAndStatusNot(companyIds, commonUtil.getSoftDeleteStatus());
		if (existingCompanyList.size() < companyIds.size()) 
			throw new ApplicationServiceExecption("Compnay not found", HttpStatus.NOT_FOUND);
		
		List<CompanyDto> existingCompanyDtoList = mapEntityToDto.transformListOfBO(existingCompanyList, CompanyDto.class);
		for (Company company : existingCompanyList) {
			company.setStatus(commonUtil.getSoftDeleteStatus());
			company.setUpdateTime(new Date());
		}
		existingCompanyList = companyDao.saveAll(existingCompanyList);
		Integer count = 0;
		for (Company company : existingCompanyList) {
			syncDataService.syncUpdate(mapDtoToEntity.transformBO(existingCompanyDtoList.get(count), Company.class), company);
			count++;
		}
		existingCompanyList = companyDao.findAllCompany();
		LOGGER.debug("CompanyServiceImpl -- softDeleteCompany -- End");
		return mapEntityToDto.transformListOfBO(existingCompanyList, CompanyDto.class);
	}

	@Override
	public CompanyDto updateCompany(CompanyDto companyDto) throws Exception {
		LOGGER.debug("CompanyServiceImpl -- update -- Start");
		commonUtil.stringNullValidator(companyDto.getId(), companyDto.getCompanyName(), "Company Id and Name");
		Company existingCompany = companyDao.findByCompanyNameAndStatusNotAndIdNot(companyDto.getCompanyName(), commonUtil.getSoftDeleteStatus(), companyDto.getId());
		if(existingCompany != null)
			throw new ApplicationServiceExecption("Company already exist", HttpStatus.BAD_REQUEST);
		
		existingCompany = companyDao.findByIdAndStatusNot(companyDto.getId(), commonUtil.getSoftDeleteStatus());
		if (existingCompany == null) 
			throw new ApplicationServiceExecption("Company not found", HttpStatus.NOT_FOUND);

		CompanyDto existingCompanyDto = mapEntityToDto.transformBO(existingCompany, CompanyDto.class);
		Company company = mapDtoToEntity.transformBO(companyDto, Company.class);
		company.setUpdateTime(new Date());
		companyDao.saveAndFlush(company);
		syncDataService.syncUpdate(mapDtoToEntity.transformBO(existingCompanyDto, Company.class), company);
		LOGGER.debug("CompanyServiceImpl -- update -- End");
		return mapEntityToDto.transformBO(company, CompanyDto.class);
	}

}
