package in.ind.mds.serviceImpl;

import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import in.ind.mds.dto.UserDto;
import in.ind.mds.dto.OwnerDto;
import in.ind.mds.dto.UserRoleDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.repo.dao.UserRoleDao;
import in.ind.mds.repo.entity.User;
import in.ind.mds.repo.entity.Owner;
import in.ind.mds.repo.entity.UserRole;
import in.ind.mds.service.SyncDataService;
import in.ind.mds.service.UserRoleService;
import in.ind.mds.util.BeanTransformerUtil;
import in.ind.mds.util.CommonUtil;
import in.ind.mds.util.DBUtil;

@Service("TST_MSSQL_USER_ROLE")

public class UserRoleServiceImpl implements UserRoleService {

	private static final Logger LOGGER = LoggerFactory.getLogger(UserRoleServiceImpl.class);

	@Autowired
	private BeanTransformerUtil<UserRole, UserRoleDto> mapEntityToDto;

	@Autowired
	private BeanTransformerUtil<UserRoleDto, UserRole> mapDtoToEntity;
	
	@Autowired
	private BeanTransformerUtil<UserDto, User> mapUserDtoToEntity;

	@Autowired
	@Qualifier("TST_MSSQL_SYNC")
	private SyncDataService syncDataService;
	/*
	 * @Autowired private UserValidator validator;
	 */
	 @Autowired
	 private CommonUtil<UserRoleDto> commonUtil;

	@Autowired
	private UserRoleDao userRoleDao;

	@Autowired
	private DBUtil dbUtil;

	public UserRoleDto findByRoleIdAndUserId(final String roleId, final String userId) throws Exception {
		LOGGER.debug("UserRoleServiceImpl -- getByRoleIdAndUserRoleStatus -- Start");
		commonUtil.stringNullValidator(roleId, userId, "RoleId and UserId");
		UserRole userRole = userRoleDao.findByRoleIdAndUserIdAndStatusNot(roleId, userId, commonUtil.getSoftDeleteStatus());

		if (userRole == null) 
			throw new ApplicationServiceExecption("UserRole not found", HttpStatus.NOT_FOUND);
		
		final UserRoleDto dto = mapEntityToDto.transformBO(userRole, UserRoleDto.class);
		LOGGER.debug("UserRoleServiceImpl -- getByRoleIdAndUserRoleStatus -- End");
		return dto;
	}

	public UserRoleDto getByUserRoleId(final String userRoleId) throws Exception {
		LOGGER.debug("UserRoleServiceImpl -- getByUserRoleId -- Start");
		commonUtil.stringNullValidator(userRoleId, "UserRoleId");
		final UserRole userRole = userRoleDao.findByIdAndStatusNot(userRoleId, commonUtil.getSoftDeleteStatus());

		if (userRole == null) 
			throw new ApplicationServiceExecption("Error userRole not found", HttpStatus.NOT_FOUND);
		
		/*
		 * Date date = user.getServerTime(); Date currentDate = new
		 * Date(System.currentTimeMillis());
		 * 
		 * if (date.before(currentDate) || date.after(currentDate)) {
		 * user.setServerTime(currentDate); userDao.save(user); }
		 */
		final UserRoleDto dto = mapEntityToDto.transformBO(userRole, UserRoleDto.class);

		LOGGER.debug("UserRoleServiceImpl -- getByUserRoleId -- End");
		return dto;
	}

	@Override
	public UserRoleDto findByRoleId(final String roleId) throws Exception {
		LOGGER.debug("UserRoleServiceImpl -- getByRoleId -- Start");
		commonUtil.stringNullValidator(roleId, "RoleId");
		final UserRole userRole = userRoleDao.findByRoleIdAndStatusNot(roleId, commonUtil.getSoftDeleteStatus());

		if (userRole == null) 
			throw new ApplicationServiceExecption("Error userRole not found", HttpStatus.NOT_FOUND);
		
		/*
		 * Date date = user.getServerTime(); Date currentDate = new
		 * Date(System.currentTimeMillis());
		 * 
		 * if (date.before(currentDate) || date.after(currentDate)) {
		 * user.setServerTime(currentDate); userDao.save(user); }
		 */
		final UserRoleDto dto = mapEntityToDto.transformBO(userRole, UserRoleDto.class);

		LOGGER.debug("UserRoleServiceImpl -- getByRoleId -- End");
		return dto;
	}

	@Override
	public List<UserRoleDto> findAll() throws Exception {
		LOGGER.debug("UserRoleServiceImpl -- findByUserRoleType -- Start");
		List<UserRole> userRole = userRoleDao.findAllUserRole();

		if (userRole.size() == 0) 
			throw new ApplicationServiceExecption("UserRole not found", HttpStatus.NOT_FOUND);
		
		final List<UserRoleDto> dto = mapEntityToDto.transformListOfBO(userRole, UserRoleDto.class);
		LOGGER.debug("UserRoleServiceImpl -- findByUserRoleType -- End");
		return dto;
	}

	@Override
	public UserRoleDto add(UserRoleDto userRoleDto) throws Exception {
		LOGGER.debug("UserRoleServiceImpl -- add -- Start");
		// final String errorMessage = validator.validateAdd(userDto);
		// if (errorMessage != null) {
		// throw new GaurageServiceException(errorMessage, HttpStatus.BAD_REQUEST);
		// }
		/*
		 * Optional<UserRole> existingUserRole =
		 * userRoleDao.findById(userRoleDto.getId()); if (existingUserRole.isPresent())
		 * { throw new ApplicationServiceExecption("UserRole exist",
		 * HttpStatus.BAD_REQUEST); }
		 */
		UserRole userRole = mapDtoToEntity.transformBO(userRoleDto, UserRole.class);

		String seqName = dbUtil.getNextSequence(userRole.getClass());
		if (seqName != null) {
			userRole.setId(seqName);
		}
		userRole.setInsertTime(new Date());
		userRole.setUpdateTime(new Date());
		userRole.setStatus(commonUtil.getActiveStatus());
		userRole=userRoleDao.save(userRole);
		syncDataService.syncCreation(userRole);
		LOGGER.debug("UserRoleServiceImpl -- add -- End");
		return mapEntityToDto.transformBO(userRole, UserRoleDto.class);
	}

	@Override
	public List<UserRoleDto> softDeleteUserRole(List<String> userRoleIds) throws Exception {
		LOGGER.debug("UserRoleServiceImpl -- delete -- Start");
		// final String errorMessage = validator.validateAdd(userDto);
		// if (errorMessage != null) {
		// throw new GaurageServiceException(errorMessage, HttpStatus.BAD_REQUEST);
		// }
		commonUtil.stringNullValidator(userRoleIds, "UserRoleId");
		List<UserRole> existingUserRoleList = userRoleDao.findByIdInAndStatusNot(userRoleIds, commonUtil.getSoftDeleteStatus());
		if (existingUserRoleList.size() < userRoleIds.size())
			throw new ApplicationServiceExecption("UserRole not found", HttpStatus.BAD_REQUEST);
		
		List<UserRoleDto> existingUserRoleDtoList = mapEntityToDto.transformListOfBO(existingUserRoleList, UserRoleDto.class);
		for(UserRole userRole: existingUserRoleList)
		{
			userRole.setStatus(commonUtil.getSoftDeleteStatus());
			userRole.setUpdateTime(new Date());
		}
		
		existingUserRoleList=userRoleDao.saveAll(existingUserRoleList);
		Integer count=0;
		for(UserRole userRole : existingUserRoleList)
		{
			syncDataService.syncUpdate(mapDtoToEntity.transformBO(existingUserRoleDtoList.get(count), UserRole.class), userRole);
			count++;
		}
		List<UserRole> userRoleList = userRoleDao.findAllUserRole();
		LOGGER.debug("UserRoleServiceImpl -- delete -- End");
		return mapEntityToDto.transformListOfBO(userRoleList, UserRoleDto.class);
	}

	@Override
	public UserRoleDto updateUserRole(UserRoleDto userRoleDto) throws Exception {
		LOGGER.debug("UserRoleServiceImpl -- update -- Start");
		// final String errorMessage = validator.validateAdd(userDto);
		// if (errorMessage != null) {
		// throw new GaurageServiceException(errorMessage, HttpStatus.BAD_REQUEST);
		// }
		commonUtil.stringNullValidator(userRoleDto.getId(), "UserRoleId");
		UserRole existingUserRole = userRoleDao.findByIdAndStatusNot(userRoleDto.getId(), commonUtil.getSoftDeleteStatus());
		if (existingUserRole == null) 
			throw new ApplicationServiceExecption("UserRole not found", HttpStatus.BAD_REQUEST);
		
		UserRoleDto existingUserRoleDto = mapEntityToDto.transformBO(existingUserRole, UserRoleDto.class);
		 UserRole userRole = mapDtoToEntity.transformBO(userRoleDto, UserRole.class);
		 userRole.setUpdateTime(new Date());
		 userRole=userRoleDao.saveAndFlush(userRole);
		syncDataService.syncUpdate(mapDtoToEntity.transformBO(existingUserRoleDto, UserRole.class), userRole);
		LOGGER.debug("UserRoleServiceImpl -- update -- End");
		return mapEntityToDto.transformBO(userRole, UserRoleDto.class);
	}
	
	@Override
	public UserRoleDto findByUserId(UserDto userDto) throws Exception {
		LOGGER.debug("UserRoleServiceImpl -- findByUserId -- Start");
		commonUtil.stringNullValidator(userDto.getId(), "UserId");
		User user  = mapUserDtoToEntity.transformBO(userDto, User.class);
		UserRole userRole = userRoleDao.findByUser(user);
		
		if (userRole == null) 
			throw new ApplicationServiceExecption("UserRole not found", HttpStatus.NOT_FOUND);
		
		final UserRoleDto userRoleDto = mapEntityToDto.transformBO(userRole, UserRoleDto.class);
		LOGGER.debug("UserRoleServiceImpl -- findByUserId -- End");
		return userRoleDto;
	}

}
