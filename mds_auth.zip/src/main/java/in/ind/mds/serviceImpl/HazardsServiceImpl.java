/**
 * 
 */
package in.ind.mds.serviceImpl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;


import in.ind.mds.dto.HazardsDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.repo.dao.HazardsDao;


import in.ind.mds.repo.entity.Hazards;
import in.ind.mds.repo.entity.Operation;
import in.ind.mds.service.HazardsService;
import in.ind.mds.service.SyncDataService;
import in.ind.mds.util.BeanTransformerUtil;
import in.ind.mds.util.CommonUtil;
import in.ind.mds.util.DBUtil;

/**
 * @author dharani
 *
 */

@Service("TST_MSSQL_HAZARDS")
public class HazardsServiceImpl implements HazardsService{
	
	private static final Logger LOGGER = LoggerFactory.getLogger(HazardsServiceImpl.class);

	@Autowired
	private BeanTransformerUtil<Hazards, HazardsDto> mapEntityToDto;

	@Autowired
	private BeanTransformerUtil<HazardsDto, Hazards> mapDtoToEntity;

	@Autowired
	@Qualifier("TST_MSSQL_SYNC")
	private SyncDataService syncDataService;

	@Autowired
	private CommonUtil<HazardsDto> commonUtil;

	@Autowired
	private HazardsDao hazardsDao;

	@Autowired
	private DBUtil dbUtil;

	@Override
	public List<HazardsDto> add(Operation operation, List<HazardsDto> hazardsDtoList) throws Exception {
		LOGGER.debug("HAZARDSServicImpl -- addMethod -- start");
		List<Hazards> hazardsList = mapDtoToEntity.transformListOfBO(hazardsDtoList, Hazards.class);
		int count=1;
		for (Hazards hazards : hazardsList) {
			String seqName = dbUtil.getNextSequence(hazards.getClass());
			if(seqName != null)
				hazards.setId(seqName);
			hazards.setSiNo(count);
			hazards.setOperationId(operation);;
			hazards.setInsertTime(new Date());
			hazards.setUpdateTime(new Date());
			hazards.setStatus(commonUtil.getActiveStatus());
			count++;
		}
		hazardsDao.saveAll(hazardsList);
		for (Hazards hazards : hazardsList) {
			syncDataService.syncCreation(hazards);
		}
		LOGGER.debug("HazardsServicImpl -- addMethod -- end");
	
		return mapEntityToDto.transformListOfBO(hazardsList,HazardsDto.class);
	}
	

	@Override
	public List<HazardsDto> update(Operation operation,List<HazardsDto> hazardsDtoList) throws Exception {
		LOGGER.debug("HazardsServicImpl -- update -- start");
		List<HazardsDto> hazardsDtoAdd = new ArrayList<>();
		List<HazardsDto> hazardsDtoUpdate = new ArrayList<>();
		for (HazardsDto hazardsDto : hazardsDtoList) {
			if(hazardsDto.getId() == null)
				hazardsDtoAdd.add(hazardsDto);
			else
				hazardsDtoUpdate.add(hazardsDto);
		}
		if(!hazardsDtoAdd.isEmpty())
			hazardsDtoList = add( operation,hazardsDtoAdd);
		
		List<String> hazardsIds = hazardsDtoUpdate.stream().map(i -> i.getId()).collect(Collectors.toList());
		List<Hazards> hazards = hazardsDao.findByIdInAndStatusNot(hazardsIds, commonUtil.getSoftDeleteStatus());
		if(hazards.size() <hazardsIds.size())
			throw new ApplicationServiceExecption("Hazards not found");
		
		List<HazardsDto> existingHazardsDto = mapEntityToDto.transformListOfBO(hazards, HazardsDto.class);
		hazards = mapDtoToEntity.transformListOfBO(hazardsDtoUpdate, Hazards.class);
		for (Hazards hazardsList : hazards) {
			hazardsList.setUpdateTime(new Date());
		}
		
		
		hazardsDtoList.addAll(mapEntityToDto.transformListOfBO(hazards, HazardsDto.class));
		LOGGER.debug("HazardsServicImpl -- update -- end");
		return hazardsDtoList;

		}
	

	@Override
	public List<HazardsDto> findByOperation(Operation operation) {
		LOGGER.debug("HazardServicImpl -- findByOPeration -- start");
		List<HazardsDto> hazardsDtoList = new ArrayList<>();
		List<Hazards> hazardsList = hazardsDao.findByOperationIdAndStatusNot(operation, commonUtil.getSoftDeleteStatus());
		if(hazardsList.isEmpty())
			return hazardsDtoList;
		
		hazardsDtoList = mapEntityToDto.transformListOfBO(hazardsList, HazardsDto.class);
		
		
		LOGGER.debug("HazardsServicImpl -- findByStaff -- end");
		return hazardsDtoList;
	}
	

	@Override
	public void softDelete(List<String> ids) throws Exception {
		LOGGER.debug("HazardsServicImpl -- softDelete -- start");
		commonUtil.stringNullValidator(ids.toArray(), "Hazards Id");
		List<Hazards> hazardsList = hazardsDao.findByIdInAndStatusNot(ids, commonUtil.getSoftDeleteStatus());
		if(hazardsList.size() <  ids.size())
			throw new ApplicationServiceExecption("Hazards not found");
		
		List<HazardsDto> hazardsDtoList = mapEntityToDto.transformListOfBO(hazardsList, HazardsDto.class);
		for (Hazards hazards : hazardsList) {
			hazards.setUpdateTime(new Date());
			hazards.setStatus(commonUtil.getSoftDeleteStatus());
		}
		Integer count = 0;
		for (Hazards hazards : hazardsList) {
			syncDataService.syncUpdate(mapDtoToEntity.transformBO(hazardsDtoList.get(count), Hazards.class), hazards);
			count++;
		}
	LOGGER.debug("HazardsServicImpl -- softDelete -- end");

	}

	@Override
	public void softDeleteByOperation(Operation operation) throws Exception {
		LOGGER.debug("HazardsServicImpl -- softDelete -- start");
		List<Hazards> hazardsList = hazardsDao.findByOperationIdAndStatusNot(operation, commonUtil.getSoftDeleteStatus());
		List<HazardsDto> hazardsDtoList = mapEntityToDto.transformListOfBO(hazardsList, HazardsDto.class);
		for (Hazards hazards : hazardsList) {
			hazards.setUpdateTime(new Date());
			hazards.setStatus(commonUtil.getSoftDeleteStatus());
		}
		Integer count = 0;
		for (Hazards hazards : hazardsList) {
			syncDataService.syncUpdate(mapDtoToEntity.transformBO(hazardsDtoList.get(count), Hazards.class), hazards);
			count++;
		}
		LOGGER.debug("HazardsServicImpl -- softDelete -- end");
	}

}
