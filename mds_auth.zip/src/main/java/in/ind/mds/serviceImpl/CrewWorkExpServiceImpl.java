/**
 * 
 */
package in.ind.mds.serviceImpl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import in.ind.mds.dto.CrewWorkExpDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.repo.dao.CrewWorkExpDao;
import in.ind.mds.repo.entity.CrewWorkExp;
import in.ind.mds.repo.entity.Staff;
import in.ind.mds.service.CrewWorkExpService;
import in.ind.mds.service.SyncDataService;
import in.ind.mds.util.BeanTransformerUtil;
import in.ind.mds.util.CommonUtil;
import in.ind.mds.util.DBUtil;

/**
 * @author mds-arockia
 *
 */
@Service("TST_MSSQL_CREW_WORK_EXP")
public class CrewWorkExpServiceImpl implements CrewWorkExpService {

	private static final Logger LOGGER = LoggerFactory.getLogger(CrewWorkExpServiceImpl.class);

	@Autowired
	private BeanTransformerUtil<CrewWorkExp, CrewWorkExpDto> mapEntityToDto;

	@Autowired
	private BeanTransformerUtil<CrewWorkExpDto, CrewWorkExp> mapDtoToEntity;

	@Autowired
	@Qualifier("TST_MSSQL_SYNC")
	private SyncDataService syncDataService;

	@Autowired
	private CommonUtil<CrewWorkExpDto> commonUtil;

	@Autowired
	private CrewWorkExpDao crewWorkExpDao;

	/*@Autowired
	@Qualifier("TST_MSSQL_ATTACHEMENT")
	private AttachmentService attachmentService;*/

	@Autowired
	private DBUtil dbUtil;

	@Override
	public List<CrewWorkExpDto> add(Staff staff, List<CrewWorkExpDto> workExpDtoList) throws Exception {
		LOGGER.debug("CrewWorkExpServicImpl -- add -- start");
		workExpDtoList = addWorkExp(staff, workExpDtoList);
		LOGGER.debug("CrewWorkExpServicImpl -- add -- end");
		return workExpDtoList;
	}

	@Override
	public List<CrewWorkExpDto> update(Staff staff, List<CrewWorkExpDto> workExpDtoList) throws Exception {
		LOGGER.debug("CrewWorkExpServicImpl -- update -- start");
		List<CrewWorkExpDto> workExpDtoListForAdd = new ArrayList<>();
		List<CrewWorkExpDto> workExpDtoListForUpdate = new ArrayList<>();
		for (CrewWorkExpDto workExpDto : workExpDtoList) {
			if (workExpDto.getId() == null)
				workExpDtoListForAdd.add(workExpDto);
			else
				workExpDtoListForUpdate.add(workExpDto);
		}
		if (!workExpDtoListForAdd.isEmpty())
			workExpDtoList = addWorkExp(staff, workExpDtoListForAdd);

		List<String> workExpIds = workExpDtoListForUpdate.stream().map(i -> i.getId()).collect(Collectors.toList());
		List<CrewWorkExp> workExpList = crewWorkExpDao.findByIdInAndStatusNot(workExpIds,
				commonUtil.getSoftDeleteStatus());
		if (workExpList.size() < workExpIds.size())
			throw new ApplicationServiceExecption("WorkExp not found");

		List<CrewWorkExpDto> existingWorkExpDtoList = mapEntityToDto.transformListOfBO(workExpList,
				CrewWorkExpDto.class);
		workExpList = mapDtoToEntity.transformListOfBO(workExpDtoListForUpdate, CrewWorkExp.class);
		for (CrewWorkExp workExp : workExpList) {
			workExp.setUpdateTime(new Date());
		}
		crewWorkExpDao.saveAll(workExpList);
		Integer count = 0;
		for (CrewWorkExp workExp : workExpList) {
			syncDataService.syncUpdate(mapDtoToEntity.transformBO(existingWorkExpDtoList.get(count), CrewWorkExp.class),
					workExp);
			count++;
		}
		workExpDtoList.addAll(workExpDtoListForUpdate);
		LOGGER.debug("CrewWorkExpServicImpl -- update -- end");
		return workExpDtoList;
	}

	@Override
	public List<CrewWorkExpDto> findByStaff(Staff staff) throws Exception {
		LOGGER.debug("CrewWorkExpServicImpl -- findByStaff -- start");
		List<CrewWorkExpDto> workExpDtoList = new ArrayList<>();
		List<CrewWorkExp> workExpList = crewWorkExpDao.findByStaffAndStatusNot(staff, commonUtil.getSoftDeleteStatus());
		if (workExpList.isEmpty())
			return workExpDtoList;

		workExpDtoList = mapEntityToDto.transformListOfBO(workExpList, CrewWorkExpDto.class);
		/*String attachmentOrigin = dbUtil.getTableName(workExpList.get(0).getClass());
		for (CrewWorkExpDto workExpDto : workExpDtoList) {
			AttachmentDto attachmentDto = new AttachmentDto();
			attachmentDto.setAttachmentOrigin(attachmentOrigin);
			attachmentDto.setRecordId(workExpDto.getId());
			attachmentDto.setAttachmentType(workExpDto.getWorkExpDocFieldName());
			workExpDto.setWorkExpDoc(attachmentService.findAttachments(attachmentDto));
		}*/
		LOGGER.debug("CrewWorkExpServicImpl -- findByStaff -- end");
		return workExpDtoList;
	}

	@Override
	public void softDeleteByStaff(Staff staff) throws Exception {
		LOGGER.debug("CrewWorkExpServicImpl -- softDelete -- start");
		List<CrewWorkExp> workExpList = crewWorkExpDao.findByStaffAndStatusNot(staff, commonUtil.getSoftDeleteStatus());
		List<CrewWorkExpDto> workExpDtoList = mapEntityToDto.transformListOfBO(workExpList, CrewWorkExpDto.class);
		for (CrewWorkExp workExp : workExpList) {
			workExp.setUpdateTime(new Date());
			workExp.setStatus(commonUtil.getSoftDeleteStatus());
		}
		Integer count = 0;
		for (CrewWorkExp workExp : workExpList) {
			syncDataService.syncUpdate(mapDtoToEntity.transformBO(workExpDtoList.get(count), CrewWorkExp.class),
					workExp);
			//attachmentService.softDelete(workExp.getId(), dbUtil.getTableName(workExp.getClass()));
			count++;
		}
		LOGGER.debug("CrewWorkExpServicImpl -- softDelete -- end");
	}

	@Override
	public void softDelete(List<String> ids) throws Exception {
		LOGGER.debug("CrewWorkExpServicImpl -- softDelete -- start");
		commonUtil.stringNullValidator(ids.toArray(), "CrewWorkExp Id");
		List<CrewWorkExp> workExpList = crewWorkExpDao.findByIdInAndStatusNot(ids, commonUtil.getSoftDeleteStatus());
		if (workExpList.size() < ids.size())
			throw new ApplicationServiceExecption("CrewWorkExp not found");

		List<CrewWorkExpDto> workExpDtoList = mapEntityToDto.transformListOfBO(workExpList, CrewWorkExpDto.class);
		for (CrewWorkExp workExp : workExpList) {
			workExp.setUpdateTime(new Date());
			workExp.setStatus(commonUtil.getSoftDeleteStatus());
		}
		Integer count = 0;
		for (CrewWorkExp workExp : workExpList) {
			syncDataService.syncUpdate(mapDtoToEntity.transformBO(workExpDtoList.get(count), CrewWorkExp.class),
					workExp);
			//attachmentService.softDelete(workExp.getId(), dbUtil.getTableName(workExp.getClass()));
			count++;
		}
		LOGGER.debug("CrewWorkExpServicImpl -- softDelete -- end");
	}

	public List<CrewWorkExpDto> addWorkExp(Staff staff, List<CrewWorkExpDto> workExpDtoList) throws Exception {
		LOGGER.debug("CrewWorkExpServicImpl -- addWorkExpMethod -- start");
		List<CrewWorkExp> workExpList = mapDtoToEntity.transformListOfBO(workExpDtoList, CrewWorkExp.class);
		for (CrewWorkExp workExp : workExpList) {
			String seqName = dbUtil.getNextSequence(workExp.getClass());
			if (seqName != null)
				workExp.setId(seqName);

			workExp.setStaff(staff);
			workExp.setStatus(commonUtil.getActiveStatus());
			workExp.setInsertTime(new Date());
			workExp.setUpdateTime(new Date());
		}
		crewWorkExpDao.saveAll(workExpList);
		for (CrewWorkExp workExp : workExpList) {
			syncDataService.syncCreation(workExp);
		}
		workExpDtoList = mapEntityToDto.transformListOfBO(workExpList, CrewWorkExpDto.class);
		/*
		 * Integer count = 0; for (CrewWorkExpDto workExpDto : workExpDtoList) {
		 * List<MultipartFile> thisAttachmentFiles = new ArrayList<>(); Integer
		 * thisAttachmentCount = 0; for (String workExpDoc : workExpDto.getWorkExpDoc())
		 * { Integer index = 0; //Integer removeAttachmentIndex = null; for
		 * (MultipartFile attachment : attachmentFiles) {
		 * if(workExpDoc.equals(attachment.getOriginalFilename())) {
		 * thisAttachmentFiles.add(attachment); // removeAttachmentIndex = index;
		 * thisAttachmentCount++; } index++; } //ArrayUtils.remove(attachmentFiles,
		 * removeAttachmentIndex); } AttachmentDto attachmentDto = new AttachmentDto();
		 * attachmentDto.setRecordId(workExpList.get(count).getId());
		 * attachmentDto.setAttachmentOrigin(dbUtil.getTableName((mapDtoToEntity.
		 * transformBO(workExpDto, CrewWorkExp.class)).getClass()));
		 * attachmentDto.setAttachmentType(workExpDto.getWorkExpDocFieldName());
		 * List<String> workExpDocPathList = attachmentService.add(attachmentDto,
		 * thisAttachmentFiles);
		 * returnWorkExpDtoList.get(count).setWorkExpDoc(workExpDocPathList); count++; }
		 */
		LOGGER.debug("CrewWorkExpServicImpl -- addWorkExpMethod -- end");
		return workExpDtoList;
	}

}
