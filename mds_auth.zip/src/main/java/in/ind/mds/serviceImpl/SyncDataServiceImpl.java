package in.ind.mds.serviceImpl;

import java.lang.reflect.Method;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;

import in.ind.mds.dto.SyncDataDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.repo.dao.SyncDataDao;
import in.ind.mds.repo.dao.SyncEventDao;
import in.ind.mds.repo.entity.SyncData;
import in.ind.mds.repo.entity.SyncEvent;
import in.ind.mds.service.SyncDataService;
import in.ind.mds.util.BeanTransformerUtil;
import in.ind.mds.util.CommonUtil;
import net.lingala.zip4j.core.ZipFile;
import net.lingala.zip4j.exception.ZipException;
import net.lingala.zip4j.model.ZipParameters;
import net.lingala.zip4j.util.Zip4jConstants;

@Service("TST_MSSQL_SYNCDATA")
public class SyncDataServiceImpl implements SyncDataService {
	private static final Logger LOGGER = LoggerFactory.getLogger(SyncDataServiceImpl.class);

	@Autowired
	private BeanTransformerUtil<SyncData, SyncDataDto> mapEntityToDto;

	@Autowired
	private BeanTransformerUtil<SyncDataDto, SyncData> mapDtoToEntity;

	@Autowired
	private SyncDataDao syncDataDao;

	@Autowired
	private SyncEventDao syncEventDao;

	@Autowired
	private ObjectMapper mapper;

	@Autowired
	private CommonUtil<SyncDataDto> commonUtil;

	private StringBuilder syncDataOutput, syncEventOutput;

	private Path jsonPath, eventDataPath;

	private SyncData populateSyncRecord(String action, String entityClassName, String fleetWideSync, String vesselId,
			String syncData) {
		SyncData sync = new SyncData();
		sync.setSyncData(syncData);
		sync.setAction(action);
		sync.setEntityClassName(entityClassName);
		sync.setFleetWideSync(fleetWideSync);
		sync.setOrigin("F"); // TODO : Get this value from config
		sync.setSyncModule("USER");// TODO : get from config if required
		sync.setVesselId(vesselId);
		sync.setInsertedBy(123);// TODO : get from session
		sync.setUpdatedBy(123);// TODO : get from session
		sync.setInsertTime(new Date());
		sync.setUpdateTime(new Date());
		sync.setUtcTime(CommonUtil.getUTCTime());
		return sync;
	}

	@Override
	public SyncDataDto syncCreation(Object entity) throws Exception {
		LOGGER.debug("SyncServiceImpl -- syncCreation -- Start");
		String jsonInString = null;
		SyncData syncData = null;

		if (Object.class.isInstance(entity) && entity != null) {
			syncData = SyncData.class.cast(entity);
		} else {
			throw new ApplicationServiceExecption("Object casting exception", HttpStatus.EXPECTATION_FAILED);
		}
		jsonInString = mapper.writeValueAsString(entity);
		syncData = populateSyncRecord("A", entity.getClass().getName(), "N", "1231", jsonInString);

		final SyncDataDto dto = mapEntityToDto.transformBO(syncData, SyncDataDto.class);
		createSyncRecord(syncData);
		LOGGER.debug("SyncServiceImpl -- syncCreation -- End");
		return dto;
	}

	@Override
	public SyncDataDto syncUpdate(Object oldEntity, Object newEntity) throws Exception {
		LOGGER.debug("SyncServiceImpl -- syncUpdate -- Start");
		StringBuilder updatedData = null;
		String vesselId = null;
		SyncDataDto dto = null;
		if (SyncData.class.isInstance(oldEntity)) {
			throw new ApplicationServiceExecption("Object casting exception", HttpStatus.EXPECTATION_FAILED);
		}
		updatedData = CommonUtil.getDeltaChange(newEntity, oldEntity);
		if (!CommonUtil.isNullOrEmpty(updatedData.toString())) {
			// Get Fleetwide sync from entity
			// get VesselId from entity
			vesselId = getVesselId(newEntity);
			SyncData syncData = populateSyncRecord("U", newEntity.getClass().getName(), "N", vesselId,
					updatedData.toString());
			dto = mapEntityToDto.transformBO(syncData, SyncDataDto.class);
			createSyncRecord(syncData);
		}
		LOGGER.debug("SyncServiceImpl -- syncUpdate -- End");
		return dto;
	}

	@Override
	public String getVesselId(Object newEntity) throws Exception {
		LOGGER.debug("SyncServiceImpl -- getVesselId -- Start");
		String vesselId = null;
		try {
			Method method = newEntity.getClass().getDeclaredMethod("getVesselId", null);
			Object obj = method.invoke(newEntity, null);
			vesselId = obj.toString();
		} catch (Exception e) {
			e.printStackTrace();// TODO :Exception logging
		}
		LOGGER.debug("SyncServiceImpl -- getVesselId -- End");
		return vesselId;
	}

	@Override
	public SyncDataDto createSyncRecord(SyncData sync) throws Exception {
		LOGGER.debug("SyncServiceImpl -- createSyncRecord -- Start");
		if (sync == null) {
			throw new ApplicationServiceExecption("SyncData is null", HttpStatus.EXPECTATION_FAILED);
		}
		final SyncDataDto dto = mapEntityToDto.transformBO(sync, SyncDataDto.class);
		syncDataDao.save(sync);
		LOGGER.debug("SyncServiceImpl -- createSyncRecord -- End");
		return dto;
	}

	@Override
	public boolean exportSyncDataList(String vesselId, String syncType) throws Exception {
		LOGGER.debug("SyncServiceImpl -- exportSyncDataList -- Start");
		List<SyncData> syncDataList = syncDataDao.findAll();
		List<SyncEvent> syncEventList = syncEventDao.findAll();
		String folderPathData = commonUtil.systemHomeFolder("SYNC_DATA");
		String zipPath = commonUtil.systemHomeFolder("ZIP_DATA");

		if (syncDataList == null) {
			throw new ApplicationServiceExecption("SyncDataList is null", HttpStatus.EXPECTATION_FAILED);
		}
		/*
		 * String listString = syncDataList.stream().map(Object::toString)
		 * .collect(Collectors.joining("| "));
		 */
		syncDataOutput = new StringBuilder();
		for (SyncData data : syncDataList) {
			syncDataOutput.append(data.getAction() + "|" + data.getSyncData());
			syncDataOutput.append("\n");
		}

		syncEventOutput = new StringBuilder();

		for (SyncEvent eventData : syncEventList) {
			syncEventOutput.append(eventData.getSyncType() + "\n" + eventData.getToSeq() + "\n"
					+ eventData.getSenderId() + "\n" + eventData.getReceiverId() + "\n" + eventData.getSyncPacketNo()
					+ "\n" + eventData.getFromSeq() + "\n" + eventData.getSyncMode() + "\n" + eventData.getDbVersion()
					+ "\n" + eventData.getConfirmedSeqNo() + "\n" + eventData.getConfirmedPacketNo());
		}

		jsonPath = Paths.get(folderPathData + "/", "sync_data.json");
		eventDataPath = Paths.get(folderPathData + "/", "sync_data_details.txt");

		boolean isReadble = Files.isReadable(jsonPath);
		Files.write(jsonPath, syncDataOutput.toString().getBytes("UTF-8"));
		Files.write(eventDataPath, syncEventOutput.toString().getBytes("UTF-8"));

		try {
			compressWithPassword(folderPathData, zipPath);
		} catch (ZipException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		LOGGER.debug("SyncServiceImpl -- exportSyncDataList -- End");

		return isReadble;
	}

	private void compressWithPassword(String folderPath, String zipPath) throws Exception {
		Timestamp timestamp = new Timestamp(System.currentTimeMillis());
		String destPath = folderPath + "DATA_SYNC_OFF_" + timestamp;
		System.out.println("Destination " + destPath);
		ZipFile zipFile = new ZipFile(destPath);
		// Setting parameters
		ZipParameters zipParameters = new ZipParameters();
		zipParameters.setCompressionMethod(Zip4jConstants.COMP_DEFLATE);
		zipParameters.setCompressionLevel(Zip4jConstants.DEFLATE_LEVEL_ULTRA);
		zipParameters.setEncryptFiles(true);
		zipParameters.setEncryptionMethod(Zip4jConstants.ENC_METHOD_AES);
		zipParameters.setAesKeyStrength(Zip4jConstants.AES_STRENGTH_256);
		// Setting password
		zipParameters.setPassword("test");
		zipFile.addFolder(zipPath, zipParameters);
	}

	private void unCompressPasswordProtectedFiles(String sourcePath) throws Exception {
		String destPath = getFileName(sourcePath);
		System.out.println("Destination " + destPath);
		ZipFile zipFile = new ZipFile(sourcePath);
		// If it is encrypted then provide password
		if (zipFile.isEncrypted()) {
			zipFile.setPassword("password");
		}
		zipFile.extractAll(destPath);
	}

	private String getFileName(String filePath) {
		// Get the folder name from the zipped file by removing .zip extension
		return filePath.substring(0, filePath.lastIndexOf("."));
	}

	@Override
	public boolean exportSyncDataList(String vesselId) throws Exception {
		// TODO Auto-generated method stub
		return false;
	}

}
