/**
 * 
 */
package in.ind.mds.serviceImpl;

import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import in.ind.mds.dto.CrewCourseCategoryDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.repo.dao.CrewCourseCategoryDao;
import in.ind.mds.repo.entity.CrewCourseCategory;
import in.ind.mds.service.CrewCourseCategoryService;
import in.ind.mds.service.SyncDataService;
import in.ind.mds.util.BeanTransformerUtil;
import in.ind.mds.util.CommonUtil;
import in.ind.mds.util.DBUtil;

/**
 * @author mds_kiruthika
 *
 */
@Service("TST_MSSQL_CREWCOURSE")
public class CrewCourseCategoryServiceImpl implements CrewCourseCategoryService{

	private static final Logger LOGGER = LoggerFactory.getLogger(CrewCourseCategoryServiceImpl.class);

	@Autowired
	private BeanTransformerUtil<CrewCourseCategory, CrewCourseCategoryDto> mapEntityToDto;

	@Autowired
	private BeanTransformerUtil<CrewCourseCategoryDto, CrewCourseCategory> mapDtoToEntity;
	
	@Autowired
	@Qualifier("TST_MSSQL_SYNC")
	private SyncDataService syncDataService;
	
	 @Autowired
	 private CommonUtil<CrewCourseCategoryDto> commonUtil;
	
	@Autowired
	private CrewCourseCategoryDao crewCourseDao;

	@Autowired
	private DBUtil dbUtil;
	
	@Override
	public CrewCourseCategoryDto add(CrewCourseCategoryDto crewCourseCategoryDto) throws Exception {
		// TODO Auto-generated method stub
		
		LOGGER.debug("CrewCourseCategoryServiceImpl -- add -- Start");
		commonUtil.stringNullValidator(crewCourseCategoryDto.getCourseName(), "Training Course category");
		CrewCourseCategory crewCourseCategory=crewCourseDao.findByCourseNameAndStatusNot(crewCourseCategoryDto.getCourseName(), commonUtil.getSoftDeleteStatus());
		if(crewCourseCategory!=null)
			throw new ApplicationServiceExecption("Course Category already exist", HttpStatus.BAD_REQUEST);
		crewCourseCategory=mapDtoToEntity.transformBO(crewCourseCategoryDto, CrewCourseCategory.class);
		String seqName = dbUtil.getNextSequence(crewCourseCategory.getClass());
		if (seqName != null) {
			crewCourseCategory.setId(seqName);
		}
		crewCourseCategory.setInsertTime(new Date());
		crewCourseCategory.setUpdateTime(new Date());
		crewCourseCategory.setStatus(commonUtil.getActiveStatus());
		crewCourseCategory=crewCourseDao.save(crewCourseCategory);
		syncDataService.syncCreation(crewCourseCategory);
		LOGGER.debug("CrewCourseCategoryServiceImpl -- add -- End");
		return mapEntityToDto.transformBO(crewCourseCategory, CrewCourseCategoryDto.class);
	}

	
	@Override
	public CrewCourseCategoryDto findByCrewCourseId(String crewCourseId) throws Exception {
		// TODO Auto-generated method stub
		LOGGER.debug("CrewCourseCategoryServiceImpl -- findByCrewCourseId -- Start");
		commonUtil.stringNullValidator(crewCourseId, "CrewCourse Id");
		CrewCourseCategory crewCourseCategory=crewCourseDao.findByIdAndStatusNot(crewCourseId, commonUtil.getSoftDeleteStatus());
		if(crewCourseCategory==null)
			throw new ApplicationServiceExecption("Crew Course not found", HttpStatus.NOT_FOUND);
		final CrewCourseCategoryDto dto = mapEntityToDto.transformBO(crewCourseCategory, CrewCourseCategoryDto.class);

		LOGGER.debug("CrewCourseCategoryServiceImpl -- findByCrewCourseId -- End");

		return dto;
	}

	
	@Override
	public List<CrewCourseCategoryDto> findAllCrewCourse() throws Exception {
		// TODO Auto-generated method stub
		
		LOGGER.debug("CrewCourseCategoryServiceImpl -- add -- Start");
		List<CrewCourseCategory> crewCourseCategories = crewCourseDao.findAllCrewCourse();
		
		if(crewCourseCategories.size()==0)
			throw new ApplicationServiceExecption("Crew Category not found", HttpStatus.NOT_FOUND);
		
		final List<CrewCourseCategoryDto> listDto = mapEntityToDto.transformListOfBO(crewCourseCategories, CrewCourseCategoryDto.class);

		LOGGER.debug("CrewCourseCategoryServiceImpl -- add -- End");

		return listDto;
	}

	
	@Override
	public List<CrewCourseCategoryDto> softDeleteCrewCourse(List<String> crewCourseIds) throws Exception {
		// TODO Auto-generated method stub
		
		LOGGER.debug("CrewCourseCategoryServiceImpl -- softDeleteCrewCourse -- Start");
		List<CrewCourseCategory> existingCrewCategoryList = crewCourseDao.findByIdInAndStatusNot(crewCourseIds, commonUtil.getSoftDeleteStatus());
		if (existingCrewCategoryList.size() < crewCourseIds.size()) 
			throw new ApplicationServiceExecption("Crewcourse not found", HttpStatus.BAD_REQUEST);
		
		
		List<CrewCourseCategoryDto> existingCrewCourseDtoList=mapEntityToDto.transformListOfBO(existingCrewCategoryList, CrewCourseCategoryDto.class);
		
		for(CrewCourseCategory crewCourseCategory:existingCrewCategoryList)
		{
			crewCourseCategory.setStatus(commonUtil.getSoftDeleteStatus());;
			crewCourseCategory.setUpdateTime(new Date());
		}
		
		existingCrewCategoryList =crewCourseDao.saveAll(existingCrewCategoryList);
		Integer count=0;
		for(CrewCourseCategory crewCourseCategory:existingCrewCategoryList)
		{
			syncDataService.syncUpdate(mapDtoToEntity.transformBO(existingCrewCourseDtoList.get(count), CrewCourseCategory.class), crewCourseCategory);
			count++;
			
		}
		List<CrewCourseCategory> crewCourseCategoryList=crewCourseDao.findAllCrewCourse();
		LOGGER.debug("CrewCourseCategoryServiceImpl -- softDeleteCrewCourse -- End");

		return mapEntityToDto.transformListOfBO(crewCourseCategoryList, CrewCourseCategoryDto.class);
	}

	
	@Override
	public CrewCourseCategoryDto updateCrewCourse(CrewCourseCategoryDto crewCourseDto) throws Exception {
		// TODO Auto-generated method stub
		
		LOGGER.debug("CrewCourseCategoryServiceImpl -- updateCrewCourse -- Start");
		commonUtil.stringNullValidator(crewCourseDto.getId(), "Crew course Id");
		List<CrewCourseCategory> crewCourseCategories = crewCourseDao.uniqueCheckForUpdate(crewCourseDto.getId(), crewCourseDto.getCourseName());
		if(crewCourseCategories.size() != 0)
			throw new ApplicationServiceExecption("Training Course already exist", HttpStatus.BAD_REQUEST);
		
		CrewCourseCategory crewCourseCategory = crewCourseDao.findByIdAndStatusNot(crewCourseDto.getId(), commonUtil.getSoftDeleteStatus());
		if (crewCourseCategory == null) 
			throw new ApplicationServiceExecption("Training Course not found", HttpStatus.BAD_REQUEST);
		
		CrewCourseCategoryDto existingCrewCourse = mapEntityToDto.transformBO(crewCourseCategory, CrewCourseCategoryDto.class);
		CrewCourseCategory crewCourseCategoryEntity = mapDtoToEntity.transformBO(crewCourseDto, CrewCourseCategory.class);
		crewCourseCategoryEntity.setUpdateTime(new Date());
		crewCourseCategoryEntity=crewCourseDao.saveAndFlush(crewCourseCategoryEntity);
		syncDataService.syncUpdate(mapDtoToEntity.transformBO(existingCrewCourse, CrewCourseCategory.class), crewCourseCategoryEntity);
		LOGGER.debug("CrewCourseCategoryServiceImpl -- updateCrewCourse -- End");

		return mapEntityToDto.transformBO(crewCourseCategoryEntity, CrewCourseCategoryDto.class);
	}

}
