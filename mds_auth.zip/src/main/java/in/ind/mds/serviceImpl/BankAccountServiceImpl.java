/**
 * 
 */
package in.ind.mds.serviceImpl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import in.ind.mds.dto.AttachmentDto;
import in.ind.mds.dto.BankAccountDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.repo.dao.BankAccountDao;
import in.ind.mds.repo.entity.BankAccount;
import in.ind.mds.repo.entity.Staff;
import in.ind.mds.service.AttachmentService;
import in.ind.mds.service.BankAccountService;
import in.ind.mds.service.SyncDataService;
import in.ind.mds.util.BeanTransformerUtil;
import in.ind.mds.util.CommonUtil;
import in.ind.mds.util.DBUtil;

/**
 * @author mds-arockia
 *
 */
@Service("TST_MSSQL_BANK_ACCOUNT")
public class BankAccountServiceImpl implements BankAccountService {

	private static final Logger LOGGER = LoggerFactory.getLogger(BankAccountServiceImpl.class);

	@Autowired
	private BeanTransformerUtil<BankAccount, BankAccountDto> mapEntityToDto;

	@Autowired
	private BeanTransformerUtil<BankAccountDto, BankAccount> mapDtoToEntity;

	@Autowired
	@Qualifier("TST_MSSQL_SYNC")
	private SyncDataService syncDataService;

	@Autowired
	private CommonUtil<BankAccountDto> commonUtil;

	@Autowired
	private BankAccountDao bankAccountDao;

	@Autowired
	@Qualifier("TST_MSSQL_ATTACHEMENT")
	private AttachmentService attachmentService;

	@Autowired
	private DBUtil dbUtil;

	@Override
	public List<BankAccountDto> add(Staff staff, List<BankAccountDto> bankAccountDtoList, MultipartFile[] attachmentFiles) throws Exception {
		LOGGER.debug("BankAccountServicImpl -- add -- start");
		bankAccountDtoList = addBankAccount(staff, bankAccountDtoList, attachmentFiles);
		
		LOGGER.debug("BankAccountServicImpl -- add -- end");
		return bankAccountDtoList;
	}

	/*
	 * Update BankAccount Details
	 * 	newly added data will be handled as add -. addBankAccount()
	 *  existing data will be updated
	*/
	@Override
	public List<BankAccountDto> update(Staff staff, List<BankAccountDto> bankAccountDtoList, MultipartFile[] attachmentFiles)
			throws Exception {
		LOGGER.debug("BankAccountServicImpl -- update -- start");
		List<BankAccountDto> bankAccountDtoListForAdd = new ArrayList<>();
		List<BankAccountDto> bankAccountListForUpdate = new ArrayList<>();
		for (BankAccountDto bankAccountDto : bankAccountDtoList) {
			if(bankAccountDto.getId() == null)
				bankAccountDtoListForAdd.add(bankAccountDto);
			else
				bankAccountListForUpdate.add(bankAccountDto);
		}
		if(!bankAccountDtoListForAdd.isEmpty())
		bankAccountDtoList = addBankAccount(staff, bankAccountDtoListForAdd, attachmentFiles);
		
		List<String> bankAccoutIds = bankAccountListForUpdate.stream().map(i -> i.getId()).collect(Collectors.toList());
		List<BankAccount> bankAccountList = bankAccountDao.findByIdInAndStatusNot(bankAccoutIds, commonUtil.getSoftDeleteStatus());
		if(bankAccountList.size() < bankAccoutIds.size())
			throw new ApplicationServiceExecption("Bank Account not found");
		
		List<BankAccountDto> existingBankAccountDtoList = mapEntityToDto.transformListOfBO(bankAccountList, BankAccountDto.class);
		bankAccountList = mapDtoToEntity.transformListOfBO(bankAccountListForUpdate, BankAccount.class);
		for (BankAccount bankAccount : bankAccountList) {
			bankAccount.setUpdateTime(new Date());
		}
		
		/**********************delete and add attachments of BankAccount********start**********/
		List<BankAccountDto> returnBankAccountDtoListForUpdate = mapEntityToDto.transformListOfBO(bankAccountList, BankAccountDto.class);
		Integer count = 0;
		for (BankAccountDto bankAccountDto : bankAccountListForUpdate) {
			if(!bankAccountDto.getSoftDeleteDocPaths().isEmpty()) 
				attachmentService.softDeleteByPathList(bankAccountDto.getSoftDeleteDocPaths());
			
			List<MultipartFile> thisAttachmentFiles = new ArrayList<>();
				for (String bankAccountDoc : bankAccountDto.getBankAccountDoc()) {
					//Integer index = 0;
					//Integer removeAttachmentIndex = null;
					for (MultipartFile attachment : attachmentFiles) {
						if(bankAccountDoc.equals(attachment.getOriginalFilename())) {
							thisAttachmentFiles.add(attachment); 
							//removeAttachmentIndex = index;
						}
						//index++;
					}
					//ArrayUtils.remove(attachmentFiles, removeAttachmentIndex);
				}
			AttachmentDto attachmentDto = new AttachmentDto();
			attachmentDto.setRecordId(bankAccountList.get(count).getId());
			attachmentDto.setAttachmentOrigin(dbUtil.getTableName((mapDtoToEntity.transformBO(bankAccountDto, BankAccount.class)).getClass()));
			attachmentDto.setAttachmentType(bankAccountDto.getBankAccountDocFieldName());
			List<String> staffPicPathList = attachmentService.add(attachmentDto, thisAttachmentFiles);
			returnBankAccountDtoListForUpdate.get(count).setBankAccountDoc(staffPicPathList);
			count++;
		}
		/**********************delete and add attachments of BankAccount********end**********/
		
		bankAccountDao.saveAll(bankAccountList);
		count = 0;
		for (BankAccount bankAccount : bankAccountList) {
			syncDataService.syncUpdate(mapDtoToEntity.transformBO(existingBankAccountDtoList.get(count), BankAccount.class), bankAccount);
			count++;
		}
		bankAccountDtoList.addAll(returnBankAccountDtoListForUpdate);
		LOGGER.debug("BankAccountServicImpl -- update -- end");
		return bankAccountDtoList;
	}

	@Override
	public List<BankAccountDto> findByStaff(Staff staff) throws Exception {
		LOGGER.debug("BankAccountServicImpl -- findByStaff -- start");
		List<BankAccountDto> bankAccountDtoList = new ArrayList<>();
		List<BankAccount> bankAccountList = bankAccountDao.findByStaffAndStatusNot(staff, commonUtil.getSoftDeleteStatus());
		if(bankAccountList.isEmpty())
			return bankAccountDtoList;
		
		bankAccountDtoList = mapEntityToDto.transformListOfBO(bankAccountList, BankAccountDto.class);
		String attachmentOrigin = dbUtil.getTableName(bankAccountList.get(0).getClass());
		for (BankAccountDto bankAccountDto : bankAccountDtoList) {
			AttachmentDto attachmentDto = new AttachmentDto();
			attachmentDto.setAttachmentOrigin(attachmentOrigin);
			attachmentDto.setRecordId(bankAccountDto.getId());
			attachmentDto.setAttachmentType(bankAccountDto.getBankAccountDocFieldName());
			bankAccountDto.setBankAccountDoc(attachmentService.findAttachments(attachmentDto));
		}
		LOGGER.debug("BankAccountServicImpl -- findByStaff -- end");
		return bankAccountDtoList;
	}

	@Override
	public void softDeleteByStaff(Staff staff) throws Exception {
		LOGGER.debug("BankAccountServicImpl -- softDelete -- start");
		List<BankAccount> bankAccountList = bankAccountDao.findByStaffAndStatusNot(staff, commonUtil.getSoftDeleteStatus());
		List<BankAccountDto> bankAccountDtoList = mapEntityToDto.transformListOfBO(bankAccountList, BankAccountDto.class);
		for (BankAccount bankAccount : bankAccountList) {
			bankAccount.setUpdateTime(new Date());
			bankAccount.setStatus(commonUtil.getSoftDeleteStatus());
		}
		Integer count = 0;
		for (BankAccount bankAccount : bankAccountList) {
			syncDataService.syncUpdate(mapDtoToEntity.transformBO(bankAccountDtoList.get(count), BankAccount.class), bankAccount);
			attachmentService.softDelete(bankAccount.getId(), dbUtil.getTableName(bankAccount.getClass()));
			count++;
		}
		LOGGER.debug("BankAccountServicImpl -- softDelete -- end");
	}
	
	@Override
	public void softDelete(List<String> ids) throws Exception {
		LOGGER.debug("BankAccountServicImpl -- softDelete -- start");
			commonUtil.stringNullValidator(ids.toArray(), "BankAccount Id");
			List<BankAccount> bankAccountList = bankAccountDao.findByIdInAndStatusNot(ids, commonUtil.getSoftDeleteStatus());
			if(bankAccountList.size() <  ids.size())
				throw new ApplicationServiceExecption("BankAccount not found");
			
			List<BankAccountDto> bankAccountDtoList = mapEntityToDto.transformListOfBO(bankAccountList, BankAccountDto.class);
			for (BankAccount bankAccount : bankAccountList) {
				bankAccount.setUpdateTime(new Date());
				bankAccount.setStatus(commonUtil.getSoftDeleteStatus());
			}
			Integer count = 0;
			for (BankAccount bankAccount : bankAccountList) {
				syncDataService.syncUpdate(mapDtoToEntity.transformBO(bankAccountDtoList.get(count), BankAccount.class), bankAccount);
				attachmentService.softDelete(bankAccount.getId(), dbUtil.getTableName(bankAccount.getClass()));
				count++;
			}
		LOGGER.debug("BankAccountServicImpl -- softDelete -- end");
	}
	
	private List<BankAccountDto> addBankAccount(Staff staff, List<BankAccountDto> bankAccountDtoList, MultipartFile[] attachmentFiles) throws Exception{
		LOGGER.debug("BankAccountServicImpl -- addBankAccountMethod -- start");
		List<BankAccount> bankAccountList = mapDtoToEntity.transformListOfBO(bankAccountDtoList, BankAccount.class);
		for (BankAccount bankAccount : bankAccountList) {
			String seqName = dbUtil.getNextSequence(bankAccount.getClass());
			if(seqName != null)
				bankAccount.setId(seqName);
			
			bankAccount.setStaff(staff);
			bankAccount.setInsertTime(new Date());
			bankAccount.setUpdateTime(new Date());
			bankAccount.setStatus(commonUtil.getActiveStatus());
		}
		List<BankAccountDto> returnBankAccountDtoList = mapEntityToDto.transformListOfBO(bankAccountList, BankAccountDto.class);
		Integer count = 0;
		for (BankAccountDto bankAccountDto : bankAccountDtoList) {
			List<MultipartFile> thisAttachmentFiles = new ArrayList<>();
				for (String bankAccountDoc : bankAccountDto.getBankAccountDoc()) {
					//Integer index = 0;
					//Integer removeAttachmentIndex = null;
					for (MultipartFile attachment : attachmentFiles) {
						if(bankAccountDoc.equals(attachment.getOriginalFilename())) {
							thisAttachmentFiles.add(attachment); 
							//removeAttachmentIndex = index;
						}
						//index++;
					}
					//ArrayUtils.remove(attachmentFiles, removeAttachmentIndex);
				}
			AttachmentDto attachmentDto = new AttachmentDto();
			attachmentDto.setRecordId(bankAccountList.get(count).getId());
			attachmentDto.setAttachmentOrigin(dbUtil.getTableName((mapDtoToEntity.transformBO(bankAccountDto, BankAccount.class)).getClass()));
			attachmentDto.setAttachmentType(bankAccountDto.getBankAccountDocFieldName());
			List<String> staffPicPathList = attachmentService.add(attachmentDto, thisAttachmentFiles);
			returnBankAccountDtoList.get(count).setBankAccountDoc(staffPicPathList);
			count++;
		}
		bankAccountDao.saveAll(bankAccountList);
		for (BankAccount bankAccount : bankAccountList) {
			syncDataService.syncCreation(bankAccount);
		}
		LOGGER.debug("BankAccountServicImpl -- addBankAccountMethod -- end");
		return returnBankAccountDtoList;
	}
	
}
