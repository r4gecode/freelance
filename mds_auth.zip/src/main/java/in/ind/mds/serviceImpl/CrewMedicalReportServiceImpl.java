/**
 * 
 */
package in.ind.mds.serviceImpl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import in.ind.mds.dto.AttachmentDto;
import in.ind.mds.dto.CrewMedicalReportDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.repo.dao.CrewMedicalReportDao;
import in.ind.mds.repo.entity.CrewMedicalReport;
import in.ind.mds.repo.entity.Staff;
import in.ind.mds.service.AttachmentService;
import in.ind.mds.service.CrewMedicalReportService;
import in.ind.mds.service.SyncDataService;
import in.ind.mds.util.BeanTransformerUtil;
import in.ind.mds.util.CommonUtil;
import in.ind.mds.util.DBUtil;

/**
 * @author mds-arockia
 *
 */
@Service("TST_MSSQL_CREW_MEDICAL_REPORT")
public class CrewMedicalReportServiceImpl implements CrewMedicalReportService{

	private static final Logger LOGGER = LoggerFactory.getLogger(CrewMedicalReportServiceImpl.class);

	@Autowired
	private BeanTransformerUtil<CrewMedicalReport, CrewMedicalReportDto> mapEntityToDto;

	@Autowired
	private BeanTransformerUtil<CrewMedicalReportDto, CrewMedicalReport> mapDtoToEntity;

	@Autowired
	@Qualifier("TST_MSSQL_SYNC")
	private SyncDataService syncDataService;

	@Autowired
	private CommonUtil<CrewMedicalReportDto> commonUtil;

	@Autowired
	private CrewMedicalReportDao crewMedicalReportDao;

	@Autowired
	@Qualifier("TST_MSSQL_ATTACHEMENT")
	private AttachmentService attachmentService;

	@Autowired
	private DBUtil dbUtil;


	@Override
	public List<CrewMedicalReportDto> add(Staff staff, List<CrewMedicalReportDto> medReportDtoList,
			MultipartFile[] attachmentFiles) throws Exception {
		LOGGER.debug("CrewMedicalReportServicImpl -- add -- start");
		medReportDtoList = addMedicalReport(staff, medReportDtoList, attachmentFiles);
		LOGGER.debug("CrewMedicalReportServicImpl -- add -- end");
		return medReportDtoList;
	}



	@Override
	public List<CrewMedicalReportDto> update(Staff staff, List<CrewMedicalReportDto> medReportDtoList,
			MultipartFile[] attachmentFiles) throws Exception {
		LOGGER.debug("CrewMedicalReportServicImpl -- update -- start");
		List<CrewMedicalReportDto> medReportDtoListForAdd = new ArrayList<>();
		List<CrewMedicalReportDto> medReportDtoListForUpdate = new ArrayList<>();
		for (CrewMedicalReportDto medReportDto : medReportDtoList) {
			if(medReportDto.getId() == null)
				medReportDtoListForAdd.add(medReportDto);
			else
				medReportDtoListForUpdate.add(medReportDto);
		}
		if(!medReportDtoListForAdd.isEmpty())
			medReportDtoList = addMedicalReport(staff, medReportDtoListForAdd, attachmentFiles);
		
		List<String> medReportIds = medReportDtoListForUpdate.stream().map(i -> i.getId()).collect(Collectors.toList());
		List<CrewMedicalReport> medReportList = crewMedicalReportDao.findByIdInAndStatusNot(medReportIds, commonUtil.getSoftDeleteStatus());
		if(medReportList.size() < medReportIds.size())
			throw new ApplicationServiceExecption("MedicalReport not found");
		
		List<CrewMedicalReportDto> existingMedReportDtoList = mapEntityToDto.transformListOfBO(medReportList, CrewMedicalReportDto.class);
		medReportList = mapDtoToEntity.transformListOfBO(medReportDtoListForUpdate, CrewMedicalReport.class);
		for (CrewMedicalReport medReport : medReportList) {
			medReport.setUpdateTime(new Date());
		}
		/**********************delete and add attachments of CrewMedicalReport********start**********/
		List<CrewMedicalReportDto> returnMedReportDtoList = mapEntityToDto.transformListOfBO(medReportList, CrewMedicalReportDto.class);
		Integer count = 0;
		for (CrewMedicalReportDto medReportDto : medReportDtoListForUpdate) {
			if(!medReportDto.getSoftDeleteDocPaths().isEmpty())
				attachmentService.softDeleteByPathList(medReportDto.getSoftDeleteDocPaths());
			
			List<MultipartFile> thisAttachmentFiles = new ArrayList<>();
				for (String medReportDoc : medReportDto.getMedicalReportDoc()) {
					//Integer index = 0;
					//Integer removeAttachmentIndex = null;
					for (MultipartFile attachment : attachmentFiles) {
						if(medReportDoc.equals(attachment.getOriginalFilename())) {
							thisAttachmentFiles.add(attachment); 
						//	removeAttachmentIndex = index;
						}
						//index++;
					}
					//ArrayUtils.remove(attachmentFiles, removeAttachmentIndex);
				}
			AttachmentDto attachmentDto = new AttachmentDto();
			attachmentDto.setRecordId(medReportList.get(count).getId());
			attachmentDto.setAttachmentOrigin(dbUtil.getTableName((mapDtoToEntity.transformBO(medReportDto, CrewMedicalReport.class)).getClass()));
			attachmentDto.setAttachmentType(medReportDto.getMedicalReportDocFieldName());
			List<String> medReportDocPathList = attachmentService.add(attachmentDto, thisAttachmentFiles);
			returnMedReportDtoList.get(count).setMedicalReportDoc(medReportDocPathList);
			count++;
		}
		/**********************delete and add attachments of CrewMedicalReport********end**********/
		crewMedicalReportDao.saveAll(medReportList);
		count = 0;
		for (CrewMedicalReport medReport : medReportList) {
			syncDataService.syncUpdate(mapDtoToEntity.transformBO(existingMedReportDtoList.get(count), CrewMedicalReport.class), medReport);
			count++;
		}
		medReportDtoList.addAll(medReportDtoListForUpdate);
		LOGGER.debug("CrewMedicalReportServicImpl -- update -- end");
		return medReportDtoList;
	}



	@Override
	public List<CrewMedicalReportDto> findByStaff(Staff staff) throws Exception {
		LOGGER.debug("CrewContractServicImpl -- findByStaff -- start");
		List<CrewMedicalReportDto> medReportDtoList = new ArrayList<>();
		List<CrewMedicalReport> medReportList = crewMedicalReportDao.findByStaffAndStatusNot(staff, commonUtil.getSoftDeleteStatus());
		if(medReportList.isEmpty())
			return medReportDtoList;
		
		medReportDtoList = mapEntityToDto.transformListOfBO(medReportList, CrewMedicalReportDto.class);
		String attachmentOrigin = dbUtil.getTableName(medReportList.get(0).getClass());
		for (CrewMedicalReportDto medReportDto : medReportDtoList) {
			AttachmentDto attachmentDto = new AttachmentDto();
			attachmentDto.setAttachmentOrigin(attachmentOrigin);
			attachmentDto.setRecordId(medReportDto.getId());
			attachmentDto.setAttachmentType(medReportDto.getMedicalReportDocFieldName());
			medReportDto.setMedicalReportDoc(attachmentService.findAttachments(attachmentDto));
		}
		LOGGER.debug("CrewMedicalReportServicImpl -- findByStaff -- end");
		return medReportDtoList;
	}



	@Override
	public void softDeleteByStaff(Staff staff) throws Exception {
		LOGGER.debug("CrewMedicalReportServicImpl -- softDelete -- start");
		List<CrewMedicalReport> medReportList = crewMedicalReportDao.findByStaffAndStatusNot(staff, commonUtil.getSoftDeleteStatus());
		List<CrewMedicalReportDto> medReportDtoList = mapEntityToDto.transformListOfBO(medReportList, CrewMedicalReportDto.class);
		for (CrewMedicalReport medReport : medReportList) {
			medReport.setUpdateTime(new Date());
			medReport.setStatus(commonUtil.getSoftDeleteStatus());
		}
		Integer count = 0;
		for (CrewMedicalReport medReport : medReportList) {
			syncDataService.syncUpdate(mapDtoToEntity.transformBO(medReportDtoList.get(count), CrewMedicalReport.class), medReport);
			attachmentService.softDelete(medReport.getId(), dbUtil.getTableName(medReport.getClass()));
			count++;
		}
		LOGGER.debug("CrewMedicalReportServicImpl -- softDelete -- end");
	}



	@Override
	public void softDelete(List<String> ids) throws Exception {
		LOGGER.debug("CrewMedicalReportServicImpl -- softDelete -- start");
		commonUtil.stringNullValidator(ids.toArray(), "MedicalReport Id");
		List<CrewMedicalReport> medReportList = crewMedicalReportDao.findByIdInAndStatusNot(ids, commonUtil.getSoftDeleteStatus());
		if(medReportList.size() <  ids.size())
			throw new ApplicationServiceExecption("MedicalReport not found");
		
		List<CrewMedicalReportDto> medReportDtoList = mapEntityToDto.transformListOfBO(medReportList, CrewMedicalReportDto.class);
		for (CrewMedicalReport medReport : medReportList) {
			medReport.setUpdateTime(new Date());
			medReport.setStatus(commonUtil.getSoftDeleteStatus());
		}
		Integer count = 0;
		for (CrewMedicalReport medReport : medReportList) {
			syncDataService.syncUpdate(mapDtoToEntity.transformBO(medReportDtoList.get(count), CrewMedicalReport.class), medReport);
			attachmentService.softDelete(medReport.getId(), dbUtil.getTableName(medReport.getClass()));
			count++;
		}
		LOGGER.debug("CrewMedicalReportServicImpl -- softDelete -- end");
	}

	
	public List<CrewMedicalReportDto> addMedicalReport(Staff staff, List<CrewMedicalReportDto> medReportDtoList, MultipartFile[] attachmentFiles) throws Exception{
		LOGGER.debug("CrewMedicalReportServicImpl -- addMedReportMethod -- start");
		List<CrewMedicalReport> medReportList = mapDtoToEntity.transformListOfBO(medReportDtoList, CrewMedicalReport.class);
		for (CrewMedicalReport medReport : medReportList) {
			String seqName = dbUtil.getNextSequence(medReport.getClass());
			if(seqName != null)
				medReport.setId(seqName);
			
			medReport.setStaff(staff);
			medReport.setStatus(commonUtil.getActiveStatus());
			medReport.setInsertTime(new Date());
			medReport.setUpdateTime(new Date());
		}
		crewMedicalReportDao.saveAll(medReportList);
		for (CrewMedicalReport medReport : medReportList) {
			syncDataService.syncCreation(medReport);
		}
		List<CrewMedicalReportDto> returnMedReportDtoList = mapEntityToDto.transformListOfBO(medReportList, CrewMedicalReportDto.class);
		Integer count = 0;
		for (CrewMedicalReportDto medReportDto : medReportDtoList) {
			List<MultipartFile> thisAttachmentFiles = new ArrayList<>();
				for (String medReportDoc : medReportDto.getMedicalReportDoc()) {
					//Integer index = 0;
					//Integer removeAttachmentIndex = null;
					for (MultipartFile attachment : attachmentFiles) {
						if(medReportDoc.equals(attachment.getOriginalFilename())) {
							thisAttachmentFiles.add(attachment); 
						//	removeAttachmentIndex = index;
						}
						//index++;
					}
					//ArrayUtils.remove(attachmentFiles, removeAttachmentIndex);
				}
			AttachmentDto attachmentDto = new AttachmentDto();
			attachmentDto.setRecordId(medReportList.get(count).getId());
			attachmentDto.setAttachmentOrigin(dbUtil.getTableName((mapDtoToEntity.transformBO(medReportDto, CrewMedicalReport.class)).getClass()));
			attachmentDto.setAttachmentType(medReportDto.getMedicalReportDocFieldName());
			List<String> medReportDocPathList = attachmentService.add(attachmentDto, thisAttachmentFiles);
			returnMedReportDtoList.get(count).setMedicalReportDoc(medReportDocPathList);
			count++;
		}
		LOGGER.debug("CrewMedicalReportServicImpl -- addMedReportMethod -- end");
		return returnMedReportDtoList;
	}

}
