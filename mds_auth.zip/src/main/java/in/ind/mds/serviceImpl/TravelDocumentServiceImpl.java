/**
 * 
 */
package in.ind.mds.serviceImpl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import in.ind.mds.dto.AttachmentDto;
import in.ind.mds.dto.TravelDocumentDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.repo.dao.TravelDocumentDao;
import in.ind.mds.repo.entity.Staff;
import in.ind.mds.repo.entity.TravelDocument;
import in.ind.mds.service.AttachmentService;
import in.ind.mds.service.SyncDataService;
import in.ind.mds.service.TravelDocumentService;
import in.ind.mds.util.BeanTransformerUtil;
import in.ind.mds.util.CommonUtil;
import in.ind.mds.util.DBUtil;

/**
 * @author mds_kiruthika
 *
 */
@Service("TST_MSSQL_TRAVELDOC")
public class TravelDocumentServiceImpl implements TravelDocumentService {

	private static final Logger LOGGER = LoggerFactory.getLogger(TravelDocumentServiceImpl.class);

	@Autowired
	private BeanTransformerUtil<TravelDocument, TravelDocumentDto> mapEntityToDto;

	@Autowired
	private BeanTransformerUtil<TravelDocumentDto, TravelDocument> mapDtoToEntity;

	@Autowired
	private TravelDocumentDao travelDocumentDao;

	@Autowired
	private DBUtil dbUtil;

	@Autowired
	@Qualifier("TST_MSSQL_SYNC")
	private SyncDataService syncDataService;

	@Autowired
	@Qualifier("TST_MSSQL_ATTACHEMENT")
	private AttachmentService attachmentService;

	@Autowired
	private CommonUtil<TravelDocumentDto> commonUtil;

	@Override
	public List<TravelDocumentDto> add(Staff staff, List<TravelDocumentDto> traveldDocDtoList,
			MultipartFile[] attachmentFiles) throws Exception {
		// TODO Auto-generated method stub
		LOGGER.debug("TravelDocumentServiceImpl -- add -- Start");
		traveldDocDtoList = addTravelDocument(staff, traveldDocDtoList, attachmentFiles);

		LOGGER.debug("TravelDocumentServiceImpl -- add -- End");

		return traveldDocDtoList;
	}

	/**
	 * @param staff
	 * @param traveldDocDtoList
	 * @param attachmentFiles
	 * @return
	 */
	private List<TravelDocumentDto> addTravelDocument(Staff staff, List<TravelDocumentDto> traveldDocDtoList,
			MultipartFile[] attachmentFiles) throws Exception {
		// TODO Auto-generated method stub

		LOGGER.debug("TravelDocumentServiceImpl -- addTravelDocument -- Start");
		List<TravelDocument> travelDocumentList = mapDtoToEntity.transformListOfBO(traveldDocDtoList,
				TravelDocument.class);
		for (TravelDocument travelDocument : travelDocumentList) {
			String seqName = dbUtil.getNextSequence(travelDocument.getClass());

			if (seqName != null)
				travelDocument.setId(seqName);

			travelDocument.setStatus(commonUtil.getActiveStatus());
			travelDocument.setUpdateTime(new Date());
			travelDocument.setInsertTime(new Date());
			//travelDocument.setUpdateTime(new Date());
			travelDocument.setStaff(staff);
		}
		travelDocumentDao.saveAll(travelDocumentList);
		for (TravelDocument document : travelDocumentList) {
			syncDataService.syncCreation(document);
		}
		List<TravelDocumentDto> returnTravelDocDtoList = mapEntityToDto.transformListOfBO(travelDocumentList,
				TravelDocumentDto.class);
		Integer count = 0;

		for (TravelDocumentDto travelDocumentDto : traveldDocDtoList) {
			List<MultipartFile> thisAttachmentFiles = new ArrayList<>();
			for (String travelDocument : travelDocumentDto.getTravelDoc()) {
				// Integer index = 0;
				// Integer removeAttachmentIndex = null;
				for (MultipartFile attachment : attachmentFiles) {
					if (travelDocument.equals(attachment.getOriginalFilename())) {
						thisAttachmentFiles.add(attachment);
						// removeAttachmentIndex = index;
					}
					// index++;
				}
				// ArrayUtils.remove(attachmentFiles, removeAttachmentIndex);
			}
			AttachmentDto attachmentDto = new AttachmentDto();
			attachmentDto.setRecordId(travelDocumentList.get(count).getId());
			attachmentDto.setAttachmentOrigin(dbUtil
					.getTableName((mapDtoToEntity.transformBO(travelDocumentDto, TravelDocument.class)).getClass()));
			attachmentDto.setAttachmentType(travelDocumentDto.getTraveDocFieldName());
			List<String> travelDocPathList = attachmentService.add(attachmentDto, thisAttachmentFiles);
			returnTravelDocDtoList.get(count).setTravelDoc(travelDocPathList);
			count++;
		}

		LOGGER.debug("TravelDocumentServiceImpl -- addTravelDocument -- End");

		return returnTravelDocDtoList;
	}

	@Override
	public List<TravelDocumentDto> updateDocument(Staff staff, List<TravelDocumentDto> travelDocumentDtos,
			MultipartFile[] attachmentFiles) throws Exception {
		// TODO Auto-generated method stub
		LOGGER.debug("TravelDocumentServiceImpl -- updateDocument -- Start");

		List<TravelDocumentDto> travelDocDtoListForAdd = new ArrayList<>();
		List<TravelDocumentDto> travelDocListForUpdate = new ArrayList<>();

		for (TravelDocumentDto travelDocumentDto : travelDocumentDtos) {
			if (travelDocumentDto.getId() == null)
				travelDocDtoListForAdd.add(travelDocumentDto);
			else
				travelDocListForUpdate.add(travelDocumentDto);
		}

		if (!travelDocDtoListForAdd.isEmpty())
			travelDocumentDtos = addTravelDocument(staff, travelDocDtoListForAdd, attachmentFiles);

		List<String> travelDocIds = travelDocListForUpdate.stream().map(i -> i.getId()).collect(Collectors.toList());
		List<TravelDocument> travelDocumentList = travelDocumentDao.findByIdInAndStatusNot(travelDocIds,
				commonUtil.getSoftDeleteStatus());
		if (travelDocumentList.size() < travelDocIds.size())
			throw new ApplicationServiceExecption("Travel Document not found");

		List<TravelDocumentDto> existingTravelDocDtoList = mapEntityToDto.transformListOfBO(travelDocumentList,
				TravelDocumentDto.class);
		travelDocumentList = mapDtoToEntity.transformListOfBO(travelDocListForUpdate, TravelDocument.class);
		for (TravelDocument travelDocument : travelDocumentList) {
			travelDocument.setUpdateTime(new Date());
		}
		
		/**********************delete and add attachments of TravelDocument********start**********/
		List<TravelDocumentDto> returnTravelDocDtoList = mapEntityToDto.transformListOfBO(travelDocumentList,
				TravelDocumentDto.class);
		Integer count = 0;

		for (TravelDocumentDto travelDocumentDto : travelDocListForUpdate) {
			if(!travelDocumentDto.getSoftDeleteDocPaths().isEmpty())
				attachmentService.softDeleteByPathList(travelDocumentDto.getSoftDeleteDocPaths());
				
			List<MultipartFile> thisAttachmentFiles = new ArrayList<>();
			for (String travelDocument : travelDocumentDto.getTravelDoc()) {
				// Integer index = 0;
				// Integer removeAttachmentIndex = null;
				for (MultipartFile attachment : attachmentFiles) {
					if (travelDocument.equals(attachment.getOriginalFilename())) {
						thisAttachmentFiles.add(attachment);
						// removeAttachmentIndex = index;
					}
					// index++;
				}
				// ArrayUtils.remove(attachmentFiles, removeAttachmentIndex);
			}
			AttachmentDto attachmentDto = new AttachmentDto();
			attachmentDto.setRecordId(travelDocumentList.get(count).getId());
			attachmentDto.setAttachmentOrigin(dbUtil
					.getTableName((mapDtoToEntity.transformBO(travelDocumentDto, TravelDocument.class)).getClass()));
			attachmentDto.setAttachmentType(travelDocumentDto.getTraveDocFieldName());
			List<String> travelDocPathList = attachmentService.add(attachmentDto, thisAttachmentFiles);
			returnTravelDocDtoList.get(count).setTravelDoc(travelDocPathList);
			count++;
		}
		/**********************delete and add attachments of TravelDocument********end**********/
		
		travelDocumentDao.saveAll(travelDocumentList);
		count = 0;
		for (TravelDocument travelDocument : travelDocumentList) {
			syncDataService.syncUpdate(
					mapDtoToEntity.transformBO(existingTravelDocDtoList.get(count), TravelDocument.class),
					travelDocument);
			count++;
		}
		travelDocumentDtos.addAll(travelDocListForUpdate);

		LOGGER.debug("TravelDocumentServiceImpl -- updateDocument -- End");

		return travelDocumentDtos;
	}

	@Override
	public List<TravelDocumentDto> findByStaff(Staff staff) throws Exception {
		// TODO Auto-generated method stub
		LOGGER.debug("TravelDocumentServiceImpl -- findByStaff -- Start");
		List<TravelDocumentDto> travelDocumentDtoList = new ArrayList<>();
		List<TravelDocument> travelDocumentList = travelDocumentDao.findByStaffAndStatusNot(staff,
				commonUtil.getSoftDeleteStatus());

		if (travelDocumentList.isEmpty())
			return travelDocumentDtoList;
		travelDocumentDtoList = mapEntityToDto.transformListOfBO(travelDocumentList, TravelDocumentDto.class);
		String attachmentOrigin = dbUtil.getTableName(travelDocumentList.get(0).getClass());
		for (TravelDocumentDto travelDocumentDto : travelDocumentDtoList) {
			AttachmentDto attachmentDto = new AttachmentDto();
			attachmentDto.setAttachmentOrigin(attachmentOrigin);
			attachmentDto.setRecordId(travelDocumentDto.getId());
			attachmentDto.setAttachmentType(travelDocumentDto.getTraveDocFieldName());
			travelDocumentDto.setTravelDoc(attachmentService.findAttachments(attachmentDto));
		}

		LOGGER.debug("TravelDocumentServiceImpl -- findByStaff -- End");
		return travelDocumentDtoList;
	}

	@Override
	public void softDeleteDocument(List<String> documentIds) throws Exception {
		// TODO Auto-generated method stub
		LOGGER.debug("TravelDocumentServiceImpl -- softDeleteDocument -- Start");
		commonUtil.stringNullValidator(documentIds, "DocumentIds");

		List<TravelDocument> existingDocumentList = travelDocumentDao.findByIdInAndStatusNot(documentIds,
				commonUtil.getSoftDeleteStatus());
		if (existingDocumentList.size() < documentIds.size())
			throw new ApplicationServiceExecption("Travel Document not found", HttpStatus.BAD_REQUEST);

		List<TravelDocumentDto> existingDocumentDtoList = mapEntityToDto.transformListOfBO(existingDocumentList,
				TravelDocumentDto.class);

		for (TravelDocument travelDocument : existingDocumentList) {
			travelDocument.setStatus(commonUtil.getSoftDeleteStatus());
			travelDocument.setUpdateTime(new Date());
		}
		travelDocumentDao.saveAll(existingDocumentList);
		Integer count = 0;
		for (TravelDocument travelDocument : existingDocumentList) {
			syncDataService.syncUpdate(
					mapDtoToEntity.transformBO(existingDocumentDtoList.get(count), TravelDocument.class),
					travelDocument);
			attachmentService.softDelete(travelDocument.getId(), dbUtil.getTableName(travelDocument.getClass()));

			count++;
		}
		LOGGER.debug("TravelDocumentServiceImpl -- softDeleteDocument -- End");
	}

	@Override
	public void softDeleteByStaff(Staff staff) throws Exception {
		// TODO Auto-generated method stub
		LOGGER.debug("TravelDocumentServiceImpl -- softDeleteByStaff -- Start");
		List<TravelDocument> travelDocList = travelDocumentDao.findByStaffAndStatusNot(staff,
				commonUtil.getSoftDeleteStatus());
		List<TravelDocumentDto> travelDocDtoList = mapEntityToDto.transformListOfBO(travelDocList,
				TravelDocumentDto.class);

		for (TravelDocument travelDocument : travelDocList) {
			travelDocument.setUpdateTime(new Date());
			travelDocument.setStatus(commonUtil.getSoftDeleteStatus());
		}

		Integer count = 0;
		for (TravelDocument travelDocument : travelDocList) {
			syncDataService.syncUpdate(mapDtoToEntity.transformBO(travelDocDtoList.get(count), TravelDocument.class),
					travelDocument);
			attachmentService.softDelete(travelDocument.getId(), dbUtil.getTableName(travelDocument.getClass()));
			count++;
		}

		LOGGER.debug("TravelDocumentServiceImpl -- softDeleteByStaff -- End");

	}

}
