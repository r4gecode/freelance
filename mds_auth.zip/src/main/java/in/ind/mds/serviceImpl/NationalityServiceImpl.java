/**
 * 
 */
package in.ind.mds.serviceImpl;

import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import in.ind.mds.dto.NationalityDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.repo.dao.NationalityDao;
import in.ind.mds.repo.entity.Nationality;
import in.ind.mds.service.NationalityService;
import in.ind.mds.service.SyncDataService;
import in.ind.mds.util.BeanTransformerUtil;
import in.ind.mds.util.CommonUtil;
import in.ind.mds.util.DBUtil;

/**
 * @author mds-arockia
 *
 */
@Service("TST_MSSQL_NATIONALITY")
public class NationalityServiceImpl implements NationalityService{

	private static final Logger LOGGER = LoggerFactory.getLogger(NationalityServiceImpl.class);

	@Autowired
	private BeanTransformerUtil<Nationality, NationalityDto> mapEntityToDto;

	@Autowired
	private BeanTransformerUtil<NationalityDto, Nationality> mapDtoToEntity;

	@Autowired
	@Qualifier("TST_MSSQL_SYNC")
	private SyncDataService syncDataService;
	
	@Autowired
	private NationalityDao nationalityDao;
	
	@Autowired
	private DBUtil dbUtil;
	
	@Autowired
	private CommonUtil<NationalityDto> commonUtil;
	
	@Override
	public NationalityDto add(NationalityDto nationalityDto) throws Exception{
		LOGGER.debug("NationalityServiceImpl -- add -- Start");
		commonUtil.stringNullValidator(nationalityDto.getNationalityName(), "NationalityName");
		Nationality nationality = nationalityDao.findByNationalityNameAndStatusNot(nationalityDto.getNationalityName(), commonUtil.getSoftDeleteStatus());
		if(nationality != null)
			throw new ApplicationServiceExecption("Nationality already exist", HttpStatus.BAD_REQUEST);
		
		nationality = mapDtoToEntity.transformBO(nationalityDto, Nationality.class);
		
		String seqName = dbUtil.getNextSequence(nationality.getClass());
		if(seqName != null) 
			nationality.setId(seqName);
		
		nationality.setInsertTime(new Date());
		nationality.setUpdateTime(new Date());
		nationality.setStatus(commonUtil.getActiveStatus());
		nationality = nationalityDao.save(nationality);
		syncDataService.syncCreation(nationality);
		LOGGER.debug("NationalityServiceImpl -- add -- End");
		return mapEntityToDto.transformBO(nationality, NationalityDto.class);
	}

	@Override
	public NationalityDto getByNationalityId(String nationalityId) throws Exception{
		LOGGER.debug("NationalityServiceImpl -- getByNationalityId -- Start");
		commonUtil.stringNullValidator(nationalityId, "NationalityId");
		Nationality nationality = nationalityDao.findByIdAndStatusNot(nationalityId, commonUtil.getSoftDeleteStatus()); 
		if (nationality == null) 
			throw new ApplicationServiceExecption("Nationality not found", HttpStatus.NOT_FOUND);
		
		final NationalityDto dto = mapEntityToDto.transformBO(nationality, NationalityDto.class);
		LOGGER.debug("NationalityServiceImpl -- getByNationalityId -- End");
		return dto;
	}

	@Override
	public List<NationalityDto> findAll() throws Exception{
		LOGGER.debug("NationalityServiceImpl -- findAll -- Start");
		List<Nationality> nationality = nationalityDao.findAllNationality();

		if (nationality.size() == 0) 
			throw new ApplicationServiceExecption("Nationality not found", HttpStatus.NOT_FOUND);
		
		final List<NationalityDto> dto = mapEntityToDto.transformListOfBO(nationality, NationalityDto.class);
		LOGGER.debug("NationalityServiceImpl -- findAll -- End");
		return dto;
	}
	
	@Override
	public List<NationalityDto> softDeleteNationality(List<String> nationalityIds) throws Exception {
		LOGGER.debug("NationalityServiceImpl -- softDeleteNationality -- start");
		commonUtil.stringNullValidator(nationalityIds.toArray(), "NationalityId");
		List<Nationality> existingNationalityList = nationalityDao.findByIdInAndStatusNot(nationalityIds, commonUtil.getSoftDeleteStatus());
		if (existingNationalityList.size() < nationalityIds.size()) 
			throw new ApplicationServiceExecption("Nationality not found", HttpStatus.BAD_REQUEST);
		
		List<NationalityDto> existingNationalityDtoList = mapEntityToDto.transformListOfBO(existingNationalityList, NationalityDto.class);
		for (Nationality nationality : existingNationalityList) {
			nationality.setStatus(commonUtil.getSoftDeleteStatus());
			nationality.setUpdateTime(new Date());
		}
		nationalityDao.saveAll(existingNationalityList);
		Integer count = 0;
		for (Nationality nationality : existingNationalityList) {
			syncDataService.syncUpdate(mapDtoToEntity.transformBO(existingNationalityDtoList.get(count), Nationality.class), nationality);
			count++;
		}
		List<Nationality> nationalityList = nationalityDao.findAllNationality();
		LOGGER.debug("NationalityServiceImpl -- softDeleteNationality -- End");
		return mapEntityToDto.transformListOfBO(nationalityList, NationalityDto.class);
	}

	@Override
	public NationalityDto updateNationality(NationalityDto nationalityDto) throws Exception{
		LOGGER.debug("NationalityServiceImpl -- update -- Start");
		commonUtil.stringNullValidator(nationalityDto.getNationalityName(), nationalityDto.getId(), "Nationality Id and Name");;
		Nationality existingNationality = nationalityDao.findByNationalityNameAndStatusNotAndIdNot(nationalityDto.getNationalityName(), commonUtil.getSoftDeleteStatus(), nationalityDto.getId());
		if(existingNationality != null)
			throw new ApplicationServiceExecption("Nationality already exist", HttpStatus.BAD_REQUEST);
		
		existingNationality = nationalityDao.findByIdAndStatusNot(nationalityDto.getId(), commonUtil.getSoftDeleteStatus());
		if (existingNationality == null) 
			throw new ApplicationServiceExecption("Nationality not found", HttpStatus.BAD_REQUEST);
		
		NationalityDto existingNationalityDto = mapEntityToDto.transformBO(existingNationality, NationalityDto.class);
		Nationality nationality = mapDtoToEntity.transformBO(nationalityDto, Nationality.class);
		nationality.setUpdateTime(new Date());
		nationality = nationalityDao.saveAndFlush(nationality);
		syncDataService.syncUpdate(mapDtoToEntity.transformBO(existingNationalityDto, Nationality.class), nationality);
		LOGGER.debug("NationalityServiceImpl -- update -- End");
		return mapEntityToDto.transformBO(nationality, NationalityDto.class);
	}

}
