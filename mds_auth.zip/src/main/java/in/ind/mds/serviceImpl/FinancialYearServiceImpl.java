/**
 * 
 */
package in.ind.mds.serviceImpl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.time.DateUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import in.ind.mds.dto.AddressDto;
import in.ind.mds.dto.FinancialQuartersDto;
import in.ind.mds.dto.FinancialYearDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.repo.dao.FinancialQuartersDao;
import in.ind.mds.repo.dao.FinancialYearDao;
import in.ind.mds.repo.entity.FinancialQuarters;
import in.ind.mds.repo.entity.FinancialYear;
import in.ind.mds.service.FinancialYearService;
import in.ind.mds.service.SyncDataService;
import in.ind.mds.util.BeanTransformerUtil;
import in.ind.mds.util.CommonUtil;
import in.ind.mds.util.DBUtil;
import in.ind.mds.enums.Months;

/**
 * @author mds-arockia
 *
 */
@Service("TST_MSSQL_FINANCIAL_YEAR")
public class FinancialYearServiceImpl implements FinancialYearService{

	private static final Logger LOGGER = LoggerFactory.getLogger(FinancialYearServiceImpl.class);

	@Autowired
	private BeanTransformerUtil<FinancialYear, FinancialYearDto> mapEntityToDto;

	@Autowired
	private BeanTransformerUtil<FinancialYearDto, FinancialYear> mapDtoToEntity;
	
	@Autowired
	private BeanTransformerUtil<FinancialQuarters, FinancialQuartersDto> mapEntityToDtoQuarters;

	@Autowired
	private BeanTransformerUtil<FinancialQuartersDto, FinancialQuarters> mapDtoToEntityQuarters;

	@Autowired
	@Qualifier("TST_MSSQL_SYNC")
	private SyncDataService syncDataService;
	
	@Autowired
	private FinancialYearDao financialYearDao;
	
	@Autowired
	private FinancialQuartersDao financialQuartersDao;
	
	@Autowired
	private CommonUtil<AddressDto> commonUtil;
	
	@Autowired
	private DBUtil dbUtil;
	
	@Override
	public FinancialYearDto add(FinancialYearDto financialYearDto) throws Exception {
		LOGGER.debug("FinancialYearServiceImpl -- add -- Start");
		FinancialYear financialYear = setStartDateAndEndDate(financialYearDto);
		String seqName = dbUtil.getNextSequence(financialYear.getClass());
		if(seqName != null) {
			financialYear.setId(seqName);
		}
		financialYear.setInsertTime(new Date());
		financialYear.setUpdateTime(new Date());
		financialYear.setStatus(commonUtil.getActiveStatus());
		financialYearDao.save(financialYear);
		syncDataService.syncCreation(financialYear);
		List<FinancialQuarters> financialQuartersList = new ArrayList<>();
		financialQuartersList = makeFinancialQuarters(financialYear);
		financialQuartersList = financialQuartersDao.saveAll(financialQuartersList);
		for (FinancialQuarters financialQuarters : financialQuartersList) {
			syncDataService.syncCreation(financialQuarters);
		}
		LOGGER.debug("FinancialYearServiceImpl -- add -- End");
		return mapEntityToDto.transformBO(financialYear, FinancialYearDto.class);
	}

	@Override
	public FinancialYearDto update(FinancialYearDto financialYearDto) throws Exception {
		LOGGER.debug("FinancialYearServiceImpl -- update -- Start");
		FinancialYear financialYear = financialYearDao.findByIdAndStatusNot(financialYearDto.getId(), commonUtil.getSoftDeleteStatus());
		if(financialYear == null)
			throw new ApplicationServiceExecption("Financial Year not found");
		
		FinancialYearDto existingFinancialYearDto = mapEntityToDto.transformBO(financialYear, FinancialYearDto.class);
		financialYear = setStartDateAndEndDate(financialYearDto);
		financialYear.setUpdateTime(new Date());
		financialYear.setUpdatedBy(0);
		financialYear = financialYearDao.save(financialYear);
		syncDataService.syncUpdate(mapDtoToEntity.transformBO(existingFinancialYearDto, FinancialYear.class), financialYear);
		
		List<FinancialQuarters> financialQuarterList = financialQuartersDao.findByFinancialYearAndStatusNot(financialYear, commonUtil.getSoftDeleteStatus());
		List<FinancialQuartersDto> financialQuarterDtoList = mapEntityToDtoQuarters.transformListOfBO(financialQuarterList, FinancialQuartersDto.class);
		financialQuarterList = updateFinancialQuarters(financialYear, financialQuarterList);
		financialQuartersDao.saveAll(financialQuarterList);
		Integer count = 0;
		for (FinancialQuarters financialQuarters : financialQuarterList) {
			syncDataService.syncUpdate(mapDtoToEntityQuarters.transformBO(financialQuarterDtoList.get(count), FinancialQuarters.class), financialQuarters);
			count++;
		}
		LOGGER.debug("FinancialYearServiceImpl -- add -- End");
		return mapEntityToDto.transformBO(financialYear, FinancialYearDto.class);
	}

	@Override
	public List<FinancialYearDto> multipleSoftDelete(List<String> ids) throws Exception {
		LOGGER.debug("FinancialYearServiceImpl -- mulipleSoftDelete -- Start");
		List<FinancialYear> existingFinancialYear = financialYearDao.findByIdInAndStatusNot(ids, commonUtil.getSoftDeleteStatus());
		if(existingFinancialYear.size() < ids.size())
			throw new ApplicationServiceExecption("Financial Year not found");
		
		List<FinancialQuarters> financialQuarterList = financialQuartersDao.findByFinancialYearInAndStatusNot(existingFinancialYear, commonUtil.getSoftDeleteStatus());
		List<FinancialQuartersDto> financialQuarterDtoList = mapEntityToDtoQuarters.transformListOfBO(financialQuarterList, FinancialQuartersDto.class);
		for (FinancialQuarters financialQuarters : financialQuarterList) {
			financialQuarters.setStatus(commonUtil.getSoftDeleteStatus());
			financialQuarters.setUpdateTime(new Date());
		}
		Integer count = 0;
		for (FinancialQuarters financialQuarters : financialQuarterList) {
			syncDataService.syncUpdate(mapDtoToEntityQuarters.transformBO(financialQuarterDtoList.get(count), FinancialQuarters.class), financialQuarters);
			count++;
		}
		List<FinancialYearDto> existingFinancialYearDto = mapEntityToDto.transformListOfBO(existingFinancialYear, FinancialYearDto.class);
		for (FinancialYear financialYear : existingFinancialYear) {
			financialYear.setStatus(commonUtil.getSoftDeleteStatus());
		}
		existingFinancialYear = financialYearDao.saveAll(existingFinancialYear);
		count = 0;
		for (FinancialYear financialYear : existingFinancialYear) {
			syncDataService.syncUpdate(mapDtoToEntity.transformBO(existingFinancialYearDto.get(count), FinancialYear.class), financialYear);
			count++;
		}
		List<FinancialYear> FinancialYearList = financialYearDao.findAllFinancialYear();
		LOGGER.debug("FinancialYearServiceImpl -- mulipleSoftDelete -- end");
		return mapEntityToDto.transformListOfBO(FinancialYearList, FinancialYearDto.class);
	}
	
	public FinancialYear setStartDateAndEndDate(FinancialYearDto financialYearDto) {
		FinancialYear financialYear = mapDtoToEntity.transformBO(financialYearDto, FinancialYear.class);
		Months months = null;
		List<Months> monthList = Arrays.asList(months.values());
		Months startingMonth = null;
		Months endingMonth = null;
		for (Months month : monthList) {
			if(month.name().equalsIgnoreCase(financialYearDto.getStartingMonth())) {
				startingMonth = month;
				if(month.getCount() == 0)
					endingMonth = monthList.get(11);
				else
					endingMonth = monthList.get(monthList.indexOf(month) - 1);
			}
		}
		Date startingDate = new Date(financialYearDto.getStartingYear() - 1900, startingMonth.getCount(), 1);
		Date endingDate = new Date(financialYearDto.getStartingYear() - 1899, endingMonth.getCount(), endingMonth.getDays());
		financialYear.setStartingDate(startingDate);
		financialYear.setEndingDate(endingDate);
		return financialYear;
	}
	
	public List<FinancialQuarters> makeFinancialQuarters(FinancialYear financialYear){
		Date q2Start = DateUtils.addMonths(financialYear.getStartingDate(), 3);
		Date q3Start = DateUtils.addMonths(financialYear.getStartingDate(), 6);
		Date q4Start = DateUtils.addMonths(financialYear.getStartingDate(), 9);
		Map<Date, Date> quarterDates = new LinkedHashMap<>();
		quarterDates.put(financialYear.getStartingDate(), DateUtils.addDays(q2Start, -1));
		quarterDates.put(q2Start, DateUtils.addMonths(q3Start, -1));
		quarterDates.put(q3Start, DateUtils.addDays(q4Start, -1));
		quarterDates.put(q4Start, financialYear.getEndingDate());
		List<FinancialQuarters> financialQuartersList = new ArrayList<>();
		Integer count = 1;
		for(Map.Entry<Date, Date> entry : quarterDates.entrySet()) {
			FinancialQuarters finanialQuarters = new FinancialQuarters();
			finanialQuarters.setFinancialYear(financialYear);
			String quartersSeqName = dbUtil.getNextSequence(finanialQuarters.getClass());
			if(quartersSeqName != null) {
				finanialQuarters.setId(quartersSeqName);
			}
			finanialQuarters.setQuarterName("Q"+count);
			finanialQuarters.setInsertTime(new Date());
			finanialQuarters.setUpdateTime(new Date());
			finanialQuarters.setStatus(commonUtil.getActiveStatus());
			finanialQuarters.setStartDate(entry.getKey());
			finanialQuarters.setEndDate(entry.getValue());
			financialQuartersList.add(finanialQuarters);
		}
		return financialQuartersList;
	}
	
	public List<FinancialQuarters> updateFinancialQuarters(FinancialYear financialYear, List<FinancialQuarters> financialQuarterList){
		Date q2Start = DateUtils.addMonths(financialYear.getStartingDate(), 3);
		Date q3Start = DateUtils.addMonths(financialYear.getStartingDate(), 6);
		Date q4Start = DateUtils.addMonths(financialYear.getStartingDate(), 9);
		Map<Date, Date> quarterDates = new LinkedHashMap<>();
		quarterDates.put(financialYear.getStartingDate(), DateUtils.addDays(q2Start, -1));
		quarterDates.put(q2Start, DateUtils.addMonths(q3Start, -1));
		quarterDates.put(q3Start, DateUtils.addDays(q4Start, -1));
		quarterDates.put(q4Start, financialYear.getEndingDate());
		Integer count = 0;
		for (FinancialQuarters financialQuarters : financialQuarterList) {
			Object key = quarterDates.keySet().toArray()[count];
			financialQuarters.setStartDate((Date)key);
			financialQuarters.setEndDate(quarterDates.get(key));
			count++;
		}
		return financialQuarterList;
	}

}
