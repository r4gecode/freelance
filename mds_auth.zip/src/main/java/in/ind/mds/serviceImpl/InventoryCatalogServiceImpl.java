/**
 * 
 */
package in.ind.mds.serviceImpl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import in.ind.mds.dto.CompanyDto;
import in.ind.mds.dto.InventoryCatalogDto;
import in.ind.mds.dto.InventoryItemDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.repo.dao.FleetDao;
import in.ind.mds.repo.dao.InventoryCatalogDao;
import in.ind.mds.repo.dao.InventoryItemDao;
import in.ind.mds.repo.dao.VesselDao;
import in.ind.mds.repo.entity.Fleet;
import in.ind.mds.repo.entity.InventoryCatalog;
import in.ind.mds.repo.entity.InventoryItem;
import in.ind.mds.repo.entity.Vessel;
import in.ind.mds.service.InventoryCatalogService;
import in.ind.mds.service.SyncDataService;
import in.ind.mds.util.BeanTransformerUtil;
import in.ind.mds.util.CommonUtil;
import in.ind.mds.util.DBUtil;

/**
 * @author mds-arockia
 *
 */
@Service("TST_MSSQL_INVENTORY_CATALOG")
public class InventoryCatalogServiceImpl implements InventoryCatalogService {

	private static final Logger LOGGER = LoggerFactory.getLogger(InventoryCatalogServiceImpl.class);

	@Autowired
	private BeanTransformerUtil<InventoryCatalog, InventoryCatalogDto> mapEntityToDto;

	@Autowired
	private BeanTransformerUtil<InventoryCatalogDto, InventoryCatalog> mapDtoToEntity;

	@Autowired
	private BeanTransformerUtil<InventoryItem, InventoryItemDto> mapEntityToDtoInvItem;

	@Autowired
	private BeanTransformerUtil<InventoryItemDto, InventoryItem> mapDtoToEntityInvItem;
	
	@Autowired
	@Qualifier("TST_MSSQL_SYNC")
	private SyncDataService syncDataService;

	@Autowired
	private InventoryCatalogDao inventoryCatalogDao;

	@Autowired
	private InventoryItemDao inventoryItemDao;

	@Autowired
	private VesselDao vesselDao;

	@Autowired
	private FleetDao fleetDao;

	@Autowired
	private DBUtil dbUtil;

	@Autowired
	private CommonUtil<CompanyDto> commonUtil;

	@Override
	public InventoryCatalogDto add(InventoryCatalogDto inventoryCatalogDto) throws Exception {
		LOGGER.debug("InventoryCatalogServiceImpl -- add -- start");
		InventoryCatalog inventoryCatalog = mapDtoToEntity.transformBO(inventoryCatalogDto, InventoryCatalog.class);
		InventoryCatalog existingInventoryCatalog = new InventoryCatalog();
		
		if (inventoryCatalogDto.getVessel() != null) {
			 existingInventoryCatalog = inventoryCatalogDao.findByInventoryNameAndVesselAndFleetAndStatusNot(inventoryCatalog.getInventoryName(), inventoryCatalog.getVessel(), inventoryCatalog.getFleet(), commonUtil.getSoftDeleteStatus());
			if(existingInventoryCatalog != null)
				throw new ApplicationServiceExecption("Inventory Catalog already exist", HttpStatus.BAD_REQUEST);
		} else if(inventoryCatalogDto.getFleet() != null) {
			 existingInventoryCatalog = inventoryCatalogDao.findByInventoryNameAndFleetAndStatusNot(inventoryCatalog.getInventoryName(), inventoryCatalog.getFleet(), commonUtil.getSoftDeleteStatus());
			if(existingInventoryCatalog != null)
				throw new ApplicationServiceExecption("Inventory Catalog already exist", HttpStatus.BAD_REQUEST);
		}else {
			existingInventoryCatalog = inventoryCatalogDao.findByInventoryNameAndStatusNot(inventoryCatalog.getInventoryName(), commonUtil.getSoftDeleteStatus());
			if(existingInventoryCatalog != null)
				throw new ApplicationServiceExecption("Inventory Catalog already exist", HttpStatus.BAD_REQUEST);
		}
		
		String seqName = dbUtil.getNextSequence(inventoryCatalog.getClass());
		if (seqName != null)
			inventoryCatalog.setId(seqName);

		inventoryCatalog.setInsertTime(new Date());
		inventoryCatalog.setUpdateTime(new Date());
		inventoryCatalog.setInsertedBy(0);
		inventoryCatalog.setUpdatedBy(0);
		inventoryCatalog.setStatus(commonUtil.getActiveStatus());
		inventoryCatalog = inventoryCatalogDao.save(inventoryCatalog);
		syncDataService.syncCreation(inventoryCatalog);
		
		List<InventoryItem> inventoryItemList = new ArrayList<>();
		InventoryItem inventoryItem = new InventoryItem();
		List<Vessel> vesselList = new ArrayList<>();
		if (inventoryCatalogDto.getVessel() != null) {
			inventoryItem = addDetailsToInventory(inventoryCatalog, inventoryItem, null, null);
			inventoryItem = inventoryItemDao.save(inventoryItem);
		} else if(inventoryCatalogDto.getFleet() != null) {
			vesselList = vesselDao.findByFleetAndStatusNot(inventoryCatalog.getFleet(), commonUtil.getSoftDeleteStatus());
			for (Vessel vessel : vesselList) {
				inventoryItem = addDetailsToInventory(inventoryCatalog, inventoryItem, null, vessel);
				inventoryItemList.add(inventoryItem);
			}
			inventoryItemList = inventoryItemDao.saveAll(inventoryItemList);
		}else {
			vesselList = vesselDao.findAllVessel();
			for (Vessel vessel : vesselList) {
				inventoryItem = addDetailsToInventory(inventoryCatalog, inventoryItem, vessel.getFleet(), vessel);
				inventoryItemList.add(inventoryItem);
			}
			inventoryItemList = inventoryItemDao.saveAll(inventoryItemList);
		}
		if(inventoryItemList.size() == 0) {
			syncDataService.syncCreation(inventoryItem);
		}else {
			for (InventoryItem invItem : inventoryItemList) {
				syncDataService.syncCreation(invItem);
			}
		}
		LOGGER.debug("InventoryCatalogServiceImpl -- add -- end");
		return mapEntityToDto.transformBO(inventoryCatalog, InventoryCatalogDto.class);
	}

	@Override
	public InventoryCatalogDto update(InventoryCatalogDto inventoryCatalogDto) throws Exception {
		LOGGER.debug("InventoryCatalogServiceImpl -- update -- start");
		commonUtil.stringNullValidator(inventoryCatalogDto.getId(), "InventoryCatalogId");
		InventoryCatalog inventoryCatalog = mapDtoToEntity.transformBO(inventoryCatalogDto, InventoryCatalog.class);
		InventoryCatalog existingInventoryCatalog = new InventoryCatalog();
		
		if (inventoryCatalogDto.getVessel() != null) {
			 existingInventoryCatalog = inventoryCatalogDao.findByInventoryNameAndVesselAndFleetAndStatusNot(inventoryCatalog.getInventoryName(), inventoryCatalog.getVessel(), inventoryCatalog.getFleet(), commonUtil.getSoftDeleteStatus());
			if(existingInventoryCatalog != null && !(inventoryCatalog.getId()).equals(existingInventoryCatalog.getId()))
				throw new ApplicationServiceExecption("Inventory Catalog already exist", HttpStatus.BAD_REQUEST);
		} else if(inventoryCatalogDto.getFleet() != null && !(inventoryCatalog.getId()).equals(existingInventoryCatalog.getId())) {
			 existingInventoryCatalog = inventoryCatalogDao.findByInventoryNameAndFleetAndStatusNot(inventoryCatalog.getInventoryName(), inventoryCatalog.getFleet(), commonUtil.getSoftDeleteStatus());
			if(existingInventoryCatalog != null)
				throw new ApplicationServiceExecption("Inventory Catalog already exist", HttpStatus.BAD_REQUEST);
		}else {
			existingInventoryCatalog = inventoryCatalogDao.findByInventoryNameAndStatusNot(inventoryCatalog.getInventoryName(), commonUtil.getSoftDeleteStatus());
			if(existingInventoryCatalog != null && !(inventoryCatalog.getId()).equals(existingInventoryCatalog.getId()))
				throw new ApplicationServiceExecption("Inventory Catalog already exist", HttpStatus.BAD_REQUEST);
		}
		
		existingInventoryCatalog = inventoryCatalogDao.findByIdAndStatusNot(inventoryCatalogDto.getId(), commonUtil.getSoftDeleteStatus());
		InventoryCatalogDto existingInvCatalogDto = mapEntityToDto.transformBO(existingInventoryCatalog, InventoryCatalogDto.class);
		inventoryCatalog.setUpdateTime(new Date());
		inventoryCatalog.setUpdatedBy(0);
		inventoryCatalog = inventoryCatalogDao.save(inventoryCatalog);
		syncDataService.syncUpdate(mapDtoToEntity.transformBO(existingInvCatalogDto, InventoryCatalog.class), inventoryCatalog);
		
		LOGGER.debug("InventoryCatalogServiceImpl -- update -- end");
		return mapEntityToDto.transformBO(inventoryCatalog, InventoryCatalogDto.class);
	}

	@Override
	public List<InventoryCatalogDto> softDelete(List<String> inventoryCatalogIds) throws Exception {
		LOGGER.debug("InventoryCatalogServiceImpl -- softDelete -- end");
		commonUtil.stringNullValidator(inventoryCatalogIds.toArray(), "InventoryCatalogId");
		List<InventoryCatalog> existingInventoryCatalogList = inventoryCatalogDao.findByIdInAndStatusNot(inventoryCatalogIds, commonUtil.getSoftDeleteStatus());
		List<InventoryCatalogDto> invCatalogDtoList = mapEntityToDto.transformListOfBO(existingInventoryCatalogList, InventoryCatalogDto.class);
		for (InventoryCatalog inventoryCatalog : existingInventoryCatalogList) {
			List<InventoryItem> existingInventoryItemList = inventoryItemDao.findByInvCatalogAndStatusNot(inventoryCatalog, commonUtil.getSoftDeleteStatus());
			List<InventoryItemDto> inventoryItemDtoList = mapEntityToDtoInvItem.transformListOfBO(existingInventoryItemList, InventoryItemDto.class);
			for (InventoryItem invItem : existingInventoryItemList) {
				invItem.setStatus(commonUtil.getSoftDeleteStatus());
				invItem.setUpdateTime(new Date());
			}
			existingInventoryItemList = inventoryItemDao.saveAll(existingInventoryItemList);
			Integer count = 0;
			for (InventoryItem invItem : existingInventoryItemList) {
				syncDataService.syncUpdate(mapDtoToEntityInvItem.transformBO(inventoryItemDtoList.get(count), InventoryItem.class), invItem);
				count++;
			}
			inventoryCatalog.setStatus(commonUtil.getSoftDeleteStatus());
			inventoryCatalog.setUpdateTime(new Date());
		}
		existingInventoryCatalogList = inventoryCatalogDao.saveAll(existingInventoryCatalogList);
		Integer count = 0;
		for (InventoryCatalog inventoryCatalog : existingInventoryCatalogList) {
			syncDataService.syncUpdate(mapDtoToEntity.transformBO(invCatalogDtoList.get(count), InventoryCatalog.class), inventoryCatalog);
			count++;
		}
		LOGGER.debug("InventoryCatalogServiceImpl -- softDelete -- end");
		return mapEntityToDto.transformListOfBO(existingInventoryCatalogList, InventoryCatalogDto.class);
	}
	
	public InventoryItem addDetailsToInventory(InventoryCatalog inventoryCatalog, InventoryItem inventoryItem, Fleet fleet, Vessel vessel) {
		String seqName = dbUtil.getNextSequence(inventoryItem.getClass());
		if (seqName != null)
			inventoryItem.setId(seqName);
		
		inventoryItem.setInvCatalog(inventoryCatalog);
		inventoryItem.setInsertTime(new Date());
		inventoryItem.setUpdateTime(new Date());
		inventoryItem.setInsertedBy(0);
		inventoryItem.setUpdatedBy(0);
		inventoryItem.setCurrQty(new Float(0));
		inventoryItem.setStatus(commonUtil.getActiveStatus());
		inventoryItem.setFleet((fleet != null)?fleet:(inventoryCatalog.getFleet()));
		inventoryItem.setVessel((vessel != null)?vessel:(inventoryCatalog.getVessel()));
		return inventoryItem;
	}

}
