package in.ind.mds.serviceImpl;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import in.ind.mds.dto.OwnerDto;
import in.ind.mds.dto.RoleDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.repo.dao.RoleDao;
import in.ind.mds.repo.entity.Owner;
import in.ind.mds.repo.entity.Role;
import in.ind.mds.service.RoleService;
import in.ind.mds.service.SyncDataService;
import in.ind.mds.util.BeanTransformerUtil;
import in.ind.mds.util.CommonUtil;
import in.ind.mds.util.DBUtil;

@Service("TST_MSSQL_ROLE")


public class RoleServiceImpl implements RoleService 
{

	private static final Logger LOGGER = LoggerFactory.getLogger(RoleServiceImpl.class);

	@Autowired
	private BeanTransformerUtil<Role, RoleDto> mapEntityToDto;

	@Autowired
	private BeanTransformerUtil<RoleDto, Role> mapDtoToEntity;
	
	@Autowired
	@Qualifier("TST_MSSQL_SYNC")
	private SyncDataService syncDataService;
	/*
	 * @Autowired private UserValidator validator;
	 */
	@Autowired
	private CommonUtil<RoleDto> commonUtil;

	@Autowired
	private RoleDao roleDao;
	
	@Autowired
	private DBUtil dbUtil;
	
	public RoleDto findByRoleIdAndRoleName(final String roleId, final String roleName)throws Exception 
	{
		LOGGER.debug("RoleServiceImpl -- getByRoleIdAndRoleName -- Start");
		commonUtil.stringNullValidator(roleId, roleName, "RoleId and RoleName");
		Role role = roleDao.findByIdAndRoleNameAndStatusNot(roleId,roleName, commonUtil.getSoftDeleteStatus());

		if (role == null) 
			throw new ApplicationServiceExecption("Role not found", HttpStatus.NOT_FOUND);
		
		final RoleDto dto = mapEntityToDto.transformBO(role, RoleDto.class);
		LOGGER.debug("RoleServiceImpl -- getByRoleIdAndRoleName -- End");
		return dto;
	}
	public RoleDto getByRoleId(final String roleId)throws Exception 
	{
		LOGGER.debug("RoleServiceImpl -- getByRoleId -- Start");
		commonUtil.stringNullValidator(roleId, "RoleId");
		final Role role = roleDao.findByIdAndStatusNot(roleId, commonUtil.getSoftDeleteStatus());

		if (role == null) 
			throw new ApplicationServiceExecption("Error role not found", HttpStatus.NOT_FOUND);
		
		/*
		 * Date date = user.getServerTime(); Date currentDate = new
		 * Date(System.currentTimeMillis());
		 * 
		 * if (date.before(currentDate) || date.after(currentDate)) {
		 * user.setServerTime(currentDate); userDao.save(user); }
		 */
		final RoleDto dto = mapEntityToDto.transformBO(role, RoleDto.class);

		LOGGER.debug("RoleServiceImpl -- getByRoleId -- End");
		return dto;
	}

	public RoleDto findByRoleName(final String roleName)throws Exception 
	{
		LOGGER.debug("RoleServiceImpl -- getByRoleName -- Start");
		commonUtil.stringNullValidator(roleName, "RoleName");
		final Role role = roleDao.findByRoleNameAndStatusNot(roleName, commonUtil.getSoftDeleteStatus());

		if (role == null) 
			throw new ApplicationServiceExecption("Error role not found", HttpStatus.NOT_FOUND);
		
		/*
		 * Date date = user.getServerTime(); Date currentDate = new
		 * Date(System.currentTimeMillis());
		 * 
		 * if (date.before(currentDate) || date.after(currentDate)) {
		 * user.setServerTime(currentDate); userDao.save(user); }
		 */
		final RoleDto dto = mapEntityToDto.transformBO(role, RoleDto.class);

		LOGGER.debug("RoleServiceImpl -- getByRoleName -- End");
		return dto;
	}
	
	public List<RoleDto> findAll() throws Exception {
		LOGGER.debug("RoleServiceImpl -- findByRoleType -- Start");
		List<Role> role = roleDao.findAllRole();

		if (role.size() == 0) 
			throw new ApplicationServiceExecption("Role not found", HttpStatus.NOT_FOUND);
		
		final List<RoleDto> dto = mapEntityToDto.transformListOfBO(role, RoleDto.class);
		LOGGER.debug("RoleServiceImpl -- findByRoleType -- End");
		return dto;
	}

	
	public RoleDto add(RoleDto roleDto) throws Exception {
		LOGGER.debug("RoleServiceImpl -- add -- Start");
		// final String errorMessage = validator.validateAdd(userDto);
		// if (errorMessage != null) {
		// throw new GaurageServiceException(errorMessage, HttpStatus.BAD_REQUEST);
		// }
		/*Optional<Role> existingRole = roleDao.findById(roleDto.getId());
		if (existingRole.isPresent()) {
			throw new ApplicationServiceExecption("Role exist", HttpStatus.BAD_REQUEST);
		}*/
		commonUtil.stringNullValidator(roleDto.getRoleName(), roleDto.getRoleCode(), roleDto.getSequenceNumber(), "Role Name, Code and SequenceNumber");
		List<Role> roles = roleDao.uniqueCheckForAdd(roleDto.getRoleName(), roleDto.getRoleCode(), roleDto.getSequenceNumber());
		if(roles.size() != 0)
			throw new ApplicationServiceExecption("Role already exist", HttpStatus.BAD_REQUEST);
		
		Role role = mapDtoToEntity.transformBO(roleDto, Role.class);
		
		String seqName = dbUtil.getNextSequence(role.getClass());
		if(seqName != null) 
			role.setId(seqName);
		
		role.setInsertTime(new Date());
		role.setUpdateTime(new Date());
		role.setStatus(commonUtil.getActiveStatus());
		role=roleDao.save(role);
		syncDataService.syncCreation(role);
		LOGGER.debug("RoleServiceImpl -- add -- End");
		return mapEntityToDto.transformBO(role, RoleDto.class);
	}
	
	
	
	public List<RoleDto> softDeleteRole(List<String> roleIds) throws Exception {
		LOGGER.debug("RoleServiceImpl -- delete -- Start");
		// final String errorMessage = validator.validateAdd(userDto);
		// if (errorMessage != null) {
		// throw new GaurageServiceException(errorMessage, HttpStatus.BAD_REQUEST);
		// }
		commonUtil.stringNullValidator(roleIds.toArray(), "RoleId");
		List<Role> existingRoleList = roleDao.findByIdInAndStatusNot(roleIds, commonUtil.getSoftDeleteStatus());
		
		if (existingRoleList.size() < roleIds.size()) 
			throw new ApplicationServiceExecption("Role not found", HttpStatus.BAD_REQUEST);
		
		List<RoleDto> existingRoleDtoList = mapEntityToDto.transformListOfBO(existingRoleList, RoleDto.class);
		for(Role role: existingRoleList)
		{
			role.setStatus(commonUtil.getSoftDeleteStatus());
			role.setUpdateTime(new Date());
		}
		
		existingRoleList=roleDao.saveAll(existingRoleList);
		Integer count=0;
		for(Role role: existingRoleList)
		{
			syncDataService.syncUpdate(mapDtoToEntity.transformBO(existingRoleDtoList.get(count), Role.class), role);
			count++;
		}
		List<Role> roleList = roleDao.findAllRole();
		LOGGER.debug("RoleServiceImpl -- delete -- End");
		return mapEntityToDto.transformListOfBO(roleList, RoleDto.class);
	}

	
	public RoleDto updateRole(RoleDto roleDto) throws Exception {
		LOGGER.debug("RoleServiceImpl -- update -- Start");
		// final String errorMessage = validator.validateAdd(userDto);
		// if (errorMessage != null) {
		// throw new GaurageServiceException(errorMessage, HttpStatus.BAD_REQUEST);
		// }
		commonUtil.stringNullValidator(roleDto.getRoleName(), roleDto.getRoleCode(), roleDto.getSequenceNumber(), roleDto.getId(), "Role Id, Name, Code and SequenceNumber");
		List<Role> roles = roleDao.uniqueCheckForUpdate(roleDto.getRoleName(), roleDto.getRoleCode(), roleDto.getSequenceNumber(), roleDto.getId());
		if(roles.size() != 0)
			throw new ApplicationServiceExecption("Role already exist", HttpStatus.BAD_REQUEST);
		
		Role role = roleDao.findByIdAndStatusNot(roleDto.getId(), commonUtil.getSoftDeleteStatus());
		if (role == null) 
			throw new ApplicationServiceExecption("Role not found", HttpStatus.BAD_REQUEST);
		
		RoleDto existingRoleDto = mapEntityToDto.transformBO(role, RoleDto.class);
		Role roleEntity = mapDtoToEntity.transformBO(roleDto, Role.class);
		roleEntity.setUpdateTime(new Date());
		roleEntity=roleDao.saveAndFlush(roleEntity);
		syncDataService.syncUpdate(mapDtoToEntity.transformBO(existingRoleDto, Role.class),roleEntity);
		LOGGER.debug("RoleServiceImpl -- update -- End");
		return mapEntityToDto.transformBO(roleEntity, RoleDto.class);
	}
	
}
