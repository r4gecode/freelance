package in.ind.mds.serviceImpl;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import in.ind.mds.dto.StatusDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.repo.dao.StatusDao;
import in.ind.mds.repo.entity.Status;
import in.ind.mds.service.StatusService;
import in.ind.mds.service.SyncDataService;
import in.ind.mds.util.BeanTransformerUtil;
import in.ind.mds.util.CommonUtil;
import in.ind.mds.util.DBUtil;

@Service("TST_MSSQL_STATUS")
public class StatusServiceImpl implements StatusService {

	private static final Logger LOGGER = LoggerFactory.getLogger(StatusServiceImpl.class);

	@Autowired
	private BeanTransformerUtil<Status, StatusDto> mapEntityToDto;

	@Autowired
	private BeanTransformerUtil<StatusDto, Status> mapDtoToEntity;
	
	@Autowired
	@Qualifier("TST_MSSQL_SYNC")
	private SyncDataService syncDataService;
	/*
	 * @Autowired private UserValidator validator;
	 */
	@Autowired
	private CommonUtil<StatusDto> commonUtil;

	@Autowired
	private StatusDao statusDao;
	
	@Autowired
	private DBUtil dbUtil;


	@Override
	public StatusDto getByStatusId(String statusId) throws Exception {
		LOGGER.debug("StatusServiceImpl -- getByStatusId -- Start");
		commonUtil.stringNullValidator(statusId, "StatusId");
		Optional<Status> status = statusDao.findById(statusId);

		if (!status.isPresent()) {
			throw new ApplicationServiceExecption("Status not found", HttpStatus.NOT_FOUND);
		}
		final StatusDto dto = mapEntityToDto.transformBO(status.get(), StatusDto.class);
		LOGGER.debug("StatusServiceImpl -- getByStatusId -- End");
		return dto;
	}

	@Override
	public StatusDto findByStatusName(String statusName) throws Exception {
		LOGGER.debug("StatusServiceImpl -- findByStatusName -- Start");
		commonUtil.stringNullValidator(statusName, "StatusName");
		Status status = statusDao.findByStatusName(statusName);

		if (status == null) {
			throw new ApplicationServiceExecption("Status not found", HttpStatus.NOT_FOUND);
		}
		final StatusDto dto = mapEntityToDto.transformBO(status, StatusDto.class);
		LOGGER.debug("StatusServiceImpl -- findByStatusName -- End");
		return dto;
	}

	@Override
	public List<StatusDto> findAll() throws Exception {
		LOGGER.debug("StatusServiceImpl -- findAll -- Start");
		List<Status> status = statusDao.findAll();

		if (status.size() == 0) {
			throw new ApplicationServiceExecption("Status not found", HttpStatus.NOT_FOUND);
		}
		final List<StatusDto> dto = mapEntityToDto.transformListOfBO(status, StatusDto.class);
		LOGGER.debug("StatusServiceImpl -- findAll -- End");
		return dto;
	}

	@Override
	public StatusDto add(StatusDto statusDto) throws Exception {
		LOGGER.debug("StatusServiceImpl -- add -- Start");
		// final String errorMessage = validator.validateAdd(userDto);
		// if (errorMessage != null) {
		// throw new GaurageServiceException(errorMessage, HttpStatus.BAD_REQUEST);
		// }
		/*Optional<Status> existingStatus = statusDao.findById(statusDto.getId());
		if (existingStatus.isPresent()) {
			throw new ApplicationServiceExecption("Status exist", HttpStatus.BAD_REQUEST);
		}*/
		final Status status = mapDtoToEntity.transformBO(statusDto, Status.class);
		
		String seqName = dbUtil.getNextSequence(status.getClass());
		if(seqName != null) {
			status.setId(seqName);
		}
		statusDao.save(status);
		syncDataService.syncCreation(status);
		LOGGER.debug("StatusServiceImpl -- add -- End");
		return statusDto;
	}
	
	
	@Override
	public void deleteStatus(String statusId) throws Exception {
		LOGGER.debug("StatusServiceImpl -- delete -- Start");
		// final String errorMessage = validator.validateAdd(userDto);
		// if (errorMessage != null) {
		// throw new GaurageServiceException(errorMessage, HttpStatus.BAD_REQUEST);
		// }
		commonUtil.stringNullValidator(statusId, "StatusId");
		Optional<Status> status = statusDao.findById(statusId);
		if (!status.isPresent()) {
			throw new ApplicationServiceExecption("status not found", HttpStatus.BAD_REQUEST);
		}
		statusDao.delete(status.get());
	LOGGER.debug("StatusServiceImpl -- delete -- End");
	}

	@Override
	public StatusDto updateStatus(StatusDto statusDto) throws Exception {
		LOGGER.debug("StatusServiceImpl -- update -- Start");
		// final String errorMessage = validator.validateAdd(userDto);
		// if (errorMessage != null) {
		// throw new GaurageServiceException(errorMessage, HttpStatus.BAD_REQUEST);
		// }
		commonUtil.stringNullValidator(statusDto.getId(), "StatusId");
		Optional<Status> existingStatus = statusDao.findById(statusDto.getId());
		if (!existingStatus.isPresent()) {
			throw new ApplicationServiceExecption("Status not found", HttpStatus.BAD_REQUEST);
		}
		StatusDto existingStatusDto = mapEntityToDto.transformBO(existingStatus.get(), StatusDto.class); 
		Status status = existingStatus.get();
		status = mapDtoToEntity.transformBO(statusDto, Status.class);
		statusDao.saveAndFlush(status);
		syncDataService.syncUpdate(mapDtoToEntity.transformBO(existingStatusDto, Status.class), status);
		LOGGER.debug("StatusServiceImpl -- update -- End");
		return statusDto;
	}




}
