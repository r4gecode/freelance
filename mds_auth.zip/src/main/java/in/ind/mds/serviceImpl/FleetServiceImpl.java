/**
 * 
 */
package in.ind.mds.serviceImpl;

import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import in.ind.mds.dto.FleetDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.repo.dao.FleetDao;
import in.ind.mds.repo.entity.Fleet;
import in.ind.mds.service.FleetService;
import in.ind.mds.service.SyncDataService;
import in.ind.mds.util.BeanTransformerUtil;
import in.ind.mds.util.CommonUtil;
import in.ind.mds.util.DBUtil;

/**
 * @author mds-arockia
 *
 */
@Service("TST_MSSQL_FLEET")
public class FleetServiceImpl implements FleetService {

	private static final Logger LOGGER = LoggerFactory.getLogger(FleetServiceImpl.class);

	@Autowired
	private BeanTransformerUtil<Fleet, FleetDto> mapEntityToDto;

	@Autowired
	private BeanTransformerUtil<FleetDto, Fleet> mapDtoToEntity;

	@Autowired
	@Qualifier("TST_MSSQL_SYNC")
	private SyncDataService syncDataService;

	@Autowired
	private FleetDao fleetDao;

	@Autowired
	private DBUtil dbUtil;

	@Autowired
	private CommonUtil<FleetDto> commonUtil;

	@Override
	public FleetDto add(FleetDto fleetDto) throws Exception {
		LOGGER.debug("FleetServiceImpl -- add -- Start");
		commonUtil.stringNullValidator(fleetDto.getFleetName(), "FleetName");
		Fleet fleet = fleetDao.findByFleetNameAndStatusNot(fleetDto.getFleetName(), commonUtil.getSoftDeleteStatus());
		if (fleet != null)
			throw new ApplicationServiceExecption("Fleet already exist", HttpStatus.BAD_REQUEST);

		fleet = mapDtoToEntity.transformBO(fleetDto, Fleet.class);
		String seqName = dbUtil.getNextSequence(fleet.getClass());
		if (seqName != null) {
			fleet.setId(seqName);
		}
		fleet.setInsertTime(new Date());
		fleet.setUpdateTime(new Date());
		fleet.setStatus(commonUtil.getActiveStatus());
		fleet = fleetDao.save(fleet);
		syncDataService.syncCreation(fleet);
		LOGGER.debug("FleetServiceImpl -- add -- End");
		return mapEntityToDto.transformBO(fleet, FleetDto.class);
	}

	@Override
	public FleetDto findByFleetId(String fleetId) throws Exception {
		LOGGER.debug("FleetServiceImpl -- findByFleetId -- Start");
		commonUtil.stringNullValidator(fleetId, "FleetId");
		Fleet fleet = fleetDao.findByIdAndStatusNot(fleetId, commonUtil.getSoftDeleteStatus());
		if (fleet == null)
			throw new ApplicationServiceExecption("Fleet not found", HttpStatus.NOT_FOUND);

		LOGGER.debug("FleetServiceImpl -- findByFleetId -- End");
		return mapEntityToDto.transformBO(fleet, FleetDto.class);
	}

	@Override
	public List<FleetDto> findAll() throws Exception {
		LOGGER.debug("FleetServiceImpl -- findAll() -- start");
		List<Fleet> fleets = fleetDao.findAllFleet();
		if (fleets.size() == 0)
			throw new ApplicationServiceExecption("Fleet not found", HttpStatus.NOT_FOUND);

		LOGGER.debug("FleetServiceImpl -- findAll() -- end");
		return mapEntityToDto.transformListOfBO(fleets, FleetDto.class);
	}

	@Override
	public List<FleetDto> softDeleteFleet(List<String> fleetIds) throws Exception {
		LOGGER.debug("FleetServiceImpl -- softDeleteFleet() -- start");
		commonUtil.stringNullValidator(fleetIds.toArray(), "FleetId");
		List<Fleet> existingFleetList = fleetDao.findByIdInAndStatusNot(fleetIds, commonUtil.getSoftDeleteStatus());
		if (existingFleetList.size() < fleetIds.size())
			throw new ApplicationServiceExecption("Fleet not found", HttpStatus.NOT_FOUND);

		List<FleetDto> existingFleetDtoList = mapEntityToDto.transformListOfBO(existingFleetList, FleetDto.class);
		for (Fleet fleet : existingFleetList) {
			fleet.setStatus(commonUtil.getSoftDeleteStatus());
			fleet.setUpdateTime(new Date());
		}
		existingFleetList = fleetDao.saveAll(existingFleetList);
		Integer count = 0;
		for (Fleet fleet : existingFleetList) {
			syncDataService.syncUpdate(mapDtoToEntity.transformBO(existingFleetDtoList.get(count), Fleet.class), fleet);
			count++;
		}
		existingFleetList = fleetDao.findAllFleet();
		LOGGER.debug("FleetServiceImpl -- softDeteteFleet() -- end");
		return mapEntityToDto.transformListOfBO(existingFleetList, FleetDto.class);
	}

	@Override
	public FleetDto updateFleet(FleetDto fleetDto) throws Exception {
		LOGGER.debug("FleetServiceImpl -- update() -- start");
		commonUtil.stringNullValidator(fleetDto.getFleetName(), fleetDto.getId(), "Fleet Id and Name");
		Fleet existingFleet = fleetDao.findByFleetNameAndStatusNotAndIdNot(fleetDto.getFleetName(),
				commonUtil.getSoftDeleteStatus(), fleetDto.getId());
		if (existingFleet != null)
			throw new ApplicationServiceExecption("Fleet already exist", HttpStatus.BAD_REQUEST);

		existingFleet = fleetDao.findByIdAndStatusNot(fleetDto.getId(), commonUtil.getSoftDeleteStatus());
		if (existingFleet == null)
			throw new ApplicationServiceExecption("Fleet not found", HttpStatus.NOT_FOUND);

		FleetDto existingFleetDto = mapEntityToDto.transformBO(existingFleet, FleetDto.class);
		Fleet fleet = mapDtoToEntity.transformBO(fleetDto, Fleet.class);
		fleet.setUpdateTime(new Date());
		fleet = fleetDao.saveAndFlush(fleet);
		syncDataService.syncUpdate(mapDtoToEntity.transformBO(existingFleetDto, Fleet.class), fleet);
		LOGGER.debug("fleetServiceImpl -- update() -- end");
		return mapEntityToDto.transformBO(fleet, FleetDto.class);
	}

}
