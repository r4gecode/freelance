/**
 * 
 */
package in.ind.mds.serviceImpl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import in.ind.mds.dto.VesselAccessDto;
import in.ind.mds.dto.VesselDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.repo.dao.UserDao;
import in.ind.mds.repo.dao.VesselAccessDao;
import in.ind.mds.repo.entity.User;
import in.ind.mds.repo.entity.Vessel;
import in.ind.mds.repo.entity.VesselAccess;
import in.ind.mds.service.SyncDataService;
import in.ind.mds.service.VesselAccessService;
import in.ind.mds.util.BeanTransformerUtil;
import in.ind.mds.util.CommonUtil;
import in.ind.mds.util.DBUtil;

/**
 * @author mds-arockia
 *
 */
@Service("TST_MSSQL_VESSEL_ACCESS")
public class VesselAccessServiceImpl implements VesselAccessService {

	private static final Logger LOGGER = LoggerFactory.getLogger(VesselAccessServiceImpl.class);

	@Autowired
	private BeanTransformerUtil<VesselAccess, VesselAccessDto> mapEntityToDto;

	@Autowired
	private BeanTransformerUtil<VesselAccessDto, VesselAccess> mapDtoToEntity;
	
	@Autowired
	private BeanTransformerUtil<Vessel, VesselDto> mapVesselEntityToDto;

	@Autowired
	@Qualifier("TST_MSSQL_SYNC")
	private SyncDataService syncDataService;
	/*
	 * @Autowired private UserValidator validator;
	 */
	@Autowired
	private CommonUtil<VesselAccessDto> commonUtil;

	@Autowired
	private UserDao userDao;
	
	@Autowired
	private VesselAccessDao vesselAccessDao;

	@Autowired
	private DBUtil dbUtil;

	@Override
	public List<VesselAccessDto> addVesselAccess(List<VesselAccessDto> vesselAccessDtoList) throws Exception {
		LOGGER.debug("VesselAccessServiceImpl -- add -- Start");
		List<VesselAccess> existingVesselAccessByUser = vesselAccessDao.findByUser(vesselAccessDtoList.stream().findFirst().get().getUser());
		if (existingVesselAccessByUser.size() != 0)
			throw new ApplicationServiceExecption("Vessel Access for this User existing already",
					HttpStatus.BAD_REQUEST);

		final List<VesselAccess> vesselAccessList = mapDtoToEntity.transformListOfBO(vesselAccessDtoList,
				VesselAccess.class);
		for (VesselAccess vesselAccess : vesselAccessList) {
			String seqName = dbUtil.getNextSequence(vesselAccess.getClass());
			if (seqName != null)
				vesselAccess.setId(seqName);

			vesselAccess.setInsertTime(new Date());
			vesselAccess.setUpdateTime(new Date());
			vesselAccess.setStatus(commonUtil.getActiveStatus());
		}
		vesselAccessDao.saveAll(vesselAccessList);
		LOGGER.debug("VesselServiceImpl -- add -- End");
		return null;
	}

	@Override
	public List<VesselAccessDto> updateVesselAccess(List<VesselAccessDto> vesselAccessDtoList) throws Exception {
		LOGGER.debug("VesselAccessServiceImpl -- update -- Start");
		commonUtil.nullValidatorOnList(vesselAccessDtoList);
		List<VesselAccess> vesselAccessList = mapDtoToEntity.transformListOfBO(vesselAccessDtoList, VesselAccess.class);
		vesselAccessList = vesselAccessDao.saveAll(vesselAccessList);
		vesselAccessDtoList = mapEntityToDto.transformListOfBO(vesselAccessList, VesselAccessDto.class);
		LOGGER.debug("VesselAccessServiceImpl -- update -- end");
		return vesselAccessDtoList;
	}

	@Override
	public List<VesselDto> findVesselByUser(String userId) throws Exception {
		LOGGER.debug("VesselServiceImpl -- findVesselByUser -- start");
		commonUtil.stringNullValidator(userId, "USerId");
		User user = userDao.findByIdAndStatusNot(userId, commonUtil.getSoftDeleteStatus());
		List<VesselAccess> vesselAccessList = vesselAccessDao.findVesselByUser(user);
		List<Vessel> vesselList = new ArrayList<>();
		for (VesselAccess vesselAccess : vesselAccessList) {
			vesselList.add(vesselAccess.getVessel());
		}
		List<VesselDto> vesselDtoList = mapVesselEntityToDto.transformListOfBO(vesselList, VesselDto.class);
		return vesselDtoList;
	}

	@Override
	public List<VesselAccessDto> findByUser(String userId) throws Exception {
		LOGGER.debug("VesselServiceImpl -- findByUser -- start");
		commonUtil.stringNullValidator(userId, "USerId");
		User user = userDao.findByIdAndStatusNot(userId, commonUtil.getSoftDeleteStatus());
		List<VesselAccess> vesselAccessList = vesselAccessDao.findByUser(user);
		List<VesselAccessDto> vesselAccessDtoList = mapEntityToDto.transformListOfBO(vesselAccessList, VesselAccessDto.class);
		LOGGER.debug("VesselServiceImpl -- findByUser -- end");
		return vesselAccessDtoList;
	}

}
