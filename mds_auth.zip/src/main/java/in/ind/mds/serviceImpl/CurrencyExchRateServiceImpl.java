/**
 * 
 */
package in.ind.mds.serviceImpl;

import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import in.ind.mds.dto.CurrencyExchRateDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.repo.dao.CurrencyExchRateDao;
import in.ind.mds.repo.entity.CurrencyExchRate;
import in.ind.mds.service.CurrencyExchRateService;
import in.ind.mds.service.SyncDataService;
import in.ind.mds.util.BeanTransformerUtil;
import in.ind.mds.util.CommonUtil;
import in.ind.mds.util.DBUtil;

/**
 * @author mds-arockia
 *
 */
@Service("TST_MSSQL_CURRENCY_EXCH_RATE")
public class CurrencyExchRateServiceImpl implements CurrencyExchRateService{
	
	private static final Logger LOGGER = LoggerFactory.getLogger(CurrencyExchRateServiceImpl.class);

	@Autowired
	private BeanTransformerUtil<CurrencyExchRate, CurrencyExchRateDto> mapEntityToDto;

	@Autowired
	private BeanTransformerUtil<CurrencyExchRateDto, CurrencyExchRate> mapDtoToEntity;

	@Autowired
	@Qualifier("TST_MSSQL_SYNC")
	private SyncDataService syncDataService;

	@Autowired
	private CurrencyExchRateDao currencyExchRateDao;
	
	@Autowired
	private DBUtil dbUtil;

	@Autowired
	private CommonUtil<CurrencyExchRateDto> commonUtil;
	
	@Override
	public CurrencyExchRateDto add(CurrencyExchRateDto currencyExchRateDto) throws Exception {
		LOGGER.debug("CurrencyExchRateServiceImpl -- add -- start");
		CurrencyExchRate currencyExchRate = mapDtoToEntity.transformBO(currencyExchRateDto, CurrencyExchRate.class);
		String seqName = dbUtil.getNextSequence(currencyExchRate.getClass());
		if(seqName != null)
			currencyExchRate.setId(seqName);
		
		currencyExchRate.setInsertTime(new Date());
		currencyExchRate.setUpdateTime(new Date());
		currencyExchRate.setStatus(commonUtil.getActiveStatus());
		currencyExchRate = currencyExchRateDao.save(currencyExchRate);
		syncDataService.syncCreation(currencyExchRate);
		LOGGER.debug("CurrencyExchRateServiceImpl -- add -- end");
		return mapEntityToDto.transformBO(currencyExchRate, CurrencyExchRateDto.class);
	}

	@Override
	public List<CurrencyExchRateDto> softDelete(List<String> ids) throws Exception {
		LOGGER.debug("CurrencyExchRateServiceImpl -- softDelete -- start");
		List<CurrencyExchRate> currencyExchRateList = currencyExchRateDao.findByIdInAndStatusNot(ids, commonUtil.getSoftDeleteStatus());
		if(currencyExchRateList.size() < ids.size())
			throw new ApplicationServiceExecption("CurrencyExchangeRate Id not found", HttpStatus.BAD_REQUEST);
		
		List<CurrencyExchRateDto> currencyExchRateDtoList = mapEntityToDto.transformListOfBO(currencyExchRateList, CurrencyExchRateDto.class);
		for (CurrencyExchRate currencyExchRate : currencyExchRateList) {
			currencyExchRate.setStatus(commonUtil.getSoftDeleteStatus());
		}
		currencyExchRateDao.saveAll(currencyExchRateList);
		Integer count = 0;
		for (CurrencyExchRate currencyExchRate : currencyExchRateList) {
			CurrencyExchRateDto currencyExchRateDto = currencyExchRateDtoList.get(count);
			syncDataService.syncUpdate(mapDtoToEntity.transformBO(currencyExchRateDto, CurrencyExchRate.class), currencyExchRate);
			count++;
		}
		LOGGER.debug("CurrencyExchRateServiceImpl -- softDelete -- end");
		return mapEntityToDto.transformListOfBO(currencyExchRateList, CurrencyExchRateDto.class);
	}

	@Override
	public CurrencyExchRateDto update(CurrencyExchRateDto currencyExchRateDto) throws Exception {
		LOGGER.debug("CurrencyExchRateServiceImpl -- update -- start");
		commonUtil.stringNullValidator(currencyExchRateDto.getId(), "CurrencyExchangeRate Id");
		CurrencyExchRate existingCurrencyExchRate = currencyExchRateDao.findByIdAndStatusNot(currencyExchRateDto.getId(), commonUtil.getSoftDeleteStatus());
		if(existingCurrencyExchRate == null)
			throw new ApplicationServiceExecption("CurrencyExchangeRate Id not found", HttpStatus.NOT_FOUND);
		
		CurrencyExchRateDto existingCurrencyExchangeRateDto = mapEntityToDto.transformBO(existingCurrencyExchRate, CurrencyExchRateDto.class);
		CurrencyExchRate newCurrencyExchRate = mapDtoToEntity.transformBO(currencyExchRateDto, CurrencyExchRate.class);
		newCurrencyExchRate = currencyExchRateDao.saveAndFlush(newCurrencyExchRate);
		syncDataService.syncUpdate(mapDtoToEntity.transformBO(existingCurrencyExchangeRateDto, CurrencyExchRate.class), newCurrencyExchRate);
		LOGGER.debug("CurrencyExchRateServiceImpl -- update -- end");
		return mapEntityToDto.transformBO(newCurrencyExchRate, CurrencyExchRateDto.class);
	}

}
