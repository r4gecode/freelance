package in.ind.mds.serviceImpl;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import in.ind.mds.dto.OwnerDto;
import in.ind.mds.dto.SftyDrillCatDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.repo.dao.SftyDrillCatDao;
import in.ind.mds.repo.entity.Owner;
import in.ind.mds.repo.entity.SafetyCategory;
import in.ind.mds.service.SftyDrillCatService;
import in.ind.mds.service.SyncDataService;
import in.ind.mds.util.BeanTransformerUtil;
import in.ind.mds.util.CommonUtil;
import in.ind.mds.util.DBUtil;

@Service("TST_MSSQL_SAFETY_CATEGORY")
public class SftyDrillCatServiceImpl implements SftyDrillCatService{

	private static final Logger LOGGER = LoggerFactory.getLogger(PortServiceImpl.class);
	
	@Autowired
	private BeanTransformerUtil<SafetyCategory, SftyDrillCatDto> mapEntityToDto;

	@Autowired
	private BeanTransformerUtil<SftyDrillCatDto, SafetyCategory> mapDtoToEntity;
	
	@Autowired
	@Qualifier("TST_MSSQL_SYNC")
	private SyncDataService syncDataService;
	/*
	 * @Autowired private UserValidator validator;
	 */
	 @Autowired
	 private CommonUtil<SftyDrillCatDto>commonUtil;

	@Autowired
	private SftyDrillCatDao sftyDrillCatDao;

	@Autowired
	private DBUtil dbUtil;

	@Override
	public SftyDrillCatDto getByCatId(String catId) throws Exception {
		// TODO Auto-generated method stub
		//return null;
		LOGGER.debug("SftyDrillCatServiceImpl -- getByCatId -- Start");
		commonUtil.stringNullValidator(catId, "CatID");
		Optional<SafetyCategory> sftyCat = sftyDrillCatDao.findById(catId);

		if (!sftyCat.isPresent()) {
			throw new ApplicationServiceExecption("Drill Category not found", HttpStatus.NOT_FOUND);
		}
		final SftyDrillCatDto dto = mapEntityToDto.transformBO(sftyCat.get(), SftyDrillCatDto.class);
		LOGGER.debug("SftyDrillCatServiceImpl -- getByCatId -- End");
		return dto;
	}

	@Override
	public List<SftyDrillCatDto> findAll() throws Exception {
		LOGGER.debug("SftyDrillCatServiceImpl -- findAll -- Start");
		List<SafetyCategory> categories = sftyDrillCatDao.findAll();

		if (categories.size() == 0) {
			throw new ApplicationServiceExecption("Port not found", HttpStatus.NOT_FOUND);
		}
		final List<SftyDrillCatDto> dto = mapEntityToDto.transformListOfBO(categories, SftyDrillCatDto.class);
		LOGGER.debug("SftyDrillCatServiceImpl -- findAll -- End");
		return dto;

	}

	@Override
	public SftyDrillCatDto add(SftyDrillCatDto sftydrillCatDto) throws Exception {
		LOGGER.debug("SftyDrillCatServiceImpl -- add -- Started");
		final SafetyCategory category = mapDtoToEntity.transformBO(sftydrillCatDto, SafetyCategory.class);
		String seqName = dbUtil.getNextSequence(category.getClass());
		if (seqName != null) {
			category.setId(seqName);
		}
		category.setInsertTime(new Date());
		category.setUpdateTime(new Date());
		category.setRecordStatus("1");
		category.setSyncRequired("Y");
		sftyDrillCatDao.save(category);
		syncDataService.syncCreation(category);
		LOGGER.debug("SftyDrillCatServiceImpl -- add -- End");
		return sftydrillCatDto;

		
	}

	@Override
	public SftyDrillCatDto findByCatName(String catName) throws Exception {
		// TODO Auto-generated method stub
		LOGGER.debug("SftyDrillCatServiceImpl -- findByCatName -- Start");
		commonUtil.stringNullValidator(catName, "CatName");
		SafetyCategory catg = sftyDrillCatDao.findByCatgName(catName);

		if (catg == null) {
			throw new ApplicationServiceExecption("Drill Category Name not found", HttpStatus.NOT_FOUND);
		}
		final SftyDrillCatDto dto = mapEntityToDto.transformBO(catg, SftyDrillCatDto.class);
		LOGGER.debug("SftyDrillCatServiceImpl -- findByCatName -- End");
		return dto;

	}

	@Override
	public SftyDrillCatDto softDeleteCat(String catId, int statusNo) throws Exception {
		LOGGER.debug("SftyDrillCatServiceImpl -- delete -- Start");
		commonUtil.stringNullValidator(catId, "CatId");
		Optional<SafetyCategory> existingCat = sftyDrillCatDao.findById(catId);
		SftyDrillCatDto catDto = null;
		if (existingCat == null) {
			throw new ApplicationServiceExecption("Drill Category not found", HttpStatus.BAD_REQUEST);
		}
		if(statusNo == 0)
			throw new ApplicationServiceExecption("StatusNo is not valide", HttpStatus.BAD_REQUEST);
		sftyDrillCatDao.softDelete(statusNo, catId);
		SafetyCategory catg = existingCat.get();
		catDto = mapEntityToDto.transformBO(catg, SftyDrillCatDto.class);
		LOGGER.debug("SftyDrillCatServiceImpl -- delete -- End");
		return catDto;
	}

	/*@Override
	public List<SftyDrillCatDto> softDeleteCat(List<String> catIds) throws Exception {
		// TODO Auto-generated method stub
		LOGGER.debug("SftyDrillCatServiceImpl -- delete -- Start");
		
		commonUtil.stringNullValidator(catIds.toArray(), "CatId");
		List<SafetyCategory> existingDrillCatList = sftyDrillCatDao.findByIdInAndStatusNot(catIds, commonUtil.getSoftDeleteStatus());
		if (existingDrillCatList.size() < catIds.size()) 
			throw new ApplicationServiceExecption("Owner not found", HttpStatus.BAD_REQUEST);
		
		List<SftyDrillCatDto> existingdrillDtoList = mapEntityToDto.transformListOfBO(existingDrillCatList, SftyDrillCatDto.class);
		for (SftyDrillCatDto sftDrillCat : existingDrillCatList) {
			sftDrillCat.setStatus(commonUtil.getSoftDeleteStatus());
			sftDrillCat.setUpdateTime(new Date());
		}
		return null;
	}*/
	
	@Override
	public SftyDrillCatDto updateCat(SftyDrillCatDto sftydrillCatDto) throws Exception {
		LOGGER.debug("SftyDrillCatServiceImpl -- update -- Start");
		commonUtil.stringNullValidator(sftydrillCatDto.getId(), "SftyDrillCatId");
		 Optional<SafetyCategory> existingCat = sftyDrillCatDao.findById(sftydrillCatDto.getId());
		 if(!existingCat.isPresent()) { 
		 throw new ApplicationServiceExecption("Drill Category not found", HttpStatus.BAD_REQUEST); 
		 }
		 SftyDrillCatDto currentCat  = mapEntityToDto.transformBO(existingCat.get(), SftyDrillCatDto.class);
		 SafetyCategory cat = null; 
		 cat = mapDtoToEntity.transformBO(sftydrillCatDto, SafetyCategory.class); 
		 sftyDrillCatDao.saveAndFlush(cat);
		 syncDataService.syncUpdate(mapDtoToEntity.transformBO(currentCat, SafetyCategory.class), cat);
		 LOGGER.debug("SftyDrillCatServiceImpl -- update -- End");
		 
		return sftydrillCatDto;
	}

	

}
