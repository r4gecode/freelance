/**
 * 
 */
package in.ind.mds.serviceImpl;

import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import in.ind.mds.dto.DrillCategoriesDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.repo.dao.DrillCategoriesDao;
import in.ind.mds.repo.entity.DrillCategories;
import in.ind.mds.service.DrillCateoriesService;
import in.ind.mds.service.SyncDataService;
import in.ind.mds.util.BeanTransformerUtil;
import in.ind.mds.util.CommonUtil;
import in.ind.mds.util.DBUtil;

/**
 * @author dharani
 *
 */

@Service("TST_MSSQL_DRILL_CATEGORIES")
public class DrillCategoriesServiceImpl  implements DrillCateoriesService{
	
	private static final Logger LOGGER = LoggerFactory.getLogger(DrillCategoriesServiceImpl.class);

	@Autowired
	private BeanTransformerUtil<DrillCategories, DrillCategoriesDto> mapEntityToDto;

	@Autowired
	private BeanTransformerUtil<DrillCategoriesDto,DrillCategories> mapDtoToEntity;

	@Autowired
	@Qualifier("TST_MSSQL_SYNC")
	private SyncDataService syncDataService;
	
	@Autowired
	private CommonUtil<DrillCategoriesDto> commonUtil;

	@Autowired
	private DrillCategoriesDao drillCategoriesDao;
	
	@Autowired
	private DBUtil dbUtil;

	@Override
	public DrillCategoriesDto add(DrillCategoriesDto drillCategoriesDto) throws Exception {
		LOGGER.debug("DtillCategoriesServiceImpl -- add -- Start");
		commonUtil.stringNullValidator(drillCategoriesDto.getDrillCtgyName(), "DrillCatyName");
		DrillCategories drillCategories = drillCategoriesDao.findByDrillCtgyNameAndStatusNot(drillCategoriesDto.getDrillCtgyName(),
				commonUtil.getSoftDeleteStatus());
		if (drillCategories != null)
			throw new ApplicationServiceExecption("DrillCategories already exist", HttpStatus.BAD_REQUEST);
		
		drillCategories = mapDtoToEntity.transformBO(drillCategoriesDto, DrillCategories.class);
		String seqName = dbUtil.getNextSequence(drillCategories.getClass());
		if (seqName != null)
			drillCategories.setId(seqName);

		drillCategories.setInsertTime(new Date());
		drillCategories.setUpdateTime(new Date());
		drillCategories.setStatus(commonUtil.getActiveStatus());
		drillCategories = drillCategoriesDao.save(drillCategories);
		syncDataService.syncCreation(drillCategories);
		LOGGER.debug("DrillCategoriesServiceImpl -- add -- End");
		return mapEntityToDto.transformBO(drillCategories, DrillCategoriesDto.class);
	}

	
	

	@Override
	public DrillCategoriesDto update(DrillCategoriesDto drillCategoriesDto) throws Exception {
		LOGGER.debug("DRillCategoriesServiceImpl -- update -- Start");
	
		commonUtil.stringNullValidator(drillCategoriesDto.getDrillCtgyName(), drillCategoriesDto.getId(), "DrillCatg Id and drillCtgyName");
		DrillCategories drillCategories = drillCategoriesDao.findByDrillCtgyNameAndStatusNotAndIdNot(drillCategoriesDto.getDrillCtgyName(),
				commonUtil.getSoftDeleteStatus(), drillCategoriesDto.getId());
		if (drillCategories != null)
			throw new ApplicationServiceExecption("DrillCategories already exist", HttpStatus.BAD_REQUEST);

		drillCategories = drillCategoriesDao.findByIdAndStatusNot(drillCategoriesDto.getId(), commonUtil.getSoftDeleteStatus());
		if (drillCategories == null)
			throw new ApplicationServiceExecption("DrillCategories not found", HttpStatus.BAD_REQUEST);

		DrillCategoriesDto existingDrillCategoriesDto = mapEntityToDto.transformBO(drillCategories, DrillCategoriesDto.class);
		drillCategories = mapDtoToEntity.transformBO(drillCategoriesDto, DrillCategories.class);
		drillCategories.setUpdateTime(new Date());
		drillCategories = drillCategoriesDao.saveAndFlush(drillCategories);
		syncDataService.syncUpdate(mapDtoToEntity.transformBO(existingDrillCategoriesDto, DrillCategories.class), drillCategories);
		LOGGER.debug("DrillCategoriesServiceImpl -- update -- End");
		return mapEntityToDto.transformBO(drillCategories, DrillCategoriesDto.class);
	}
	

	@Override
	public List<DrillCategoriesDto> softDeleteDrillCtgy(List<String> drillIds) throws Exception {
		LOGGER.debug("DrillCategoriesServiceImpl -- delete -- Start");
		commonUtil.stringNullValidator(drillIds.toArray(), "drillId");
		List<DrillCategories> existingDrillCategoriesList = drillCategoriesDao.findByIdInAndStatusNot(drillIds,
				commonUtil.getSoftDeleteStatus());
		if (existingDrillCategoriesList.size() < drillIds.size())
			throw new ApplicationServiceExecption("DrillCategories not found", HttpStatus.BAD_REQUEST);

		List<DrillCategoriesDto> existingDrillCtgyDtoList = mapEntityToDto.transformListOfBO(existingDrillCategoriesList,
				DrillCategoriesDto.class);
		for (DrillCategories drillCategories : existingDrillCategoriesList) {
			drillCategories.setStatus(commonUtil.getSoftDeleteStatus());
			drillCategories.setUpdateTime(new Date());
		}
		drillCategoriesDao.saveAll(existingDrillCategoriesList);
		Integer count = 0;
		for (DrillCategories drillCategories : existingDrillCategoriesList) {
			syncDataService.syncUpdate(mapDtoToEntity.transformBO(existingDrillCtgyDtoList.get(count), DrillCategories.class), drillCategories);
			count++;
		}
		existingDrillCategoriesList = drillCategoriesDao.findAllDrillCategories();
		LOGGER.debug("DrillCategoriesServiceImpl -- delete -- End");
		return mapEntityToDto.transformListOfBO(existingDrillCategoriesList, DrillCategoriesDto.class);
	}

	@Override
	public List<DrillCategoriesDto> findAll() throws Exception {
		LOGGER.debug("DRillCategoriesServiceImpl -- findByDrillCatgyType -- Start");
		List<DrillCategories> drillCategories = drillCategoriesDao.findAllDrillCategories();

		if (drillCategories.size() == 0)
			throw new ApplicationServiceExecption("DrillCategories not found", HttpStatus.NOT_FOUND);

		final List<DrillCategoriesDto> dto = mapEntityToDto.transformListOfBO(drillCategories, DrillCategoriesDto.class);
		LOGGER.debug("DrillCategoriesServiceImpl -- findByDrillCategoriesType -- End");
		return dto;
	}

	@Override
	public DrillCategoriesDto getByDrillCtgyId(String drillId) throws Exception {
		LOGGER.debug("DrillCategoriesServiceImpl -- getByDrillCtgyId -- Start");
		commonUtil.stringNullValidator(drillId, "drillCtgyId");

		final DrillCategories drillCategories = drillCategoriesDao.findByIdAndStatusNot(drillId, commonUtil.getSoftDeleteStatus());

		if (drillCategories == null)
			throw new ApplicationServiceExecption("Error drillCategories not found", HttpStatus.NOT_FOUND);

		
		final DrillCategoriesDto dto = mapEntityToDto.transformBO(drillCategories, DrillCategoriesDto.class);

		LOGGER.debug("DrillCategoriesServiceImpl -- getByDrillId -- End");
		return dto;
	}




	@Override
	public DrillCategoriesDto findByDrillCtgyName(String drillCtgyName) throws Exception {
		LOGGER.debug("DrillCategoriesServiceImpl -- getByLocationName -- Start");
		commonUtil.stringNullValidator(drillCtgyName, "DrillCtgyName");

		final DrillCategories drillCategories = drillCategoriesDao.findByDrillCtgyNameAndStatusNot(drillCtgyName,
				commonUtil.getSoftDeleteStatus());

		if (drillCategories == null)
			throw new ApplicationServiceExecption("Error DrillCategories not found", HttpStatus.NOT_FOUND);

		
		final DrillCategoriesDto dto = mapEntityToDto.transformBO(drillCategories, DrillCategoriesDto.class);

		LOGGER.debug("DrillCategoriesServiceImpl -- getByLocationName -- End");
		return dto;

}
}
