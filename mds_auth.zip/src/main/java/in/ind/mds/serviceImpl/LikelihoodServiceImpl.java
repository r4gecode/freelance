/**
 * 
 */
package in.ind.mds.serviceImpl;

import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import in.ind.mds.dto.LikelihoodDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.repo.dao.LikelihoodDao;
import in.ind.mds.repo.entity.Likelihood;
import in.ind.mds.service.LikelihoodService;
import in.ind.mds.service.SyncDataService;
import in.ind.mds.util.BeanTransformerUtil;
import in.ind.mds.util.CommonUtil;
import in.ind.mds.util.DBUtil;

/**
 * @author shalini
 *
 */
@Service("TST_MSSQL_LIKELIHOOD")
public class LikelihoodServiceImpl implements LikelihoodService{
	
	private static final Logger LOGGER = LoggerFactory.getLogger(LikelihoodServiceImpl.class);

	@Autowired
	private BeanTransformerUtil<Likelihood, LikelihoodDto> mapEntityToDto;

	@Autowired
	private BeanTransformerUtil<LikelihoodDto, Likelihood> mapDtoToEntity;
	
	@Autowired
	@Qualifier("TST_MSSQL_SYNC")
	private SyncDataService syncDataService;
	
	 @Autowired
	 private CommonUtil<LikelihoodDto> commonUtil;
	
	@Autowired
	private LikelihoodDao likelihoodDao;

	@Autowired
	private DBUtil dbUtil;

	@Override
	public LikelihoodDto add(LikelihoodDto likelihoodDto) throws Exception {
		LOGGER.debug("LikelihoodServiceImpl -- add -- Start");
		commonUtil.stringNullValidator(likelihoodDto.getTypeOfLikelihood(), "TypeOfLikelihood");
		Likelihood likelihood=likelihoodDao.findByItemNumberAndStatusNot(likelihoodDto.getItemNumber(), commonUtil.getSoftDeleteStatus());
		if(likelihood!=null)
			throw new ApplicationServiceExecption("likelihood already exist", HttpStatus.BAD_REQUEST);
		likelihood=mapDtoToEntity.transformBO(likelihoodDto, Likelihood.class);
		String seqName = dbUtil.getNextSequence(likelihood.getClass());
		if (seqName != null) {
			likelihood.setId(seqName);
		}
		likelihood.setInsertTime(new Date());
		likelihood.setUpdateTime(new Date());
		likelihood.setStatus(commonUtil.getActiveStatus());
		likelihood=likelihoodDao.save(likelihood);
		syncDataService.syncCreation(likelihood);
		LOGGER.debug("LikelihoodServiceImpl -- add -- End");
		return mapEntityToDto.transformBO(likelihood, LikelihoodDto.class);
	}


	@Override
	public LikelihoodDto update(LikelihoodDto likelihoodDto) throws Exception {
		LOGGER.debug("LikelihoodServiceImpl -- update -- Start");
		commonUtil.stringNullValidator(likelihoodDto.getId(), "Crew course Id");
		List<Likelihood> likelihoods = likelihoodDao.uniqueCheckForUpdate(likelihoodDto.getId(), likelihoodDto.getItemNumber(),likelihoodDto.getTypeOfLikelihood());
		if(likelihoods.size() != 0)
			throw new ApplicationServiceExecption("likelihood already exist", HttpStatus.BAD_REQUEST);
		
		Likelihood likelihood = likelihoodDao.findByIdAndStatusNot(likelihoodDto.getId(), commonUtil.getSoftDeleteStatus());
		if (likelihood == null) 
			throw new ApplicationServiceExecption("likelihood not found", HttpStatus.BAD_REQUEST);
		
		LikelihoodDto existingLikelihood = mapEntityToDto.transformBO(likelihood, LikelihoodDto.class);
		Likelihood likelihoodEntity = mapDtoToEntity.transformBO(likelihoodDto, Likelihood.class);
		likelihoodEntity.setUpdateTime(new Date());
		likelihoodEntity=likelihoodDao.saveAndFlush(likelihoodEntity);
		syncDataService.syncUpdate(mapDtoToEntity.transformBO(existingLikelihood, Likelihood.class), likelihoodEntity);
		LOGGER.debug("LikelihoodServiceImpl -- update -- End");

		return mapEntityToDto.transformBO(likelihoodEntity, LikelihoodDto.class);
	}

	@Override
	public LikelihoodDto findById(String likelihoodId) throws Exception {
		LOGGER.debug("LikelihoodServiceImpl -- findById -- Start");
		commonUtil.stringNullValidator(likelihoodId, "Likelihood Id");
		Likelihood likelihood=likelihoodDao.findByIdAndStatusNot(likelihoodId, commonUtil.getSoftDeleteStatus());
		if(likelihood==null)
			throw new ApplicationServiceExecption("likelihood not found", HttpStatus.NOT_FOUND);
		final LikelihoodDto dto = mapEntityToDto.transformBO(likelihood, LikelihoodDto.class);

		LOGGER.debug("LikelihoodServiceImpl -- findById -- End");

		return dto;
	}

	@Override
	public List<LikelihoodDto> findAllLikelihood() throws Exception {
		LOGGER.debug("LikelihoodServiceImpl -- findAllLikelihood -- Start");
		List<Likelihood> likelihoods = likelihoodDao.findAllLikelihood();
		
		if(likelihoods.size()==0)
			throw new ApplicationServiceExecption("likelihood not found", HttpStatus.NOT_FOUND);
		
		final List<LikelihoodDto> listDto = mapEntityToDto.transformListOfBO(likelihoods, LikelihoodDto.class);

		LOGGER.debug("LikelihoodServiceImpl -- findAllLikelihood -- End");

		return listDto;
	}


	@Override
	public List<LikelihoodDto> softDelete(List<String> likelihoodId) throws Exception {
		LOGGER.debug("LikelihoodServiceImpl -- softDelete -- Start");
		List<Likelihood> existingLikelihoodList = likelihoodDao.findByIdInAndStatusNot(likelihoodId, commonUtil.getSoftDeleteStatus());
		if (existingLikelihoodList.size() < likelihoodId.size()) 
			throw new ApplicationServiceExecption("Likelihood not found", HttpStatus.BAD_REQUEST);
		
		
		List<LikelihoodDto> existingLikelihoodDtoList=mapEntityToDto.transformListOfBO(existingLikelihoodList, LikelihoodDto.class);
		
		for(Likelihood likelihood:existingLikelihoodList)
		{
			likelihood.setStatus(commonUtil.getSoftDeleteStatus());;
			likelihood.setUpdateTime(new Date());
		}
		
		existingLikelihoodList =likelihoodDao.saveAll(existingLikelihoodList);
		Integer count=0;
		for(Likelihood likelihood:existingLikelihoodList)
		{
			syncDataService.syncUpdate(mapDtoToEntity.transformBO(existingLikelihoodDtoList.get(count), Likelihood.class), likelihood);
			count++;
			
		}
		List<Likelihood> likelihoodList=likelihoodDao.findAllLikelihood();
		LOGGER.debug("LikelihoodServiceImpl -- softDelete -- End");

		return mapEntityToDto.transformListOfBO(likelihoodList, LikelihoodDto.class);
	}
}
