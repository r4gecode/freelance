package in.ind.mds.serviceImpl;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import in.ind.mds.dto.UserAuditDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.repo.dao.UserAuditDao;
import in.ind.mds.repo.entity.UserAudit;
import in.ind.mds.service.SyncDataService;
import in.ind.mds.service.UserAuditService;
import in.ind.mds.util.BeanTransformerUtil;
import in.ind.mds.util.CommonUtil;
import in.ind.mds.util.DBUtil;

@Service("TST_MSSQL_USER_AUDIT")

public class UserAuditServiceImpl implements UserAuditService
{

	private static final Logger LOGGER = LoggerFactory.getLogger(UserAuditServiceImpl.class);

	@Autowired
	private BeanTransformerUtil<UserAudit, UserAuditDto> mapEntityToDto;

	@Autowired
	private BeanTransformerUtil<UserAuditDto, UserAudit> mapDtoToEntity;

	@Autowired
	@Qualifier("TST_MSSQL_SYNC")
	private SyncDataService syncDataService;
	/*
	 * @Autowired private UserValidator validator;
	 */
	@Autowired
	private CommonUtil<UserAuditDto> commonUtil;

	@Autowired
	private UserAuditDao userAuditDao;
	
	@Autowired
	private DBUtil dbUtil;


	public UserAuditDto findByUserIdAndAuditId(final String userId, final String auditId)throws Exception 
	{
		LOGGER.debug("UserAuditServiceImpl -- getByUserIdAndUserIp -- Start");
		commonUtil.stringNullValidator(userId, auditId, "UserId and AuditId");
		UserAudit userAudit = userAuditDao.findByUserIdAndId(userId,auditId);

		if (userAudit == null) {
			throw new ApplicationServiceExecption("UserAudit not found", HttpStatus.NOT_FOUND);
		}
		final UserAuditDto dto = mapEntityToDto.transformBO(userAudit, UserAuditDto.class);
		LOGGER.debug("UserAuditServiceImpl -- getByUserIdAndUserIp -- End");
		return dto;
	}

	public UserAuditDto getByAuditId(final String auditId)throws Exception 
	{
		LOGGER.debug("UserAuditServiceImpl -- getByAuditId -- Start");
		commonUtil.stringNullValidator(auditId, "AuditId");
		final Optional<UserAudit> userAudit = userAuditDao.findById(auditId);

		if (!userAudit.isPresent()) {
			throw new ApplicationServiceExecption("Error userAudit not found", HttpStatus.NOT_FOUND);
		}
		/*
		 * Date date = user.getServerTime(); Date currentDate = new
		 * Date(System.currentTimeMillis());
		 * 
		 * if (date.before(currentDate) || date.after(currentDate)) {
		 * user.setServerTime(currentDate); userDao.save(user); }
		 */
		final UserAuditDto dto = mapEntityToDto.transformBO(userAudit.get(), UserAuditDto.class);

		LOGGER.debug("UserAuditServiceImpl -- getByAuditId -- End");
		return dto;
	}

	@Override
	public UserAuditDto findByUserIp(final String userIp)throws Exception 
	{
		LOGGER.debug("UserAuditServiceImpl -- getByUserIp -- Start");
		commonUtil.stringNullValidator(userIp, "UserIp");
		final UserAudit userAudit = userAuditDao.findByUserIp(userIp);

		if (userAudit == null) {
			throw new ApplicationServiceExecption("Error userAudit not found", HttpStatus.NOT_FOUND);
		}
		/*
		 * Date date = user.getServerTime(); Date currentDate = new
		 * Date(System.currentTimeMillis());
		 * 
		 * if (date.before(currentDate) || date.after(currentDate)) {
		 * user.setServerTime(currentDate); userDao.save(user); }
		 */
		final UserAuditDto dto = mapEntityToDto.transformBO(userAudit, UserAuditDto.class);

		LOGGER.debug("UserAuditServiceImpl -- getByUserIp -- End");
		return dto;
	}
	
	@Override
	public List<UserAuditDto> findAll() throws Exception {
		LOGGER.debug("UserAuditServiceImpl -- findByUserAuditType -- Start");
		List<UserAudit> userAudit = userAuditDao.findAll();

		if (userAudit.size() == 0) {
			throw new ApplicationServiceExecption("UserAudit not found", HttpStatus.NOT_FOUND);
		}
		final List<UserAuditDto> dto = mapEntityToDto.transformListOfBO(userAudit, UserAuditDto.class);
		LOGGER.debug("UserAuditServiceImpl -- findByUserAuditType -- End");
		return dto;
	}

	@Override
	public UserAuditDto add(UserAuditDto userAuditDto) throws Exception {
		LOGGER.debug("UserAuditServiceImpl -- add -- Start");
		// final String errorMessage = validator.validateAdd(userDto);
		// if (errorMessage != null) {
		// throw new GaurageServiceException(errorMessage, HttpStatus.BAD_REQUEST);
		// }
		/*Optional<UserAudit> existingUserAudit = userAuditDao.findById(userAuditDto.getId());
		if (existingUserAudit.isPresent()) {
			throw new ApplicationServiceExecption("UserAudit exist", HttpStatus.BAD_REQUEST);
		}*/
		final UserAudit userAudit = mapDtoToEntity.transformBO(userAuditDto, UserAudit.class);
		
		String seqName = dbUtil.getNextSequence(userAudit.getClass());
		if(seqName != null) {
			userAudit.setId(seqName);
		}
		userAudit.setInsertTime(new Date());

		userAuditDao.save(userAudit);
		syncDataService.syncCreation(userAudit);
		LOGGER.debug("UserAuditServiceImpl -- add -- End");
		return userAuditDto;
	}
	
	
	@Override
	public void deleteUserAudit(String auditId) throws Exception {
		LOGGER.debug("UserAuditServiceImpl -- delete -- Start");
		// final String errorMessage = validator.validateAdd(userDto);
		// if (errorMessage != null) {
		// throw new GaurageServiceException(errorMessage, HttpStatus.BAD_REQUEST);
		// }
		commonUtil.stringNullValidator(auditId, "AuditId");
		Optional<UserAudit> userAudit = userAuditDao.findById(auditId);
		if (!userAudit.isPresent()) {
			throw new ApplicationServiceExecption("UserAudit not found", HttpStatus.BAD_REQUEST);
		}
		userAuditDao.delete(userAudit.get());
		LOGGER.debug("UserAuditServiceImpl -- delete -- End");
	}

	@Override
	public UserAuditDto updateUserAudit(UserAuditDto userAuditDto) throws Exception {
		LOGGER.debug("UserAuditServiceImpl -- update -- Start");
		// final String errorMessage = validator.validateAdd(userDto);
		// if (errorMessage != null) {
		// throw new GaurageServiceException(errorMessage, HttpStatus.BAD_REQUEST);
		// }
		commonUtil.stringNullValidator(userAuditDto.getId(), "UserAuditId");
		Optional<UserAudit> existingUserAudit = userAuditDao.findById(userAuditDto.getId());
		if (!existingUserAudit.isPresent()) {
			throw new ApplicationServiceExecption("UserAudit not found", HttpStatus.BAD_REQUEST);
		}
		UserAuditDto existingUserAuditDto = mapEntityToDto.transformBO(existingUserAudit.get(), UserAuditDto.class);
		UserAudit userAudit = existingUserAudit.get();
		userAudit = mapDtoToEntity.transformBO(userAuditDto, UserAudit.class);
		userAuditDao.saveAndFlush(userAudit);
		syncDataService.syncUpdate(mapDtoToEntity.transformBO(existingUserAuditDto, UserAudit.class), userAudit);
		LOGGER.debug("UserAuditServiceImpl -- update -- End");
		return userAuditDto;
	}

}
	
