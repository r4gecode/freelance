package in.ind.mds.serviceImpl;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.ind.mds.repo.dao.ExceptionLogDao;
import in.ind.mds.repo.entity.ExceptionLog;
import in.ind.mds.service.ExceptionLogService;

@Service
public class ExceptionLogServiceImpl implements ExceptionLogService{

	@Autowired
	private ExceptionLogDao exceptionLogDao;
	
	
	@Override
	public Integer addNewException(String exception) {
		ExceptionLog exceptionLog = new ExceptionLog(exception, null, new Date(), 1);
		ExceptionLog excLog = exceptionLogDao.save(exceptionLog);
		return excLog.getId();
	}

	
}
