/**
 * 
 */
package in.ind.mds.serviceImpl;

import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import in.ind.mds.dto.CrewCertificateTypeDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.repo.dao.CrewCertificateTypeDao;
import in.ind.mds.repo.entity.CrewCertificateType;
import in.ind.mds.service.CrewCertificateTypeService;
import in.ind.mds.service.SyncDataService;
import in.ind.mds.util.BeanTransformerUtil;
import in.ind.mds.util.CommonUtil;
import in.ind.mds.util.DBUtil;

/**
 * @author mds-arockia
 *
 */
@Service("TST_MSSQL_CREW_CERTIFICATE_TYPE")
public class CrewCertificateTypeServiceImpl implements CrewCertificateTypeService{
	
	private static final Logger LOGGER = LoggerFactory.getLogger(CrewCertificateTypeServiceImpl.class);

	@Autowired
	private BeanTransformerUtil<CrewCertificateType, CrewCertificateTypeDto> mapEntityToDto;

	@Autowired
	private BeanTransformerUtil<CrewCertificateTypeDto, CrewCertificateType> mapDtoToEntity;

	@Autowired
	@Qualifier("TST_MSSQL_SYNC")
	private SyncDataService syncDataService;
	
	@Autowired
	private CrewCertificateTypeDao crewCertificateTypeDao;
	
	@Autowired
	private DBUtil dbUtil;
	
	@Autowired
	private CommonUtil<CrewCertificateTypeDto> commonUtil;
	
	@Override
	public CrewCertificateTypeDto add(CrewCertificateTypeDto certificateTypeDto) throws Exception {
		LOGGER.debug("CrewCertificateTypeServiceImpl -- add -- start");
		commonUtil.stringNullValidator(certificateTypeDto.getCertificateType(), "CertificateType");
		List<CrewCertificateType> certificateTypeList = crewCertificateTypeDao.findByCertificateTypeAndStatusNot(certificateTypeDto.getCertificateType(), commonUtil.getSoftDeleteStatus());
		if(!certificateTypeList.isEmpty())
			throw new ApplicationServiceExecption("CertificateType already exist");
		
		CrewCertificateType certificateType = mapDtoToEntity.transformBO(certificateTypeDto, CrewCertificateType.class);
		String seqName = dbUtil.getNextSequence(certificateType.getClass());
		if(seqName != null)
			certificateType.setId(seqName);
		
		certificateType.setInsertTime(new Date());
		certificateType.setUpdateTime(new Date());
		certificateType.setStatus(commonUtil.getActiveStatus());
		crewCertificateTypeDao.save(certificateType);
		syncDataService.syncCreation(certificateType);
		LOGGER.debug("CrewCertificateTypeServiceImpl -- add -- end");
		return mapEntityToDto.transformBO(certificateType, CrewCertificateTypeDto.class);
	}

	@Override
	public CrewCertificateTypeDto update(CrewCertificateTypeDto certificateTypeDto) throws Exception {
		LOGGER.debug("CrewCertificateTypeServiceImpl -- update -- start");
		commonUtil.stringNullValidator(certificateTypeDto.getCertificateType(), certificateTypeDto.getId(), "CertificateType and Id");
		List<CrewCertificateType> certificateTypeList = crewCertificateTypeDao.findByCertificateTypeAndStatusNotAndIdNot(certificateTypeDto.getCertificateType(), commonUtil.getSoftDeleteStatus(), certificateTypeDto.getId());
		if(!certificateTypeList.isEmpty())
			throw new ApplicationServiceExecption("CertificateType already exist");
		
		CrewCertificateType certificateType = crewCertificateTypeDao.findByIdAndStatusNot(certificateTypeDto.getId(), commonUtil.getSoftDeleteStatus());
		if(certificateType == null)
			throw new ApplicationServiceExecption("CertificateType not found");
		
		CrewCertificateTypeDto existingCertificateTypeDto = mapEntityToDto.transformBO(certificateType, CrewCertificateTypeDto.class);
		certificateType = mapDtoToEntity.transformBO(certificateTypeDto, CrewCertificateType.class);
		certificateType.setUpdateTime(new Date());
		crewCertificateTypeDao.save(certificateType);
		syncDataService.syncUpdate(mapDtoToEntity.transformBO(existingCertificateTypeDto, CrewCertificateType.class), certificateType);
		LOGGER.debug("CrewCertificateTypeServiceImpl -- update -- end");
		return mapEntityToDto.transformBO(certificateType, CrewCertificateTypeDto.class);
	}

	@Override
	public CrewCertificateTypeDto findById(String id) throws Exception {
		LOGGER.debug("CrewCertificateTypeServiceImpl -- findById -- start");
		commonUtil.stringNullValidator(id, "CertificateType Id");
		CrewCertificateType crewCertificateType = crewCertificateTypeDao.findByIdAndStatusNot(id, commonUtil.getSoftDeleteStatus());
		if(crewCertificateType == null)
			throw new ApplicationServiceExecption("CertificateType not found");
		LOGGER.debug("CrewCertificateTypeServiceImpl -- findById -- end");
		return mapEntityToDto.transformBO(crewCertificateType, CrewCertificateTypeDto.class);
	}
	

	@Override
	public List<CrewCertificateTypeDto> findAll() throws Exception {
		LOGGER.debug("CrewCertificateTypeServiceImpl -- findAll -- start");
		List<CrewCertificateType> certificateTypeList = crewCertificateTypeDao.findAllCrewCertificateType();
		if(certificateTypeList.isEmpty())
			throw new ApplicationServiceExecption("CertificateType not found");
		LOGGER.debug("CrewCertificateTypeServiceImpl -- findAll -- end");
		return mapEntityToDto.transformListOfBO(certificateTypeList, CrewCertificateTypeDto.class);
	}

	@Override
	public List<CrewCertificateTypeDto> softDelete(List<String> ids) throws Exception {
		LOGGER.debug("CrewCertificateTypeServiceImpl -- softDelete -- start");
		commonUtil.stringNullValidator(ids.toArray(), "CertificateType Id");
		List<CrewCertificateType> certificateTypeList = crewCertificateTypeDao.findByIdInAndStatusNot(ids, commonUtil.getSoftDeleteStatus());
		if(certificateTypeList.size() < ids.size())
			throw new ApplicationServiceExecption("CertificateType not found");
		
		List<CrewCertificateTypeDto> certificateTypeDtoList = mapEntityToDto.transformListOfBO(certificateTypeList, CrewCertificateTypeDto.class);
		for (CrewCertificateType crewCertificateType : certificateTypeList) {
			crewCertificateType.setUpdateTime(new Date());
			crewCertificateType.setStatus(commonUtil.getSoftDeleteStatus());
		}
		crewCertificateTypeDao.saveAll(certificateTypeList);
		Integer count = 0;
		for (CrewCertificateType crewCertificateType : certificateTypeList) {
			syncDataService.syncUpdate(mapDtoToEntity.transformBO(certificateTypeDtoList.get(count), CrewCertificateType.class), crewCertificateType);
			count ++;
		}
		certificateTypeList = crewCertificateTypeDao.findAllCrewCertificateType();
		LOGGER.debug("CrewCertificateTypeServiceImpl -- softDelete -- end");
		return mapEntityToDto.transformListOfBO(certificateTypeList, CrewCertificateTypeDto.class);
	}

}
