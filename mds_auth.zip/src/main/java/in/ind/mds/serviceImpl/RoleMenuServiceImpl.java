package in.ind.mds.serviceImpl;

import java.util.Date;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import in.ind.mds.dto.OwnerDto;
import in.ind.mds.dto.RoleMenuDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.repo.dao.MenuDao;
import in.ind.mds.repo.dao.RoleDao;
import in.ind.mds.repo.dao.RoleMenuDao;
import in.ind.mds.repo.entity.Menu;
import in.ind.mds.repo.entity.Role;
import in.ind.mds.repo.entity.RoleMenu;
import in.ind.mds.service.RoleMenuService;
import in.ind.mds.service.SyncDataService;
import in.ind.mds.util.BeanTransformerUtil;
import in.ind.mds.util.CommonUtil;
import in.ind.mds.util.DBUtil;

@Service("TST_MSSQL_ROLE_MENU")


public class RoleMenuServiceImpl implements RoleMenuService 
{

	private static final Logger LOGGER = LoggerFactory.getLogger(RoleMenuServiceImpl.class);

	@Autowired
	private BeanTransformerUtil<RoleMenu, RoleMenuDto> mapEntityToDto;

	@Autowired
	private BeanTransformerUtil<RoleMenuDto, RoleMenu> mapDtoToEntity;
	
	@Autowired
	@Qualifier("TST_MSSQL_SYNC")
	private SyncDataService syncDataService;
	/*
	 * @Autowired private UserValidator validator;
	 */
	@Autowired
	private CommonUtil<RoleMenuDto> commonUtil;

	@Autowired
	private RoleMenuDao roleMenuDao;
	
	@Autowired
	private MenuDao menuDao;
	
	@Autowired
	private RoleDao roleDao;
	
	@Autowired
	private DBUtil dbUtil;

	public RoleMenuDto findByRoleMenuIdAndMenuId(final String roleMenuId, final String menuId)throws Exception 
	{
		LOGGER.debug("RoleMenuServiceImpl -- getByRoleIdAndMenuId -- Start");
		commonUtil.stringNullValidator(roleMenuId, menuId, "RoleMenuId and MenuId");
		
		Menu menu = menuDao.findByIdAndStatusNot(menuId, commonUtil.getActiveStatus());
		if (menu == null) 
			throw new ApplicationServiceExecption("Menu not found", HttpStatus.NOT_FOUND);
		
		RoleMenu roleMenu = roleMenuDao.findByIdAndMenuAndStatusNot(roleMenuId, menu, commonUtil.getSoftDeleteStatus());

		if (roleMenu == null) 
			throw new ApplicationServiceExecption("RoleMenu not found", HttpStatus.NOT_FOUND);
		
		final RoleMenuDto dto = mapEntityToDto.transformBO(roleMenu, RoleMenuDto.class);
		LOGGER.debug("RoleMenuServiceImpl -- getByRoleIdAndMenuId -- End");
		return dto;
	}

	public RoleMenuDto getByRoleMenuId(final String roleMenuId)throws Exception 
	{
		LOGGER.debug("RoleMenuServiceImpl -- getByRoleMenuId -- Start");
		commonUtil.stringNullValidator(roleMenuId, "RoleMenuId");
		final RoleMenu roleMenu = roleMenuDao.findByIdAndStatusNot(roleMenuId, commonUtil.getSoftDeleteStatus());

		if (roleMenu == null) 
			throw new ApplicationServiceExecption("Error roleMenu not found", HttpStatus.NOT_FOUND);
		
		/*
		 * Date date = user.getServerTime(); Date currentDate = new
		 * Date(System.currentTimeMillis());
		 * 
		 * if (date.before(currentDate) || date.after(currentDate)) {
		 * user.setServerTime(currentDate); userDao.save(user); }
		 */
		final RoleMenuDto dto = mapEntityToDto.transformBO(roleMenu, RoleMenuDto.class);

		LOGGER.debug("RoleMenuServiceImpl -- getByRoleMenuId -- End");
		return dto;
	}

	@Override
	public List<RoleMenuDto> findByMenuId(final String menuId)throws Exception 
	{
		LOGGER.debug("RoleMenuServiceImpl -- getByMenuId -- Start");
		commonUtil.stringNullValidator(menuId, "MenuId");
		
		Menu menu = menuDao.findByIdAndStatusNot(menuId, commonUtil.getActiveStatus());
		if (menu == null) 
			throw new ApplicationServiceExecption("Menu not found", HttpStatus.NOT_FOUND);
		
		final List<RoleMenu> roleMenu = roleMenuDao.findByMenuAndStatusNot(menu, commonUtil.getSoftDeleteStatus());

		if (roleMenu.size() == 0) 
			throw new ApplicationServiceExecption("Error roleMenu not found", HttpStatus.NOT_FOUND);
		
		/*
		 * Date date = user.getServerTime(); Date currentDate = new
		 * Date(System.currentTimeMillis());
		 * 
		 * if (date.before(currentDate) || date.after(currentDate)) {
		 * user.setServerTime(currentDate); userDao.save(user); }
		 */
		final List<RoleMenuDto> dto = mapEntityToDto.transformListOfBO(roleMenu, RoleMenuDto.class);

		LOGGER.debug("RoleMenuServiceImpl -- getByMenuId -- End");
		return dto;
	}
	@Override
	public List<RoleMenuDto> findAll() throws Exception {
		LOGGER.debug("RoleMenuServiceImpl -- findByRoleMenuType -- Start");
		List<RoleMenu> roleMenu = roleMenuDao.findAllRoleMenu();

		if (roleMenu.size() == 0) 
			throw new ApplicationServiceExecption("RoleMenu not found", HttpStatus.NOT_FOUND);
		
		final List<RoleMenuDto> dto = mapEntityToDto.transformListOfBO(roleMenu, RoleMenuDto.class);
		LOGGER.debug("RoleMenuServiceImpl -- findByRoleMenuType -- End");
		return dto;
	}

	@Override
	public RoleMenuDto add(RoleMenuDto roleMenuDto) throws Exception {
		LOGGER.debug("RoleMenuServiceImpl -- add -- Start");
		// final String errorMessage = validator.validateAdd(userDto);
		// if (errorMessage != null) {
		// throw new GaurageServiceException(errorMessage, HttpStatus.BAD_REQUEST);
		// }
		/*Optional<RoleMenu> existingRoleMenu = roleMenuDao.findById(roleMenuDto.getId());
		if (existingRoleMenu.isPresent()) {
			throw new ApplicationServiceExecption("RoleMenu exist", HttpStatus.BAD_REQUEST);
		}*/
		RoleMenu roleMenu = mapDtoToEntity.transformBO(roleMenuDto, RoleMenu.class);
		
		String seqName = dbUtil.getNextSequence(roleMenu.getClass());
		if(seqName != null) {
			roleMenu.setId(seqName);
		}
		roleMenu.setInsertTime(new Date());
		roleMenu.setUpdateTime(new Date());
		roleMenu.setStatus(commonUtil.getActiveStatus());
		roleMenu=roleMenuDao.save(roleMenu);
		syncDataService.syncCreation(roleMenu);
		LOGGER.debug("RoleMenuServiceImpl -- add -- End");
		return mapEntityToDto.transformBO(roleMenu, RoleMenuDto.class);
	}
	
	
	@Override
	public List<RoleMenuDto> softDeleteRoleMenu(List<String> roleMenuIds) throws Exception {
		LOGGER.debug("RoleMenuServiceImpl -- softDeleteRoleMenu -- Start");
		// final String errorMessage = validator.validateAdd(userDto);
		// if (errorMessage != null) {
		// throw new GaurageServiceException(errorMessage, HttpStatus.BAD_REQUEST);
		// }
		commonUtil.stringNullValidator(roleMenuIds, "RoleMenuId");
		List<RoleMenu> existingRoleMenuList = roleMenuDao.findByIdInAndStatusNot(roleMenuIds,commonUtil.getSoftDeleteStatus());
		if (existingRoleMenuList.size() < roleMenuIds.size()) 
			throw new ApplicationServiceExecption("Role Menu not found", HttpStatus.BAD_REQUEST);
		
		List<RoleMenuDto> existingRoleMenuDtoList = mapEntityToDto.transformListOfBO(existingRoleMenuList, RoleMenuDto.class);
		for(RoleMenu roleMenu: existingRoleMenuList)
		{
			roleMenu.setStatus(commonUtil.getSoftDeleteStatus());
			roleMenu.setUpdateTime(new Date());
		}
		existingRoleMenuList=roleMenuDao.saveAll(existingRoleMenuList);
		Integer count=0;
		for(RoleMenu roleMenu:existingRoleMenuList)
		{
			syncDataService.syncUpdate(mapDtoToEntity.transformBO(existingRoleMenuDtoList.get(count), RoleMenu.class), roleMenu);
			count++;
		}
		List<RoleMenu> roleMenuList=roleMenuDao.findAllRoleMenu();
		LOGGER.debug("RoleMenuServiceImpl -- softDeleteRoleMenu -- End");
		return mapEntityToDto.transformListOfBO(roleMenuList, RoleMenuDto.class);
	}
	@Override
	public RoleMenuDto updateRoleMenu(RoleMenuDto roleMenuDto) throws Exception {
		LOGGER.debug("RoleMenuServiceImpl -- update -- Start");
		// final String errorMessage = validator.validateAdd(userDto);
		// if (errorMessage != null) {
		// throw new GaurageServiceException(errorMessage, HttpStatus.BAD_REQUEST);
		// }
		commonUtil.stringNullValidator(roleMenuDto.getId(), "RoleMenuId");
		RoleMenu existingRoleMenu = roleMenuDao.findByIdAndStatusNot(roleMenuDto.getId(),commonUtil.getSoftDeleteStatus());
		if (existingRoleMenu == null) 
			throw new ApplicationServiceExecption("RoleMenu not found", HttpStatus.BAD_REQUEST);
		
		RoleMenuDto existingRoloMenuDto = mapEntityToDto.transformBO(existingRoleMenu, RoleMenuDto.class);
		RoleMenu roleMenuEntity = mapDtoToEntity.transformBO(roleMenuDto, RoleMenu.class);
		roleMenuEntity.setUpdateTime(new Date());
		roleMenuEntity=roleMenuDao.saveAndFlush(roleMenuEntity);
		syncDataService.syncUpdate(mapDtoToEntity.transformBO(existingRoloMenuDto, RoleMenu.class), roleMenuEntity);
		LOGGER.debug("RoleMenuServiceImpl -- update -- End");
		return mapEntityToDto.transformBO(roleMenuEntity, RoleMenuDto.class);
	}

	@Override
	public List<RoleMenuDto> findByRoleId(final String roleId)throws Exception 
	{
		LOGGER.debug("RoleMenuServiceImpl -- findByRoleId -- Start");
		commonUtil.stringNullValidator(roleId, "RoleId");
		Role role = roleDao.findByIdAndStatusNot(roleId,commonUtil.getSoftDeleteStatus());
		List<RoleMenu> roleMenuList = roleMenuDao.findByRole(role);
		if (CollectionUtils.isEmpty(roleMenuList)) 
			throw new ApplicationServiceExecption("Role Menu not found", HttpStatus.NOT_FOUND);
		
		final List<RoleMenuDto> dto = mapEntityToDto.transformListOfBO(roleMenuList, RoleMenuDto.class);

		LOGGER.debug("RoleMenuServiceImpl -- findByRoleId -- End");
		return dto;
	}
}
	
	

