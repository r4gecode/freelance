/**
 * 
 */
package in.ind.mds.serviceImpl;

import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.expression.spel.ast.OperatorPower;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;

import in.ind.mds.dto.DrillAgendaDto;
import in.ind.mds.dto.DrillSchedulerDto;
import in.ind.mds.dto.HazardsDto;
import in.ind.mds.dto.OfficeReviewDto;
import in.ind.mds.dto.OperationDto;
import in.ind.mds.dto.ShipBoardTrainingDto;
import in.ind.mds.dto.StaffDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.repo.dao.OperationDao;
import in.ind.mds.repo.dao.OperationTypeDao;
import in.ind.mds.repo.dao.ShipBoardTrainingDao;
import in.ind.mds.repo.entity.BankDetails;
import in.ind.mds.repo.entity.DrillScheduler;
import in.ind.mds.repo.entity.Operation;
import in.ind.mds.repo.entity.ShipBoardTraining;
import in.ind.mds.repo.entity.Staff;
import in.ind.mds.service.HazardsService;
import in.ind.mds.service.OfficeReviewService;
import in.ind.mds.service.OperationService;
import in.ind.mds.service.SyncDataService;
import in.ind.mds.util.BeanTransformerUtil;
import in.ind.mds.util.CommonUtil;
import in.ind.mds.util.DBUtil;

/**
 * @author dharani
 *
 */

@Service("TST_MSSQL_OPERATION")
public class OperationServiceImpl implements OperationService {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(OperationServiceImpl.class);
	
	@Autowired
	private BeanTransformerUtil<Operation, OperationDto> mapEntityToDto;

	@Autowired
	private BeanTransformerUtil<OperationDto, Operation> mapDtoToEntity;

	@Autowired
	@Qualifier("TST_MSSQL_SYNC")
	private SyncDataService syncDataService;

	@Autowired
	private CommonUtil<OperationDto> commonUtil;

	@Autowired
	private OperationDao operationDao;
	
	@Autowired
	private DBUtil dbUtil;
	
	@Autowired
	@Qualifier("TST_MSSQL_HAZARDS")
	private HazardsService hazardsService;
	


	@Override
	public OperationDto add(OperationDto operationDtoList) throws Exception {
		LOGGER.debug("OperationServiceImpl -- add -- Start");
			
				
		commonUtil.stringNullValidator(operationDtoList.getOperation(), "Operation");
		Operation operation = operationDao.findByOperationInAndStatusNot(operationDtoList.getOperation(), commonUtil.getSoftDeleteStatus());
	 if(operation != null)
		throw new ApplicationServiceExecption("Operation already exist", HttpStatus.BAD_REQUEST);
				 operation= mapDtoToEntity.transformBO(operationDtoList, Operation.class);
				String seqName = dbUtil.getNextSequence(operation.getClass());
				
				if(seqName != null) 
					operation.setId(seqName);
				
				operation.setInsertTime(new Date());
				operation.setUpdateTime(new Date());
				operation.setStatus(commonUtil.getActiveStatus());
				operation = operationDao.save(operation);
				syncDataService.syncCreation(operation);
				
				
				OperationDto operationDtos = null;
				operationDtos = mapEntityToDto.transformBO(operation, OperationDto.class);
				
				/***********Hazards*****start****/
		List<HazardsDto> hazardsDtoList = hazardsService.add(operation,operationDtoList.getHazardsDtoList() );
		operationDtos.setHazardsDtoList(hazardsDtoList);
		

		LOGGER.debug("OperationServiceImpl -- add -- End");
		return operationDtos;
		
	}

	@Override
	public OperationDto update(OperationDto operationDtoList) throws Exception {
		LOGGER.debug("OperationServiceImpl -- updateStaff -- Start");
		
		
		
		Operation operation = operationDao.findByIdAndStatusNot(operationDtoList.getId(), commonUtil.getSoftDeleteStatus());
		if (operation == null) 
			throw new ApplicationServiceExecption("Operation not found", HttpStatus.BAD_REQUEST);

			OperationDto existingOperationDto = mapEntityToDto.transformBO(operation,OperationDto.class);
		operation = mapDtoToEntity.transformBO(operationDtoList, Operation.class);
		operation.setUpdateTime(new Date());
		operationDao.saveAndFlush(operation);
		syncDataService.syncUpdate(mapDtoToEntity.transformBO(existingOperationDto, Operation.class), operation);
		
		
		/*********************Hazards ********************/
		List<String> hazardsIds = operationDtoList.getHazardIds();
		if(!hazardsIds.isEmpty())
			hazardsService.softDelete(hazardsIds);
		
		List<HazardsDto> hazardsDtoList = operationDtoList.getHazardsDtoList();
		hazardsDtoList = hazardsService.update(operation, hazardsDtoList);
		operationDtoList.setHazardsDtoList(hazardsDtoList);
				
		LOGGER.debug("Operation -- update -- End");
		return operationDtoList;
		
	}

	@Override
	public OperationDto findById(String id) throws Exception {
LOGGER.debug("OperationServiceImpl --  -- Start");
		
		commonUtil.stringNullValidator(id,"Id");
		Operation operation=operationDao.findByIdAndStatusNot(id, commonUtil.getSoftDeleteStatus());
		if (operation == null) 
			throw new ApplicationServiceExecption("OPeration not found", HttpStatus.NOT_FOUND);
		
		OperationDto operationDto = mapEntityToDto.transformBO(operation,OperationDto.class);
		
		/*****************Hazards***************start****************/
		operationDto.setHazardsDtoList(hazardsService.findByOperation(operation));
		
		LOGGER.debug("OperationServiceImpl -- getByDrillSchedulerId -- End");

		return operationDto;
	}

	@Override
	public List<OperationDto> findAll() throws Exception {
		LOGGER.debug("OperationServiceImpl -- findAll -- Start");
		List<Operation> operation = operationDao.findAll();

		if (operation.isEmpty()) 
			throw new ApplicationServiceExecption("Operation not found", HttpStatus.NOT_FOUND);
		
		LOGGER.debug("OpperationServiceImpl -- findAll -- End");
		return mapEntityToDto.transformListOfBO(operation, OperationDto.class);
	}

	@Override
	public List<OperationDto> softDelete(List<String> ids) throws Exception {
		LOGGER.debug("OperationServiceImpl -- softDelete -- Start");
		commonUtil.stringNullValidator(ids, "Ids");

		List<Operation> existingOperation = operationDao.findByIdAndStatusNot(ids, commonUtil.getSoftDeleteStatus());
		if (existingOperation.size() < ids.size())
			throw new ApplicationServiceExecption("Operation not found", HttpStatus.BAD_REQUEST);

		List<OperationDto> existingOperationDto = mapEntityToDto.transformListOfBO(existingOperation, OperationDto.class);
		for (Operation operation : existingOperation) {
			operation.setStatus(commonUtil.getSoftDeleteStatus());
			operation.setUpdateTime(new Date());
		}
		existingOperation = operationDao.saveAll(existingOperation);
		Integer count = 0;
		for (Operation operation : existingOperation) {
			syncDataService.syncUpdate(mapDtoToEntity.transformBO(existingOperationDto.get(count), Operation.class), operation);
			hazardsService.softDeleteByOperation(operation);
			count++;
		}
		List<Operation> operationList = operationDao.findAll();
		LOGGER.debug("OperationServiceImpl -- softDeleteStaff -- End");
		return mapEntityToDto.transformListOfBO(operationList, OperationDto.class);
	}

}
