/**
 * 
 */
package in.ind.mds.serviceImpl;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.time.DateUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.databind.ObjectMapper;

import in.ind.mds.dto.AttachmentDto;
import in.ind.mds.dto.DrillAgendaDto;
import in.ind.mds.dto.DrillSchedulerDto;
import in.ind.mds.dto.StaffDto;
import in.ind.mds.enums.FreequencyTypes;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.repo.dao.DrillSchedulerDao;
import in.ind.mds.repo.entity.DrillCompletion;
import in.ind.mds.repo.entity.DrillScheduler;
import in.ind.mds.service.AttachmentService;
import in.ind.mds.service.DrillAgendaService;
import in.ind.mds.service.DrillSchedulerService;
import in.ind.mds.service.SyncDataService;
import in.ind.mds.util.BeanTransformerUtil;
import in.ind.mds.util.CommonUtil;
import in.ind.mds.util.DBUtil;

/**
 * @author Hinaya
 *
 */
@Service("TST_MSSQL_DRILL_SCHEDULER")
public class DrillSchedulerServiceImpl implements DrillSchedulerService {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(DrillSchedulerServiceImpl.class);

	@Autowired
	private BeanTransformerUtil<DrillScheduler, DrillSchedulerDto> mapEntityToDto;
	
	@Autowired
	private BeanTransformerUtil<DrillSchedulerDto, DrillScheduler> mapDtoToEntity;
	
	@Autowired
	@Qualifier("TST_MSSQL_SYNC")
	private SyncDataService syncDataService;
	
	@Autowired
	 private CommonUtil<StaffDto> commonUtil;
	
	@Autowired
	private DrillSchedulerDao drillSchedulerDao;
	
	@Autowired
	@Qualifier("TST_MSSQL_DRILL_AGENDA")
	private DrillAgendaService drillAgendaService;

	@Autowired
	@Qualifier("TST_MSSQL_ATTACHEMENT")
	private AttachmentService attachmentService;
	
	@Autowired
	private DBUtil dbUtil;

	
	@Override
	public DrillSchedulerDto findById(String DrillSchedulerId) throws Exception {
		LOGGER.debug("DrillSchedulerServiceImpl -- getByDrillSchedulerId -- Start");
		
		commonUtil.stringNullValidator(DrillSchedulerId,"DrillSchedulerId");
		DrillScheduler drillScheduler=drillSchedulerDao.findByIdAndStatusNot(DrillSchedulerId, commonUtil.getSoftDeleteStatus());
		if (drillScheduler == null) 
			throw new ApplicationServiceExecption("Drill scheduler not found", HttpStatus.NOT_FOUND);
		
		DrillSchedulerDto drillSchedulerDto = mapEntityToDto.transformBO(drillScheduler, DrillSchedulerDto.class);
		AttachmentDto attachmentDto = new AttachmentDto();
		attachmentDto.setAttachmentOrigin(dbUtil.getTableName(drillScheduler.getClass()));
		attachmentDto.setRecordId(drillScheduler.getId());
		attachmentDto.setAttachmentType(drillSchedulerDto.getDrillSchedulerDocsFieldName());
		List<String> attachmentPathList = attachmentService.findAttachments(attachmentDto);
		drillSchedulerDto.setDrillSchedulerDocs(attachmentPathList);
		
		/*****************Drill Agenda***************start****************/
		drillSchedulerDto.setDrillAgenda(drillAgendaService.findByDrillScheduler(drillScheduler));
		
		LOGGER.debug("DrillSchedulerServiceImpl -- getByDrillSchedulerId -- End");
		return drillSchedulerDto;
	}

	@Override
	public DrillSchedulerDto add(String drillSchedulerDetails, Map<String, MultipartFile[]> attachments) throws Exception {
		// TODO Auto-generated method stub

		LOGGER.debug("DrillSchedulerServiceImpl -- add -- Start");
		ObjectMapper mapper = new ObjectMapper();
		DrillSchedulerDto drillSchedulerDto = mapper.readValue(drillSchedulerDetails, DrillSchedulerDto.class);
		DrillScheduler drillScheduler = mapDtoToEntity.transformBO(drillSchedulerDto, DrillScheduler.class);
		String seqName = dbUtil.getNextSequence(drillScheduler.getClass());
		
		if(seqName != null) 
			drillScheduler.setId(seqName);
		
		drillScheduler.setInsertTime(new Date());
		drillScheduler.setUpdateTime(new Date());
		drillScheduler.setStatus(commonUtil.getActiveStatus());
		drillScheduler = drillSchedulerDao.save(drillScheduler);
		syncDataService.syncCreation(drillScheduler);
		
		DrillSchedulerDto drillSchedulers = null;
		drillSchedulers = mapEntityToDto.transformBO(drillScheduler, DrillSchedulerDto.class);
		AttachmentDto attachmentDto = new AttachmentDto();
		attachmentDto.setRecordId(drillScheduler.getId());
		attachmentDto.setAttachmentOrigin(dbUtil.getTableName(drillScheduler.getClass()));
		attachmentDto.setAttachmentType(drillSchedulers.getDrillSchedulerDocsFieldName());
		List<String> attachmentPathList = attachmentService.add(attachmentDto, Arrays.asList(attachments.get("drillSchedulerDocs")));
		drillSchedulers.setDrillSchedulerDocs(attachmentPathList);
		
		/***********DrillAgenda*****start****/
		List<DrillAgendaDto> drillAgendaDtoList = drillAgendaService.add(drillScheduler, drillSchedulerDto.getDrillAgenda(), attachments.get("drillAgendaDocs"));
		drillSchedulers.setDrillAgenda(drillAgendaDtoList);

		
		LOGGER.debug("DrillSchedulerServiceImpl -- add -- End");
		return drillSchedulers;
	
		}

	@Override
	public List<DrillSchedulerDto> findAll() throws Exception {
		LOGGER.debug("DrillSchedulerServiceImpl -- findAll -- Start");
		List<DrillScheduler> drillSchedulerList = drillSchedulerDao.findAllDrillScheduler();

		if (drillSchedulerList.isEmpty()) 
			throw new ApplicationServiceExecption("Drill Scheduler not found", HttpStatus.NOT_FOUND);
		
		LOGGER.debug("DrillSchedulerServiceImpl -- findAll -- End");
		return mapEntityToDto.transformListOfBO(drillSchedulerList, DrillSchedulerDto.class);
	}

	@Override
	public List<DrillSchedulerDto> softDeleteDrillScheduler(List<String> drillSchedulerIds) throws Exception {
		LOGGER.debug("DrillSchedulerServiceImpl -- softDeleteStaff -- Start");
		commonUtil.stringNullValidator(drillSchedulerIds, "drillSchedulerIds");
		
		List<DrillScheduler> existingDrillSchedulerList = drillSchedulerDao.findByIdInAndStatusNot(drillSchedulerIds, commonUtil.getSoftDeleteStatus());
		if (existingDrillSchedulerList.size() < drillSchedulerIds.size()) 
			throw new ApplicationServiceExecption("Drill Scheduler not found", HttpStatus.BAD_REQUEST);
		
		List<DrillSchedulerDto> existingDrillSchedulerDtoList = mapEntityToDto.transformListOfBO(existingDrillSchedulerList, DrillSchedulerDto.class);
		for(DrillScheduler drillScheduler : existingDrillSchedulerList)
		{
			drillScheduler.setStatus(commonUtil.getSoftDeleteStatus());
			drillScheduler.setUpdateTime(new Date());
		}
		existingDrillSchedulerList=drillSchedulerDao.saveAll(existingDrillSchedulerList);
		Integer count=0;
		for(DrillScheduler drillScheduler: existingDrillSchedulerList)
		{
			syncDataService.syncUpdate(mapDtoToEntity.transformBO(existingDrillSchedulerDtoList.get(count), DrillScheduler.class), drillScheduler);
			attachmentService.softDelete(drillScheduler.getId(), dbUtil.getTableName(drillScheduler.getClass()));
			drillAgendaService.softDeleteByDrillScheduler(drillScheduler);
			count++;
		}
		List<DrillScheduler> drillSchedulerList = drillSchedulerDao.findAllDrillScheduler();
		LOGGER.debug("DrillSchedulerServiceImpl -- softDeleteStaff -- End");
		return mapEntityToDto.transformListOfBO(drillSchedulerList, DrillSchedulerDto.class);
	}

	@Override
	public DrillSchedulerDto updateDrillScheduler(String drillSchedulerDetails, Map<String, MultipartFile[]> attachments)
			throws Exception {
		LOGGER.debug("DrillSchedulerServiceImpl -- updateStaff -- Start");
		ObjectMapper mapper = new ObjectMapper();
		DrillSchedulerDto drillSchedulerDto = mapper.readValue(drillSchedulerDetails, DrillSchedulerDto.class);
		
		/*commonUtil.stringNullValidator(drillSchedulerDto.getId() ,"Id");*/
		
		DrillScheduler drillScheduler = drillSchedulerDao.findByIdAndStatusNot(drillSchedulerDto.getId(), commonUtil.getSoftDeleteStatus());
		if (drillScheduler == null) 
			throw new ApplicationServiceExecption("Drill Scheduler not found", HttpStatus.BAD_REQUEST);

		DrillSchedulerDto existingDrillSchedulerDto = mapEntityToDto.transformBO(drillScheduler, DrillSchedulerDto.class);
		drillScheduler = mapDtoToEntity.transformBO(drillSchedulerDto, DrillScheduler.class);
		drillScheduler.setUpdateTime(new Date());
		drillSchedulerDao.saveAndFlush(drillScheduler);
		syncDataService.syncUpdate(mapDtoToEntity.transformBO(existingDrillSchedulerDto, DrillScheduler.class), drillScheduler);
		//drillSchedulerDto = mapEntityToDto.transformBO(drillScheduler, DrillSchedulerDto.class);
		
		
		/**********************Drill Agenda ********************/
		List<String> drillAgendaIds = drillSchedulerDto.getDrillAgendaIds();
		if(!drillAgendaIds.isEmpty())
			drillAgendaService.softDelete(drillAgendaIds);
		
		List<DrillAgendaDto> drillAgendaDtoList = drillSchedulerDto.getDrillAgenda();
		drillAgendaDtoList = drillAgendaService.update(drillScheduler, drillAgendaDtoList, attachments.get("drillAgendaDoc"));
		drillSchedulerDto.setDrillAgenda(drillAgendaDtoList);
		
				
		LOGGER.debug("DrillSchedulerServiceImpl -- updateStaff -- End");
		return drillSchedulerDto;
		
	}

	@Override
	public void updationAtDrillCompletion(DrillCompletion drillCompletion) throws Exception {
		DrillScheduler drillScheduler = drillSchedulerDao.findByIdAndStatusNot(drillCompletion.getDrillScheduler().getId(), commonUtil.getSoftDeleteStatus());
		if(drillScheduler == null)
			throw new ApplicationServiceExecption("Related Drill scheduler not found for Drill Completion", HttpStatus.BAD_REQUEST);
		
		DrillSchedulerDto 	drillSchedulerDto = mapEntityToDto.transformBO(drillScheduler, DrillSchedulerDto.class);
		drillScheduler.setLastDoneDate(drillCompletion.getCarriedOutDate());
		Date nextDueDate = drillCompletion.getCarriedOutDate();
		 if(drillScheduler.getFrequencyType().equals(FreequencyTypes.DAYS.getNames()))
			 nextDueDate=DateUtils.addDays(nextDueDate, drillScheduler.getFrequency());
		else if(drillScheduler.getFrequencyType().equals(FreequencyTypes.WEEKS.getNames()))
			nextDueDate=DateUtils.addWeeks(nextDueDate, drillScheduler.getFrequency());
		else if(drillScheduler.getFrequencyType().equals(FreequencyTypes.MONTHS.getNames()))
			nextDueDate=DateUtils.addMonths(nextDueDate, drillScheduler.getFrequency());
		else if(drillScheduler.getFrequencyType().equals(FreequencyTypes.YEARS.getNames()))
			nextDueDate=DateUtils.addYears(nextDueDate, drillScheduler.getFrequency());
		else if(drillScheduler.getFrequencyType().equals(FreequencyTypes.RANGEHOURS.getNames())) 
			nextDueDate=DateUtils.addDays(nextDueDate, (int) (drillScheduler.getFrequency()));
		
		drillScheduler.setNextDueDate(nextDueDate);
		drillScheduler.setUpdateTime(new Date());
		drillSchedulerDao.save(drillScheduler);
		syncDataService.syncUpdate(mapDtoToEntity.transformBO(drillSchedulerDto, DrillScheduler.class), drillScheduler);
	}

	
}
