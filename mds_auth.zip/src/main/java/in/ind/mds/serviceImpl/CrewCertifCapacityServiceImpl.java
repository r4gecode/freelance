/**
 * 
 */
package in.ind.mds.serviceImpl;

import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import in.ind.mds.dto.CrewCertifCapacityDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.repo.dao.CrewCertifCapacityDao;
import in.ind.mds.repo.entity.CrewCertifCapacity;
import in.ind.mds.service.CrewCertifCapacityService;
import in.ind.mds.service.SyncDataService;
import in.ind.mds.util.BeanTransformerUtil;
import in.ind.mds.util.CommonUtil;
import in.ind.mds.util.DBUtil;

/**
 * @author mds-arockia
 *
 */
@Service("TST_MSSQL_CREW_CERTIF_CAPACITY")
public class CrewCertifCapacityServiceImpl implements CrewCertifCapacityService {

	private static final Logger LOGGER = LoggerFactory.getLogger(CrewCertifCapacityServiceImpl.class);

	@Autowired
	private BeanTransformerUtil<CrewCertifCapacity, CrewCertifCapacityDto> mapEntityToDto;

	@Autowired
	private BeanTransformerUtil<CrewCertifCapacityDto, CrewCertifCapacity> mapDtoToEntity;

	@Autowired
	@Qualifier("TST_MSSQL_SYNC")
	private SyncDataService syncDataService;

	@Autowired
	private CrewCertifCapacityDao crewCertifCapacityDao;

	@Autowired
	private DBUtil dbUtil;

	@Autowired
	private CommonUtil<CrewCertifCapacityDto> commonUtil;

	@Override
	public CrewCertifCapacityDto add(CrewCertifCapacityDto crewCertifCapacityDto) throws Exception {
		LOGGER.debug("CrewCertifCapacityServiceImpl -- add -- start");
		commonUtil.stringNullValidator(crewCertifCapacityDto.getCertifCapacity(), "CertificateCapacity");
		List<CrewCertifCapacity> crewCertifCapacityList = crewCertifCapacityDao.findByCertifCapacityAndStatusNot(
				crewCertifCapacityDto.getCertifCapacity(), commonUtil.getSoftDeleteStatus());
		if (!crewCertifCapacityList.isEmpty())
			throw new ApplicationServiceExecption("CrewCertificateCapacity already exist", HttpStatus.BAD_REQUEST);

		CrewCertifCapacity crewCertifCapacity = mapDtoToEntity.transformBO(crewCertifCapacityDto,
				CrewCertifCapacity.class);
		String seqName = dbUtil.getNextSequence(crewCertifCapacity.getClass());
		if (seqName != null)
			crewCertifCapacity.setId(seqName);

		crewCertifCapacity.setInsertTime(new Date());
		crewCertifCapacity.setUpdateTime(new Date());
		crewCertifCapacity.setStatus(commonUtil.getActiveStatus());

		crewCertifCapacityDao.save(crewCertifCapacity);
		syncDataService.syncCreation(crewCertifCapacity);
		LOGGER.debug("CrewCertifCapacityServiceImpl -- add -- end");
		return mapEntityToDto.transformBO(crewCertifCapacity, CrewCertifCapacityDto.class);
	}

	@Override
	public CrewCertifCapacityDto update(CrewCertifCapacityDto certifCapacityDto) throws Exception {
		LOGGER.debug("CrewCertifCapacityServiceImpl -- update -- start");
		commonUtil.stringNullValidator(certifCapacityDto.getId(), certifCapacityDto.getCertifCapacity(),
				"CertificateCapacity and Id");
		List<CrewCertifCapacity> certifCapacityList = crewCertifCapacityDao.findByCertifCapacityAndStatusNotAndIdNot(
				certifCapacityDto.getCertifCapacity(), commonUtil.getSoftDeleteStatus(), certifCapacityDto.getId());
		if (!certifCapacityList.isEmpty())
			throw new ApplicationServiceExecption("CrewCertificateCapacity already exist");

		CrewCertifCapacity certifCapacity = crewCertifCapacityDao.findByIdAndStatusNot(certifCapacityDto.getId(),
				commonUtil.getSoftDeleteStatus());
		if (certifCapacity == null)
			throw new ApplicationServiceExecption("CrewCertificateCapacity not found");

		CrewCertifCapacityDto existingCertificateCapacityDto = mapEntityToDto.transformBO(certifCapacity,
				CrewCertifCapacityDto.class);
		certifCapacity = mapDtoToEntity.transformBO(certifCapacityDto, CrewCertifCapacity.class);
		certifCapacity.setUpdateTime(new Date());
		crewCertifCapacityDao.save(certifCapacity);
		syncDataService.syncUpdate(mapDtoToEntity.transformBO(existingCertificateCapacityDto, CrewCertifCapacity.class),
				certifCapacity);
		LOGGER.debug("CrewCertifCapacityServiceImpl -- update -- end");
		return mapEntityToDto.transformBO(certifCapacity, CrewCertifCapacityDto.class);
	}

	@Override
	public CrewCertifCapacityDto findById(String id) throws Exception {
		LOGGER.debug("CrewCertifCapacityServiceImpl -- findById -- start");
		commonUtil.stringNullValidator(id, "CertifCapacity Id");
		CrewCertifCapacity certifCapacity = crewCertifCapacityDao.findByIdAndStatusNot(id,
				commonUtil.getSoftDeleteStatus());
		if (certifCapacity == null)
			throw new ApplicationServiceExecption("CertifCapacity not found", HttpStatus.BAD_REQUEST);
		
		LOGGER.debug("CrewCertifCapacityServiceImpl -- findById -- end");
		return mapEntityToDto.transformBO(certifCapacity, CrewCertifCapacityDto.class);
	}

	@Override
	public List<CrewCertifCapacityDto> findAll() throws Exception {
		LOGGER.debug("CrewCertifCapacityServiceImpl -- findAll -- start");
		List<CrewCertifCapacity> certifCapacityList = crewCertifCapacityDao.findAllCrewCertifCapacity();
		if (certifCapacityList.isEmpty())
			throw new ApplicationServiceExecption("CertifCapacity not found", HttpStatus.BAD_REQUEST);
		
		LOGGER.debug("CrewCertifCapacityServiceImpl -- findAll -- end");
		return mapEntityToDto.transformListOfBO(certifCapacityList, CrewCertifCapacityDto.class);
	}

	@Override
	public List<CrewCertifCapacityDto> softDelete(List<String> ids) throws Exception {
		LOGGER.debug("CrewCertifCapacityServiceImpl -- softDelete -- start");
		commonUtil.stringNullValidator(ids.toArray(), "CertifCapacity Id");
		List<CrewCertifCapacity> certifCapacityList = crewCertifCapacityDao.findByIdInAndStatusNot(ids,
				commonUtil.getSoftDeleteStatus());
		if (certifCapacityList.size() < ids.size())
			throw new ApplicationServiceExecption("CertifCapacity not found", HttpStatus.BAD_REQUEST);

		List<CrewCertifCapacityDto> certifCapacityDtoList = mapEntityToDto.transformListOfBO(certifCapacityList, CrewCertifCapacityDto.class);
		for (CrewCertifCapacity crewCertifCapacity : certifCapacityList) {
			crewCertifCapacity.setUpdateTime(new Date());
			crewCertifCapacity.setStatus(commonUtil.getSoftDeleteStatus());
		}
		crewCertifCapacityDao.saveAll(certifCapacityList);
		Integer count = 0; 
		for (CrewCertifCapacity crewCertifCapacity : certifCapacityList) {
			syncDataService.syncUpdate(mapDtoToEntity.transformBO(certifCapacityDtoList.get(count), CrewCertifCapacity.class), crewCertifCapacity);
			count++;
		}
		certifCapacityList = crewCertifCapacityDao.findAllCrewCertifCapacity();
		LOGGER.debug("CrewCertifCapacityServiceImpl -- softDelete -- end");
		return mapEntityToDto.transformListOfBO(certifCapacityList, CrewCertifCapacityDto.class);
	}

}
