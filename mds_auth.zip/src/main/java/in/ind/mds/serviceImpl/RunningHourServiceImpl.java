/**
 * 
 */
package in.ind.mds.serviceImpl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import in.ind.mds.dto.ComponentDto;
import in.ind.mds.dto.RunningHourDto;
import in.ind.mds.dto.ScheduledJobDto;
import in.ind.mds.enums.RunningHourTypes;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.repo.dao.RunningHourDao;
import in.ind.mds.repo.dao.ScheduledJobDao;
import in.ind.mds.repo.entity.Component;
import in.ind.mds.repo.entity.Fleet;
import in.ind.mds.repo.entity.RunningHour;
import in.ind.mds.service.AttachmentService;
import in.ind.mds.service.ComponentService;
import in.ind.mds.service.RunningHourService;
import in.ind.mds.service.ScheduledJobService;
import in.ind.mds.service.SyncDataService;
import in.ind.mds.util.BeanTransformerUtil;
import in.ind.mds.util.CommonUtil;
import in.ind.mds.util.DBUtil;

/**
 * @author mds-arockia
 *
 */
@Service("TST_MSSQL_RUNNING_HOUR")
public class RunningHourServiceImpl implements RunningHourService{

	private static final Logger LOGGER = LoggerFactory.getLogger(RunningHourServiceImpl.class);

	@Autowired
	private BeanTransformerUtil<RunningHour, RunningHourDto> mapEntityToDto;

	@Autowired
	private BeanTransformerUtil<RunningHourDto, RunningHour> mapDtoToEntity;
	
	@Autowired
	private BeanTransformerUtil<ComponentDto, Component> mapDtoToEntityComponent;
	
	@Autowired
	private BeanTransformerUtil<Component, ComponentDto> mapEntityToDtoComponent;
	
	@Autowired
	@Qualifier("TST_MSSQL_SYNC")
	private SyncDataService syncDataService;
	
	@Autowired
	private RunningHourDao runningHourDao;
	
	@Autowired
	@Qualifier("TST_MSSQL_SCHEDULED_JOB")
	private ScheduledJobService scheduledJobService;
	
	@Autowired
	private ScheduledJobDao scheduledJobDao;
	
	@Autowired
	private ComponentService componentService;
	
	@Autowired
	@Qualifier("TST_MSSQL_ATTACHEMENT")
	private AttachmentService attachmentService;
	
	@Autowired
	private DBUtil dbUtil;
	
	@Autowired
	private CommonUtil<RunningHourDto> commonUtil;
	
	/*
	 * update each component with given running hour details,
	 * update job scheduled by the component and running hour modification.
	 * create new record for running hour based on each component. 	
	*/
	@Override
	public List<RunningHourDto> add(RunningHourDto runningHourDto) throws Exception {
		LOGGER.debug("RunningHourServiceImpl -- add -- start");
		RunningHour runningHour = mapDtoToEntity.transformBO(runningHourDto, RunningHour.class);
		
		runningHour.setInsertTime(new Date());
		runningHour.setUpdateTime(new Date());
		runningHour.setEntryDate(new Date());
		runningHour.setFromDate(new Date());
		runningHour.setToDate(new Date());
		runningHour.setrHType("ds");
		runningHour.setNumOfDays(2);
		runningHour.setStatus(commonUtil.getActiveStatus());
		
		runningHourDao.save(runningHour);
		
		/*ScheduledJobDto scheduledJobDto = new ScheduledJobDto();
		
		List<ScheduledJobDto> scheduledJobDtoList = new ArrayList<>();
		List<RunningHour> runningHourList = new ArrayList<>();
		List<Component> componentList = mapDtoToEntityComponent.transformListOfBO(runningHourDto.getComponents(), Component.class);
		if(runningHourDto.getrHType().equals(RunningHourTypes.COUNTERBASIS.getName())) {
			for (Component component : componentList) {
				if(component.getLastRHEntryDate() != null && (component.getLastRHEntryDate().compareTo(runningHour.getEntryDate()) > 0 || component.getLastRHEntryDate().compareTo(runningHour.getEntryDate()) == 0))
					throw new ApplicationServiceExecption("Entry date shouldn't be earlier than last entry date");
				
				int noOfDays =  (int) ((runningHour.getEntryDate().getTime() - component.getcRStartDate().getTime())/(1000*60*60*24));
				component.setTotalRH(component.getTotalRH()+component.getRunningHours());
				float avgRH = component.getTotalRH()/noOfDays;
				component.setLastRHEntryDate(runningHour.getEntryDate());
				component.setAvgRH(avgRH);
				*//*************modify scheduled job records*********start**************//*
				scheduledJobDto.setComponent(mapEntityToDtoComponent.transformBO(component, ComponentDto.class));
				scheduledJobDto.setTotalRH(component.getTotalRH());
				scheduledJobDto.setAvgRunningHour(avgRH);
				scheduledJobDto.setTotalNODComponentRun(noOfDays);
				scheduledJobDto.setRhFromLastCompletion((component.getTotalRH() - componentService.getByComponentId(component.getId()).getTotalRH()));
				scheduledJobDtoList.add(scheduledJobDto);
				//scheduledJobService.updationAtAddRH(scheduledJob, (component.getTotalRH() - componentService.getByComponentId(component.getId()).getTotalRH()));     // current total running hours - existing total running hours (component) 
				
				
				runningHour.setComponent(component);
				String seqName = dbUtil.getNextSequence(runningHour.getClass());
				if(seqName != null)
					runningHour.setId(seqName);
				
				runningHour.setFromDate(runningHour.getEntryDate()); 
				runningHour.setToDate(runningHour.getEntryDate());
				
				
//				runningHour.setFromDate(new Date());   // modification
//				runningHour.setToDate(new Date());
//				runningHour.setEntryDate(new Date());
				
			//	runningHour.setNumOfDays(noOfDays);   // modification
				runningHour.setInsertTime(new Date());
				runningHour.setUpdateTime(new Date());
				runningHour.setStatus(commonUtil.getActiveStatus());
				runningHourList.add(runningHour);
			}
		}else {
			for (Component component : componentList) {
				if(component.getLastRHEntryDate().compareTo(runningHour.getFromDate())>0 || component.getLastRHEntryDate().compareTo(runningHour.getFromDate()) == 0)
					throw new ApplicationServiceExecption("FromDate shouldn't be earlier than last ToDate date");
				
				component.setTotalRH(component.getTotalRH()+component.getRunningHours());
//				Integer noOfDays = component.getTotalNODComponentRun() + runningHour.getNumOfDays();
				Integer noOfDays = component.getTotalNODComponentRun() ;// modified
				Float avgRH = component.getTotalRH() / noOfDays;
				
				component.setAvgRH(avgRH);
				component.setLastRHEntryDate(runningHour.getToDate());
				*//*************modify scheduled job records*********start**************//*
				scheduledJobDto.setComponent(mapEntityToDtoComponent.transformBO(component, ComponentDto.class));
				scheduledJobDto.setTotalRH(component.getTotalRH());
				scheduledJobDto.setAvgRunningHour(avgRH);
				scheduledJobDto.setTotalNODComponentRun(noOfDays);
				scheduledJobDto.setRhFromLastCompletion(component.getRunningHours());
				scheduledJobDtoList.add(scheduledJobDto);
				//scheduledJobService.updationAtAddRH(scheduledJob, component.getRunningHours());
				
				runningHour.setComponent(component);
				String seqName = dbUtil.getNextSequence(runningHour.getClass());
				if(seqName != null)
					runningHour.setId(seqName);
				
				runningHour.setInsertTime(new Date());
				runningHour.setUpdateTime(new Date());
				runningHour.setStatus(commonUtil.getActiveStatus());
				runningHourList.add(runningHour);
			}
		}
		scheduledJobService.updationAtAddRH(scheduledJobDtoList);
		runningHourDao.saveAll(runningHourList);
		componentService.saveAll(componentList);
		for (RunningHour rhour : runningHourList) {
			syncDataService.syncCreation(rhour);
		}
		
		LOGGER.debug("RunningHourServiceImpl -- add -- end");*/
		return null;
	}

	@Override
	public RunningHourDto udpate(RunningHourDto runningHourDto) throws Exception {
//		LOGGER.debug("RunningHourServiceImpl -- update -- start");
//		
//		RunningHour existingRH = runningHourDao.findByIdAndStatusNot(runningHourDto.getId(), commonUtil.getSoftDeleteStatus());
//		//RunningHourDto existingRHDto = mapEntityToDto.transformBO(existingRH, transformer)
//		
//		RunningHour runningHour = mapDtoToEntity.transformBO(runningHourDto, RunningHour.class);
//		
//		ScheduledJobDto scheduledJobDto = new ScheduledJobDto();
//		
//		List<ScheduledJobDto> scheduledJobDtoList = new ArrayList<>();
//		List<RunningHour> runningHourList = new ArrayList<>();
//		List<Component> componentList = new ArrayList<>();
//		Component component = runningHour.getComponent();
//		componentList.add(component);
//		if(runningHourDto.getrHType().equals(RunningHourTypes.COUNTERBASIS.getName())) {
//				
//			if(component.getLastRHEntryDate().compareTo(runningHour.getEntryDate()) > 0 || component.getLastRHEntryDate().compareTo(runningHour.getEntryDate()) == 0)
//					throw new ApplicationServiceExecption("Entry date shouldn't be earlier than last entry date");
//				
//				Integer noOfDays =  (int) ((runningHour.getEntryDate().getTime() - component.getcRStartDate().getTime())/(1000*60*60*24));
//				Float avgRH = component.getTotalRH()/noOfDays;
//				component.setLastRHEntryDate(runningHour.getEntryDate());
//				component.setAvgRH(avgRH);
//				/*************modify scheduled job records*********start**************/
//				scheduledJobDto.setComponent(mapEntityToDtoComponent.transformBO(component, ComponentDto.class));
//				scheduledJobDto.setTotalRH(component.getTotalRH());
//				scheduledJobDto.setAvgRunningHour(avgRH);
//				scheduledJobDto.setTotalNODComponentRun(noOfDays);
//				scheduledJobDto.setRhFromLastCompletion((component.getTotalRH() - componentService.getByComponentId(component.getId()).getTotalRH()));
//				scheduledJobDtoList.add(scheduledJobDto);
//				//scheduledJobService.updationAtAddRH(scheduledJob, (component.getTotalRH() - componentService.getByComponentId(component.getId()).getTotalRH()));     // current total running hours - existing total running hours (component) 
//				
//				runningHour.setComponent(component);
//				String seqName = dbUtil.getNextSequence(runningHour.getClass());
//				if(seqName != null)
//					runningHour.setId(seqName);
//				
//				runningHour.setInsertTime(new Date());
//				runningHour.setUpdateTime(new Date());
//				
//				runningHourList.add(runningHour);
//			
//		}else {
//				if(component.getLastRHEntryDate().compareTo(runningHour.getFromDate())>0 || component.getLastRHEntryDate().compareTo(runningHour.getFromDate()) == 0)
//					throw new ApplicationServiceExecption("FromDate shouldn't be earlier than last ToDate date");
//				
//				component.setTotalRH(component.getTotalRH()+component.getRunningHours());
//				//Integer noOfDays = component.getTotalNODComponentRun() + runningHour.getNumOfDays();
//				Float avgRH = component.getTotalRH() / noOfDays;
//				component.setAvgRH(avgRH);
//				component.setLastRHEntryDate(runningHour.getToDate());
//				/*************modify scheduled job records*********start**************/
//				scheduledJobDto.setComponent(mapEntityToDtoComponent.transformBO(component, ComponentDto.class));
//				scheduledJobDto.setTotalRH(component.getTotalRH());
//				scheduledJobDto.setAvgRunningHour(avgRH);
//				scheduledJobDto.setTotalNODComponentRun(noOfDays);
//				scheduledJobDto.setRhFromLastCompletion(component.getRunningHours());
//				scheduledJobDtoList.add(scheduledJobDto);
//				//scheduledJobService.updationAtAddRH(scheduledJob, component.getRunningHours());
//		}
//		scheduledJobService.updationAtAddRH(scheduledJobDtoList);
//		runningHourDao.saveAll(runningHourList);
//		componentService.saveAll(componentList);
//		for (RunningHour rhour : runningHourList) {
//			syncDataService.syncCreation(rhour);
//		}
		LOGGER.debug("RunningHourServiceImpl -- update -- end");
		return null;
	}

	@Override
	public RunningHourDto findById(String id) throws Exception {
		LOGGER.debug("RunningHourServiceImpl -- findById -- start");
		scheduledJobDao.findByIdAndStatusNot(id, commonUtil.getSoftDeleteStatus());
		LOGGER.debug("RunningHourServiceImpl -- findById -- end");
		return null;
	}

	@Override
	public List<RunningHourDto> findAll() throws Exception {
		LOGGER.debug("RunningHourServiceImpl -- findAll -- start");
		LOGGER.debug("RunningHourServiceImpl -- findAll -- end");
		return null;
	}

	@Override
	public List<RunningHourDto> softDelete(List<String> ids) throws Exception {
		LOGGER.debug("RunningHourServiceImpl -- softDelete -- start");
		LOGGER.debug("RunningHourServiceImpl -- softDelete -- end");
		return null;
	}

}
