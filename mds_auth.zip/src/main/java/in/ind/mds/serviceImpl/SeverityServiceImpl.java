/**
 * 
 */
package in.ind.mds.serviceImpl;

import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import in.ind.mds.dto.SeverityDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.repo.dao.SeverityDao;
import in.ind.mds.repo.entity.Severity;
import in.ind.mds.service.SeverityService;
import in.ind.mds.service.SyncDataService;
import in.ind.mds.util.BeanTransformerUtil;
import in.ind.mds.util.CommonUtil;
import in.ind.mds.util.DBUtil;

/**
 * @author Hinaya
 *
 */
@Service("TST_MSSQL_SEVERITY")
public class SeverityServiceImpl implements SeverityService {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(SeverityServiceImpl.class);

	@Autowired
	private BeanTransformerUtil<Severity, SeverityDto> mapEntityToDto;

	@Autowired
	private BeanTransformerUtil<SeverityDto, Severity> mapDtoToEntity;

	@Autowired
	@Qualifier("TST_MSSQL_SYNC")
	private SyncDataService syncDataService;
	
	@Autowired
	private SeverityDao severityDao;
	
	@Autowired
	private DBUtil dbUtil;
	
	@Autowired
	private CommonUtil<SeverityDto> commonUtil;


	@Override
	public SeverityDto getById(String id) throws Exception {
		LOGGER.debug("SeverityServiceImpl -- findByFleetId -- Start");
		commonUtil.stringNullValidator(id, "Id");
		Severity severity = severityDao.findByIdAndStatusNot(id, commonUtil.getSoftDeleteStatus());
		if (severity == null)
			throw new ApplicationServiceExecption("Severity not found", HttpStatus.NOT_FOUND);

		LOGGER.debug("SeverityServiceImpl -- findById -- End");
		return mapEntityToDto.transformBO(severity, SeverityDto.class);
	}

	@Override
	public SeverityDto add(SeverityDto severityDto) throws Exception {
		LOGGER.debug("SeverityServiceImpl -- add -- start");
		commonUtil.stringNullValidator(severityDto.getItemNumber(), severityDto.getTypeOfSeverity(),"ItemNumber and TypeOfSeverity");
		List<Severity> existingSeverityList=severityDao.uniqueCheckForAdd(severityDto.getItemNumber(),severityDto.getTypeOfSeverity());
		if(!(existingSeverityList.isEmpty()))
			throw new ApplicationServiceExecption("Severity already exist", HttpStatus.BAD_REQUEST);
	
		Severity severity = mapDtoToEntity.transformBO(severityDto, Severity.class);
		String seqName = dbUtil.getNextSequence(severity.getClass());
		if(seqName != null)
			severity.setId(seqName);
		
		severity.setInsertTime(new Date());
		severity.setUpdateTime(new Date());
		severity.setStatus(commonUtil.getActiveStatus());
		severity = severityDao.save(severity);
		syncDataService.syncCreation(severity);
		LOGGER.debug("SeverityServiceImpl -- add -- end");
		return mapEntityToDto.transformBO(severity, SeverityDto.class);
	}

	@Override
	public List<SeverityDto> findAllSeverity() throws Exception {
		LOGGER.debug("SeverityServiceImpl -- findAllActivityType -- start");
		List<Severity> severityList = severityDao.findAllSeverity();
		if(severityList.size() == 0)
			throw new ApplicationServiceExecption("Severity not found");
		
		LOGGER.debug("SeverityServiceImpl -- findAllActivityType -- end");
		return mapEntityToDto.transformListOfBO(severityList, SeverityDto.class);
	}

	@Override
	public List<SeverityDto> softDelete(List<String> ids) throws Exception {
		LOGGER.debug("SeverityServiceImpl -- softDelete -- start");
		commonUtil.stringNullValidator(ids.toArray(), "Severity Id");
		List<Severity> severityList = severityDao.findByIdInAndStatusNot(ids, commonUtil.getSoftDeleteStatus());
		if(severityList.size() < ids.size())
			throw new ApplicationServiceExecption("Severity not found");
		
		List<SeverityDto> severityDtoList = mapEntityToDto.transformListOfBO(severityList, SeverityDto.class);
		for (Severity severity : severityList) {
			severity.setStatus(commonUtil.getSoftDeleteStatus());
			severity.setUpdateTime(new Date());
		}
		severityList = severityDao.saveAll(severityList);
		Integer count = 0;
		for (Severity severity : severityList) {
			syncDataService.syncUpdate(mapDtoToEntity.transformBO(severityDtoList.get(count), Severity.class), severity);
			count++;
		}
		severityList = severityDao.findAllSeverity();
		LOGGER.debug("SeverityServiceImpl -- softDelete -- end");
		return mapEntityToDto.transformListOfBO(severityList, SeverityDto.class);
	}

	@Override
	public SeverityDto update(SeverityDto severityDto) throws Exception {
		LOGGER.debug("SeverityServiceImpl -- update -- start");
		commonUtil.stringNullValidator(severityDto.getItemNumber(), severityDto.getId(), "ItemNumber Name And Id");
		List<Severity> existingStaffList = severityDao.uniqueCheckForUpdate(severityDto.getItemNumber(), severityDto.getId(),severityDto.getTypeOfSeverity());
		if(!existingStaffList.isEmpty())
			throw new ApplicationServiceExecption("Staff already exist", HttpStatus.BAD_REQUEST);
		
		Severity severity = severityDao.findByIdAndStatusNot(severityDto.getId(), commonUtil.getSoftDeleteStatus());
		if(severity == null)
			throw new ApplicationServiceExecption("Severity not found", HttpStatus.BAD_REQUEST);
		
		SeverityDto existingSeverityDto = mapEntityToDto.transformBO(severity, SeverityDto.class);
		severity = mapDtoToEntity.transformBO(severityDto, Severity.class);
		severity.setUpdateTime(new Date());
		severity = severityDao.save(severity);
		syncDataService.syncUpdate(mapDtoToEntity.transformBO(existingSeverityDto, Severity.class), severity);
		LOGGER.debug("SeverityServiceImpl -- update -- end");
		return mapEntityToDto.transformBO(severity, SeverityDto.class);
	}

}
