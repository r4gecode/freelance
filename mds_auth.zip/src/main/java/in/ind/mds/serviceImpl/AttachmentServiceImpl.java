/**
 * 
 */
package in.ind.mds.serviceImpl;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import in.ind.mds.dto.AttachmentDto;
import in.ind.mds.repo.dao.AttachmentDao;
import in.ind.mds.repo.entity.Attachment;
import in.ind.mds.service.AttachmentService;
import in.ind.mds.service.SyncDataService;
import in.ind.mds.util.BeanTransformerUtil;
import in.ind.mds.util.CommonUtil;
import in.ind.mds.util.DBUtil;

/**
 * @author mds-arockia
 *
 */
@Service("TST_MSSQL_ATTACHEMENT")
public class AttachmentServiceImpl implements AttachmentService {

	private static final Logger LOGGER = LoggerFactory.getLogger(AttachmentServiceImpl.class);

	@Autowired
	private BeanTransformerUtil<Attachment, AttachmentDto> mapEntityToDto;

	@Autowired
	private BeanTransformerUtil<AttachmentDto, Attachment> mapDtoToEntity;

	@Autowired
	@Qualifier("TST_MSSQL_SYNC")
	private SyncDataService syncDataService;

	@Autowired
	private CommonUtil<AttachmentDto> commonUtil;

	@Autowired
	private AttachmentDao attachmentDao;

	@Autowired
	private DBUtil dbUtil;

	@Override
	public List<String> add(AttachmentDto attachmentDto, List<MultipartFile> attachmentFiles) throws Exception {
		LOGGER.debug("AttachmentServiceImpl -- add -- Start");
		List<String> attachmentPaths = new ArrayList<>();
		List<Attachment> attachmentList = new ArrayList<>();
		for (MultipartFile attachmentFile : attachmentFiles) {
			Attachment attachment = new Attachment();
			String seqName = dbUtil.getNextSequence(attachment.getClass());
			if (seqName != null)
				attachment.setId(seqName);

			byte[] bytes = attachmentFile.getBytes();
			Path path = Paths.get("/home/shalini/Pictures/"+ attachmentFile.getOriginalFilename());
			Files.write(path, bytes);
			attachmentPaths.add(path.toString());
			attachment.setRecordId(attachmentDto.getRecordId());
			attachment.setAttachmentOrigin(attachmentDto.getAttachmentOrigin());
			attachment.setAttachmentType(attachmentDto.getAttachmentType());
			attachment.setAttachmentPath(path.toString());
			attachment.setInsertTime(new Date());
			attachment.setUpdateTime(new Date());
			attachment.setStatus(commonUtil.getActiveStatus());
			attachmentList.add(attachment);
		}
		attachmentDao.saveAll(attachmentList);
		for (Attachment attachment : attachmentList) {
			syncDataService.syncCreation(attachment);
		}
		LOGGER.debug("StaffServiceImpl -- add -- End");
		return attachmentPaths;
	}

	@Override
	public List<String> findAttachments(AttachmentDto attachmentDto) throws Exception {
		LOGGER.debug("AttachmentServiceImpl -- findByStaff -- start");
		commonUtil.stringNullValidator(attachmentDto.getRecordId(), attachmentDto.getAttachmentOrigin(),
				attachmentDto.getAttachmentType(), "Attachment Origin, Type, RecordId");
		List<String> attachmentPath = new ArrayList<>();
		List<Attachment> attachmentList = attachmentDao.findByRecordIdAndAttachmentOriginAndAttachmentTypeAndStatusNot(
				attachmentDto.getRecordId(), attachmentDto.getAttachmentOrigin(), attachmentDto.getAttachmentType(),
				commonUtil.getSoftDeleteStatus());
		if (attachmentList.isEmpty())
			return attachmentPath;

		attachmentPath = attachmentList.stream().map(i -> i.getAttachmentPath()).collect(Collectors.toList());
		LOGGER.debug("AttachmentServiceImpl -- findByStaff -- end");
		return attachmentPath;
	}

	@Override
	public void softDelete(String recordId, String attachmentOrigin) throws Exception {
		LOGGER.debug("AttachmentServiceImpl -- softDeleteByRecordId -- start");
		commonUtil.stringNullValidator(recordId, attachmentOrigin, "AttachmentType and RecordId");
		List<Attachment> attachmentList = attachmentDao.findByRecordIdAndAttachmentOriginAndStatusNot(recordId,
				attachmentOrigin, commonUtil.getSoftDeleteStatus());
		if (!attachmentList.isEmpty()) {
			List<AttachmentDto> attachmentDtoList = mapEntityToDto.transformListOfBO(attachmentList,
					AttachmentDto.class);
			for (Attachment attachment : attachmentList) {
				attachment.setUpdateTime(new Date());
				attachment.setStatus(commonUtil.getSoftDeleteStatus());
			}
			attachmentDao.saveAll(attachmentList);
			Integer count = 0;
			for (Attachment attachment : attachmentList) {
				syncDataService.syncUpdate(mapDtoToEntity.transformBO(attachmentDtoList.get(count), Attachment.class),
						attachment);
				count++;
			}
		}
		LOGGER.debug("AttachmentServiceImpl -- softDeleteByRecordId -- end");
	}

	@Override
	public void softDeleteByPathList(List<String> attachmentPathList) throws Exception {
		LOGGER.debug("AttachmentServiceImpl -- softDeleteByPathList-- start");
		commonUtil.stringNullValidator(attachmentPathList.toArray(), "AttachmentPath");
		List<Attachment> attachmentList = attachmentDao.findByAttachmentPathInAndStatusNot(attachmentPathList, commonUtil.getSoftDeleteStatus());
		if (!attachmentList.isEmpty()) {
			List<AttachmentDto> attachmentDtoList = mapEntityToDto.transformListOfBO(attachmentList,
					AttachmentDto.class);
			for (Attachment attachment : attachmentList) {
				attachment.setUpdateTime(new Date());
				attachment.setStatus(commonUtil.getSoftDeleteStatus());
			}
			attachmentDao.saveAll(attachmentList);
			Integer count = 0;
			for (Attachment attachment : attachmentList) {
				syncDataService.syncUpdate(mapDtoToEntity.transformBO(attachmentDtoList.get(count), Attachment.class),
						attachment);
				count++;
			}
		}
		LOGGER.debug("AttachmentServiceImpl -- softDeleteByPathList -- end");
	}

}
