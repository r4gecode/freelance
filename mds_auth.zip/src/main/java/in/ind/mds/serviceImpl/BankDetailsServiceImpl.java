/**
 * 
 */
package in.ind.mds.serviceImpl;

import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import in.ind.mds.dto.BankDetailsDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.repo.dao.BankDetailsDao;
import in.ind.mds.repo.entity.BankDetails;
import in.ind.mds.service.BankDetailsService;
import in.ind.mds.service.SyncDataService;
import in.ind.mds.util.BeanTransformerUtil;
import in.ind.mds.util.CommonUtil;
import in.ind.mds.util.DBUtil;

/**
 * @author mds-arockia
 *
 */
@Service("TST_MSSQL_BANK_DETAILS")
public class BankDetailsServiceImpl implements BankDetailsService{

	private static final Logger LOGGER = LoggerFactory.getLogger(BankDetailsServiceImpl.class);

	@Autowired
	private BeanTransformerUtil<BankDetails, BankDetailsDto> mapEntityToDto;

	@Autowired
	private BeanTransformerUtil<BankDetailsDto, BankDetails> mapDtoToEntity;

	@Autowired
	@Qualifier("TST_MSSQL_SYNC")
	private SyncDataService syncDataService;
	
	@Autowired
	private BankDetailsDao bankDetailsDao;
	
	@Autowired
	private DBUtil dbUtil;
	
	@Autowired
	private CommonUtil<BankDetailsDto> commonUtil;

	@Override
	public BankDetailsDto add(BankDetailsDto bankDetailsDto) throws Exception{
		LOGGER.debug("BankDetailsServiceImpl -- add -- Start");
		commonUtil.stringNullValidator(bankDetailsDto.getBankName(), "Bank Name");
		BankDetails bankDetails = bankDetailsDao.findByBankNameAndStatusNot(bankDetailsDto.getBankName(), commonUtil.getSoftDeleteStatus());
		if(bankDetails != null)
			throw new ApplicationServiceExecption("BankDetails already exist", HttpStatus.BAD_REQUEST);
		
		bankDetails = mapDtoToEntity.transformBO(bankDetailsDto, BankDetails.class);
		String seqName = dbUtil.getNextSequence(bankDetails.getClass());
		if(seqName != null) 
			bankDetails.setId(seqName);
		
		bankDetails.setInsertTime(new Date());
		bankDetails.setUpdateTime(new Date());
		bankDetails.setStatus(commonUtil.getActiveStatus());
		bankDetailsDao.save(bankDetails);
		syncDataService.syncCreation(bankDetails);
		LOGGER.debug("BankDetailsServiceImpl -- add -- End");
		return mapEntityToDto.transformBO(bankDetails, BankDetailsDto.class);
	}

	@Override
	public BankDetailsDto findById(String bankDetailsId) throws Exception {
		LOGGER.debug("BankDetailsServiceImpl -- getByAddressId -- Start");
		commonUtil.stringNullValidator(bankDetailsId, "Bank Id");
		BankDetails bankDetails = bankDetailsDao.findByIdAndStatusNot(bankDetailsId, commonUtil.getSoftDeleteStatus()); 
		if (bankDetails == null) 
			throw new ApplicationServiceExecption("BankDetails not found", HttpStatus.NOT_FOUND);
		
		final BankDetailsDto dto = mapEntityToDto.transformBO(bankDetails, BankDetailsDto.class);
		LOGGER.debug("BankDetailsServiceImpl -- getByBankDetailsId -- End");
		return dto;
	}

	@Override
	public List<BankDetailsDto> findAll() throws Exception {
		LOGGER.debug("BankDetailsServiceImpl -- findAllBankDetails -- Start");
		List<BankDetails> bankDetails = bankDetailsDao.findAllBankDetails();

		if (bankDetails.size() == 0) 
			throw new ApplicationServiceExecption("BankDetails not found", HttpStatus.NOT_FOUND);
		
		final List<BankDetailsDto> dto = mapEntityToDto.transformListOfBO(bankDetails, BankDetailsDto.class);
		LOGGER.debug("BankDetailsServiceImpl -- findAllBankDetails -- End");
		return dto;
	}
	
	@Override
	public List<BankDetailsDto> softDeleteBankDetails(List<String> bankDetailsIds) throws Exception {
		LOGGER.debug("BankDetailsServiceImpl -- softDeleteBankDetails -- start");
		commonUtil.stringNullValidator(bankDetailsIds.toArray(), "Bank Id");
		List<BankDetails> existingBankDetails = bankDetailsDao.findByIdInAndStatusNot(bankDetailsIds, commonUtil.getSoftDeleteStatus());
		if (existingBankDetails.size() == 0) 
			throw new ApplicationServiceExecption("Bank Details not found", HttpStatus.BAD_REQUEST);
		
		List<BankDetailsDto> existingBankDetailsDto = mapEntityToDto.transformListOfBO(existingBankDetails, BankDetailsDto.class);
		for (BankDetails bankDetails : existingBankDetails) {
			bankDetails.setStatus(commonUtil.getSoftDeleteStatus());
			bankDetails.setUpdateTime(new Date());
		}
		existingBankDetails = bankDetailsDao.saveAll(existingBankDetails);
		Integer count = 0;
		for (BankDetails bankDetails : existingBankDetails) {
			BankDetailsDto bankDetailsDto = existingBankDetailsDto.get(count);
			syncDataService.syncUpdate(mapDtoToEntity.transformBO(bankDetailsDto, BankDetails.class), bankDetails);
			count++;
		}
		existingBankDetails = bankDetailsDao.findAllBankDetails();
		LOGGER.debug("AddressServiceImpl -- softDeleteBankDetails -- End");
		return mapEntityToDto.transformListOfBO(existingBankDetails, BankDetailsDto.class);
	}
	

	@Override
	public BankDetailsDto updateBankDetails(BankDetailsDto bankDetailsDto) throws Exception {
		LOGGER.debug("BankDetailsServiceImpl -- updateBankDetails -- Start");
		commonUtil.stringNullValidator(bankDetailsDto.getId(), bankDetailsDto.getBankName(), "Bank Id and Name");
		BankDetails existingBankDetails = bankDetailsDao.findByBankNameAndStatusNotAndIdNot(bankDetailsDto.getBankName(), commonUtil.getSoftDeleteStatus(), bankDetailsDto.getId());
		if(existingBankDetails != null)
			throw new ApplicationServiceExecption("BankDetails already exist", HttpStatus.BAD_REQUEST);
		
		existingBankDetails = bankDetailsDao.findByIdAndStatusNot(bankDetailsDto.getId(), commonUtil.getSoftDeleteStatus());
		if (existingBankDetails == null) 
			throw new ApplicationServiceExecption("BankDetails not found", HttpStatus.BAD_REQUEST);

		BankDetailsDto existingBankDetailsDto = mapEntityToDto.transformBO(existingBankDetails, BankDetailsDto.class);
		BankDetails bankDetails = mapDtoToEntity.transformBO(bankDetailsDto, BankDetails.class);
		bankDetails.setUpdateTime(new Date());
		bankDetailsDao.saveAndFlush(bankDetails);
		syncDataService.syncUpdate(mapDtoToEntity.transformBO(existingBankDetailsDto, BankDetails.class), bankDetails);
		LOGGER.debug("BankDetailsServiceImpl -- updateBankDetails -- End");
		return mapEntityToDto.transformBO(bankDetails, BankDetailsDto.class);
	}

}
