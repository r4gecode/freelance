/**
 * 
 */
package in.ind.mds.serviceImpl;

import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;


import in.ind.mds.dto.OperationTypeDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.repo.dao.OperationTypeDao;
import in.ind.mds.repo.entity.OperationType;
import in.ind.mds.service.OperationTypeService;
import in.ind.mds.service.SyncDataService;
import in.ind.mds.util.BeanTransformerUtil;
import in.ind.mds.util.CommonUtil;
import in.ind.mds.util.DBUtil;

/**
 * @author dharani
 *
 */

@Service("TST_MSSQL_OPERATION_TYPE")
public class OperationTypeServiceImpl implements OperationTypeService{
	
	private static final Logger LOGGER = LoggerFactory.getLogger(OperationTypeServiceImpl.class);

	@Autowired
	private BeanTransformerUtil<OperationType, OperationTypeDto> mapEntityToDto;

	@Autowired
	private BeanTransformerUtil<OperationTypeDto, OperationType> mapDtoToEntity;

	@Autowired
	@Qualifier("TST_MSSQL_SYNC")
	private SyncDataService syncDataService;
	
	@Autowired
	private CommonUtil<OperationTypeDto> commonUtil;
	
	@Autowired
	private DBUtil dbUtil;
	
	@Autowired
	private OperationTypeDao operationTypeDao;
	


	@Override
	public OperationTypeDto findById(String id) throws Exception {
		LOGGER.debug("OPerationTypeServiceImpl -- findById -- Start");

		commonUtil.stringNullValidator(id, "Id");

		final OperationType operationType = operationTypeDao.findByIdAndStatusNot(id,
				commonUtil.getSoftDeleteStatus());

		if (operationType == null)
			throw new ApplicationServiceExecption(" OPerationType not found", HttpStatus.NOT_FOUND);

		 
		final OperationTypeDto operationTypeDto = mapEntityToDto.transformBO(operationType, OperationTypeDto.class);

		LOGGER.debug("JobCategoryServiceImpl -- getByJobCtgyId -- End");
		return operationTypeDto;
	}

	@Override
	public OperationTypeDto add(OperationTypeDto operationTypeDto) throws Exception {
		LOGGER.debug("OperationTypeServiceImpl -- add -- Start");
	
		commonUtil.stringNullValidator(operationTypeDto.getOperationTypeName(), "OperationTypeName");
		OperationType operationType = operationTypeDao.findByOperationTypeNameAndStatusNot(operationTypeDto.getOperationTypeName(),
				commonUtil.getSoftDeleteStatus());
			
		if ( operationType !=null)
			throw new ApplicationServiceExecption("OperationType already exist", HttpStatus.BAD_REQUEST);

		operationType = mapDtoToEntity.transformBO(operationTypeDto, OperationType.class);
		String seqName = dbUtil.getNextSequence(operationType.getClass());
		if (seqName != null) {
			operationType.setId(seqName);
		}
		operationType.setInsertTime(new Date());
		operationType.setUpdateTime(new Date());
		operationType.setStatus(commonUtil.getActiveStatus());
		operationType = operationTypeDao.save(operationType);
		syncDataService.syncCreation(operationType);
		LOGGER.debug("OPerationTypeServiceImpl -- add -- End");
		return mapEntityToDto.transformBO(operationType, OperationTypeDto.class);
		
	}

	@Override
	public OperationTypeDto update(OperationTypeDto operationTypeDto) throws Exception {
		LOGGER.debug("OPerationTypeServiceImpl -- update -- Start");
		
		commonUtil.stringNullValidator(operationTypeDto.getId(), operationTypeDto.getOperationTypeName(),
				"OperationType Id and Name");
		OperationType existingoperationType = operationTypeDao.findByOperationTypeNameAndStatusNotAndIdNot(
				operationTypeDto.getOperationTypeName(), commonUtil.getSoftDeleteStatus(), operationTypeDto.getId());
		if (existingoperationType != null)
			throw new ApplicationServiceExecption("operationType already exist", HttpStatus.BAD_REQUEST);

		existingoperationType = operationTypeDao.findByIdAndStatusNot(operationTypeDto.getId(),
				commonUtil.getSoftDeleteStatus());
		if (existingoperationType == null)
			throw new ApplicationServiceExecption("OperationType not found", HttpStatus.BAD_REQUEST);

	OperationTypeDto existingOperationTypeDto = mapEntityToDto.transformBO(existingoperationType, OperationTypeDto.class);
		OperationType operationType = mapDtoToEntity.transformBO(operationTypeDto, OperationType.class);
		operationType.setUpdateTime(new Date());
		operationType = operationTypeDao.saveAndFlush(operationType);
		syncDataService.syncUpdate(mapDtoToEntity.transformBO(existingOperationTypeDto, OperationType.class), operationType);
		LOGGER.debug("OperationTYpeServiceImpl -- update -- End");
		return mapEntityToDto.transformBO(operationType, OperationTypeDto.class);
	}

	@Override
	public List<OperationTypeDto> softDelete(List<String> id) throws Exception {
		LOGGER.debug("OperationTypeServiceImpl -- softdelete -- Start");
		
		commonUtil.stringNullValidator(id.toArray(), "Id");
		List<OperationType> existingOPerationTypeList = operationTypeDao.findByIdInAndStatusNot(id,
				commonUtil.getSoftDeleteStatus());
		if (existingOPerationTypeList.size() < id.size())
			throw new ApplicationServiceExecption("OperationType not found", HttpStatus.BAD_REQUEST);

		List<OperationTypeDto> existingOperationTypeDtoList = mapEntityToDto.transformListOfBO(existingOPerationTypeList,
				OperationTypeDto.class);
		for (OperationType operationType : existingOPerationTypeList) {
			operationType.setStatus(commonUtil.getSoftDeleteStatus());
			operationType.setUpdateTime(new Date());
		}
		operationTypeDao.saveAll(existingOPerationTypeList);
		Integer count = 0;
		for (OperationType operationType : existingOPerationTypeList) {
			syncDataService.syncUpdate(mapDtoToEntity.transformBO(existingOperationTypeDtoList.get(count), OperationType.class), operationType);
			count++;
		}
		existingOPerationTypeList = operationTypeDao.findAll();
		LOGGER.debug("OperationTypeServiceImpl -- softdelete -- End");
		return mapEntityToDto.transformListOfBO(existingOPerationTypeList, OperationTypeDto.class);
	}

	@Override
	public List<OperationTypeDto> findAll() throws Exception {
		LOGGER.debug("OperationTYpeServiceImpl -- findAll -- Start");
		List<OperationType> operationType = operationTypeDao.findAll();

		if (operationType.size() == 0)
			throw new ApplicationServiceExecption("OperationType not found", HttpStatus.NOT_FOUND);

		final List<OperationTypeDto> operationTypeDto = mapEntityToDto.transformListOfBO(operationType,OperationTypeDto.class);
		LOGGER.debug("OperationTypeServiceImpl -- findByJobCategoryType -- End");
		return operationTypeDto;
	}

}
