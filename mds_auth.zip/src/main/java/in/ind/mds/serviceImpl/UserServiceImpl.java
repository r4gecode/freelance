package in.ind.mds.serviceImpl;

import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import in.ind.mds.dto.OwnerDto;
import in.ind.mds.dto.UserDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.repo.dao.UserDao;
import in.ind.mds.repo.entity.Owner;
import in.ind.mds.repo.entity.User;
import in.ind.mds.service.SyncDataService;
import in.ind.mds.service.UserService;
import in.ind.mds.util.BeanTransformerUtil;
import in.ind.mds.util.CommonUtil;
import in.ind.mds.util.DBUtil;

@Service("TST_MSSQL_USER")
public class UserServiceImpl implements UserService {

	private static final Logger LOGGER = LoggerFactory.getLogger(UserServiceImpl.class);

	@Autowired
	private BeanTransformerUtil<User, UserDto> mapEntityToDto;

	@Autowired
	private BeanTransformerUtil<UserDto, User> mapDtoToEntity;

	@Autowired
	@Qualifier("TST_MSSQL_SYNC")
	private SyncDataService syncDataService;
	/*
	 * @Autowired private UserValidator validator;
	 */
	 @Autowired
	 private CommonUtil<UserDto> commonUtil;

	@Autowired
	private UserDao userDao;

	@Autowired
	private DBUtil dbUtil;

	public UserDto getByUserNameAndPassword(String userName, String password) throws Exception {
		LOGGER.debug("UserServiceImpl -- getByEmailAndPassword -- Start");
		commonUtil.stringNullValidator(userName, password, "Email and Password");
		User user = userDao.findByUserNameAndPasswordAndStatusNot(userName, password, commonUtil.getSoftDeleteStatus());

		if (user == null) 
			throw new ApplicationServiceExecption("User not found", HttpStatus.NOT_FOUND);
		
		final UserDto dto = mapEntityToDto.transformBO(user, UserDto.class);
		LOGGER.debug("UserServiceImpl -- getByEmailAndPassword -- End");
		return dto;
	}

	/*
	 * public UserDto getById(String userId) throws Exception {
	 * LOGGER.debug("UserServiceImpl -- getById -- Start"); final User user =
	 * userDao.getById(userId);
	 * 
	 * if (user == null) { throw new
	 * ApplicationServiceExecption("Error user not found", HttpStatus.NOT_FOUND); }
	 * 
	 * Date date = user.getServerTime(); Date currentDate = new
	 * Date(System.currentTimeMillis());
	 * 
	 * if (date.before(currentDate) || date.after(currentDate)) {
	 * user.setServerTime(currentDate); userDao.save(user); }
	 * 
	 * final UserDto dto = mapEntityToDto.transformBO(user, UserDto.class);
	 * 
	 * LOGGER.debug("UserServiceImpl -- getById -- End"); return dto; }
	 */
	@Override
	public UserDto findByName(String userName) throws Exception {
		LOGGER.debug("UserServiceImpl -- getById -- Start");
		commonUtil.stringNullValidator(userName, "UserName");
		final User user = userDao.findByUserNameAndStatusNot(userName, commonUtil.getSoftDeleteStatus());

		if (user == null) 
			throw new ApplicationServiceExecption("Error user not found", HttpStatus.NOT_FOUND);
		
		/*
		 * Date date = user.getServerTime(); Date currentDate = new
		 * Date(System.currentTimeMillis());
		 * 
		 * if (date.before(currentDate) || date.after(currentDate)) {
		 * user.setServerTime(currentDate); userDao.save(user); }
		 */
		final UserDto dto = mapEntityToDto.transformBO(user, UserDto.class);

		LOGGER.debug("UserServiceImpl -- getById -- End");
		return dto;
	}

	@Override
	public UserDto saveUser(UserDto userDto) throws Exception {
		LOGGER.debug("UserServiceImpl -- add -- Start");
		// final String errorMessage = validator.validateAdd(userDto);
		// if (errorMessage != null) {
		// throw new GaurageServiceException(errorMessage, HttpStatus.BAD_REQUEST);
		// }
		/*
		 * Optional<User> existingUser = userDao.findById(userDto.getId()); if
		 * (existingUser.isPresent()) { throw new
		 * ApplicationServiceExecption("User exist", HttpStatus.BAD_REQUEST); }
		 */
		commonUtil.stringNullValidator(userDto.getUserName(), "UserName");
		User user = userDao.findByUserNameAndStatusNot(userDto.getUserName(), commonUtil.getSoftDeleteStatus());
		if(user != null)
			throw new ApplicationServiceExecption("User Already Exist", HttpStatus.BAD_REQUEST);
		
		 user = mapDtoToEntity.transformBO(userDto, User.class);
		
		String seqName = dbUtil.getNextSequence(user.getClass());
		if (seqName != null) 
			user.setId(seqName);

		user.setInsertTime(new Date());
		user.setUpdateTime(new Date());
		user.setStatus(commonUtil.getActiveStatus());
		user=userDao.save(user);
		syncDataService.syncCreation(user);
		LOGGER.debug("UserServiceImpl -- add -- End");
		return mapEntityToDto.transformBO(user, UserDto.class);
	}

	public List<UserDto> findAll() throws Exception {
		LOGGER.debug("UserServiceImpl -- findByUserType -- Start");
		List<User> user = userDao.findAllUser();

		if (user.size() == 0) 
			throw new ApplicationServiceExecption("User not found", HttpStatus.NOT_FOUND);
		
		final List<UserDto> dto = mapEntityToDto.transformListOfBO(user, UserDto.class);
		LOGGER.debug("UserServiceImpl -- findByUserType -- End");
		return dto;
	}

	@Override
	public List<UserDto> softDeleteUser(List<String> userIds) throws Exception {
		LOGGER.debug("UserServiceImpl -- delete -- Start");
		// final String errorMessage = validator.validateAdd(userDto);
		// if (errorMessage != null) {
		// throw new GaurageServiceException(errorMessage, HttpStatus.BAD_REQUEST);
		// }
		commonUtil.stringNullValidator(userIds, "UserId");
		List<User> existingUserList = userDao.findByIdInAndStatusNot(userIds, commonUtil.getSoftDeleteStatus());
		if (existingUserList.size() < userIds.size()) 
			throw new ApplicationServiceExecption("User not found", HttpStatus.BAD_REQUEST);
		
		List<UserDto> existingUserDtoList = mapEntityToDto.transformListOfBO(existingUserList, UserDto.class);
		
		for(User user : existingUserList)
		{
			user.setStatus(commonUtil.getSoftDeleteStatus());
			user.setUpdateTime(new Date());
		}
		existingUserList=userDao.saveAll(existingUserList);
		Integer count = 0;
		for(User user:existingUserList)
		{
			syncDataService.syncUpdate(mapDtoToEntity.transformBO(existingUserDtoList.get(count), User.class), user);
			count++;
		}
		List<User> userList = userDao.findAllUser();
		LOGGER.debug("PortServiceImpl -- delete -- End");
		return mapEntityToDto.transformListOfBO(userList, UserDto.class);
	}

	@Override
	public UserDto updateUser(UserDto userDto) throws Exception {

		LOGGER.debug("UserServiceImpl -- update -- Start"); // final String
		// errorMessage = validator.validateAdd(userDto); // if (errorMessage != null) {
		// throw new GaurageServiceException(errorMessage, HttpStatus.BAD_REQUEST);
		// }
		commonUtil.stringNullValidator(userDto.getId(), userDto.getUserName(), "User Id and Name");
		User existingUser = userDao.findByUserNameAndStatusNotAndIdNot(userDto.getUserName(), commonUtil.getSoftDeleteStatus(), userDto.getId());
		if(existingUser != null)
			throw new ApplicationServiceExecption("User Already Exist", HttpStatus.BAD_REQUEST);
		
		existingUser = userDao.findByIdAndStatusNot(userDto.getId(), commonUtil.getSoftDeleteStatus());
		if (existingUser == null) 
			throw new ApplicationServiceExecption("User not found", HttpStatus.BAD_REQUEST);
		
		UserDto existingUserDto = mapEntityToDto.transformBO(existingUser, UserDto.class);
		 User user = mapDtoToEntity.transformBO(userDto, User.class);
		 user.setUpdateTime(new Date());
		 user=userDao.saveAndFlush(user);
		syncDataService.syncUpdate(mapDtoToEntity.transformBO(existingUserDto, User.class), user);
		LOGGER.debug("UserServiceImpl -- update -- End");
		return mapEntityToDto.transformBO(user, UserDto.class);

	}
	
	public UserDto getActiveUserByUserNameAndPassword(String email, String password) throws Exception {
		LOGGER.debug("UserServiceImpl -- getByEmailAndPassword -- Start");
		commonUtil.stringNullValidator(email, password, "Email and Password");
		User user = userDao.findByUserNameAndPasswordAndStatus(email, password, commonUtil.getActiveStatus());

		if (user == null) 
			throw new ApplicationServiceExecption("User not found", HttpStatus.NOT_FOUND);
		
		final UserDto dto = mapEntityToDto.transformBO(user, UserDto.class);
		LOGGER.debug("UserServiceImpl -- getByEmailAndPassword -- End");
		return dto;
	}

}
