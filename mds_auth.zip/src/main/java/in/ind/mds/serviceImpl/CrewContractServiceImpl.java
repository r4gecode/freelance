/**
 * 
 */
package in.ind.mds.serviceImpl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import in.ind.mds.dto.AttachmentDto;
import in.ind.mds.dto.CrewContractDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.repo.dao.CrewContractDao;
import in.ind.mds.repo.entity.CrewContract;
import in.ind.mds.repo.entity.Staff;
import in.ind.mds.service.AttachmentService;
import in.ind.mds.service.CrewContractService;
import in.ind.mds.service.SyncDataService;
import in.ind.mds.util.BeanTransformerUtil;
import in.ind.mds.util.CommonUtil;
import in.ind.mds.util.DBUtil;

/**
 * @author mds-arockia
 *
 */
@Service("TST_MSSQL_CREW_CONTRACT")
public class CrewContractServiceImpl implements CrewContractService{

	private static final Logger LOGGER = LoggerFactory.getLogger(CrewContractServiceImpl.class);

	@Autowired
	private BeanTransformerUtil<CrewContract, CrewContractDto> mapEntityToDto;

	@Autowired
	private BeanTransformerUtil<CrewContractDto, CrewContract> mapDtoToEntity;

	@Autowired
	@Qualifier("TST_MSSQL_SYNC")
	private SyncDataService syncDataService;

	@Autowired
	private CommonUtil<CrewContractDto> commonUtil;

	@Autowired
	private CrewContractDao crewContractDao;

	@Autowired
	@Qualifier("TST_MSSQL_ATTACHEMENT")
	private AttachmentService attachmentService;

	@Autowired
	private DBUtil dbUtil;
	
	@Override
	public List<CrewContractDto> add(Staff staff, List<CrewContractDto> contractDtoList,
			MultipartFile[] attachmentFiles) throws Exception {
		LOGGER.debug("CrewContractServicImpl -- add -- start");
		contractDtoList = addContract(staff, contractDtoList, attachmentFiles);
		LOGGER.debug("CrewContractServicImpl -- add -- end");
		return contractDtoList;
	}

	@Override
	public List<CrewContractDto> update(Staff staff, List<CrewContractDto> contractDtoList,
			MultipartFile[] attachmentFiles) throws Exception {
		LOGGER.debug("CrewContractServicImpl -- update -- start");
		List<CrewContractDto> contractDtoListForAdd = new ArrayList<>();
		List<CrewContractDto> contractDtoListForUpdate = new ArrayList<>();
		for (CrewContractDto contractDto : contractDtoList) {
			if(contractDto.getId() == null)
				contractDtoListForAdd.add(contractDto);
			else
				contractDtoListForUpdate.add(contractDto);
		}
		if(!contractDtoListForAdd.isEmpty())
			contractDtoList = addContract(staff, contractDtoListForAdd, attachmentFiles);
		
		List<String> contractIds = contractDtoListForUpdate.stream().map(i -> i.getId()).collect(Collectors.toList());
		List<CrewContract> contractList = crewContractDao.findByIdInAndStatusNot(contractIds, commonUtil.getSoftDeleteStatus());
		if(contractList.size() < contractIds.size())
			throw new ApplicationServiceExecption("Contract not found");
		
		List<CrewContractDto> existingContractDtoList = mapEntityToDto.transformListOfBO(contractList, CrewContractDto.class);
		contractList = mapDtoToEntity.transformListOfBO(contractDtoListForUpdate, CrewContract.class);
		for (CrewContract contract : contractList) {
			contract.setUpdateTime(new Date());
		}
		/**********************delete and add attachments of CrewContract********start**********/
		List<CrewContractDto> returnContractDtoList = mapEntityToDto.transformListOfBO(contractList, CrewContractDto.class);
		Integer count = 0;
		for (CrewContractDto contractDto : contractDtoListForUpdate) {
			if(!contractDto.getSoftDeleteDocPaths().isEmpty())
				attachmentService.softDeleteByPathList(contractDto.getSoftDeleteDocPaths());
			
			List<MultipartFile> thisAttachmentFiles = new ArrayList<>();
				for (String contractDoc : contractDto.getContractDoc()) {
					Integer index = 0;
					//Integer removeAttachmentIndex = null;
					for (MultipartFile attachment : attachmentFiles) {
						if(contractDoc.equals(attachment.getOriginalFilename())) {
							thisAttachmentFiles.add(attachment); 
						//	removeAttachmentIndex = index;
						}
						index++;
					}
					//ArrayUtils.remove(attachmentFiles, removeAttachmentIndex);
				}
			AttachmentDto attachmentDto = new AttachmentDto();
			attachmentDto.setRecordId(contractList.get(count).getId());
			attachmentDto.setAttachmentOrigin(dbUtil.getTableName((mapDtoToEntity.transformBO(contractDto, CrewContract.class)).getClass()));
			attachmentDto.setAttachmentType(contractDto.getContractDocFieldName());
			List<String> contractDocPathList = attachmentService.add(attachmentDto, thisAttachmentFiles);
			returnContractDtoList.get(count).setContractDoc(contractDocPathList);
			count++;
		}
		/**********************delete and add attachments of CrewContract********end**********/
		crewContractDao.saveAll(contractList);
		count = 0;
		for (CrewContract contract : contractList) {
			syncDataService.syncUpdate(mapDtoToEntity.transformBO(existingContractDtoList.get(count), CrewContract.class), contract);
			count++;
		}
		contractDtoList.addAll(contractDtoListForUpdate);
		LOGGER.debug("CrewContractServicImpl -- update -- end");
		return contractDtoList;
	}

	@Override
	public List<CrewContractDto> findByStaff(Staff staff) throws Exception {
		LOGGER.debug("CrewContractServicImpl -- findByStaff -- start");
		List<CrewContractDto> contractDtoList = new ArrayList<>();
		List<CrewContract> contractList = crewContractDao.findByStaffAndStatusNot(staff, commonUtil.getSoftDeleteStatus());
		if(contractList.isEmpty())
			return contractDtoList;
		
		contractDtoList = mapEntityToDto.transformListOfBO(contractList, CrewContractDto.class);
		String attachmentOrigin = dbUtil.getTableName(contractList.get(0).getClass());
		for (CrewContractDto contractDto : contractDtoList) {
			AttachmentDto attachmentDto = new AttachmentDto();
			attachmentDto.setAttachmentOrigin(attachmentOrigin);
			attachmentDto.setRecordId(contractDto.getId());
			attachmentDto.setAttachmentType(contractDto.getContractDocFieldName());
			contractDto.setContractDoc(attachmentService.findAttachments(attachmentDto));
		}
		LOGGER.debug("CrewContractServicImpl -- findByStaff -- end");
		return contractDtoList;
	}

	@Override
	public void softDeleteByStaff(Staff staff) throws Exception {
		LOGGER.debug("CrewContractServicImpl -- softDelete -- start");
		List<CrewContract> contractList = crewContractDao.findByStaffAndStatusNot(staff, commonUtil.getSoftDeleteStatus());
		List<CrewContractDto> contractDtoList = mapEntityToDto.transformListOfBO(contractList, CrewContractDto.class);
		for (CrewContract contract : contractList) {
			contract.setUpdateTime(new Date());
			contract.setStatus(commonUtil.getSoftDeleteStatus());
		}
		Integer count = 0;
		for (CrewContract contract : contractList) {
			syncDataService.syncUpdate(mapDtoToEntity.transformBO(contractDtoList.get(count), CrewContract.class), contract);
			attachmentService.softDelete(contract.getId(), dbUtil.getTableName(contract.getClass()));
			count++;
		}
		LOGGER.debug("CrewContractServicImpl -- softDelete -- end");
	}

	@Override
	public void softDelete(List<String> ids) throws Exception {
		LOGGER.debug("CrewContractServicImpl -- softDelete -- start");
		commonUtil.stringNullValidator(ids.toArray(), "Contract Id");
		List<CrewContract> contractList = crewContractDao.findByIdInAndStatusNot(ids, commonUtil.getSoftDeleteStatus());
		if(contractList.size() <  ids.size())
			throw new ApplicationServiceExecption("Contract not found");
		
		List<CrewContractDto> contractDtoList = mapEntityToDto.transformListOfBO(contractList, CrewContractDto.class);
		for (CrewContract contract : contractList) {
			contract.setUpdateTime(new Date());
			contract.setStatus(commonUtil.getSoftDeleteStatus());
		}
		Integer count = 0;
		for (CrewContract contract : contractList) {
			syncDataService.syncUpdate(mapDtoToEntity.transformBO(contractDtoList.get(count), CrewContract.class), contract);
			attachmentService.softDelete(contract.getId(), dbUtil.getTableName(contract.getClass()));
			count++;
		}
		LOGGER.debug("CrewContractServicImpl -- softDelete -- end");
	}
	
	public List<CrewContractDto> addContract(Staff staff, List<CrewContractDto> contractDtoList, MultipartFile[] attachmentFiles) throws Exception{
		LOGGER.debug("CrewContractServicImpl -- addContractMethod -- start");
		List<CrewContract> contractList = mapDtoToEntity.transformListOfBO(contractDtoList, CrewContract.class);
		for (CrewContract contract : contractList) {
			String seqName = dbUtil.getNextSequence(contract.getClass());
			if(seqName != null)
				contract.setId(seqName);
			
			contract.setStaff(staff);
			contract.setStatus(commonUtil.getActiveStatus());
			contract.setInsertTime(new Date());
			contract.setUpdateTime(new Date());
		}
		crewContractDao.saveAll(contractList);
		for (CrewContract contract : contractList) {
			syncDataService.syncCreation(contract);
		}
		List<CrewContractDto> returnContractDtoList = mapEntityToDto.transformListOfBO(contractList, CrewContractDto.class);
		Integer count = 0;
		for (CrewContractDto contractDto : contractDtoList) {
			List<MultipartFile> thisAttachmentFiles = new ArrayList<>();
				for (String contractDoc : contractDto.getContractDoc()) {
					Integer index = 0;
					//Integer removeAttachmentIndex = null;
					for (MultipartFile attachment : attachmentFiles) {
						if(contractDoc.equals(attachment.getOriginalFilename())) {
							thisAttachmentFiles.add(attachment); 
						//	removeAttachmentIndex = index;
						}
						index++;
					}
					//ArrayUtils.remove(attachmentFiles, removeAttachmentIndex);
				}
			AttachmentDto attachmentDto = new AttachmentDto();
			attachmentDto.setRecordId(contractList.get(count).getId());
			attachmentDto.setAttachmentOrigin(dbUtil.getTableName((mapDtoToEntity.transformBO(contractDto, CrewContract.class)).getClass()));
			attachmentDto.setAttachmentType(contractDto.getContractDocFieldName());
			List<String> contractDocPathList = attachmentService.add(attachmentDto, thisAttachmentFiles);
			returnContractDtoList.get(count).setContractDoc(contractDocPathList);
			count++;
		}
		LOGGER.debug("CrewContractServicImpl -- addContractMethod -- end");
		return returnContractDtoList;
	}

}
