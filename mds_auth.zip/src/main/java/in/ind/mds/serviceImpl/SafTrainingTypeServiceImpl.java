/**
 * 
 */
package in.ind.mds.serviceImpl;

import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import in.ind.mds.dto.SafTrainingTypeDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.repo.dao.SafTrainingTypeDao;
import in.ind.mds.repo.entity.SafTrainingType;
import in.ind.mds.service.SafTrainingTypeService;
import in.ind.mds.service.SyncDataService;
import in.ind.mds.util.BeanTransformerUtil;
import in.ind.mds.util.CommonUtil;
import in.ind.mds.util.DBUtil;

/**
 * @author shalini
 *
 */
@Service("TST_MSSQL_SAF_TRAINING_TYPE")
public class SafTrainingTypeServiceImpl implements SafTrainingTypeService{

	private static final Logger LOGGER = LoggerFactory.getLogger(SafTrainingTypeServiceImpl.class);

	@Autowired
	private BeanTransformerUtil<SafTrainingType, SafTrainingTypeDto> mapEntityToDto;

	@Autowired
	private BeanTransformerUtil<SafTrainingTypeDto, SafTrainingType> mapDtoToEntity;

	@Autowired
	@Qualifier("TST_MSSQL_SYNC")
	private SyncDataService syncDataService;
	
	@Autowired
	private SafTrainingTypeDao safTrainingTypeDao;
	
	@Autowired
	private DBUtil dbUtil;

	
	@Autowired
	private CommonUtil<SafTrainingTypeDto> commonUtil;


	@Override
	public SafTrainingTypeDto add(SafTrainingTypeDto safTrainingTypeDto) throws Exception {
		LOGGER.debug("SafTrainingTypeServiceImpl -- add -- start");
		commonUtil.stringNullValidator(safTrainingTypeDto.getTrainingTypeName(), "TrainingTypeName");
		List<SafTrainingType> safTrainingTypeList = safTrainingTypeDao.findByTrainingTypeNameAndStatusNot(
				safTrainingTypeDto.getTrainingTypeName(), commonUtil.getSoftDeleteStatus());
		if (!safTrainingTypeList.isEmpty())
			throw new ApplicationServiceExecption("safTrainingType already exist", HttpStatus.BAD_REQUEST);

		SafTrainingType safTrainingType = mapDtoToEntity.transformBO(safTrainingTypeDto,
				SafTrainingType.class);
		String seqName = dbUtil.getNextSequence(safTrainingType.getClass());
		if (seqName != null)
			safTrainingType.setId(seqName);

		safTrainingType.setInsertTime(new Date());
		safTrainingType.setUpdateTime(new Date());
		safTrainingType.setStatus(commonUtil.getActiveStatus());

		safTrainingTypeDao.save(safTrainingType);
		syncDataService.syncCreation(safTrainingType);
		LOGGER.debug("SafTrainingTypeServiceImpl -- add -- end");
		return mapEntityToDto.transformBO(safTrainingType, SafTrainingTypeDto.class);
	}

	@Override
	public SafTrainingTypeDto update(SafTrainingTypeDto safTrainingTypeDto) throws Exception {
		LOGGER.debug("SafTrainingTypeServiceImpl -- update -- start");
		commonUtil.stringNullValidator(safTrainingTypeDto.getId(), safTrainingTypeDto.getTrainingTypeName(),
				"TrainingTypeName and Id");
		List<SafTrainingType> safTrainingTypeList = safTrainingTypeDao.findByTrainingTypeNameAndStatusNotAndIdNot(
				safTrainingTypeDto.getTrainingTypeName(), commonUtil.getSoftDeleteStatus(), safTrainingTypeDto.getId());
		if (!safTrainingTypeList.isEmpty())
			throw new ApplicationServiceExecption("safTrainingType already exist");

		SafTrainingType safTrainingType = safTrainingTypeDao.findByIdAndStatusNot(safTrainingTypeDto.getId(),
				commonUtil.getSoftDeleteStatus());
		if (safTrainingType == null)
			throw new ApplicationServiceExecption("safTrainingType not found");

		SafTrainingTypeDto existingSafTrainingTypeDto = mapEntityToDto.transformBO(safTrainingType,
				SafTrainingTypeDto.class);
		safTrainingType = mapDtoToEntity.transformBO(safTrainingTypeDto, SafTrainingType.class);
		safTrainingType.setUpdateTime(new Date());
		safTrainingTypeDao.save(safTrainingType);
		syncDataService.syncUpdate(mapDtoToEntity.transformBO(existingSafTrainingTypeDto, SafTrainingType.class),
				safTrainingType);
		LOGGER.debug("SafTrainingTypeServiceImpl -- update -- end");
		return mapEntityToDto.transformBO(safTrainingType, SafTrainingTypeDto.class);
	}


	@Override
	public SafTrainingTypeDto findById(String id) throws Exception {
		LOGGER.debug("SafTrainingTypeServiceImpl -- findById -- start");
		commonUtil.stringNullValidator(id, "SafTrainingType Id");
		SafTrainingType safTrainingType = safTrainingTypeDao.findByIdAndStatusNot(id,
				commonUtil.getSoftDeleteStatus());
		if (safTrainingType == null)
			throw new ApplicationServiceExecption("safTrainingType not found", HttpStatus.BAD_REQUEST);
		
		LOGGER.debug("SafTrainingTypeServiceImpl -- findById -- end");
		return mapEntityToDto.transformBO(safTrainingType, SafTrainingTypeDto.class);
	}

	@Override
	public List<SafTrainingTypeDto> findAll() throws Exception {
		LOGGER.debug("SafTrainingTypeServiceImpl -- findAll -- start");
		List<SafTrainingType> safTrainingTypeList = safTrainingTypeDao.findAllSafTrainingType();
		if (safTrainingTypeList.isEmpty())
			throw new ApplicationServiceExecption("SafTrainingType not found", HttpStatus.BAD_REQUEST);
		
		LOGGER.debug("SafTrainingTypeServiceImpl -- findAll -- end");
		return mapEntityToDto.transformListOfBO(safTrainingTypeList, SafTrainingTypeDto.class);
	}



	@Override
	public List<SafTrainingTypeDto> softDelete(List<String> ids) throws Exception {
		LOGGER.debug("SafTrainingTypeServiceImpl -- softDelete -- start");
		commonUtil.stringNullValidator(ids.toArray(), "SafTrainingType Id");
		List<SafTrainingType> safTrainingTypeList = safTrainingTypeDao.findByIdInAndStatusNot(ids,
				commonUtil.getSoftDeleteStatus());
		if (safTrainingTypeList.size() < ids.size())
			throw new ApplicationServiceExecption("SafTrainingType not found", HttpStatus.BAD_REQUEST);

		List<SafTrainingTypeDto> safTrainingTypeDtoList = mapEntityToDto.transformListOfBO(safTrainingTypeList, SafTrainingTypeDto.class);
		for (SafTrainingType safTrainingType : safTrainingTypeList) {
			safTrainingType.setUpdateTime(new Date());
			safTrainingType.setStatus(commonUtil.getSoftDeleteStatus());
		}
		safTrainingTypeDao.saveAll(safTrainingTypeList);
		Integer count = 0; 
		for (SafTrainingType safTrainingType : safTrainingTypeList) {
			syncDataService.syncUpdate(mapDtoToEntity.transformBO(safTrainingTypeDtoList.get(count), SafTrainingType.class), safTrainingType);
			count++;
		}
		safTrainingTypeList = safTrainingTypeDao.findAllSafTrainingType();
		LOGGER.debug("SafTrainingTypeServiceImpl -- softDelete -- end");
		return mapEntityToDto.transformListOfBO(safTrainingTypeList, SafTrainingTypeDto.class);
	}
}
