package in.ind.mds.serviceImpl;

import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import in.ind.mds.dto.VesselDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.repo.dao.VesselDao;
import in.ind.mds.repo.entity.Vessel;
import in.ind.mds.service.SyncDataService;
import in.ind.mds.service.VesselService;
import in.ind.mds.util.BeanTransformerUtil;
import in.ind.mds.util.CommonUtil;
import in.ind.mds.util.DBUtil;

@Service("TST_MSSQL_VESSEL")
public class VesselServiceImpl implements VesselService {

	private static final Logger LOGGER = LoggerFactory.getLogger(VesselServiceImpl.class);

	@Autowired
	private BeanTransformerUtil<Vessel, VesselDto> mapEntityToDto;

	@Autowired
	private BeanTransformerUtil<VesselDto, Vessel> mapDtoToEntity;
	
	@Autowired
	@Qualifier("TST_MSSQL_SYNC")
	private SyncDataService syncDataService;
	/*
	 * @Autowired private UserValidator validator;
	 */
	 @Autowired
	 private CommonUtil<VesselDto> commonUtil;
	
	@Autowired
	private VesselDao vesselDao;

	@Autowired
	private DBUtil dbUtil;
	
	@Autowired
	private SyncServiceImpl syncService;
	
	@Override
	public VesselDto getByVesselId(String vesselId) throws Exception {
		LOGGER.debug("VesselServiceImpl -- getVesselId -- Start");
		commonUtil.stringNullValidator(vesselId, "VesselId");
		Vessel vessel = vesselDao.findByIdAndStatusNot(vesselId, commonUtil.getSoftDeleteStatus());
		if (vessel == null) 
			throw new ApplicationServiceExecption("Vessel not found", HttpStatus.NOT_FOUND);
		
		final VesselDto dto = mapEntityToDto.transformBO(vessel, VesselDto.class);
		LOGGER.debug("VesselServiceImpl -- getByVesselId -- End");
		return dto;
	}

	@Override
	public VesselDto findByVesselName(String vesselName) throws Exception {
		LOGGER.debug("VesselServiceImpl -- findByVesselName -- Start");
		commonUtil.stringNullValidator(vesselName, "VesselName");
		Vessel vessel = vesselDao.findByVesselNameAndStatusNot(vesselName,commonUtil.getSoftDeleteStatus());

		if (vessel == null) 
			throw new ApplicationServiceExecption("Vessel not found", HttpStatus.NOT_FOUND);
		
		final VesselDto dto = mapEntityToDto.transformBO(vessel, VesselDto.class);
		LOGGER.debug("VesselServiceImpl -- findByVesselName -- End");
		return dto;
	}

	@Override
	public List<VesselDto> findAll() throws Exception {
		LOGGER.debug("VesselServiceImpl -- findByVesselName -- Start");

		List<Vessel> vessel = vesselDao.findAllVessel();

		if (vessel.size() == 0) 
			throw new ApplicationServiceExecption("Vessel not found", HttpStatus.NOT_FOUND);
		
		final List<VesselDto> listDto = mapEntityToDto.transformListOfBO(vessel, VesselDto.class);
		LOGGER.debug("VesselServiceImpl -- findByVesselName -- End");
		return listDto;
	}

	@Override
	public VesselDto add(VesselDto vesselDto) throws Exception {
		LOGGER.debug("VesselServiceImpl -- add -- Start");
		// final String errorMessage = validator.validateAdd(userDto);
		// if (errorMessage != null) {
		// throw new GaurageServiceException(errorMessage, HttpStatus.BAD_REQUEST);
		// }
		commonUtil.stringNullValidator(vesselDto.getImoNo(),vesselDto.getVesselCode(), vesselDto.getVesselName(), "ImoNo and VesselCode and VesselName");
		List <Vessel> existingVessels = vesselDao.uniqueCheckForAdd(vesselDto.getVesselCode(), vesselDto.getVesselName());
		if(!(existingVessels.isEmpty()))
			throw new ApplicationServiceExecption("Vessel already exist", HttpStatus.BAD_REQUEST);
		
		Vessel existingVessel = vesselDao.findByImoNoAndStatusNot(vesselDto.getImoNo(), commonUtil.getSoftDeleteStatus());
		if (existingVessel != null) 
			throw new ApplicationServiceExecption("Vessel exist", HttpStatus.BAD_REQUEST);
		
		Vessel vessel = mapDtoToEntity.transformBO(vesselDto, Vessel.class);
		String seqName = dbUtil.getNextSequence(vessel.getClass());
		if(seqName != null) 
			vessel.setId(seqName);
		
		vessel.setInsertTime(new Date());
		vessel.setUpdateTime(new Date());
		vessel.setStatus(commonUtil.getActiveStatus());
		vessel=vesselDao.save(vessel);
		syncDataService.syncCreation(vessel);
		syncService.syncCreation(vessel);
		LOGGER.debug("VesselServiceImpl -- add -- End");
		return mapEntityToDto.transformBO(vessel, VesselDto.class);
	}

	@Override
	public List<VesselDto>softDeleteVessel(List<String> vesselIds) throws Exception {
		LOGGER.debug("VesselServiceImpl -- delete -- Start");
		// final String errorMessage = validator.validateAdd(userDto);
		// if (errorMessage != null) {
		// throw new GaurageServiceException(errorMessage, HttpStatus.BAD_REQUEST);
		// }
		commonUtil.stringNullValidator(vesselIds, "VesselId");
		List<Vessel> existingVesselList = vesselDao.findByIdInAndStatusNot(vesselIds, commonUtil.getSoftDeleteStatus());
		if (existingVesselList.size() < vesselIds.size()) 
			throw new ApplicationServiceExecption("Vessel not found", HttpStatus.BAD_REQUEST);
		
		
		List<VesselDto> existingVesselDtoList = mapEntityToDto.transformListOfBO(existingVesselList, VesselDto.class);
		
		for(Vessel vessel : existingVesselList)
		{
			vessel.setStatus(commonUtil.getSoftDeleteStatus());
			vessel.setUpdateTime(new Date());
		}
		existingVesselList=vesselDao.saveAll(existingVesselList);
		Integer count=0;
		for(Vessel vessel : existingVesselList)
		{
			syncDataService.syncUpdate(mapDtoToEntity.transformBO(existingVesselDtoList.get(count), Vessel.class), vessel);
			count++;
		}
		
		
		List<Vessel> vesselList = vesselDao.findAllVessel();
		LOGGER.debug("VesselServiceImpl -- delete -- End");
		return mapEntityToDto.transformListOfBO(vesselList, VesselDto.class);
	}

	@Override
	public VesselDto updateVessel(VesselDto vesselDto) throws Exception {
		LOGGER.debug("VesselServiceImpl -- update -- Start");
		// final String errorMessage = validator.validateAdd(userDto);
		// if (errorMessage != null) {
		// throw new GaurageServiceException(errorMessage, HttpStatus.BAD_REQUEST);
		// }
		commonUtil.stringNullValidator(vesselDto.getVesselCode(), vesselDto.getVesselName(), vesselDto.getId(), "Vessel Id and Name and Code");
		List<Vessel> existVessel = vesselDao.uniqueCheckForUpdate(vesselDto.getVesselCode(), vesselDto.getVesselName(), vesselDto.getId());
		if(existVessel.size() != 0)
			throw new ApplicationServiceExecption("Vessel already exist", HttpStatus.BAD_REQUEST);
		
		Vessel vessel = vesselDao.findByIdAndStatusNot(vesselDto.getId(), commonUtil.getSoftDeleteStatus());
		if (vessel == null) 
			throw new ApplicationServiceExecption("Vessel not found", HttpStatus.BAD_REQUEST);
		
		VesselDto existingVessel = mapEntityToDto.transformBO(vessel, VesselDto.class);
		Vessel vesselEntity = mapDtoToEntity.transformBO(vesselDto, Vessel.class);
		vesselEntity.setUpdateTime(new Date());
		vesselEntity=vesselDao.saveAndFlush(vesselEntity);
		syncDataService.syncUpdate(mapDtoToEntity.transformBO(existingVessel, Vessel.class), vesselEntity);
		LOGGER.debug("VesselServiceImpl -- update -- End");
		return mapEntityToDto.transformBO(vesselEntity, VesselDto.class);
	}

}
