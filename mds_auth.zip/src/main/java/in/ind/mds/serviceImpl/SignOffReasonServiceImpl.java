package in.ind.mds.serviceImpl;

import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;


import in.ind.mds.dto.SignOffReasonDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.repo.dao.SignOffReasonDao;
import in.ind.mds.repo.entity.SignOffReason;
import in.ind.mds.service.SignOffReasonService;
import in.ind.mds.service.SyncDataService;
import in.ind.mds.util.BeanTransformerUtil;
import in.ind.mds.util.CommonUtil;
import in.ind.mds.util.DBUtil;

@Service("TST_MSSQL_CREW_SIGN_OFF_REASON")
public class SignOffReasonServiceImpl implements SignOffReasonService{

	private static final Logger LOGGER = LoggerFactory.getLogger(SignOffReasonServiceImpl.class);
	
	@Autowired
	private BeanTransformerUtil<SignOffReason, SignOffReasonDto> mapEntityToDto;
	
	@Autowired
	private BeanTransformerUtil<SignOffReasonDto, SignOffReason> mapDtoToEntity;
	
	@Autowired
	@Qualifier("TST_MSSQL_SYNC")
	private SyncDataService syncDataService;
	
	@Autowired
	private SignOffReasonDao signOffReasonDao;
	
	@Autowired
	private DBUtil dbUtil;
	
	@Autowired
	private CommonUtil<SignOffReasonDto> commonUtil;
	
	
	@Override
	public SignOffReasonDto add(SignOffReasonDto signOffReasonDto) throws Exception {
		// TODO Auto-generated method stub
		LOGGER.debug("SignOffReasonServiceImpl -- add -- start");
		commonUtil.stringNullValidator(signOffReasonDto.getSignOffReason(), "SignOffReason");
		SignOffReason signOffReason = signOffReasonDao.findBySignOffReasonAndStatusNot(signOffReasonDto.getSignOffReason(), commonUtil.getSoftDeleteStatus());
		if(signOffReason != null)
			throw new ApplicationServiceExecption("SignOffReason already exist", HttpStatus.BAD_REQUEST);
		
		signOffReason = mapDtoToEntity.transformBO(signOffReasonDto, SignOffReason.class);
		String seqName = dbUtil.getNextSequence(signOffReason.getClass());
		if(seqName != null)
			signOffReason.setId(seqName);
		
		signOffReason.setInsertedBy(0);
		signOffReason.setInsertTime(new Date());
		signOffReason.setUpdateBy(0);
		signOffReason.setUpdateTime(new Date());
		signOffReason.setStatus(commonUtil.getActiveStatus());
		signOffReason = signOffReasonDao.save(signOffReason);
		syncDataService.syncCreation(signOffReason);
		LOGGER.debug("SignOffReasonServiceImpl -- add -- end");
		return mapEntityToDto.transformBO(signOffReason, SignOffReasonDto.class);


	}

	@Override
	public List<SignOffReasonDto> findAllSignOffReason() throws Exception {
		// TODO Auto-generated method stub
		LOGGER.debug("SignOffReasonServiceImpl -- findAllSignOffReason -- start");
		List<SignOffReason> signOffReasonList = signOffReasonDao.findAllSignOffReason();
		if(signOffReasonList.size() == 0)
			throw new ApplicationServiceExecption("SignOffReason not found");
		
		LOGGER.debug("SignOffReasonServiceImpl -- findAllSignOffReason -- end");
		return mapEntityToDto.transformListOfBO(signOffReasonList, SignOffReasonDto.class);
	}

	@Override
	public List<SignOffReasonDto> softDelete(List<String> ids) throws Exception {
		// TODO Auto-generated method stub
		LOGGER.debug("SignOffReasonServiceImpl -- softDelete -- start");
		commonUtil.stringNullValidator(ids.toArray(), "ActivityType Id");
		List<SignOffReason> signOffReasonList = signOffReasonDao.findByIdInAndStatusNot(ids, commonUtil.getSoftDeleteStatus());
		if(signOffReasonList.size() < ids.size())
			throw new ApplicationServiceExecption("SignOffReason not found");
		
		List<SignOffReasonDto> signOffReasonDtoList = mapEntityToDto.transformListOfBO(signOffReasonList, SignOffReasonDto.class);
		for (SignOffReason signOffReason : signOffReasonList) {
			signOffReason.setStatus(commonUtil.getSoftDeleteStatus());
			signOffReason.setUpdateTime(new Date());
		}
		signOffReasonList = signOffReasonDao.saveAll(signOffReasonList);
		Integer count = 0;
		for (SignOffReason signOffReason : signOffReasonList) {
			syncDataService.syncUpdate(mapDtoToEntity.transformBO(signOffReasonDtoList.get(count), SignOffReason.class), signOffReason);
			count++;
		}
		signOffReasonList = signOffReasonDao.findAllSignOffReason();
		LOGGER.debug("SignOffReasonServiceImpl -- softDelete -- end");
		return mapEntityToDto.transformListOfBO(signOffReasonList, SignOffReasonDto.class);


	}

	@Override
	public SignOffReasonDto update(SignOffReasonDto signOffReasonDto) throws Exception {
		// TODO Auto-generated method stub
		
			LOGGER.debug("SignOffReasonServiceImpl -- update -- start");
			commonUtil.stringNullValidator(signOffReasonDto.getSignOffReason(), signOffReasonDto.getId(), "SignOffReason And Id");
			SignOffReason signOffReason = signOffReasonDao.findBySignOffReasonAndStatusNotAndIdNot(signOffReasonDto.getSignOffReason(), commonUtil.getSoftDeleteStatus(), signOffReasonDto.getId());
			if(signOffReason != null)
				throw new ApplicationServiceExecption("SignOffReason already exist", HttpStatus.BAD_REQUEST);
			
			signOffReason = signOffReasonDao.findByIdAndStatusNot(signOffReasonDto.getId(), commonUtil.getSoftDeleteStatus());
			if(signOffReason == null)
				throw new ApplicationServiceExecption("SignOffReason not found", HttpStatus.BAD_REQUEST);
			
			SignOffReasonDto existingSignOffReasonDto = mapEntityToDto.transformBO(signOffReason, SignOffReasonDto.class);
			signOffReason = mapDtoToEntity.transformBO(signOffReasonDto, SignOffReason.class);
			signOffReason.setUpdateBy(0);
			signOffReason.setUpdateTime(new Date());
			signOffReason = signOffReasonDao.save(signOffReason);
			syncDataService.syncUpdate(mapDtoToEntity.transformBO(existingSignOffReasonDto, SignOffReason.class), signOffReason);
			LOGGER.debug("SignOffReasonServiceImpl -- update -- end");
			return mapEntityToDto.transformBO(signOffReason, SignOffReasonDto.class);
		}

		

}
