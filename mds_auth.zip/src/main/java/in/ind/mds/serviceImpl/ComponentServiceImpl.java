package in.ind.mds.serviceImpl;

import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import in.ind.mds.dto.ComponentDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.repo.dao.ComponentDao;
import in.ind.mds.repo.dao.VesselDao;
import in.ind.mds.repo.entity.Component;
import in.ind.mds.repo.entity.Vessel;
import in.ind.mds.service.ComponentService;
import in.ind.mds.service.SyncDataService;
import in.ind.mds.util.BeanTransformerUtil;
import in.ind.mds.util.CommonUtil;
import in.ind.mds.util.DBUtil;

@Service("TST_MSSQL_COMPONENT")

public class ComponentServiceImpl implements ComponentService {
	private static final Logger LOGGER = LoggerFactory.getLogger(ComponentServiceImpl.class);

	@Autowired
	private BeanTransformerUtil<Component, ComponentDto> mapEntityToDto;

	@Autowired
	private BeanTransformerUtil<ComponentDto, Component> mapDtoToEntity;

	@Autowired
	@Qualifier("TST_MSSQL_SYNC")
	private SyncDataService syncDataService;
	/*
	 * @Autowired private UserValidator validator;
	 */
	@Autowired
	private CommonUtil<ComponentDto> commonUtil;

	@Autowired
	private VesselDao vesselDao;
	
	@Autowired
	private ComponentDao componentDao;

	@Autowired
	private DBUtil dbUtil;

	public ComponentDto findByComponentNameAndComponentType(final String componentName, final String componentType)
			throws Exception {
		LOGGER.debug("ComponentServiceImpl -- getByComponentNameAndComponentType -- Start");

		commonUtil.stringNullValidator(componentName, componentType, "ComponentName and ComponentType");
		Component component = componentDao.findByComponentNameAndComponentTypeAndStatusNot(componentName, componentType,
				commonUtil.getSoftDeleteStatus());

		if (component == null) {
			throw new ApplicationServiceExecption("Component not found", HttpStatus.NOT_FOUND);
		}
		final ComponentDto dto = mapEntityToDto.transformBO(component, ComponentDto.class);
		LOGGER.debug("ComponentServiceImpl -- getByComponentNameAndComponentType -- End");
		return dto;
	}

	public ComponentDto getByComponentId(final String componentId) throws Exception {
		LOGGER.debug("ComponentServiceImpl -- getByComponentId -- Start");

		commonUtil.stringNullValidator(componentId, "ComponentId");

		final Component component = componentDao.findByIdAndStatusNot(componentId, commonUtil.getSoftDeleteStatus());

		if (component == null)
			throw new ApplicationServiceExecption("Error component not found", HttpStatus.NOT_FOUND);

		/*
		 * Date date = user.getServerTime(); Date currentDate = new
		 * Date(System.currentTimeMillis());
		 * 
		 * if (date.before(currentDate) || date.after(currentDate)) {
		 * user.setServerTime(currentDate); userDao.save(user); }
		 */
		final ComponentDto dto = mapEntityToDto.transformBO(component, ComponentDto.class);

		LOGGER.debug("ComponentServiceImpl -- getByComponentId -- End");
		return dto;
	}

	@Override
	public ComponentDto findBySfiCode(final String sfiCode) throws Exception {
		LOGGER.debug("ComponentServiceImpl -- getBySfiCode -- Start");

		commonUtil.stringNullValidator(sfiCode, "SfiCode");
		final Component component = componentDao.findBySfiCodeAndStatusNot(sfiCode, commonUtil.getSoftDeleteStatus());

		if (component == null) {
			throw new ApplicationServiceExecption("Error component not found", HttpStatus.NOT_FOUND);
		}
		/*
		 * Date date = user.getServerTime(); Date currentDate = new
		 * Date(System.currentTimeMillis());
		 * 
		 * if (date.before(currentDate) || date.after(currentDate)) {
		 * user.setServerTime(currentDate); userDao.save(user); }
		 */
		final ComponentDto dto = mapEntityToDto.transformBO(component, ComponentDto.class);

		LOGGER.debug("ComponentServiceImpl -- getBySfiCode -- End");
		return dto;
	}

	public List<ComponentDto> findAll() throws Exception {
		LOGGER.debug("ComponentServiceImpl -- findByComponentType -- Start");
		List<Component> component = componentDao.findAllComponent();

		if (component.size() == 0) {
			throw new ApplicationServiceExecption("Component not found", HttpStatus.NOT_FOUND);
		}
		final List<ComponentDto> dto = mapEntityToDto.transformListOfBO(component, ComponentDto.class);
		LOGGER.debug("ComponentServiceImpl -- findByComponentType -- End");
		return dto;
	}

	@Override
	public ComponentDto add(ComponentDto componentDto) throws Exception {
		LOGGER.debug("ComponentServiceImpl -- add -- Start");
		// final String errorMessage = validator.validateAdd(userDto);
		// if (errorMessage != null) {
		// throw new GaurageServiceException(errorMessage, HttpStatus.BAD_REQUEST);
		// }
		/*
		 * Optional<Component> existingComponent =
		 * componentDao.findById(componentDto.getId()); if
		 * (existingComponent.isPresent()) { throw new
		 * ApplicationServiceExecption("Component exist", HttpStatus.BAD_REQUEST); }
		 */
		commonUtil.stringNullValidator(componentDto.getComponentName(), componentDto.getCode(),
				"Component Name and Code");
		List<Component> existingComponents;
		if (componentDto.getSfiCode() != null)
			existingComponents = componentDao.uniqueCheckForAdd(componentDto.getComponentName(), componentDto.getCode(),
					componentDto.getSfiCode());
		else
			existingComponents = componentDao.uniqueCheckForAdd(componentDto.getComponentName(), componentDto.getCode(),
					"temp");

		if (existingComponents.size() != 0)
			throw new ApplicationServiceExecption("Component already exist", HttpStatus.NOT_FOUND);

		Component component = mapDtoToEntity.transformBO(componentDto, Component.class);
		String seqName = dbUtil.getNextSequence(component.getClass());
		if (seqName != null) {
			component.setId(seqName);
		}
		component.setInsertTime(new Date());
		component.setUpdateTime(new Date());
		component.setStatus(commonUtil.getActiveStatus());
		  
		/*Date date=component.getcRStartDate();
		DateFormat dateFormat = new SimpleDateFormat("yyyy-mm-dd hh:mm:ss");
		String strDate = dateFormat.format(date);  
		Date d = dateFormat.parse(strDate);*/
		//component.setcRStartDate(cRStartDate);
		
		component = componentDao.save(component);
		syncDataService.syncCreation(component);
		LOGGER.debug("ComponentServiceImpl -- add -- End");
		return mapEntityToDto.transformBO(component, ComponentDto.class);
	}

	@Override
	public List<ComponentDto> softDeleteComponent(List<String> componentIds) throws Exception {
		LOGGER.debug("ComponentServiceImpl -- delete -- Start");
		// final String errorMessage = validator.validateAdd(userDto);
		// if (errorMessage != null) {
		// throw new GaurageServiceException(errorMessage, HttpStatus.BAD_REQUEST);
		// }
		commonUtil.stringNullValidator(componentIds.toArray(), "ComponentId");
		List<Component> existingComponentList = componentDao.findByIdInAndStatusNot(componentIds,
				commonUtil.getSoftDeleteStatus());
		if (existingComponentList.size() < componentIds.size())
			throw new ApplicationServiceExecption("Component not found", HttpStatus.BAD_REQUEST);

		List<ComponentDto> existingComponentDtoList = mapEntityToDto.transformListOfBO(existingComponentList,
				ComponentDto.class);
		for (Component component : existingComponentList) {
			component.setStatus(commonUtil.getSoftDeleteStatus());
			component.setUpdateTime(new Date());
		}
		componentDao.saveAll(existingComponentList);
		Integer count = 0;
		for (Component component : existingComponentList) {
			syncDataService.syncUpdate(mapDtoToEntity.transformBO(existingComponentDtoList.get(count), Component.class), component);
			count++;
		}
		existingComponentList = componentDao.findAllComponent();
		LOGGER.debug("ComponentServiceImpl -- softDelete -- End");
		return mapEntityToDto.transformListOfBO(existingComponentList, ComponentDto.class);
	}

	@Override 
	public ComponentDto updateComponent(ComponentDto componentDto) throws Exception {
		LOGGER.debug("ComponentServiceImpl -- update -- Start");
		// final String errorMessage = validator.validateAdd(userDto);
		// if (errorMessage != null) {
		// throw new GaurageServiceException(errorMessage, HttpStatus.BAD_REQUEST);
		// }
		commonUtil.stringNullValidator(componentDto.getComponentName(), componentDto.getCode(), componentDto.getId(),
				"Component Id, Name and Code");
		List<Component> existingComponents;
		if (componentDto.getSfiCode() != null)
			existingComponents = componentDao.uniqueCheckForUpdate(componentDto.getComponentName(), componentDto.getCode(),
					componentDto.getSfiCode(), componentDto.getId());
		else
			existingComponents = componentDao.uniqueCheckForUpdate(componentDto.getComponentName(), componentDto.getCode(),
					"temp", componentDto.getId());

		if (existingComponents.size() != 0)
			throw new ApplicationServiceExecption("Component already exist", HttpStatus.NOT_FOUND);

		Component component = componentDao.findByIdAndStatusNot(componentDto.getId(), commonUtil.getSoftDeleteStatus());
		if (component == null)
			throw new ApplicationServiceExecption("Component not found", HttpStatus.BAD_REQUEST);

		ComponentDto existingComponentDto = mapEntityToDto.transformBO(component, ComponentDto.class);
		component = mapDtoToEntity.transformBO(componentDto, Component.class);
		component.setUpdateTime(new Date());
		component = componentDao.saveAndFlush(component);
		syncDataService.syncUpdate(mapDtoToEntity.transformBO(existingComponentDto, Component.class), component);
		LOGGER.debug("ComponentServiceImpl -- update -- End");
		return mapEntityToDto.transformBO(component, ComponentDto.class);
	}

	@Override
	public List<ComponentDto> findByVessel(String vesselId) throws Exception {
		LOGGER.debug("ComponentServiceImpl -- findByVessel -- Start");
		commonUtil.stringNullValidator(vesselId, "Vessel Id");
		Vessel vessel = vesselDao.findByIdAndStatusNot(vesselId, commonUtil.getSoftDeleteStatus());
		if(vessel == null)
			throw new ApplicationServiceExecption("Vessel Not found", HttpStatus.BAD_REQUEST);
		
		List<Component> componentList = componentDao.findByVessel(vessel);
		if(componentList.isEmpty())
			throw new ApplicationServiceExecption("No component found for this vessel", HttpStatus.BAD_REQUEST);
		
		LOGGER.debug("ComponentServiceImpl -- findByVessel -- End");
		return mapEntityToDto.transformListOfBO(componentList, ComponentDto.class);
	}

	@Override
	public List<ComponentDto> findByOnlyRHBasis() throws Exception {
		LOGGER.debug("ComponentServiceImpl -- findByOnlyRHBasis -- Start");
		List<Component> componentList = componentDao.findByRHRequiredAndCRRequiredNot("Y", "Y");
		if(componentList.isEmpty())
			throw new ApplicationServiceExecption("No component found with (running hour basis and not counter basis)", HttpStatus.BAD_REQUEST);
		
		LOGGER.debug("ComponentServiceImpl -- findByOnlyRHBasis -- End");
		return mapEntityToDto.transformListOfBO(componentList, ComponentDto.class);
	}

	@Override
	public List<ComponentDto> findByCRBasis() throws Exception {
		LOGGER.debug("ComponentServiceImpl -- findByCRBasis -- Start");
		List<Component> componentList = componentDao.findByCRRequired("Y");
		if(componentList.isEmpty())
			throw new ApplicationServiceExecption("No component found with counter basis", HttpStatus.BAD_REQUEST);
		
		LOGGER.debug("ComponentServiceImpl -- findByCRBasis -- End");
		return mapEntityToDto.transformListOfBO(componentList, ComponentDto.class);
	}

	@Override
	public List<Component> saveAll(List<Component> componentList) throws Exception {
		LOGGER.debug("ComponentServiceImpl -- saveAll -- Start");
		List<Component> existingComponentList = componentDao.findByIdInAndStatusNot(componentList.stream().map(i -> i.getId()).collect(Collectors.toList()), commonUtil.getSoftDeleteStatus());
		componentDao.saveAll(componentList);
		Integer count = 0; 
		for (Component component : componentList) {
			syncDataService.syncUpdate(existingComponentList.get(count), component);
			count++;
		}
		LOGGER.debug("ComponentServiceImpl -- saveAll -- End");
		return null;
	}

}
