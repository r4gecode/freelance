package in.ind.mds.serviceImpl;

import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import in.ind.mds.dto.LocOnboardDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.repo.dao.LocOnboardDao;
import in.ind.mds.repo.entity.LocOnboard;
import in.ind.mds.service.LocOnboardService;
import in.ind.mds.service.SyncDataService;
import in.ind.mds.util.BeanTransformerUtil;
import in.ind.mds.util.CommonUtil;
import in.ind.mds.util.DBUtil;

@Service("TST_MSSQL_LOC_ONBOARD")

public class LocOnboardServiceImpl implements LocOnboardService {

	private static final Logger LOGGER = LoggerFactory.getLogger(LocOnboardServiceImpl.class);

	@Autowired
	private BeanTransformerUtil<LocOnboard, LocOnboardDto> mapEntityToDto;

	@Autowired
	private BeanTransformerUtil<LocOnboardDto, LocOnboard> mapDtoToEntity;

	@Autowired
	@Qualifier("TST_MSSQL_SYNC")
	private SyncDataService syncDataService;
	/*
	 * @Autowired private UserValidator validator;
	 */
	@Autowired
	private CommonUtil<LocOnboardDto> commonUtil;

	@Autowired
	private LocOnboardDao locOnboardDao;

	@Autowired
	private DBUtil dbUtil;

	public LocOnboardDto findByLocationIdAndLocationName(final String locationId, final String locationName)
			throws Exception {
		LOGGER.debug("LocOnboardServiceImpl -- getByLocationIdAndLocationName -- Start");
		commonUtil.stringNullValidator(locationId, locationName, "LocationId and LocationName");

		LocOnboard locOnboard = locOnboardDao.findByIdAndLocationNameAndStatusNot(locationId, locationName,
				commonUtil.getSoftDeleteStatus());

		if (locOnboard == null)
			throw new ApplicationServiceExecption("LocOnboard not found", HttpStatus.NOT_FOUND);

		final LocOnboardDto dto = mapEntityToDto.transformBO(locOnboard, LocOnboardDto.class);
		LOGGER.debug("LocOnboardServiceImpl -- getByLocationIdAndLocationName -- End");
		return dto;
	}

	public LocOnboardDto getByLocationId(final String locationId) throws Exception {
		LOGGER.debug("LocOnboardServiceImpl -- getByLocationId -- Start");
		commonUtil.stringNullValidator(locationId, "LocationId");

		final LocOnboard locOnboard = locOnboardDao.findByIdAndStatusNot(locationId, commonUtil.getSoftDeleteStatus());

		if (locOnboard == null)
			throw new ApplicationServiceExecption("Error locOnboard not found", HttpStatus.NOT_FOUND);

		/*
		 * Date date = user.getServerTime(); Date currentDate = new
		 * Date(System.currentTimeMillis());
		 * 
		 * if (date.before(currentDate) || date.after(currentDate)) {
		 * user.setServerTime(currentDate); userDao.save(user); }
		 */
		final LocOnboardDto dto = mapEntityToDto.transformBO(locOnboard, LocOnboardDto.class);

		LOGGER.debug("LocOnboardServiceImpl -- getByLocationId -- End");
		return dto;
	}

	@Override
	public LocOnboardDto findByLocationName(final String locationName) throws Exception {
		LOGGER.debug("LocOnboardServiceImpl -- getByLocationName -- Start");
		commonUtil.stringNullValidator(locationName, "LocationName");

		final LocOnboard locOnboard = locOnboardDao.findByLocationNameAndStatusNot(locationName,
				commonUtil.getSoftDeleteStatus());

		if (locOnboard == null)
			throw new ApplicationServiceExecption("Error locOnboard not found", HttpStatus.NOT_FOUND);

		/*
		 * Date date = user.getServerTime(); Date currentDate = new
		 * Date(System.currentTimeMillis());
		 * 
		 * if (date.before(currentDate) || date.after(currentDate)) {
		 * user.setServerTime(currentDate); userDao.save(user); }
		 */
		final LocOnboardDto dto = mapEntityToDto.transformBO(locOnboard, LocOnboardDto.class);

		LOGGER.debug("LocOnboardServiceImpl -- getByLocationName -- End");
		return dto;
	}

	@Override
	public List<LocOnboardDto> findAll() throws Exception {
		LOGGER.debug("LocOnboardServiceImpl -- findByLocOnboardType -- Start");
		List<LocOnboard> locOnboard = locOnboardDao.findAllLocOnboard();

		if (locOnboard.size() == 0)
			throw new ApplicationServiceExecption("LocOnboard not found", HttpStatus.NOT_FOUND);

		final List<LocOnboardDto> dto = mapEntityToDto.transformListOfBO(locOnboard, LocOnboardDto.class);
		LOGGER.debug("LocOnboardServiceImpl -- findByLocOnboardType -- End");
		return dto;
	}

	@Override
	public LocOnboardDto add(LocOnboardDto locOnboardDto) throws Exception {
		LOGGER.debug("LocOnboardServiceImpl -- add -- Start");
		// final String errorMessage = validator.validateAdd(userDto);
		// if (errorMessage != null) {
		// throw new GaurageServiceException(errorMessage, HttpStatus.BAD_REQUEST);
		// }
		/*
		 * Optional<LocOnboard> existingLocOnboard =
		 * locOnboardDao.findById(locOnboardDto.getId()); if
		 * (existingLocOnboard.isPresent()) { throw new
		 * ApplicationServiceExecption("LocOnboard exist", HttpStatus.BAD_REQUEST); }
		 */
		commonUtil.stringNullValidator(locOnboardDto.getLocationName(), "LocationName");
		LocOnboard locOnboard = locOnboardDao.findByLocationNameAndStatusNot(locOnboardDto.getLocationName(),
				commonUtil.getSoftDeleteStatus());
		if (locOnboard != null)
			throw new ApplicationServiceExecption("LocOnBoard already exist", HttpStatus.BAD_REQUEST);

		locOnboard = mapDtoToEntity.transformBO(locOnboardDto, LocOnboard.class);
		String seqName = dbUtil.getNextSequence(locOnboard.getClass());
		if (seqName != null)
			locOnboard.setId(seqName);

		locOnboard.setInsertTime(new Date());
		locOnboard.setUpdateTime(new Date());
		locOnboard.setStatus(commonUtil.getActiveStatus());
		locOnboard = locOnboardDao.save(locOnboard);
		syncDataService.syncCreation(locOnboard);
		LOGGER.debug("LocOnboardServiceImpl -- add -- End");
		return mapEntityToDto.transformBO(locOnboard, LocOnboardDto.class);
	}

	@Override
	public List<LocOnboardDto> softDeleteLocOnboard(List<String> locationIds) throws Exception {
		LOGGER.debug("LocOnboardServiceImpl -- delete -- Start");
		// final String errorMessage = validator.validateAdd(userDto);
		// if (errorMessage != null) {
		// throw new GaurageServiceException(errorMessage, HttpStatus.BAD_REQUEST);
		// }
		commonUtil.stringNullValidator(locationIds.toArray(), "LocationId");
		List<LocOnboard> existingLocOnboardList = locOnboardDao.findByIdInAndStatusNot(locationIds,
				commonUtil.getSoftDeleteStatus());
		if (existingLocOnboardList.size() < locationIds.size())
			throw new ApplicationServiceExecption("LocOnboard not found", HttpStatus.BAD_REQUEST);

		List<LocOnboardDto> existingLocOnboardDtoList = mapEntityToDto.transformListOfBO(existingLocOnboardList,
				LocOnboardDto.class);
		for (LocOnboard locOnboard : existingLocOnboardList) {
			locOnboard.setStatus(commonUtil.getSoftDeleteStatus());
			locOnboard.setUpdateTime(new Date());
		}
		locOnboardDao.saveAll(existingLocOnboardList);
		Integer count = 0;
		for (LocOnboard locOnboard : existingLocOnboardList) {
			syncDataService.syncUpdate(mapDtoToEntity.transformBO(existingLocOnboardDtoList.get(count), LocOnboard.class), locOnboard);
			count++;
		}
		existingLocOnboardList = locOnboardDao.findAllLocOnboard();
		LOGGER.debug("LocOnboardServiceImpl -- delete -- End");
		return mapEntityToDto.transformListOfBO(existingLocOnboardList, LocOnboardDto.class);
	}

	@Override
	public LocOnboardDto updateLocOnboard(LocOnboardDto locOnboardDto) throws Exception {
		LOGGER.debug("LocOnboardServiceImpl -- update -- Start");
		// final String errorMessage = validator.validateAdd(userDto);
		// if (errorMessage != null) {
		// throw new GaurageServiceException(errorMessage, HttpStatus.BAD_REQUEST);
		// }
		commonUtil.stringNullValidator(locOnboardDto.getLocationName(), locOnboardDto.getId(), "Location Id and Name");
		LocOnboard locOnboard = locOnboardDao.findByLocationNameAndStatusNotAndIdNot(locOnboardDto.getLocationName(),
				commonUtil.getSoftDeleteStatus(), locOnboardDto.getId());
		if (locOnboard != null)
			throw new ApplicationServiceExecption("LocOnBoard already exist", HttpStatus.BAD_REQUEST);

		locOnboard = locOnboardDao.findByIdAndStatusNot(locOnboardDto.getId(), commonUtil.getSoftDeleteStatus());
		if (locOnboard == null)
			throw new ApplicationServiceExecption("LocOnboard not found", HttpStatus.BAD_REQUEST);

		LocOnboardDto existingLocOnboardDto = mapEntityToDto.transformBO(locOnboard, LocOnboardDto.class);
		locOnboard = mapDtoToEntity.transformBO(locOnboardDto, LocOnboard.class);
		locOnboard.setUpdateTime(new Date());
		locOnboard = locOnboardDao.saveAndFlush(locOnboard);
		syncDataService.syncUpdate(mapDtoToEntity.transformBO(existingLocOnboardDto, LocOnboard.class), locOnboard);
		LOGGER.debug("LocOnboardServiceImpl -- update -- End");
		return mapEntityToDto.transformBO(locOnboard, LocOnboardDto.class);
	}

}
