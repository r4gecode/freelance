/**
 * 
 */
package in.ind.mds.serviceImpl;

import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import in.ind.mds.dto.ActivityTypeDto;
import in.ind.mds.dto.SafMeetingAgendaDto;

import in.ind.mds.exception.ApplicationServiceExecption;

import in.ind.mds.repo.dao.SafMeetingAgendaDao;

import in.ind.mds.repo.entity.SafMeetingAgenda;

import in.ind.mds.service.SafMeetingAgendaService;
import in.ind.mds.service.SyncDataService;
import in.ind.mds.util.BeanTransformerUtil;
import in.ind.mds.util.CommonUtil;
import in.ind.mds.util.DBUtil;

/**
 * @author Hinaya
 *
 */
@Service("TST_MSSQL_SAF_MEETING_AGENDA")
public class SafMeetingAgendaServiceImpl implements SafMeetingAgendaService{
	
	private static final Logger LOGGER = LoggerFactory.getLogger(SafMeetingAgendaServiceImpl.class);
	
	@Autowired
	private BeanTransformerUtil<SafMeetingAgenda, SafMeetingAgendaDto> mapEntityToDto;

	@Autowired
	private BeanTransformerUtil<SafMeetingAgendaDto, SafMeetingAgenda> mapDtoToEntity;

	@Autowired
	@Qualifier("TST_MSSQL_SYNC")
	private SyncDataService syncDataService;
	
	@Autowired
	private SafMeetingAgendaDao safMeetingAgendaDao;
	
	@Autowired
	private DBUtil dbUtil;
	
	@Autowired
	private CommonUtil<ActivityTypeDto> commonUtil;

	@Override
	public SafMeetingAgendaDto getById(String id) throws Exception {
		LOGGER.debug("SafMeetingAgendaServiceImpl -- getById -- Start");
		commonUtil.stringNullValidator(id, "Id");
		SafMeetingAgenda safMeetingAgenda = safMeetingAgendaDao.findByIdAndStatusNot(id, commonUtil.getSoftDeleteStatus());
		if (safMeetingAgenda == null) 
			throw new ApplicationServiceExecption("safMeetingAgenda not found", HttpStatus.NOT_FOUND);
		
		final SafMeetingAgendaDto dto = mapEntityToDto.transformBO(safMeetingAgenda, SafMeetingAgendaDto.class);
		LOGGER.debug("SafMeetingAgendaServiceImpl -- getById -- End");
		return dto;
	}

	@Override
	public List<SafMeetingAgendaDto> findAll() throws Exception {
		// TODO Auto-generated method stub
		LOGGER.debug("SafMeetingAgendaServiceImpl -- findAllSafMeetingAgenda -- start");
		List<SafMeetingAgenda> safMeetingAgendaList = safMeetingAgendaDao.findAllSafMeetingAgenda();
		if(safMeetingAgendaList.size() == 0)
			throw new ApplicationServiceExecption("SafMeetingAgenda not found");
		
		LOGGER.debug("SafMeetingAgendaServiceImpl -- findAllSafMeetingAgenda -- end");
		return mapEntityToDto.transformListOfBO(safMeetingAgendaList, SafMeetingAgendaDto.class);
	}

	@Override
	public SafMeetingAgendaDto add(SafMeetingAgendaDto safMeetingAgendaDto) throws Exception {
		// TODO Auto-generated method stub
		LOGGER.debug("SafMeetingAgendaServiceImpl -- add -- start");
		commonUtil.stringNullValidator(safMeetingAgendaDto.getAgendaName(), "ActivityType Name");
		SafMeetingAgenda safMeetingAgenda = safMeetingAgendaDao.findByAgendaNameAndStatusNot(safMeetingAgendaDto.getAgendaName(), commonUtil.getSoftDeleteStatus());
		if(safMeetingAgenda != null)
			throw new ApplicationServiceExecption("Activity Name already exist", HttpStatus.BAD_REQUEST);
		
		safMeetingAgenda = mapDtoToEntity.transformBO(safMeetingAgendaDto, SafMeetingAgenda.class);
		String seqName = dbUtil.getNextSequence(safMeetingAgenda.getClass());
		if(seqName != null)
			safMeetingAgenda.setId(seqName);
		
		
		safMeetingAgenda.setInsertTime(new Date());
		safMeetingAgenda.setUpdateTime(new Date());
		safMeetingAgenda.setStatus(commonUtil.getActiveStatus());
		safMeetingAgenda = safMeetingAgendaDao.save(safMeetingAgenda);
		syncDataService.syncCreation(safMeetingAgenda);
		LOGGER.debug("SafMeetingAgendaServiceImpl -- add -- end");
		return mapEntityToDto.transformBO(safMeetingAgenda, SafMeetingAgendaDto.class);
		
	}

	@Override
	public List<SafMeetingAgendaDto> softDelete(List<String> ids) throws Exception {
		// TODO Auto-generated method stub
		LOGGER.debug("SafMeetingAgendaServiceImpl -- softDelete -- start");
		commonUtil.stringNullValidator(ids.toArray(), "SafMeetingAgenda Id");
		List<SafMeetingAgenda> safMeetingAgendaList = safMeetingAgendaDao.findByIdInAndStatusNot(ids, commonUtil.getSoftDeleteStatus());
		if(safMeetingAgendaList.size() < ids.size())
			throw new ApplicationServiceExecption("SafMeetingAgenda not found");
		
		List<SafMeetingAgendaDto> safMeetingAgendaDtoList = mapEntityToDto.transformListOfBO(safMeetingAgendaList, SafMeetingAgendaDto.class);
		for (SafMeetingAgenda safMeetingAgenda : safMeetingAgendaList) {
			safMeetingAgenda.setStatus(commonUtil.getSoftDeleteStatus());
			safMeetingAgenda.setUpdateTime(new Date());
		}
		safMeetingAgendaList = safMeetingAgendaDao.saveAll(safMeetingAgendaList);
		Integer count = 0;
		for (SafMeetingAgenda safMeetingAgenda : safMeetingAgendaList) {
			syncDataService.syncUpdate(mapDtoToEntity.transformBO(safMeetingAgendaDtoList.get(count), SafMeetingAgenda.class), safMeetingAgenda);
			count++;
		}
		safMeetingAgendaList = safMeetingAgendaDao.findAllSafMeetingAgenda();
		LOGGER.debug("SafMeetingAgendaServiceImpl -- softDelete -- end");
		return mapEntityToDto.transformListOfBO(safMeetingAgendaList, SafMeetingAgendaDto.class);
	}

	@Override
	public SafMeetingAgendaDto update(SafMeetingAgendaDto safMeetingAgendaDto) throws Exception {
		// TODO Auto-generated method stub
		LOGGER.debug("SafMeetingAgendaServiceImpl -- update -- start");
		commonUtil.stringNullValidator(safMeetingAgendaDto.getAgendaName(), safMeetingAgendaDto.getId(), "ActivityType Name And Id");
		SafMeetingAgenda safMeetingAgenda = safMeetingAgendaDao.findByAgendaNameAndStatusNotAndIdNot(safMeetingAgendaDto.getAgendaName(), commonUtil.getSoftDeleteStatus(), safMeetingAgendaDto.getId());
		if(safMeetingAgenda != null)
			throw new ApplicationServiceExecption("Activity Name already exist", HttpStatus.BAD_REQUEST);
		
		safMeetingAgenda = safMeetingAgendaDao.findByIdAndStatusNot(safMeetingAgendaDto.getId(), commonUtil.getSoftDeleteStatus());
		if(safMeetingAgenda == null)
			throw new ApplicationServiceExecption("Activity Type not found", HttpStatus.BAD_REQUEST);
		
		SafMeetingAgendaDto existingsafMeetingAgendaDto = mapEntityToDto.transformBO(safMeetingAgenda, SafMeetingAgendaDto.class);
		safMeetingAgenda = mapDtoToEntity.transformBO(safMeetingAgendaDto, SafMeetingAgenda.class);
		safMeetingAgenda.setUpdateTime(new Date());
		safMeetingAgenda = safMeetingAgendaDao.save(safMeetingAgenda);
		syncDataService.syncUpdate(mapDtoToEntity.transformBO(existingsafMeetingAgendaDto, SafMeetingAgenda.class), safMeetingAgenda);
		LOGGER.debug("SafMeetingAgendaServiceImpl -- update -- end");
		return mapEntityToDto.transformBO(safMeetingAgenda, SafMeetingAgendaDto.class);
		
	}

}
