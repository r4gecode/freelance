/**
 * 
 */
package in.ind.mds.serviceImpl;

import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import in.ind.mds.dto.DepartmentDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.repo.dao.DepartmentDao;
import in.ind.mds.repo.entity.Department;
import in.ind.mds.service.DepartmentService;
import in.ind.mds.service.SyncDataService;
import in.ind.mds.util.BeanTransformerUtil;
import in.ind.mds.util.CommonUtil;
import in.ind.mds.util.DBUtil;

/**
 * @author mds-arockia
 *
 */
@Service("TST_MSSQL_DEPARTMENT")
public class DepartmentServiceImpl implements DepartmentService {

	private static final Logger LOGGER = LoggerFactory.getLogger(DepartmentServiceImpl.class);

	@Autowired
	private BeanTransformerUtil<Department, DepartmentDto> mapEntityToDto;

	@Autowired
	private BeanTransformerUtil<DepartmentDto, Department> mapDtoToEntity;

	@Autowired
	@Qualifier("TST_MSSQL_SYNC")
	private SyncDataService syncDataService;

	@Autowired
	private DepartmentDao departmentDao;

	@Autowired
	private DBUtil dbUtil;

	@Autowired
	private CommonUtil<DepartmentDto> commonUtil;

	@Override
	public DepartmentDto findByDepartmentId(String departmentId) throws Exception {
		LOGGER.debug("DepartmentServiceImpl -- findByDepartmentId -- Start");
		commonUtil.stringNullValidator(departmentId, "DepartmentId");
		Department existingDepartment = departmentDao.findByIdAndStatusNot(departmentId,
				commonUtil.getSoftDeleteStatus());
		if (existingDepartment == null)
			throw new ApplicationServiceExecption("Department not found", HttpStatus.NOT_FOUND);

		final DepartmentDto dto = mapEntityToDto.transformBO(existingDepartment, DepartmentDto.class);
		LOGGER.debug("DepartmentServiceImpl -- findByDepartmentId -- End");
		return dto;
	}

	@Override
	public List<DepartmentDto> findAll() throws Exception {
		LOGGER.debug("DepartmentServiceImpl -- findAll -- Start");
		List<Department> department = departmentDao.findAllDepartment();
		if (department.size() == 0) {
			throw new ApplicationServiceExecption("Department not found", HttpStatus.NOT_FOUND);
		}
		final List<DepartmentDto> dto = mapEntityToDto.transformListOfBO(department, DepartmentDto.class);
		LOGGER.debug("DepartmentServiceImpl -- findAll -- End");
		return dto;
	}

	@Override
	public DepartmentDto add(DepartmentDto departmentDto) throws Exception {
		LOGGER.debug("AddressServiceImpl -- add -- Start");
		commonUtil.stringNullValidator(departmentDto.getDepartmentName(), "DepartmentName");
		Department department = departmentDao.findByDepartmentNameAndStatusNot(departmentDto.getDepartmentName(),
				commonUtil.getSoftDeleteStatus());
		if (department != null)
			throw new ApplicationServiceExecption("Department Already Exist", HttpStatus.BAD_REQUEST);

		department = mapDtoToEntity.transformBO(departmentDto, Department.class);
		String seqName = dbUtil.getNextSequence(department.getClass());
		if (seqName != null) {
			department.setId(seqName);
		}
		department.setInsertTime(new Date());
		department.setUpdateTime(new Date());
		department.setStatus(commonUtil.getActiveStatus());
		department = departmentDao.save(department);
		syncDataService.syncCreation(department);
		LOGGER.debug("DepartmentServiceImpl -- add -- End");
		return mapEntityToDto.transformBO(department, DepartmentDto.class);
	}

	@Override
	public List<DepartmentDto> softDeleteDepartment(List<String> departmentIds) throws Exception {
		LOGGER.debug("DepartmentServiceImpl -- softDelete -- Start");
		commonUtil.stringNullValidator(departmentIds.toArray(), "DepartmentId");
		List<Department> existingDepartmentList = departmentDao.findByIdInAndStatusNot(departmentIds,
				commonUtil.getSoftDeleteStatus());
		if (existingDepartmentList.size() < departmentIds.size())
			throw new ApplicationServiceExecption("Department not found", HttpStatus.BAD_REQUEST);

		List<DepartmentDto> existingDepartmentDtoList = mapEntityToDto.transformListOfBO(existingDepartmentList,
				DepartmentDto.class);
		for (Department department : existingDepartmentList) {
			department.setStatus(commonUtil.getSoftDeleteStatus());
			department.setUpdateTime(new Date());
		}
		departmentDao.saveAll(existingDepartmentList);
		Integer count = 0;
		for (Department department : existingDepartmentList) {
			syncDataService.syncUpdate(mapDtoToEntity.transformBO(existingDepartmentDtoList.get(count), Department.class), department);
			count++;
		}
		existingDepartmentList = departmentDao.findAllDepartment(); 
		LOGGER.debug("DepartmentServiceImpl -- softDelete -- End");
		return mapEntityToDto.transformListOfBO(existingDepartmentList, DepartmentDto.class);
	}

	@Override
	public DepartmentDto updateDepartment(DepartmentDto departmentDto) throws Exception {
		LOGGER.debug("DepartmentServiceImpl -- update -- Start");
		commonUtil.stringNullValidator(departmentDto.getDepartmentName(), departmentDto.getId(),
				"Department Id and Name");
		Department existingDepartment = departmentDao.findByDepartmentNameAndStatusNotAndIdNot(
				departmentDto.getDepartmentName(), commonUtil.getSoftDeleteStatus(), departmentDto.getId());
		if (existingDepartment != null)
			throw new ApplicationServiceExecption("Department Already Exist", HttpStatus.BAD_REQUEST);

		existingDepartment = departmentDao.findByIdAndStatusNot(departmentDto.getId(),
				commonUtil.getSoftDeleteStatus());
		if (existingDepartment == null)
			throw new ApplicationServiceExecption("Deparment not found", HttpStatus.BAD_REQUEST);

		DepartmentDto existingDepartmentDto = mapEntityToDto.transformBO(existingDepartment, DepartmentDto.class);
		Department department = mapDtoToEntity.transformBO(departmentDto, Department.class);
		department.setUpdateTime(new Date());
		department = departmentDao.saveAndFlush(department);
		syncDataService.syncUpdate(mapDtoToEntity.transformBO(existingDepartmentDto, Department.class), department);
		LOGGER.debug("DepartmentServiceImpl -- update -- End");
		return departmentDto;
	}

}
