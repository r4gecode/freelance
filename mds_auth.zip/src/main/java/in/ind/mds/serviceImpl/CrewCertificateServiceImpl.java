/**
 * 
 */
package in.ind.mds.serviceImpl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import in.ind.mds.dto.AttachmentDto;
import in.ind.mds.dto.CrewCertificateDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.repo.dao.CrewCertificateDao;
import in.ind.mds.repo.entity.CrewCertificate;
import in.ind.mds.repo.entity.Staff;
import in.ind.mds.service.AttachmentService;
import in.ind.mds.service.CrewCertificateService;
import in.ind.mds.service.SyncDataService;
import in.ind.mds.util.BeanTransformerUtil;
import in.ind.mds.util.CommonUtil;
import in.ind.mds.util.DBUtil;

/**
 * @author mds-arockia
 *
 */
@Service("TST_MSSQL_CREW_CERTIFICATE")
public class CrewCertificateServiceImpl implements CrewCertificateService{

	private static final Logger LOGGER = LoggerFactory.getLogger(CrewCertificateServiceImpl.class);

	@Autowired
	private BeanTransformerUtil<CrewCertificate, CrewCertificateDto> mapEntityToDto;

	@Autowired
	private BeanTransformerUtil<CrewCertificateDto, CrewCertificate> mapDtoToEntity;

	@Autowired
	@Qualifier("TST_MSSQL_SYNC")
	private SyncDataService syncDataService;

	@Autowired
	private CommonUtil<CrewCertificateDto> commonUtil;

	@Autowired
	private CrewCertificateDao crewCertificateDao;

	@Autowired
	@Qualifier("TST_MSSQL_ATTACHEMENT")
	private AttachmentService attachmentService;

	@Autowired
	private DBUtil dbUtil;
	
	@Override
	public List<CrewCertificateDto> add(Staff staff, List<CrewCertificateDto> certificateDtoList,
			MultipartFile[] attachmentFiles) throws Exception {
		LOGGER.debug("CrewCertificateServicImpl -- add -- start");
		certificateDtoList = addCertificate(staff, certificateDtoList, attachmentFiles);
		LOGGER.debug("CrewCertificateServicImpl -- add -- end");
		return certificateDtoList;
	}

	@Override
	public List<CrewCertificateDto> update(Staff staff, List<CrewCertificateDto> certificateDtoList,
			MultipartFile[] attachmentFiles) throws Exception {
		LOGGER.debug("CrewCertificateServicImpl -- update -- start");
		List<CrewCertificateDto> certificateDtoListForAdd = new ArrayList<>();
		List<CrewCertificateDto> certificateDtoListForUpdate = new ArrayList<>();
		for (CrewCertificateDto certificateDto : certificateDtoList) {
			if(certificateDto.getId() == null)
				certificateDtoListForAdd.add(certificateDto);
			else
				certificateDtoListForUpdate.add(certificateDto);
		}
		if(!certificateDtoListForAdd.isEmpty())
			certificateDtoList = addCertificate(staff, certificateDtoListForAdd, attachmentFiles);
		
		List<String> certificateIds = certificateDtoListForUpdate.stream().map(i -> i.getId()).collect(Collectors.toList());
		List<CrewCertificate> certificateList = crewCertificateDao.findByIdInAndStatusNot(certificateIds, commonUtil.getSoftDeleteStatus());
		if(certificateList.size() < certificateIds.size())
			throw new ApplicationServiceExecption("Certificate not found");
		
		List<CrewCertificateDto> existingCertificateDtoList = mapEntityToDto.transformListOfBO(certificateList, CrewCertificateDto.class);
		certificateList = mapDtoToEntity.transformListOfBO(certificateDtoListForUpdate, CrewCertificate.class);
		for (CrewCertificate certificate : certificateList) {
			certificate.setUpdateTime(new Date());
		}
		/**********************delete and add attachments of CrewCertificate********start**********/
		List<CrewCertificateDto> returnCertificateDtoList = mapEntityToDto.transformListOfBO(certificateList, CrewCertificateDto.class);
		Integer count = 0;
		for (CrewCertificateDto certificateDto : certificateDtoListForUpdate) {
			if(!certificateDto.getSoftDeleteDocPaths().isEmpty())
				attachmentService.softDeleteByPathList(certificateDto.getSoftDeleteDocPaths());
				
			List<MultipartFile> thisAttachmentFiles = new ArrayList<>();
				for (String certificateDoc : certificateDto.getCertificateDoc()) {
					//Integer index = 0;
					//Integer removeAttachmentIndex = null;
					for (MultipartFile attachment : attachmentFiles) {
						if(certificateDoc.equals(attachment.getOriginalFilename())) {
							thisAttachmentFiles.add(attachment); 
						//	removeAttachmentIndex = index;
						}
						//index++;
					}
					//ArrayUtils.remove(attachmentFiles, removeAttachmentIndex);
				}
			AttachmentDto attachmentDto = new AttachmentDto();
			attachmentDto.setRecordId(certificateList.get(count).getId());
			attachmentDto.setAttachmentOrigin(dbUtil.getTableName((mapDtoToEntity.transformBO(certificateDto, CrewCertificate.class)).getClass()));
			attachmentDto.setAttachmentType(certificateDto.getCertificateDocFieldName());
			List<String> certificateDocPathList = attachmentService.add(attachmentDto, thisAttachmentFiles);
			returnCertificateDtoList.get(count).setCertificateDoc(certificateDocPathList);
			count++;
		}
		/**********************delete and add attachments of CrewCertificate********end**********/
		crewCertificateDao.saveAll(certificateList);
		count = 0;
		for (CrewCertificate certificate : certificateList) {
			syncDataService.syncUpdate(mapDtoToEntity.transformBO(existingCertificateDtoList.get(count), CrewCertificate.class), certificate);
			count++;
		}
		certificateDtoList.addAll(certificateDtoListForUpdate);
		LOGGER.debug("CrewCertificateServicImpl -- update -- end");
		return certificateDtoList;
	}

	@Override
	public List<CrewCertificateDto> findByStaff(Staff staff) throws Exception {
		LOGGER.debug("CrewCertificateServicImpl -- findByStaff -- start");
		List<CrewCertificateDto> certificateDtoList = new ArrayList<>();
		List<CrewCertificate> certificateList = crewCertificateDao.findByStaffAndStatusNot(staff, commonUtil.getSoftDeleteStatus());
		if(certificateList.isEmpty())
			return certificateDtoList;
		
		certificateDtoList = mapEntityToDto.transformListOfBO(certificateList, CrewCertificateDto.class);
		String attachmentOrigin = dbUtil.getTableName(certificateList.get(0).getClass());
		for (CrewCertificateDto certificateDto : certificateDtoList) {
			AttachmentDto attachmentDto = new AttachmentDto();
			attachmentDto.setAttachmentOrigin(attachmentOrigin);
			attachmentDto.setRecordId(certificateDto.getId());
			attachmentDto.setAttachmentType(certificateDto.getCertificateDocFieldName());
			certificateDto.setCertificateDoc(attachmentService.findAttachments(attachmentDto));
		}
		LOGGER.debug("CrewCertificateServicImpl -- findByStaff -- end");
		return certificateDtoList;
	}

	@Override
	public void softDeleteByStaff(Staff staff) throws Exception {
		LOGGER.debug("CrewCertificateServicImpl -- softDelete -- start");
		List<CrewCertificate> certificateList = crewCertificateDao.findByStaffAndStatusNot(staff, commonUtil.getSoftDeleteStatus());
		List<CrewCertificateDto> certificateDtoList = mapEntityToDto.transformListOfBO(certificateList, CrewCertificateDto.class);
		for (CrewCertificate certificate : certificateList) {
			certificate.setUpdateTime(new Date());
			certificate.setStatus(commonUtil.getSoftDeleteStatus());
		}
		Integer count = 0;
		for (CrewCertificate certificate : certificateList) {
			syncDataService.syncUpdate(mapDtoToEntity.transformBO(certificateDtoList.get(count), CrewCertificate.class), certificate);
			attachmentService.softDelete(certificate.getId(), dbUtil.getTableName(certificate.getClass()));
			count++;
		}
		LOGGER.debug("CrewCertificateServicImpl -- softDelete -- end");
	}

	@Override
	public void softDelete(List<String> ids) throws Exception {
		LOGGER.debug("CrewCertificateServicImpl -- softDelete -- start");
		commonUtil.stringNullValidator(ids.toArray(), "Certificate Id");
		List<CrewCertificate> certificateList = crewCertificateDao.findByIdInAndStatusNot(ids, commonUtil.getSoftDeleteStatus());
		if(certificateList.size() <  ids.size())
			throw new ApplicationServiceExecption("Certificate not found");
		
		List<CrewCertificateDto> certificateDtoList = mapEntityToDto.transformListOfBO(certificateList, CrewCertificateDto.class);
		for (CrewCertificate certificate : certificateList) {
			certificate.setUpdateTime(new Date());
			certificate.setStatus(commonUtil.getSoftDeleteStatus());
		}
		Integer count = 0;
		for (CrewCertificate certificate : certificateList) {
			syncDataService.syncUpdate(mapDtoToEntity.transformBO(certificateDtoList.get(count), CrewCertificate.class), certificate);
			attachmentService.softDelete(certificate.getId(), dbUtil.getTableName(certificate.getClass()));
			count++;
		}
		LOGGER.debug("CrewCertificateServicImpl -- softDelete -- end");
	}
	
	public List<CrewCertificateDto> addCertificate(Staff staff, List<CrewCertificateDto> certificateDtoList, MultipartFile[] attachmentFiles) throws Exception{
		LOGGER.debug("CrewCertificateServicImpl -- addCertificateMethod -- start");
		List<CrewCertificate> certificateList = mapDtoToEntity.transformListOfBO(certificateDtoList, CrewCertificate.class);
		for (CrewCertificate certificate : certificateList) {
			String seqName = dbUtil.getNextSequence(certificate.getClass());
			if(seqName != null)
				certificate.setId(seqName);
			
			certificate.setStaff(staff);
			certificate.setStatus(commonUtil.getActiveStatus());
			certificate.setInsertTime(new Date());
			certificate.setUpdateTime(new Date());
		}
		crewCertificateDao.saveAll(certificateList);
		for (CrewCertificate certificate : certificateList) {
			syncDataService.syncCreation(certificate);
		}
		List<CrewCertificateDto> returnCertificateDtoList = mapEntityToDto.transformListOfBO(certificateList, CrewCertificateDto.class);
		Integer count = 0;
		for (CrewCertificateDto certificateDto : certificateDtoList) {
			List<MultipartFile> thisAttachmentFiles = new ArrayList<>();
				for (String certificateDoc : certificateDto.getCertificateDoc()) {
					//Integer index = 0;
					//Integer removeAttachmentIndex = null;
					for (MultipartFile attachment : attachmentFiles) {
						if(certificateDoc.equals(attachment.getOriginalFilename())) {
							thisAttachmentFiles.add(attachment); 
						//	removeAttachmentIndex = index;
						}
						//index++;
					}
					//ArrayUtils.remove(attachmentFiles, removeAttachmentIndex);
				}
			AttachmentDto attachmentDto = new AttachmentDto();
			attachmentDto.setRecordId(certificateList.get(count).getId());
			attachmentDto.setAttachmentOrigin(dbUtil.getTableName((mapDtoToEntity.transformBO(certificateDto, CrewCertificate.class)).getClass()));
			attachmentDto.setAttachmentType(certificateDto.getCertificateDocFieldName());
			List<String> certificateDocPathList = attachmentService.add(attachmentDto, thisAttachmentFiles);
			returnCertificateDtoList.get(count).setCertificateDoc(certificateDocPathList);
			count++;
		}
		LOGGER.debug("CrewCertificateServicImpl -- addCertificateMethod -- end");
		return returnCertificateDtoList;
	}

}
