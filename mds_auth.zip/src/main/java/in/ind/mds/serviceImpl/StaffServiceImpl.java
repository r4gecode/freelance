/**
 * 
 */
package in.ind.mds.serviceImpl;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.databind.ObjectMapper;

import in.ind.mds.dto.AttachmentDto;
import in.ind.mds.dto.BankAccountDto;
import in.ind.mds.dto.CrewActivityDto;
import in.ind.mds.dto.CrewCertificateDto;
import in.ind.mds.dto.CrewContractDto;
import in.ind.mds.dto.CrewMedicalReportDto;
import in.ind.mds.dto.CrewTrainingDto;
import in.ind.mds.dto.CrewWorkExpDto;
import in.ind.mds.dto.StaffDetailsDto;
import in.ind.mds.dto.StaffDto;
import in.ind.mds.dto.TravelDocumentDto;
import in.ind.mds.dto.UserDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.repo.dao.StaffDao;
import in.ind.mds.repo.entity.Staff;
import in.ind.mds.repo.entity.User;
import in.ind.mds.service.AttachmentService;
import in.ind.mds.service.BankAccountService;
import in.ind.mds.service.CrewActivityService;
import in.ind.mds.service.CrewCertificateService;
import in.ind.mds.service.CrewContractService;
import in.ind.mds.service.CrewMedicalReportService;
import in.ind.mds.service.CrewTrainingService;
import in.ind.mds.service.CrewWorkExpService;
import in.ind.mds.service.StaffService;
import in.ind.mds.service.SyncDataService;
import in.ind.mds.service.TravelDocumentService;
import in.ind.mds.service.UserService;
import in.ind.mds.util.BeanTransformerUtil;
import in.ind.mds.util.CommonUtil;
import in.ind.mds.util.DBUtil;

/**
 * @author mds_kiruthika
 *
 */
@Service("TST_MSSQL_STAFF")
public class StaffServiceImpl implements StaffService {

	private static final Logger LOGGER = LoggerFactory.getLogger(StaffServiceImpl.class);

	@Autowired
	private BeanTransformerUtil<Staff, StaffDto> mapEntityToDto;

	@Autowired
	private BeanTransformerUtil<StaffDto, Staff> mapDtoToEntity;

	@Autowired
	private BeanTransformerUtil<UserDto, User> mapDtoToEntityUser;

	@Autowired
	@Qualifier("TST_MSSQL_SYNC")
	private SyncDataService syncDataService;

	@Autowired
	private CommonUtil<StaffDto> commonUtil;

	@Autowired
	private StaffDao staffDao;

	@Autowired
	private UserService userService;

	@Autowired
	@Qualifier("TST_MSSQL_BANK_ACCOUNT")
	private BankAccountService bankAccountService;

	@Autowired
	@Qualifier("TST_MSSQL_CREW_ACTIVITY")
	private CrewActivityService crewActivityService;

	@Autowired
	@Qualifier("TST_MSSQL_CREW_MEDICAL_REPORT")
	private CrewMedicalReportService crewMedicalReportService;

	@Autowired
	@Qualifier("TST_MSSQL_CREW_TRAINING")
	private CrewTrainingService crewTrainingService;

	@Autowired
	@Qualifier("TST_MSSQL_CREW_WORK_EXP")
	private CrewWorkExpService crewWorkExpService;

	@Autowired
	@Qualifier("TST_MSSQL_CREW_CERTIFICATE")
	private CrewCertificateService crewCertificateService;

	@Autowired
	@Qualifier("TST_MSSQL_TRAVELDOC")
	private TravelDocumentService travelDocumentService;

	@Autowired
	@Qualifier("TST_MSSQL_ATTACHEMENT")
	private AttachmentService attachmentService;

	@Autowired
	@Qualifier("TST_MSSQL_CREW_CONTRACT")
	private CrewContractService crewContractService;

	@Autowired
	private DBUtil dbUtil;

	@Override
	public StaffDetailsDto getByStaffId(String staffId) throws Exception {
		LOGGER.debug("StaffServiceImpl -- getByStaffId -- Start");
		StaffDetailsDto staffDetailsDto = new StaffDetailsDto();
		commonUtil.stringNullValidator(staffId, "StaffId");
		Staff staff = staffDao.findByIdAndStatusNot(staffId, commonUtil.getSoftDeleteStatus());
		if (staff == null)
			throw new ApplicationServiceExecption("Staff not found", HttpStatus.NOT_FOUND);

		StaffDto staffDto = mapEntityToDto.transformBO(staff, StaffDto.class);
		AttachmentDto attachmentDto = new AttachmentDto();
		attachmentDto.setAttachmentOrigin(dbUtil.getTableName(staff.getClass()));
		attachmentDto.setRecordId(staff.getId());
		attachmentDto.setAttachmentType(staffDto.getStaffPicFieldName());
		List<String> attachmentPathList = attachmentService.findAttachments(attachmentDto);
		staffDto.setStaffPic(attachmentPathList);
		attachmentDto.setAttachmentType(staffDto.getStaffDocFieldName());
		attachmentPathList = attachmentService.findAttachments(attachmentDto);
		staffDto.setStaffDoc(attachmentPathList);
		staffDetailsDto.setStaff(staffDto);
		/***************** Bank Account***************start ****************/
		staffDetailsDto.setBankAccountDtoList(bankAccountService.findByStaff(staff));
		/***************** CrewActivity***************start ****************/
		staffDetailsDto.setActivityDtoList(crewActivityService.findByStaff(staff));
		/***************** CrewMedicalReport***************start ****************/
		staffDetailsDto.setMedicalReportList(crewMedicalReportService.findByStaff(staff));
		/***************** CrewTraining***************start ****************/
		staffDetailsDto.setTrainingList(crewTrainingService.findByStaff(staff));
		/***************** CrewWorkExp***************start ****************/
		staffDetailsDto.setWorkExpList(crewWorkExpService.findByStaff(staff));
		/***************** CrewCertificate***************start ****************/
		staffDetailsDto.setCertificateDtoList(crewCertificateService.findByStaff(staff));
		/***************** TravelDocument***************start ****************/
		staffDetailsDto.setTravelDocumentDtoList(travelDocumentService.findByStaff(staff));
		/***************** CrewContract***************start ****************/
		staffDetailsDto.setContractDtoList(crewContractService.findByStaff(staff));
		LOGGER.debug("StaffServiceImpl -- getByStaffId -- End");
		return staffDetailsDto;
	}

	@Override
	public StaffDetailsDto add(String staffDetails, Map<String, MultipartFile[]> attachments) throws Exception {
		LOGGER.debug("StaffServiceImpl -- add -- Start");
		ObjectMapper mapper = new ObjectMapper();
		StaffDetailsDto staffDetailsDto = mapper.readValue(staffDetails, StaffDetailsDto.class);
		StaffDto staffDto = staffDetailsDto.getStaff();
		commonUtil.stringNullValidator(staffDto.getStaffType(), staffDto.getStaffCode(), staffDto.getFirstName(),
				staffDto.getPassportNumber(), "StaffType and StaffCode and FirstName and PassportNumber");
		List<Staff> existingStaffList = staffDao.uniqueCheckForAdd(staffDto.getStaffCode(),
				staffDto.getPassportNumber());
		if (!(existingStaffList.isEmpty()))
			throw new ApplicationServiceExecption("Staff already exist", HttpStatus.BAD_REQUEST);

		Staff staff = mapDtoToEntity.transformBO(staffDto, Staff.class);

		/*
		 * Saving staff user name and password with user details. for login purpose
		 */
		if (staffDto.getRole().getLoginAccount().equals("Y") && staffDto.getUserName() != null
				&& staffDto.getPassword() != null) {
			UserDto userDto = new UserDto();
			userDto.setUserName(staffDto.getUserName());
			userDto.setPassword(staffDto.getPassword());
			userDto.setUserShortName(staffDto.getFirstName());
			userDto = userService.saveUser(userDto);
			staff.setLoginUser(mapDtoToEntityUser.transformBO(userDto, User.class));
		}
		String seqName = dbUtil.getNextSequence(staff.getClass());

		if (seqName != null)
			staff.setId(seqName);

		staff.setInsertTime(new Date());
		staff.setUpdateTime(new Date());
		staff.setStatus(commonUtil.getActiveStatus());
		staff = staffDao.save(staff);

		syncDataService.syncCreation(staff);

		staffDto = mapEntityToDto.transformBO(staff, StaffDto.class);
		AttachmentDto attachmentDto = new AttachmentDto();
		attachmentDto.setRecordId(staff.getId());
		attachmentDto.setAttachmentOrigin(dbUtil.getTableName(staff.getClass()));
		attachmentDto.setAttachmentType(staffDto.getStaffPicFieldName());
		List<String> attachmentPathList = attachmentService.add(attachmentDto,
				Arrays.asList(attachments.get("staffPic")));
		staffDto.setStaffPic(attachmentPathList);
		attachmentDto.setAttachmentType(staffDto.getStaffDocFieldName());
		attachmentPathList = attachmentService.add(attachmentDto, Arrays.asList(attachments.get("staffDoc")));
		staffDto.setStaffDoc(attachmentPathList);
		staffDetailsDto.setStaff(staffDto);
		/*********** BankAccount*****start ****/
		if (staffDetailsDto.getBankAccountDtoList() != null) {
			List<BankAccountDto> bankAccountDtoList = bankAccountService.add(staff,
					staffDetailsDto.getBankAccountDtoList(), attachments.get("bankAccountDoc"));
			staffDetailsDto.setBankAccountDtoList(bankAccountDtoList);
		}
		/*********** CrewActivity*****start ****/
		if (staffDetailsDto.getActivityDtoList() != null) {
			List<CrewActivityDto> crewActivityDtoList = crewActivityService.add(staff,
					staffDetailsDto.getActivityDtoList(), attachments.get("activityDoc"));
			staffDetailsDto.setActivityDtoList(crewActivityDtoList);
		}
		/*********** CrewMedicalReport*****start ****/

		if (staffDetailsDto.getMedicalReportList() != null) {
			List<CrewMedicalReportDto> medicalReportDtoList = crewMedicalReportService.add(staff,
					staffDetailsDto.getMedicalReportList(), attachments.get("medicalReportDoc"));
			staffDetailsDto.setMedicalReportList(medicalReportDtoList);
		}
		/*********** CrewTraining*****start ****/
		if (staffDetailsDto.getTrainingList() != null) {
			List<CrewTrainingDto> crewTrainingDtoList = crewTrainingService.add(staff,
					staffDetailsDto.getTrainingList(), attachments.get("trainingDoc"));
			staffDetailsDto.setTrainingList(crewTrainingDtoList);
		}
		/*********** CrewWorkExp*****start ****/
		if (staffDetailsDto.getWorkExpList() != null) {
			List<CrewWorkExpDto> crewWorkExpList = crewWorkExpService.add(staff, staffDetailsDto.getWorkExpList());
			staffDetailsDto.setWorkExpList(crewWorkExpList);
		}
		/*********** CrewCertificate*****start ****/
		if (staffDetailsDto.getCertificateDtoList() != null) {
			List<CrewCertificateDto> certificateDtoList = crewCertificateService.add(staff,
					staffDetailsDto.getCertificateDtoList(), attachments.get("certificateDoc"));
			staffDetailsDto.setCertificateDtoList(certificateDtoList);
		}
		/*********** TravelDocument*****start ****/
		if (staffDetailsDto.getTravelDocumentDtoList() != null) {
			List<TravelDocumentDto> travelDocumentDtoList = travelDocumentService.add(staff,
					staffDetailsDto.getTravelDocumentDtoList(), attachments.get("travelDoc"));
			staffDetailsDto.setTravelDocumentDtoList(travelDocumentDtoList);
		}
		/*********** CrewContract*****start ****/
		if (staffDetailsDto.getContractDtoList() != null) {
			List<CrewContractDto> contractDtoList = crewContractService.add(staff, staffDetailsDto.getContractDtoList(),
					attachments.get("contractDoc"));
			staffDetailsDto.setContractDtoList(contractDtoList);
		}
		LOGGER.debug("StaffServiceImpl -- add -- End");
		return staffDetailsDto;
	}

	@Override
	public List<StaffDto> findAll() throws Exception {
		LOGGER.debug("StaffServiceImpl -- findAll -- Start");
		List<Staff> staffList = staffDao.findAllStaff();

		if (staffList.isEmpty())
			throw new ApplicationServiceExecption("Staff not found", HttpStatus.NOT_FOUND);

		LOGGER.debug("StaffServiceImpl -- findAll -- End");
		return mapEntityToDto.transformListOfBO(staffList, StaffDto.class);
	}

	@Override
	public List<StaffDto> softDeleteStaff(List<String> staffIds) throws Exception {
		LOGGER.debug("StaffServiceImpl -- softDeleteStaff -- Start");
		commonUtil.stringNullValidator(staffIds, "StaffId");

		List<Staff> existingStaffList = staffDao.findByIdInAndStatusNot(staffIds, commonUtil.getSoftDeleteStatus());
		if (existingStaffList.size() < staffIds.size())
			throw new ApplicationServiceExecption("Staff not found", HttpStatus.BAD_REQUEST);

		List<StaffDto> existingStaffDtoList = mapEntityToDto.transformListOfBO(existingStaffList, StaffDto.class);
		for (Staff staff : existingStaffList) {
			staff.setStatus(commonUtil.getSoftDeleteStatus());
			staff.setUpdateTime(new Date());
		}
		existingStaffList = staffDao.saveAll(existingStaffList);
		Integer count = 0;
		for (Staff staff : existingStaffList) {
			syncDataService.syncUpdate(mapDtoToEntity.transformBO(existingStaffDtoList.get(count), Staff.class), staff);
			attachmentService.softDelete(staff.getId(), dbUtil.getTableName(staff.getClass()));
			bankAccountService.softDeleteByStaff(staff);
			crewActivityService.softDeleteByStaff(staff);
			crewMedicalReportService.softDeleteByStaff(staff);
			crewTrainingService.softDeleteByStaff(staff);
			crewWorkExpService.softDeleteByStaff(staff);
			crewCertificateService.softDeleteByStaff(staff);
			travelDocumentService.softDeleteByStaff(staff);
			crewContractService.softDeleteByStaff(staff);
			count++;
		}
		List<Staff> staffList = staffDao.findAllStaff();
		LOGGER.debug("StaffServiceImpl -- softDeleteStaff -- End");
		return mapEntityToDto.transformListOfBO(staffList, StaffDto.class);
	}

	@Override
	public StaffDetailsDto updateStaff(String staffDetails, Map<String, MultipartFile[]> attachments) throws Exception {
		LOGGER.debug("StaffServiceImpl -- updateStaff -- Start");
		ObjectMapper mapper = new ObjectMapper();
		StaffDetailsDto staffDetailsDto = mapper.readValue(staffDetails, StaffDetailsDto.class);
		StaffDto staffDto = staffDetailsDto.getStaff();
		commonUtil.stringNullValidator(staffDto.getStaffCode(), staffDto.getFirstName(), staffDto.getId(),
				"Staff Id, Name and Code");
		List<Staff> existingStaffList = staffDao.uniqueCheckForUpdate(staffDto.getStaffCode(), staffDto.getId(),
				staffDto.getPassportNumber());
		if (!existingStaffList.isEmpty())
			throw new ApplicationServiceExecption("Staff already exist", HttpStatus.BAD_REQUEST);

		Staff staff = staffDao.findByIdAndStatusNot(staffDto.getId(), commonUtil.getSoftDeleteStatus());
		if (staff == null)
			throw new ApplicationServiceExecption("Staff not found", HttpStatus.BAD_REQUEST);

		/*
		 * Saving staff user name and password with user details. for login purpose
		 */
		if (staffDto.getRole().getLoginAccount().equals("Y") && staffDto.getUserName() != null
				&& staffDto.getPassword() != null) {
			UserDto userDto = new UserDto();
			userDto.setUserName(staffDto.getUserName());
			userDto.setPassword(staffDto.getPassword());
			userDto.setUserShortName(staffDto.getFirstName());
			userDto = userService.saveUser(userDto);
			staff.setLoginUser(mapDtoToEntityUser.transformBO(userDto, User.class));
		}

		StaffDto existingStaffDto = mapEntityToDto.transformBO(staff, StaffDto.class);
		staff = mapDtoToEntity.transformBO(staffDto, Staff.class);
		staff.setUpdateTime(new Date());
		staffDao.saveAndFlush(staff);
		syncDataService.syncUpdate(mapDtoToEntity.transformBO(existingStaffDto, Staff.class), staff);

		staffDetailsDto.setStaff(mapEntityToDto.transformBO(staff, StaffDto.class));

		
		/*********** BankAccount*****start ****/
		if (staffDetailsDto.getBankAccountDtoList() != null) {
			List<String> bankAccountIds = staffDetailsDto.getBankAccountIds();
			if (!bankAccountIds.isEmpty())
				bankAccountService.softDelete(bankAccountIds);

			List<BankAccountDto> bankAccountDtoList = staffDetailsDto.getBankAccountDtoList();
			bankAccountDtoList = bankAccountService.update(staff, bankAccountDtoList, attachments.get("bankAccountDoc"));
			staffDetailsDto.setBankAccountDtoList(bankAccountDtoList);
		}
		/*********** CrewActivity*****start ****/
		if (staffDetailsDto.getActivityDtoList() != null) {
			List<String> activityIds = staffDetailsDto.getActivityIds();
			if (!activityIds.isEmpty())
				crewActivityService.softDelete(activityIds);

			List<CrewActivityDto> activityDtoList = staffDetailsDto.getActivityDtoList();
			activityDtoList = crewActivityService.update(staff, activityDtoList, attachments.get("activityDoc"));
			staffDetailsDto.setActivityDtoList(activityDtoList);
		}
		/*********** CrewMedicalReport*****start ****/

		if (staffDetailsDto.getMedicalReportList() != null) {
			List<String> medicalReportIds = staffDetailsDto.getMedicalReportIds();
			if (!medicalReportIds.isEmpty())
				crewMedicalReportService.softDelete(medicalReportIds);

			List<CrewMedicalReportDto> medicalDtoList = staffDetailsDto.getMedicalReportList();
			medicalDtoList = crewMedicalReportService.update(staff, medicalDtoList, attachments.get("medicalReportDoc"));
			staffDetailsDto.setMedicalReportList(medicalDtoList);
		}
		/*********** CrewTraining*****start ****/
		if (staffDetailsDto.getTrainingList() != null) {
			List<String> trainingIds = staffDetailsDto.getTrainingIds();
			if (!trainingIds.isEmpty())
				crewTrainingService.softDelete(trainingIds);

			List<CrewTrainingDto> trainingDtoList = staffDetailsDto.getTrainingList();
			trainingDtoList = crewTrainingService.update(staff, trainingDtoList, attachments.get("trainingDoc"));
			staffDetailsDto.setTrainingList(trainingDtoList);
		}
		/*********** CrewWorkExp*****start ****/
		if (staffDetailsDto.getWorkExpList() != null) {
			List<String> workExpIds = staffDetailsDto.getWorkExpIds();
			if (!workExpIds.isEmpty())
				crewWorkExpService.softDelete(workExpIds);

			List<CrewWorkExpDto> workExpDtoList = staffDetailsDto.getWorkExpList();
			workExpDtoList = crewWorkExpService.update(staff, workExpDtoList);
			staffDetailsDto.setWorkExpList(workExpDtoList);
		}
		/*********** CrewCertificate*****start ****/
		if (staffDetailsDto.getCertificateDtoList() != null) {
			List<String> certificateIds = staffDetailsDto.getCertificateIds();
			if (!certificateIds.isEmpty())
				crewCertificateService.softDelete(certificateIds);

			List<CrewCertificateDto> certificateDtoList = staffDetailsDto.getCertificateDtoList();
			certificateDtoList = crewCertificateService.update(staff, certificateDtoList,
					attachments.get("certificateDoc"));
			staffDetailsDto.setCertificateDtoList(certificateDtoList);
		}
		/*********** TravelDocument*****start ****/
		if (staffDetailsDto.getTravelDocumentDtoList() != null) {
			List<String> travelDocIds = staffDetailsDto.getTravelDocumentIds();
			if (!travelDocIds.isEmpty())
				travelDocumentService.softDeleteDocument(travelDocIds);

			List<TravelDocumentDto> travelDocumentDtoList = staffDetailsDto.getTravelDocumentDtoList();
			travelDocumentDtoList = travelDocumentService.updateDocument(staff, travelDocumentDtoList,
					attachments.get("travelDoc"));
			staffDetailsDto.setTravelDocumentDtoList(travelDocumentDtoList);
		}
		/*********** CrewContract*****start ****/
		if (staffDetailsDto.getContractDtoList() != null) {
			List<String> contractDocIds = staffDetailsDto.getContractIds();
			if (!contractDocIds.isEmpty())
				travelDocumentService.softDeleteDocument(contractDocIds);

			List<CrewContractDto> contractDtoList = staffDetailsDto.getContractDtoList();
			contractDtoList = crewContractService.update(staff, contractDtoList, attachments.get("contractDoc"));
			staffDetailsDto.setContractDtoList(contractDtoList);
		}

		LOGGER.debug("StaffServiceImpl -- updateStaff -- End");
		return staffDetailsDto;

	}

}
