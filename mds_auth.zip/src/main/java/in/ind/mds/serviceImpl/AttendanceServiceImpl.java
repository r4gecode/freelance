/**
 * 
 */
package in.ind.mds.serviceImpl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import in.ind.mds.dto.AttendanceDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.repo.dao.AttendanceDao;
import in.ind.mds.repo.entity.Attendance;
import in.ind.mds.service.AttendanceService;
import in.ind.mds.service.SyncDataService;
import in.ind.mds.util.BeanTransformerUtil;
import in.ind.mds.util.CommonUtil;
import in.ind.mds.util.DBUtil;

/**
 * @author shalini
 *
 */
@Service("TST_MSSQL_ATTENDANCE")
public class AttendanceServiceImpl implements AttendanceService{
	private static final Logger LOGGER = LoggerFactory.getLogger(AttendanceServiceImpl.class);

	@Autowired
	private BeanTransformerUtil<Attendance, AttendanceDto> mapEntityToDto;

	@Autowired
	private BeanTransformerUtil<AttendanceDto, Attendance> mapDtoToEntity;

	@Autowired
	@Qualifier("TST_MSSQL_SYNC")
	private SyncDataService syncDataService;

	@Autowired
	private AttendanceDao attendanceDao;

	@Autowired
	private DBUtil dbUtil;

	@Autowired
	private CommonUtil<AttendanceDto> commonUtil;

	

	@Override
	public AttendanceDto add(AttendanceDto attendanceDto) throws Exception {
		LOGGER.debug("AttendanceServiceImpl -- add -- Start");
		Attendance attendance = mapDtoToEntity.transformBO(attendanceDto, Attendance.class);
		String seqName = dbUtil.getNextSequence(attendance.getClass());
		if(seqName != null) {
			attendance.setId(seqName);
		}
		attendance.setInsertTime(new Date());
		attendance.setUpdateTime(new Date());
		attendance.setStatus(commonUtil.getActiveStatus());
		attendance = attendanceDao.save(attendance);
		syncDataService.syncCreation(attendance);
		LOGGER.debug("AttendanceServiceImpl -- add -- End");
		return mapEntityToDto.transformBO(attendance, AttendanceDto.class);
	}
	
	@Override
	public AttendanceDto updateAttendance(AttendanceDto attendanceDto) throws Exception {
		LOGGER.debug("AttendanceServiceImpl -- update -- Start");
		
		commonUtil.stringNullValidator(attendanceDto.getId(), "AttendanceId");
		Attendance existingAttendance = attendanceDao.findByIdAndStatusNot(attendanceDto.getId(),commonUtil.getSoftDeleteStatus());
		if (existingAttendance == null) 
			throw new ApplicationServiceExecption("Attendance not found", HttpStatus.BAD_REQUEST);

		AttendanceDto existingAttendanceDto = mapEntityToDto.transformBO(existingAttendance, AttendanceDto.class);
		Attendance attendance = mapDtoToEntity.transformBO(attendanceDto, Attendance.class);
		attendance.setUpdateTime(new Date());
		attendance = attendanceDao.saveAndFlush(attendance);
		syncDataService.syncUpdate(mapDtoToEntity.transformBO(existingAttendanceDto, Attendance.class), attendance);
		LOGGER.debug("AttendanceServiceImpl -- update -- End");
		return mapEntityToDto.transformBO(attendance, AttendanceDto.class);
	}
	@Override
	public List<AttendanceDto> findAll() throws Exception {
		LOGGER.debug("AttendanceServiceImpl -- findAll -- Start");
		List<Attendance> attendance = attendanceDao.findAllAttendance();
		if (attendance.size() == 0) {
			throw new ApplicationServiceExecption("Attendance not found", HttpStatus.NOT_FOUND);
		}
		final List<AttendanceDto> dto = mapEntityToDto.transformListOfBO(attendance, AttendanceDto.class);
		LOGGER.debug("AttendanceServiceImpl -- findAll -- End");
		return dto;
	}
	
	@Override
	public List<AttendanceDto> softDelete(List<String>attendanceIds) throws Exception {
		LOGGER.debug("AttendanceServiceImpl -- delete -- Start");
		commonUtil.stringNullValidator(attendanceIds.toArray(), "AttendanceId");
		List<Attendance> existingAttendanceList = attendanceDao.findByIdInAndStatusNot(attendanceIds, commonUtil.getSoftDeleteStatus());
		if (existingAttendanceList.size() <  attendanceIds.size()) 
			throw new ApplicationServiceExecption("Attendance not found", HttpStatus.BAD_REQUEST);

		List<AttendanceDto> existingAttendanceDtoList = mapEntityToDto.transformListOfBO(existingAttendanceList, AttendanceDto.class);
		for (Attendance attendance : existingAttendanceList) {
			attendance.setStatus(commonUtil.getSoftDeleteStatus());
			attendance.setUpdateTime(new Date());
		}
		attendanceDao.saveAll(existingAttendanceList);
		Integer count = 0;
		for (Attendance attendance : existingAttendanceList) {
			syncDataService.syncUpdate(mapDtoToEntity.transformBO(existingAttendanceDtoList.get(count), Attendance.class), attendance);
			count++;
		}
		existingAttendanceList = attendanceDao.findAllAttendance();
		LOGGER.debug("AttendanceServiceImpl -- delete -- End");
		return mapEntityToDto.transformListOfBO(existingAttendanceList, AttendanceDto.class);
	}
	@Override
	public AttendanceDto findById(String attendanceId) throws Exception {
		LOGGER.debug("AttendanceServiceImpl -- findById -- Start");
		commonUtil.stringNullValidator(attendanceId, "AttendanceId");
		Attendance attendance = attendanceDao.findByIdAndStatusNot(attendanceId, commonUtil.getSoftDeleteStatus()); 
		if (attendance == null) {
			throw new ApplicationServiceExecption("Attendance not found", HttpStatus.NOT_FOUND);
		}
		final AttendanceDto dto = mapEntityToDto.transformBO(attendance, AttendanceDto.class);
		LOGGER.debug("AttendanceServiceImpl -- findById -- End");
		return dto;
	}

	@Override
	public List<AttendanceDto> findByMaster(String attendanceRecId,String origin) throws ApplicationServiceExecption {
LOGGER.debug("AttendanceServiceImpl--findByDrillCompletion--start");
//DrillCompletion drillCompl=mapDtoToEntity.transformBO(drillCompletion,DrillCompletion.class);
List<AttendanceDto> attendanceDtoList=new ArrayList<AttendanceDto>();
/*String attendanceRecId=drillCompletion.getId();
String attendanceOrigin=dbUtil.getTableName(drillCompletion.getClass());*/

      List<Attendance> att=attendanceDao.findByRecordIdAndAttendanceOriginAndStatusNot(attendanceRecId,origin,commonUtil.getSoftDeleteStatus());
      if(att==null) {
    	  throw new ApplicationServiceExecption("Attendance Not Found",HttpStatus.NOT_FOUND);
    	  
      }
      List<AttendanceDto> attendanceDtos=mapEntityToDto.transformListOfBO(att, AttendanceDto.class);
      //List<AttendanceDto> dto=mapEntityToDto.transformListOfBO(att, AttendanceDto.class);
	attendanceDtoList.addAll(attendanceDtos);

		
		return attendanceDtoList;
	}

	@Override
	public List<AttendanceDto> addAll(String id, String origin,List<AttendanceDto> attendanceDtoList) throws Exception {
LOGGER.debug("AttendanceServiceImpl--addAll--start");
List<Attendance> attendanceList=mapDtoToEntity.transformListOfBO(attendanceDtoList, Attendance.class);
for(Attendance attendance:attendanceList) {
	String seqName = dbUtil.getNextSequence(attendance.getClass());
	if (seqName != null)
		attendance.setId(seqName);
attendance.setAttendanceOrigin(origin);
attendance.setRecordId(id);
	attendance.setInsertTime(new Date());
	attendance.setUpdateTime(new Date());
	attendance.setStatus(commonUtil.getActiveStatus());
}
List<AttendanceDto> dtoList=mapEntityToDto.transformListOfBO(attendanceList, AttendanceDto.class);
attendanceDao.saveAll(attendanceList);
for(Attendance att:attendanceList) {
	syncDataService.syncCreation(att);
}
LOGGER.debug("AttendanceServiceImpl--addAll--end");
		
		return dtoList;
	}

	@Override
	public void softDeleteByMaster(String id, String origin) throws Exception {
	LOGGER.debug("AttendanceServiceImpl--softDeleteByDrilCompl--start");
	List<Attendance> attendanceList=new ArrayList<Attendance>();
	List<Attendance> returnlist=new ArrayList<Attendance>();

	List<String> ids=new ArrayList<String>();
	//for(DrillCompletionDto drillCompletionDto:drillCompletionDtoList) {
	//String id=drillCompletionDto.getId();
	//String origin=dbUtil.getTableName(drillCompletionDto.getClass());
	attendanceList=attendanceDao.findByRecordIdAndAttendanceOriginAndStatusNot(id, origin, commonUtil.getSoftDeleteStatus());
	for(Attendance att:attendanceList) {
		String attId=att.getId();
		ids.add(attId);
returnlist.add(att);
	}
	
	//List<AttendanceDto> returnattendanceList=softDelete(ids);
	List<AttendanceDto> returnattendanceList = mapEntityToDto.transformListOfBO(returnlist, AttendanceDto.class);
	for (Attendance attendance : returnlist) {
		attendance.setUpdateTime(new Date());
		attendance.setStatus(commonUtil.getSoftDeleteStatus());
	}
	Integer count = 0;
	for (Attendance attendance : returnlist) {
		syncDataService.syncUpdate(mapDtoToEntity.transformBO(returnattendanceList.get(count), Attendance.class), attendance);
		//attachmentService.softDelete(officeReview.getId(), dbUtil.getTableName(officeReview.getClass()));
		count++;
	}
	LOGGER.debug("AttendanceServiceImpl--softDeleteByDrillCompl--end");
	}

	@Override
	public List<AttendanceDto> updateAll(String id, String origin,List<AttendanceDto> attendanceDtoList) throws Exception {
		LOGGER.debug("AttendanceServicImpl -- update -- start");
		List<AttendanceDto> attendanceDtoListForAdd = new ArrayList<>();
		List<AttendanceDto> attendanceListForUpdate = new ArrayList<>();
		for (AttendanceDto attendanceDto : attendanceDtoList) {
			if(attendanceDto.getId() == null)
				attendanceDtoListForAdd.add(attendanceDto);
			else
				attendanceListForUpdate.add(attendanceDto);
		}
		if(!attendanceDtoListForAdd.isEmpty())
			attendanceDtoList = addAll(id,origin, attendanceDtoListForAdd);
		
		List<String> attendanceIds = attendanceListForUpdate.stream().map(i -> i.getId()).collect(Collectors.toList());
		List<Attendance> attendanceList = attendanceDao.findByIdInAndStatusNot(attendanceIds, commonUtil.getSoftDeleteStatus());
		if(attendanceList.size() < attendanceIds.size())
			throw new ApplicationServiceExecption("Attendance not found");
		
		List<AttendanceDto> existingAttendanceDtoList = mapEntityToDto.transformListOfBO(attendanceList, AttendanceDto.class);
		attendanceList = mapDtoToEntity.transformListOfBO(attendanceListForUpdate, Attendance.class);
		for (Attendance attendance : attendanceList) {
			attendance.setUpdateTime(new Date());
		}
		
		/**********************delete and add attachments of BankAccount********start**********//*
		List<AttendanceDto> returnAttendanceListForUpdate = mapEntityToDto.transformListOfBO(attendanceList, AttendanceDto.class);
		Integer count = 0;
		for (AttendanceDto attendanceDto : attendanceListForUpdate) {
			if(!attendanceDto.getSoftDeleteDocPaths().isEmpty()) 
				attachmentService.softDeleteByPathList(bankAccountDto.getSoftDeleteDocPaths());
			
			List<MultipartFile> thisAttachmentFiles = new ArrayList<>();
				for (String bankAccountDoc : bankAccountDto.getBankAccountDoc()) {
					for (MultipartFile attachment : attachmentFiles) {
						if(bankAccountDoc.equals(attachment.getOriginalFilename())) {
							thisAttachmentFiles.add(attachment); 
						}
											}
				}
			AttachmentDto attachmentDto = new AttachmentDto();
			attachmentDto.setRecordId(bankAccountList.get(count).getId());
			attachmentDto.setAttachmentOrigin(dbUtil.getTableName((mapDtoToEntity.transformBO(bankAccountDto, BankAccount.class)).getClass()));
			attachmentDto.setAttachmentType(bankAccountDto.getBankAccountDocFieldName());
			List<String> staffPicPathList = attachmentService.add(attachmentDto, thisAttachmentFiles);
			returnBankAccountDtoListForUpdate.get(count).setBankAccountDoc(staffPicPathList);
			count++;
		}*/
		/**********************delete and add attachments of BankAccount********end**********/
		
		attendanceDao.saveAll(attendanceList);
		Integer count = 0;
		for (Attendance attendance : attendanceList) {
			syncDataService.syncUpdate(mapDtoToEntity.transformBO(existingAttendanceDtoList.get(count), Attendance.class), attendance);
			count++;
		}
		attendanceDtoList.addAll(mapEntityToDto.transformListOfBO(attendanceList, AttendanceDto.class));
		LOGGER.debug("BankAccountServicImpl -- update -- end");
		return attendanceDtoList;
	}
}
