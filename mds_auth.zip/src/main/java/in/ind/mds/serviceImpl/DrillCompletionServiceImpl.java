/**
 * 
 */
package in.ind.mds.serviceImpl;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.databind.ObjectMapper;

import in.ind.mds.dto.AttachmentDto;
import in.ind.mds.dto.AttendanceDto;
import in.ind.mds.dto.BankAccountDto;
import in.ind.mds.dto.CrewActivityDto;
import in.ind.mds.dto.CrewCertificateDto;
import in.ind.mds.dto.CrewContractDto;
import in.ind.mds.dto.CrewMedicalReportDto;
import in.ind.mds.dto.CrewTrainingDto;
import in.ind.mds.dto.CrewWorkExpDto;
import in.ind.mds.dto.DrillCategoriesDto;
import in.ind.mds.dto.DrillCompletionDto;
import in.ind.mds.dto.JobCompletionDto;
import in.ind.mds.dto.OfficeReviewDto;
import in.ind.mds.dto.StaffDetailsDto;
import in.ind.mds.dto.StaffDto;
import in.ind.mds.dto.TravelDocumentDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.repo.dao.DrillCompletionDao;
import in.ind.mds.repo.dao.DrillSchedulerDao;
import in.ind.mds.repo.dao.StaffDao;
import in.ind.mds.repo.entity.Attendance;
import in.ind.mds.repo.entity.DrillCompletion;
import in.ind.mds.repo.entity.DrillScheduler;
import in.ind.mds.repo.entity.Staff;
import in.ind.mds.service.AttachmentService;
import in.ind.mds.service.AttendanceService;
import in.ind.mds.service.BankAccountService;
import in.ind.mds.service.CrewActivityService;
import in.ind.mds.service.CrewMedicalReportService;
import in.ind.mds.service.DrillCateoriesService;
import in.ind.mds.service.DrillCompletionService;
import in.ind.mds.service.DrillSchedulerService;
import in.ind.mds.service.OfficeReviewService;
import in.ind.mds.service.SyncDataService;
import in.ind.mds.util.BeanTransformerUtil;
import in.ind.mds.util.CommonUtil;
import in.ind.mds.util.DBUtil;

/**
 * @author shalini
 *
 */
@Service("TST_MSSQL_DRILL_COMPLETION")
public class DrillCompletionServiceImpl implements DrillCompletionService{
	private static final Logger LOGGER = LoggerFactory.getLogger(DrillCompletionServiceImpl.class);

	
	@Autowired
	private BeanTransformerUtil<DrillCompletion, DrillCompletionDto> mapEntityToDto;
	
	@Autowired
	private BeanTransformerUtil<DrillCompletionDto, DrillCompletion> mapDtoToEntity;
	
	@Autowired
	@Qualifier("TST_MSSQL_SYNC")
	private SyncDataService syncDataService;
	
	@Autowired
	 private CommonUtil<DrillCompletionDto> commonUtil;
	
	@Autowired
	private DrillCompletionDao drillCompletionDao;
	
	@Autowired
	@Qualifier("TST_MSSQL_DRILL_SCHEDULER")
	private DrillSchedulerService drillSchedulerService; 
	
	@Autowired
	private DrillSchedulerDao drillSchedulerDao;

	
	@Autowired
	@Qualifier("TST_MSSQL_ATTENDANCE")
	private AttendanceService attendanceService;
	
	@Autowired
	@Qualifier("TST_MSSQL_OFFICE_REVIEW")
	private OfficeReviewService officeReviewService;
	
	@Autowired
	@Qualifier("TST_MSSQL_ATTACHEMENT")
	private AttachmentService attachmentService;
	
	@Autowired
	private DBUtil dbUtil;
	@Override
	public DrillCompletionDto findById(String drillCompletionId) throws Exception{
		
		LOGGER.debug("DrillCompletionServiceImpl -- findById -- Start");
		//DrillCompletionDto drillCompletionDto = new DrillCompletionDto();
		commonUtil.stringNullValidator(drillCompletionId,"DrillCompletionId");
		DrillCompletion drillCompletion=drillCompletionDao.findByIdAndStatusNot(drillCompletionId, commonUtil.getSoftDeleteStatus());
		if (drillCompletion == null) 
			throw new ApplicationServiceExecption("drillCompletion not found", HttpStatus.NOT_FOUND);
		String id=drillCompletion.getId();
		String origin=dbUtil.getTableName(drillCompletion.getClass());
		
		DrillCompletionDto drillCompletionDto = mapEntityToDto.transformBO(drillCompletion, DrillCompletionDto.class);
		AttachmentDto attachmentDto = new AttachmentDto();
		attachmentDto.setAttachmentOrigin(dbUtil.getTableName(drillCompletion.getClass()));
		attachmentDto.setRecordId(drillCompletion.getId());
		attachmentDto.setAttachmentType(drillCompletionDto.getDrillCompletionDocFieldName());
		List<String> attachmentPathList = attachmentService.findAttachments(attachmentDto);
		drillCompletionDto.setDrillCompletionDoc(attachmentPathList);
		//attachmentDto.setAttachmentType(drillCompletionDto.getDrillCompletionDocFieldName());
		//attachmentPathList = attachmentService.findAttachments(attachmentDto);
		
		/*****************Attendance***************start****************/
		drillCompletionDto.setAttendanceDtoList(attendanceService.findByMaster(id, origin));
		/*****************OfficeReview***************start****************/
		drillCompletionDto.setOfficeReviewDtoList(officeReviewService.findByMaster(id, origin));
		
		LOGGER.debug("DrillCompletionServiceImpl -- findById -- End");
		return drillCompletionDto;
	}
	@Override
	public DrillCompletionDto add(String drillCompletionDetails, Map<String, MultipartFile[]> attachments) throws Exception {
		
		LOGGER.debug("DrillCompletionServiceImpl -- add -- Start");
		ObjectMapper mapper = new ObjectMapper();
		DrillCompletionDto drillCompletionDto = mapper.readValue(drillCompletionDetails, DrillCompletionDto.class);
		//DrillCompletionDto drillCompletionDto = commonUtil.stringJsonToEntity(drillCompletionDetails, DrillCompletionDto.class);

		/*List<DrillCompletion> existingDrillCompletionList=drillCompletionDao.uniqueCheckForAdd(drillCompletionDto.getJobStatus());
		if(!(existingDrillCompletionList.isEmpty()))
			throw new ApplicationServiceExecption("DrillCompletion already exist", HttpStatus.BAD_REQUEST);*/
		
		DrillCompletion drillCompletion= mapDtoToEntity.transformBO(drillCompletionDto, DrillCompletion.class);
		DrillCompletionDto drillCompl=drillCompletionDto;
		String seqName = dbUtil.getNextSequence(drillCompletion.getClass());
		
		if(seqName != null) 
			drillCompletion.setId(seqName);
		
		drillCompletion.setInsertTime(new Date());
		drillCompletion.setUpdateTime(new Date());
		drillCompletion.setStatus(commonUtil.getActiveStatus());
		drillCompletion=drillCompletionDao.save(drillCompletion);
		
		syncDataService.syncCreation(drillCompletion);
		AttachmentDto attachmentDto = new AttachmentDto();
		attachmentDto.setRecordId(drillCompletion.getId());
		attachmentDto.setAttachmentOrigin(dbUtil.getTableName(drillCompletion.getClass()));
		attachmentDto.setAttachmentType(drillCompletionDto.getDrillCompletionDocFieldName());
		List<String> attachmentPathList = attachmentService.add(attachmentDto, Arrays.asList(attachments.get("drillCompletionDoc")));
		drillSchedulerService.updationAtDrillCompletion(drillCompletion);
		drillCompletionDto = mapEntityToDto.transformBO(drillCompletion, DrillCompletionDto.class);
		drillCompletionDto.setDrillCompletionDoc(attachmentPathList);
		String id=drillCompletion.getId();
		String origin=dbUtil.getTableName(drillCompletion.getClass());
		
		/***********Attendance*****start****/
		List<AttendanceDto> attendanceDtoList = attendanceService.addAll( id,origin,drillCompl.getAttendanceDtoList());
		drillCompletionDto.setAttendanceDtoList(attendanceDtoList);
		
		/***********OfficeReview*****start****/
		List<OfficeReviewDto> officeReviewDtoList = officeReviewService.addAll(id,origin,drillCompl.getOfficeReviewDtoList(), attachments.get("officeReviewAtch"));
		drillCompletionDto.setOfficeReviewDtoList(officeReviewDtoList);
		
		LOGGER.debug("DrillCompletionServiceImpl -- add -- End");
		return drillCompletionDto;
	}
	

	@Override
	public List<DrillCompletionDto> findAll() throws Exception {
		LOGGER.debug("DrillCompletionServiceImpl -- findAll -- Start");
		List<DrillCompletion> drillCompletionList = drillCompletionDao.findAllDrillCompletion();

		if (drillCompletionList.isEmpty()) 
			throw new ApplicationServiceExecption("DrillCompletion not found", HttpStatus.NOT_FOUND);
		
		LOGGER.debug("DrillCompletionServiceImpl -- findAll -- End");
		return mapEntityToDto.transformListOfBO(drillCompletionList, DrillCompletionDto.class);
	}

	
	@Override
	public List<DrillCompletionDto> softDelete(List<String> drillCompletionIds) throws Exception {
		LOGGER.debug("DrillCompletionServiceImpl -- softDelete -- Start");
		commonUtil.stringNullValidator(drillCompletionIds, "DrillCompletionId");
		
		List<DrillCompletion> existingDrillCompletionList = drillCompletionDao.findByIdInAndStatusNot(drillCompletionIds, commonUtil.getSoftDeleteStatus());
		if (existingDrillCompletionList.size() < drillCompletionIds.size()) 
			throw new ApplicationServiceExecption("DrillCompletion not found", HttpStatus.BAD_REQUEST);
		
		List<DrillCompletionDto> existingDrillCompletionDtoList = mapEntityToDto.transformListOfBO(existingDrillCompletionList, DrillCompletionDto.class);
		for(DrillCompletion drillCompletion : existingDrillCompletionList)
		{
			drillCompletion.setStatus(commonUtil.getSoftDeleteStatus());
			drillCompletion.setUpdateTime(new Date());
		}
		existingDrillCompletionList=drillCompletionDao.saveAll(existingDrillCompletionList);
		Integer count=0;
		for(DrillCompletion drillCompletion : existingDrillCompletionList)
		{
			String id=drillCompletion.getId();
			String origin=dbUtil.getTableName(drillCompletion.getClass());
			syncDataService.syncUpdate(mapDtoToEntity.transformBO(existingDrillCompletionDtoList.get(count), DrillCompletion.class), drillCompletion);
			attachmentService.softDelete(drillCompletion.getId(), dbUtil.getTableName(drillCompletion.getClass()));
			attendanceService.softDeleteByMaster(id, origin);
			officeReviewService.softDeleteByMaster(id, origin);
			count++;
		}
		List<DrillCompletion> drillCompletionList = drillCompletionDao.findAllDrillCompletion();
		LOGGER.debug("DrillCompletionServiceImpl -- softDelete -- End");
		return mapEntityToDto.transformListOfBO(drillCompletionList, DrillCompletionDto.class);
	}
	
	@Override
	public DrillCompletionDto update(String drillCompletionDetails, Map<String, MultipartFile[]> attachments) throws Exception {
		LOGGER.debug("DrillCompletionServiceImpl -- update -- Start");
		ObjectMapper mapper = new ObjectMapper();
		DrillCompletionDto drillCompletionDto = mapper.readValue(drillCompletionDetails, DrillCompletionDto.class);
		//StaffDto staffDto = staffDetailsDto.getStaff();
		commonUtil.stringNullValidator(drillCompletionDto.getId(),"Id");
		List<DrillCompletion> existingDrillCompletionList = drillCompletionDao.uniqueCheckForUpdate(drillCompletionDto.getJobStatus(), drillCompletionDto.getId());
		if(!existingDrillCompletionList.isEmpty())
			throw new ApplicationServiceExecption("DrillCompletion already exist", HttpStatus.BAD_REQUEST);
		
		DrillCompletion drillCompletion = drillCompletionDao.findByIdAndStatusNot(drillCompletionDto.getId(), commonUtil.getSoftDeleteStatus());
		//DrillScheduler drillScheduler=drillSchedulerDao.findByIdAndStatusNot(drillCompletionDto.getId(),commonUtil.getSoftDeleteStatus());
		if (drillCompletion == null) 
			throw new ApplicationServiceExecption("DrillCompletion not found", HttpStatus.BAD_REQUEST);

		
		/*if(drillCompletion.getCarriedOutDate().compareTo(drillScheduler.getLastDoneDate()) != 0)
			throw new ApplicationServiceExecption("Remove the records which are added after this drillCompletion", HttpStatus.BAD_REQUEST);*/
		DrillCompletionDto existingDrillCompletionDto = mapEntityToDto.transformBO(drillCompletion, DrillCompletionDto.class);
		drillCompletion = mapDtoToEntity.transformBO(drillCompletionDto, DrillCompletion.class);
		drillCompletion.setUpdateTime(new Date());
		AttachmentDto attachmentDto = new AttachmentDto();
		attachmentDto.setAttachmentOrigin(dbUtil.getTableName(drillCompletion.getClass()));
		attachmentDto.setRecordId(drillCompletion.getId());
		attachmentDto.setAttachmentType(drillCompletionDto.getDrillCompletionDocFieldName());
		List<String> attachmentPathList = attachmentService.findAttachments(attachmentDto);
		String id=drillCompletion.getId();
		String origin=dbUtil.getTableName(drillCompletion.getClass());
		
		drillCompletionDao.saveAndFlush(drillCompletion);
		syncDataService.syncUpdate(mapDtoToEntity.transformBO(existingDrillCompletionDto, DrillCompletion.class), drillCompletion);
		
//		staffDetailsDto.setStaff(mapEntityToDto.transformBO(drillCompletion, StaffDto.class));
		
		/**********************Attendance ********************/
		List<String> attendanceIds = drillCompletionDto.getAttendanceIds();
		if(!attendanceIds.isEmpty())
			attendanceService.softDelete(attendanceIds);
		
		List<AttendanceDto> attendanceDtoList = drillCompletionDto.getAttendanceDtoList();
		attendanceDtoList = attendanceService.updateAll(id,origin,attendanceDtoList);
		drillCompletionDto.setAttendanceDtoList(attendanceDtoList);
		
		/**********************Office Review ********************/
		List<String> officeReviewIds = drillCompletionDto.getOfficeReviewIds();
		if(!officeReviewIds.isEmpty())
			officeReviewService.softDelete(officeReviewIds);
		
		List<OfficeReviewDto> officeReviewDtoList = drillCompletionDto.getOfficeReviewDtoList();
		officeReviewDtoList = officeReviewService.updateAll( id,origin,officeReviewDtoList, attachments.get("officeReviewAtch"));
		drillCompletionDto.setOfficeReviewDtoList(officeReviewDtoList);
		drillSchedulerService.updationAtDrillCompletion(drillCompletion);
		drillCompletionDto.setDrillCompletionDoc(attachmentPathList);
		LOGGER.debug("DrillCompletionServiceImpl -- update -- End");
		return drillCompletionDto;
		
	}

}
