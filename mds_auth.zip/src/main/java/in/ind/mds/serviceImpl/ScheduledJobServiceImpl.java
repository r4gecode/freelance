/**
 * 
 */
package in.ind.mds.serviceImpl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.time.DateUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import in.ind.mds.dto.AttachmentDto;
import in.ind.mds.dto.ComponentDto;
import in.ind.mds.dto.ScheduledJobDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.repo.dao.ScheduledJobDao;
import in.ind.mds.repo.entity.Component;
import in.ind.mds.repo.entity.JobCompletion;
import in.ind.mds.repo.entity.ScheduledJob;
import in.ind.mds.service.AttachmentService;
import in.ind.mds.service.ScheduledJobService;
import in.ind.mds.service.SyncDataService;
import in.ind.mds.util.BeanTransformerUtil;
import in.ind.mds.util.CommonUtil;
import in.ind.mds.util.DBUtil;
import in.ind.mds.enums.FreequencyTypes;

/**
 * @author mds-arockia
 *
 */
@Service("TST_MSSQL_SCHEDULED_JOB")
public class ScheduledJobServiceImpl implements ScheduledJobService {

	private static final Logger LOGGER = LoggerFactory.getLogger(ScheduledJobServiceImpl.class);

	@Autowired
	private BeanTransformerUtil<ScheduledJob, ScheduledJobDto> mapEntityToDto;

	@Autowired
	private BeanTransformerUtil<ScheduledJobDto, ScheduledJob> mapDtoToEntity;

	@Autowired
	private BeanTransformerUtil<ComponentDto, Component> mapDtoToEntityComponent;

	@Autowired
	@Qualifier("TST_MSSQL_SYNC")
	private SyncDataService syncDataService;

	@Autowired
	private ScheduledJobDao scheduledJobDao;

	@Autowired
	@Qualifier("TST_MSSQL_ATTACHEMENT")
	private AttachmentService attachmentService;

	@Autowired
	private DBUtil dbUtil;

	@Autowired
	private CommonUtil<ScheduledJobDto> commonUtil;

	@Override
	public ScheduledJobDto add(String scheduledJobDetails, MultipartFile[] attachmentFiles) throws Exception {
		LOGGER.debug("ScheduledJobServiceImpl -- add -- start");
		ScheduledJobDto scheduledJobDto = commonUtil.stringJsonToEntity(scheduledJobDetails, ScheduledJobDto.class);
		ScheduledJob scheduledJob = mapDtoToEntity.transformBO(scheduledJobDto, ScheduledJob.class);
		String seqName = dbUtil.getNextSequence(scheduledJob.getClass());
		if (seqName != null)
			scheduledJob.setId(seqName);

		scheduledJob.setInsertTime(new Date());
		scheduledJob.setUpdateTime(new Date());
		scheduledJob.setStatus(commonUtil.getActiveStatus());
		AttachmentDto attachmentDto = new AttachmentDto();
		attachmentDto.setRecordId(scheduledJob.getId());
		attachmentDto.setAttachmentOrigin(dbUtil.getTableName(scheduledJob.getClass()));
		attachmentDto.setAttachmentType(scheduledJobDto.getScheduledJobAtchFieldName());
		List<String> attachmentPathList = attachmentService.add(attachmentDto, Arrays.asList(attachmentFiles));
		scheduledJobDao.save(scheduledJob);
		syncDataService.syncCreation(scheduledJob);
		scheduledJobDto = mapEntityToDto.transformBO(scheduledJob, ScheduledJobDto.class);
		scheduledJobDto.setScheduledJobAtch(attachmentPathList);
		LOGGER.debug("ScheduledJobServiceImpl -- add -- end");
		return scheduledJobDto;
	}

	@Override
	public ScheduledJobDto update(String scheduledJobDetails, MultipartFile[] attachmentFiles) throws Exception {
		LOGGER.debug("ScheduledJobServiceImpl -- update -- start");
		ScheduledJobDto scheduledJobDto = commonUtil.stringJsonToEntity(scheduledJobDetails, ScheduledJobDto.class);
		commonUtil.stringNullValidator(scheduledJobDto.getId());
		ScheduledJob scheduledJob = scheduledJobDao.findByIdAndStatusNot(scheduledJobDto.getId(),
				commonUtil.getSoftDeleteStatus());
		if (scheduledJob == null)
			throw new ApplicationServiceExecption("ScheduledJob not found", HttpStatus.BAD_REQUEST);

		ScheduledJobDto existingScheduledJobDto = mapEntityToDto.transformBO(scheduledJob, ScheduledJobDto.class);
		scheduledJob = mapDtoToEntity.transformBO(scheduledJobDto, ScheduledJob.class);
		scheduledJob.setUpdateTime(new Date());
		scheduledJobDao.save(scheduledJob);
		syncDataService.syncUpdate(mapDtoToEntity.transformBO(existingScheduledJobDto, ScheduledJob.class),
				scheduledJob);
		AttachmentDto attachmentDto = new AttachmentDto();
		attachmentDto.setAttachmentOrigin(dbUtil.getTableName(scheduledJob.getClass()));
		attachmentDto.setRecordId(scheduledJob.getId());
		attachmentDto.setAttachmentType(scheduledJobDto.getScheduledJobAtchFieldName());
		List<String> attachmentPathList = attachmentService.findAttachments(attachmentDto);
		scheduledJobDto.setScheduledJobAtch(attachmentPathList);
		LOGGER.debug("ScheduledJobServiceImpl -- update -- end");
		return scheduledJobDto;
	}

	@Override
	public ScheduledJobDto findById(String id) throws Exception {
		LOGGER.debug("ScheduledJobServiceImpl -- findById -- start");
		commonUtil.stringNullValidator(id, "ScheduledJob Id");
		ScheduledJob scheduledJob = scheduledJobDao.findByIdAndStatusNot(id, commonUtil.getSoftDeleteStatus());
		if (scheduledJob == null)
			throw new ApplicationServiceExecption("ScheduledJob not found", HttpStatus.BAD_REQUEST);

		ScheduledJobDto scheduledJobDto = mapEntityToDto.transformBO(scheduledJob, ScheduledJobDto.class);
		AttachmentDto attachmentDto = new AttachmentDto();
		attachmentDto.setAttachmentOrigin(dbUtil.getTableName(scheduledJob.getClass()));
		attachmentDto.setRecordId(scheduledJob.getId());
		attachmentDto.setAttachmentType(scheduledJobDto.getScheduledJobAtchFieldName());
		List<String> attachmentPathList = attachmentService.findAttachments(attachmentDto);
		scheduledJobDto.setScheduledJobAtch(attachmentPathList);
		LOGGER.debug("ScheduledJobServiceImpl -- findById -- end");
		return scheduledJobDto;
	}

	@Override
	public List<ScheduledJobDto> findAll() throws Exception {
		LOGGER.debug("ScheduledJobServiceImpl -- findAll -- start");
		List<ScheduledJob> scheduledJobList = scheduledJobDao.findAllScheduledJob();
		if (scheduledJobList.isEmpty())
			throw new ApplicationServiceExecption("No Scheduled Job found", HttpStatus.BAD_REQUEST);

		LOGGER.debug("ScheduledJobServiceImpl -- findAll -- end");
		return mapEntityToDto.transformListOfBO(scheduledJobList, ScheduledJobDto.class);
	}

	@Override
	public List<ScheduledJobDto> softDelete(List<String> ids) throws Exception {
		LOGGER.debug("ScheduledJobServiceImpl -- softDelete -- start");
		commonUtil.stringNullValidator(ids.toArray(), "Scheduled Id");
		List<ScheduledJob> scheduledJobList = scheduledJobDao.findByIdInAndStatusNot(ids,
				commonUtil.getSoftDeleteStatus());
		if (scheduledJobList.size() < ids.size())
			throw new ApplicationServiceExecption("Scheduled Job not found", HttpStatus.BAD_REQUEST);

		List<ScheduledJobDto> scheduledJobDtoList = mapEntityToDto.transformListOfBO(scheduledJobList,
				ScheduledJobDto.class);
		for (ScheduledJob scheduledJob : scheduledJobList) {
			scheduledJob.setUpdateTime(new Date());
			scheduledJob.setStatus(commonUtil.getSoftDeleteStatus());
		}
		scheduledJobDao.saveAll(scheduledJobList);
		Integer count = 0;
		for (ScheduledJob scheduledJob : scheduledJobList) {
			syncDataService.syncUpdate(mapDtoToEntity.transformBO(scheduledJobDtoList.get(count), ScheduledJob.class),
					scheduledJob);
			count++;
		}
		scheduledJobList = scheduledJobDao.findAllScheduledJob();
		LOGGER.debug("ScheduledJobServiceImpl -- softDelete -- end");
		return mapEntityToDto.transformListOfBO(scheduledJobList, ScheduledJobDto.class);
	}

	@Override
	public void updationAtJobCompletion(JobCompletion jobCompletion) throws Exception {
		ScheduledJob scheduledJob = scheduledJobDao.findByIdAndStatusNot(jobCompletion.getScheduledJob().getId(),
				commonUtil.getSoftDeleteStatus());
		if (scheduledJob == null)
			throw new ApplicationServiceExecption("Related Scheduled Job not found for Job Completion",
					HttpStatus.BAD_REQUEST);

		ScheduledJobDto scheduledJobDto = mapEntityToDto.transformBO(scheduledJob, ScheduledJobDto.class);
		scheduledJob.setLastDoneDate(jobCompletion.getCompletedDate());
		Date nextDueDate = jobCompletion.getCompletedDate();
		if (scheduledJob.getFrequencyType().equals(FreequencyTypes.DAYS.getNames()))
			DateUtils.addDays(nextDueDate, (int) (scheduledJob.getToFrequency() / scheduledJob.getAvgRunningHour()));
		else if (scheduledJob.getFrequencyType().equals(FreequencyTypes.DAYS.getNames()))
			DateUtils.addDays(nextDueDate, scheduledJob.getToFrequency());
		else if (scheduledJob.getFrequencyType().equals(FreequencyTypes.WEEKS.getNames()))
			DateUtils.addWeeks(nextDueDate, scheduledJob.getToFrequency());
		else if (scheduledJob.getFrequencyType().equals(FreequencyTypes.MONTHS.getNames()))
			DateUtils.addMonths(nextDueDate, scheduledJob.getToFrequency());
		else if (scheduledJob.getFrequencyType().equals(FreequencyTypes.YEARS.getNames()))
			DateUtils.addYears(nextDueDate, scheduledJob.getToFrequency());
		else if (scheduledJob.getFrequencyType().equals(FreequencyTypes.RANGEHOURS.getNames()))
			DateUtils.addDays(nextDueDate, (int) (scheduledJob.getToFrequency() / scheduledJob.getAvgRunningHour()));

		scheduledJob.setNextDueDate(nextDueDate);
		scheduledJob.setUpdateTime(new Date());
		scheduledJobDao.save(scheduledJob);
		syncDataService.syncUpdate(mapDtoToEntity.transformBO(scheduledJobDto, ScheduledJob.class), scheduledJob);
	}

	@Override
	public void updationAtAddRH(List<ScheduledJobDto> scheduledJobDtoList) throws Exception {

		List<ScheduledJob> newListofScheduledJob = new ArrayList<>();
		List<ScheduledJobDto> existingListofScheduledJobDto = new ArrayList<>();
		for (ScheduledJobDto scheduledJobDto : scheduledJobDtoList) {
			List<ScheduledJob> scheduledJobList = scheduledJobDao.findByComponent(
					mapDtoToEntityComponent.transformBO(scheduledJobDto.getComponent(), Component.class));
			if (!scheduledJobList.isEmpty()) {
				existingListofScheduledJobDto.addAll(mapEntityToDto.transformListOfBO(scheduledJobList, ScheduledJobDto.class));
				for (ScheduledJob scheduledJob : scheduledJobList) {
					scheduledJob.setTotalRH(scheduledJobDto.getTotalRH());
					scheduledJob.setAvgRunningHour(scheduledJobDto.getAvgRunningHour());
					scheduledJob.setTotalNODComponentRun(scheduledJobDto.getTotalNODComponentRun());
					scheduledJob.setRhFromLastCompletion(
							scheduledJob.getRhFromLastCompletion() + scheduledJobDto.getRhFromLastCompletion());
					if(scheduledJob.getLastDoneDate() != null && scheduledJob.getFrequencyType().equals(FreequencyTypes.HOURS.getNames()) && scheduledJob.getFrequencyType().equals(FreequencyTypes.RANGEHOURS.getNames())) 
						scheduledJob.setNextDueDate(DateUtils.addDays(scheduledJob.getLastDoneDate(), (int) (scheduledJob.getFromFrequency()/scheduledJob.getAvgRunningHour())));
					
				}
				newListofScheduledJob.addAll(scheduledJobList);
			}
		}
		scheduledJobDao.saveAll(newListofScheduledJob);
		Integer count = 0;
		for (ScheduledJob scheduledJob : newListofScheduledJob) {
			syncDataService.syncUpdate(mapDtoToEntity.transformBO(existingListofScheduledJobDto.get(count), ScheduledJob.class),scheduledJob);
			count ++;
		}
	}

}
