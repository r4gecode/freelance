package in.ind.mds.serviceImpl;

import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import in.ind.mds.dto.MenuDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.repo.dao.MenuDao;
import in.ind.mds.repo.entity.Menu;
import in.ind.mds.service.MenuService;
import in.ind.mds.service.SyncDataService;
import in.ind.mds.util.BeanTransformerUtil;
import in.ind.mds.util.CommonUtil;
import in.ind.mds.util.DBUtil;

@Service("TST_MSSQL_MENU")

public class MenuServiceImpl implements MenuService {
	private static final Logger LOGGER = LoggerFactory.getLogger(MenuServiceImpl.class);

	@Autowired
	private BeanTransformerUtil<Menu, MenuDto> mapEntityToDto;

	@Autowired
	private BeanTransformerUtil<MenuDto, Menu> mapDtoToEntity;

	@Autowired
	@Qualifier("TST_MSSQL_SYNC")
	private SyncDataService syncDataService;
	/*
	 * @Autowired private UserValidator validator;
	 */
	@Autowired
	private CommonUtil<MenuDto> commonUtil;

	@Autowired
	private MenuDao menuDao;

	@Autowired
	private DBUtil dbUtil;

	public MenuDto findByMenuDescAndMenuUrl(final String menuDesc, final String menuUrl) throws Exception {
		LOGGER.debug("MenuServiceImpl -- getByEmailAndPassword -- Start");
		commonUtil.stringNullValidator(menuDesc, menuUrl, "MenuDesc and MenuUrl");

		Menu menu = menuDao.findByMenuDescAndMenuUrlAndStatusNot(menuDesc, menuUrl, commonUtil.getSoftDeleteStatus());

		if (menu == null)
			throw new ApplicationServiceExecption("User not found", HttpStatus.NOT_FOUND);

		final MenuDto dto = mapEntityToDto.transformBO(menu, MenuDto.class);
		LOGGER.debug("MenuServiceImpl -- getByMenuDescAndMenuUrl -- End");
		return dto;
	}

	public MenuDto getByMenuId(final String menuId) throws Exception {
		LOGGER.debug("MenuServiceImpl -- getByMenuId -- Start");
		commonUtil.stringNullValidator(menuId, "MenuId");

		final Menu menu = menuDao.findByIdAndStatusNot(menuId, commonUtil.getSoftDeleteStatus());

		if (menu == null)
			throw new ApplicationServiceExecption("Error menu not found", HttpStatus.NOT_FOUND);

		/*
		 * Date date = user.getServerTime(); Date currentDate = new
		 * Date(System.currentTimeMillis());
		 * 
		 * if (date.before(currentDate) || date.after(currentDate)) {
		 * user.setServerTime(currentDate); userDao.save(user); }
		 */
		final MenuDto dto = mapEntityToDto.transformBO(menu, MenuDto.class);

		LOGGER.debug("MenuServiceImpl -- getByMenuId -- End");
		return dto;
	}

	@Override
	public MenuDto findByMenuCode(final String menuCode) throws Exception {
		LOGGER.debug("MenuServiceImpl -- getByMenuCode -- Start");
		commonUtil.stringNullValidator(menuCode, "Menucode");

		final Menu menu = menuDao.findByMenuCodeAndStatusNot(menuCode, commonUtil.getSoftDeleteStatus());

		if (menu == null)
			throw new ApplicationServiceExecption("Error menu not found", HttpStatus.NOT_FOUND);

		/*
		 * Date date = user.getServerTime(); Date currentDate = new
		 * Date(System.currentTimeMillis());
		 * 
		 * if (date.before(currentDate) || date.after(currentDate)) {
		 * user.setServerTime(currentDate); userDao.save(user); }
		 */
		final MenuDto dto = mapEntityToDto.transformBO(menu, MenuDto.class);

		LOGGER.debug("MenuServiceImpl -- getByMenuCode -- End");
		return dto;
	}

	@Override
	public List<MenuDto> findAll() throws Exception {
		LOGGER.debug("MenuServiceImpl -- findByMenuType -- Start");
		List<Menu> menu = menuDao.findAllMenu();

		if (menu.size() == 0)
			throw new ApplicationServiceExecption("Menu not found", HttpStatus.NOT_FOUND);

		final List<MenuDto> dto = mapEntityToDto.transformListOfBO(menu, MenuDto.class);
		LOGGER.debug("MenuServiceImpl -- findByMenuType -- End");
		return dto;
	}

	@Override
	public MenuDto add(MenuDto menuDto) throws Exception {
		LOGGER.debug("PortServiceImpl -- add -- Start");
		// final String errorMessage = validator.validateAdd(userDto);
		// if (errorMessage != null) {
		// throw new GaurageServiceException(errorMessage, HttpStatus.BAD_REQUEST);
		// }
		/*
		 * Optional<Menu> existingMenu = menuDao.findById(menuDto.getId()); if
		 * (existingMenu.isPresent()) { throw new
		 * ApplicationServiceExecption("Menu exist", HttpStatus.BAD_REQUEST); }
		 */
		commonUtil.stringNullValidator(menuDto.getMenuCode(), menuDto.getMenuDesc(), "Menu Code and Desc");
		List<Menu> menus = menuDao.uniqueCheckForAdd(menuDto.getMenuDesc(), menuDto.getMenuCode());
		if (menus.size() != 0)
			throw new ApplicationServiceExecption("Menu already exist", HttpStatus.BAD_REQUEST);

		Menu menu = mapDtoToEntity.transformBO(menuDto, Menu.class);

		String seqName = dbUtil.getNextSequence(menu.getClass());
		if (seqName != null)
			menu.setId(seqName);

		menu.setInsertTime(new Date());
		menu.setUpdateTime(new Date());
		menu.setStatus(commonUtil.getActiveStatus());
		menu = menuDao.save(menu);
		syncDataService.syncCreation(menu);
		LOGGER.debug("MenuServiceImpl -- add -- End");
		return mapEntityToDto.transformBO(menu, MenuDto.class);
	}

	@Override
	public List<MenuDto> softDeleteMenu(List<String> menuIds) throws Exception {
		LOGGER.debug("MenuServiceImpl -- delete -- Start");
		// final String errorMessage = validator.validateAdd(userDto);
		// if (errorMessage != null) {
		// throw new GaurageServiceException(errorMessage, HttpStatus.BAD_REQUEST);
		// }
		commonUtil.stringNullValidator(menuIds.toArray(), "MenuId");
		List<Menu> existingMenuList = menuDao.findByIdInAndStatusNot(menuIds, commonUtil.getSoftDeleteStatus());
		if (existingMenuList.size() < menuIds.size())
			throw new ApplicationServiceExecption("Menu not found", HttpStatus.BAD_REQUEST);

		List<MenuDto> existingMenuDtoList = mapEntityToDto.transformListOfBO(existingMenuList, MenuDto.class);
		for (Menu menu : existingMenuList) {
			menu.setStatus(commonUtil.getSoftDeleteStatus());
			menu.setUpdateTime(new Date());
		}
		existingMenuList = menuDao.saveAll(existingMenuList);
		Integer count = 0;
		for (Menu menu : existingMenuList) {
			syncDataService.syncUpdate(mapDtoToEntity.transformBO(existingMenuDtoList.get(count), Menu.class), menu);
			count++;
		}
		existingMenuList = menuDao.findAllMenu();
		LOGGER.debug("MenuServiceImpl -- delete -- End");
		return mapEntityToDto.transformListOfBO(existingMenuList, MenuDto.class);
	}

	@Override
	public MenuDto updateMenu(MenuDto menuDto) throws Exception {
		LOGGER.debug("MenuServiceImpl -- update -- Start");
		// final String errorMessage = validator.validateAdd(userDto);
		// if (errorMessage != null) {
		// throw new GaurageServiceException(errorMessage, HttpStatus.BAD_REQUEST);
		// }
		commonUtil.stringNullValidator(menuDto.getMenuDesc(), menuDto.getMenuCode(), menuDto.getId(),
				"Menu Id, Code and Desc");
		List<Menu> existingMenus = menuDao.uniqueCheckForUpdate(menuDto.getMenuDesc(), menuDto.getMenuCode(),
				menuDto.getId());
		if (existingMenus.size() != 0)
			throw new ApplicationServiceExecption("Menu already exist", HttpStatus.BAD_REQUEST);

		Menu existingMenu = menuDao.findByIdAndStatusNot(menuDto.getId(), commonUtil.getSoftDeleteStatus());
		if (existingMenu == null)
			throw new ApplicationServiceExecption("Menu not found", HttpStatus.BAD_REQUEST);

		MenuDto existingMenuDto = mapEntityToDto.transformBO(existingMenu, MenuDto.class);
		Menu menu = mapDtoToEntity.transformBO(menuDto, Menu.class);
		menu.setUpdateTime(new Date());
		menu = menuDao.saveAndFlush(menu);
		syncDataService.syncUpdate(mapDtoToEntity.transformBO(existingMenuDto, Menu.class), menu);
		LOGGER.debug("MenuServiceImpl -- update -- End");
		return mapEntityToDto.transformBO(menu, MenuDto.class);
	}

}
