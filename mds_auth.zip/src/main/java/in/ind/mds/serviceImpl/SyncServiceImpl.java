package in.ind.mds.serviceImpl;

import java.lang.reflect.Method;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;

import in.ind.mds.dto.SyncDataDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.repo.dao.SyncDataDao;
import in.ind.mds.repo.entity.SyncData;
import in.ind.mds.service.SyncDataService;
import in.ind.mds.util.BeanTransformerUtil;
import in.ind.mds.util.CommonUtil;

@Service("TST_MSSQL_SYNC")
public class SyncServiceImpl implements SyncDataService {
	private static final Logger LOGGER = LoggerFactory.getLogger(SyncServiceImpl.class);

	@Autowired
	private BeanTransformerUtil<SyncData, SyncDataDto> mapEntityToDto;

	@Autowired
	private BeanTransformerUtil<SyncDataDto, SyncData> mapDtoToEntity;

	@Autowired
	private SyncDataDao syncDataDao;

	@Autowired
	private ObjectMapper mapper;


	private SyncData populateSyncRecord(String action, String entityClassName, String fleetWideSync, String vesselId,
			String syncData) {
		SyncData sync = new SyncData();
		sync.setSyncData(syncData);
		sync.setAction(action);
		sync.setEntityClassName(entityClassName);
		sync.setFleetWideSync(fleetWideSync);
		sync.setOrigin("F"); // TODO : Get this value from config
		sync.setSyncModule("USER");// TODO : get from config if required
		sync.setVesselId(vesselId);
		sync.setInsertedBy(123);// TODO : get from session
		sync.setUpdatedBy(123);// TODO : get from session
		sync.setInsertTime(new Date());
		sync.setUpdateTime(new Date());
		sync.setUtcTime(CommonUtil.getUTCTime());
		return sync;
	}

	@Override
	public SyncDataDto syncCreation(Object entity) throws Exception {
		LOGGER.debug("SyncServiceImpl -- syncCreation -- Start");
		String jsonInString = null;
		SyncData syncData = null;
		String vesselId = null;

		jsonInString = mapper.writeValueAsString(entity);
		vesselId = getVesselId(entity);
		syncData = populateSyncRecord("A", entity.getClass().getName(), (vesselId == null)?"Y":"N", vesselId, jsonInString);

		final SyncDataDto dto = mapEntityToDto.transformBO(syncData, SyncDataDto.class);
		createSyncRecord(syncData);
		LOGGER.debug("SyncServiceImpl -- syncCreation -- End");
		return dto;
	}

	@Override
	public SyncDataDto syncUpdate(Object oldEntity, Object newEntity) throws Exception {
		LOGGER.debug("SyncServiceImpl -- syncUpdate -- Start");
		StringBuilder updatedData = null;
		String vesselId = null;
		SyncDataDto dto = null;
		if (SyncData.class.isInstance(oldEntity)) {
			throw new ApplicationServiceExecption("Object casting exception", HttpStatus.EXPECTATION_FAILED);
		}
		updatedData = CommonUtil.getDeltaChange(newEntity, oldEntity);
		if (!CommonUtil.isNullOrEmpty(updatedData.toString())) {
			// Get Fleetwide sync from entity
			// get VesselId from entity
			vesselId = getVesselId(newEntity);
			SyncData syncData = populateSyncRecord("U", newEntity.getClass().getName(), (vesselId == null)?"Y":"N", vesselId,
					updatedData.toString());
			dto = mapEntityToDto.transformBO(syncData, SyncDataDto.class);
			createSyncRecord(syncData);
		}
		LOGGER.debug("SyncServiceImpl -- syncUpdate -- End");
		return dto;
	}

	@Override
	public String getVesselId(Object newEntity) throws Exception {
		LOGGER.debug("SyncServiceImpl -- getVesselId -- Start");
		String vesselId = null;
		try {
			Method method = newEntity.getClass().getDeclaredMethod("getVesselId", null);
			Object obj = method.invoke(newEntity, null);
			vesselId = obj.toString();
		} catch (Exception e) {
			e.printStackTrace();// TODO :Exception logging
		}
		LOGGER.debug("SyncServiceImpl -- getVesselId -- End");
		return vesselId;
	}

	@Override
	public SyncDataDto createSyncRecord(SyncData sync) throws Exception {
		LOGGER.debug("SyncServiceImpl -- createSyncRecord -- Start");
		if (sync == null) {
			throw new ApplicationServiceExecption("SyncData is null", HttpStatus.EXPECTATION_FAILED);
		}
		final SyncDataDto dto = mapEntityToDto.transformBO(sync, SyncDataDto.class);
		syncDataDao.save(sync);
		LOGGER.debug("SyncServiceImpl -- createSyncRecord -- End");
		return dto;
	}

	@Override
	public boolean exportSyncDataList(String vesselId) throws Exception {
		LOGGER.debug("SyncServiceImpl -- exportSyncDataList -- Start");
		List<SyncData> syncDataList = syncDataDao.findAll();

		if (syncDataList == null) {
			throw new ApplicationServiceExecption("SyncDataList is null", HttpStatus.EXPECTATION_FAILED);
		}
		/*String listString = syncDataList.stream().map(Object::toString)
                .collect(Collectors.joining("| "));
		*/
		StringBuilder syncDataOutput = new StringBuilder();
		for (SyncData data : syncDataList) {
			syncDataOutput.append(data.getAction() + "|" + data.getSyncData());
			syncDataOutput.append("\t");
		}

		Path file = Paths.get("file1.txt");
		boolean isReadble = Files.isReadable(file);
		Files.write(file, syncDataOutput.toString().getBytes("UTF-8"));
		LOGGER.debug("SyncServiceImpl -- exportSyncDataList -- End");
		return isReadble;
	}

	@Override
	public boolean exportSyncDataList(String vesselId, String syncType) throws Exception {
		// TODO Auto-generated method stub
		return false;
	}

}
