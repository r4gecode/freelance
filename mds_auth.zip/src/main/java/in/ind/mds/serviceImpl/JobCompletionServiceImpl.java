/**
 * 
 */
package in.ind.mds.serviceImpl;

import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import in.ind.mds.dto.AttachmentDto;
import in.ind.mds.dto.JobCompletionDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.repo.dao.JobCompletionDao;
import in.ind.mds.repo.dao.ScheduledJobDao;
import in.ind.mds.repo.entity.JobCompletion;
import in.ind.mds.repo.entity.ScheduledJob;
import in.ind.mds.service.AttachmentService;
import in.ind.mds.service.JobCompletionService;
import in.ind.mds.service.ScheduledJobService;
import in.ind.mds.service.SyncDataService;
import in.ind.mds.util.BeanTransformerUtil;
import in.ind.mds.util.CommonUtil;
import in.ind.mds.util.DBUtil;

/**
 * @author mds-arockia
 *
 */
@Service("TST_MSSQL_JOB_COMPLETION")
public class JobCompletionServiceImpl implements JobCompletionService{

	private static final Logger LOGGER = LoggerFactory.getLogger(JobCompletionServiceImpl.class);

	@Autowired
	private BeanTransformerUtil<JobCompletion, JobCompletionDto> mapEntityToDto;

	@Autowired
	private BeanTransformerUtil<JobCompletionDto, JobCompletion> mapDtoToEntity;
	
	@Autowired
	@Qualifier("TST_MSSQL_SYNC")
	private SyncDataService syncDataService;
	
	@Autowired
	private JobCompletionDao jobCompletionDao;
	
	@Autowired
	@Qualifier("TST_MSSQL_SCHEDULED_JOB")
	private ScheduledJobService scheduledJobService;
	
	@Autowired
	private ScheduledJobDao scheduledJobDao;
	
	@Autowired
	@Qualifier("TST_MSSQL_ATTACHEMENT")
	private AttachmentService attachmentService;
	
	@Autowired
	private DBUtil dbUtil;
	
	@Autowired
	private CommonUtil<JobCompletionDto> commonUtil;
	
	@Override
	public JobCompletionDto add(String jobCompletionDetails, MultipartFile[] attachmentFiles) throws Exception {
		LOGGER.debug("JobCompletionServiceImpl -- add -- start");
		JobCompletionDto jobCompletionDto = commonUtil.stringJsonToEntity(jobCompletionDetails, JobCompletionDto.class);
		JobCompletion jobCompletion = mapDtoToEntity.transformBO(jobCompletionDto, JobCompletion.class);
		String seqName = dbUtil.getNextSequence(jobCompletion.getClass());
		if(seqName != null)
			jobCompletion.setId(seqName);
		
		jobCompletion.setInsertTime(new Date());
		jobCompletion.setUpdateTime(new Date());
		
		AttachmentDto attachmentDto = new AttachmentDto();
		attachmentDto.setRecordId(jobCompletion.getId());
		attachmentDto.setAttachmentOrigin(dbUtil.getTableName(jobCompletion.getClass()));
		attachmentDto.setAttachmentType(jobCompletionDto.getJobCompletionAtchFieldName());
		List<String> attachmentPathList = attachmentService.add(attachmentDto, Arrays.asList(attachmentFiles));
		jobCompletionDao.save(jobCompletion);
		syncDataService.syncCreation(jobCompletion);
		/********************update scheduled job dates********start***/
		scheduledJobService.updationAtJobCompletion(jobCompletion);

		jobCompletionDto = mapEntityToDto.transformBO(jobCompletion, JobCompletionDto.class);
		jobCompletionDto.setJobCompletionAtch(attachmentPathList);
		LOGGER.debug("JobCompletionServiceImpl -- add -- end");
		return jobCompletionDto;
	}

	@Override
	public JobCompletionDto update(String jobCompletionDetails, MultipartFile[] attachmentFiles) throws Exception {
		LOGGER.debug("JobCompletionServiceImpl -- update -- start");
		JobCompletionDto jobCompletionDto = commonUtil.stringJsonToEntity(jobCompletionDetails, JobCompletionDto.class);
		commonUtil.stringNullValidator(jobCompletionDto.getId());
		JobCompletion jobCompletion = jobCompletionDao.findByIdAndStatusNot(jobCompletionDto.getId(), commonUtil.getSoftDeleteStatus());
		if(jobCompletion == null)
			throw new ApplicationServiceExecption("JobCompletion not found", HttpStatus.BAD_REQUEST);
		
		ScheduledJob scheduledJob = scheduledJobDao.findByIdAndStatusNot(jobCompletion.getScheduledJob().getId(), commonUtil.getSoftDeleteStatus());
		if(jobCompletion.getCompletedDate().compareTo(scheduledJob.getLastDoneDate()) != 0)
			throw new ApplicationServiceExecption("Remove the records which are added after this JobCompletion", HttpStatus.BAD_REQUEST);
		
		JobCompletionDto existingJobCompletoinDto = mapEntityToDto.transformBO(jobCompletion, JobCompletionDto.class);
		
		jobCompletion = mapDtoToEntity.transformBO(jobCompletionDto, JobCompletion.class);
		jobCompletion.setUpdateTime(new Date());
		
		AttachmentDto attachmentDto = new AttachmentDto();
		attachmentDto.setAttachmentOrigin(dbUtil.getTableName(jobCompletion.getClass()));
		attachmentDto.setRecordId(jobCompletion.getId());
		attachmentDto.setAttachmentType(jobCompletionDto.getJobCompletionAtchFieldName());
		List<String> attachmentPathList = attachmentService.findAttachments(attachmentDto);
		
		jobCompletionDao.save(jobCompletion);
		syncDataService.syncUpdate(mapDtoToEntity.transformBO(existingJobCompletoinDto, JobCompletion.class), jobCompletion);
		/********************update scheduled job dates********start***/
		scheduledJobService.updationAtJobCompletion(jobCompletion);
		
		jobCompletionDto.setJobCompletionAtch(attachmentPathList);
		LOGGER.debug("JobCompletionServiceImpl -- update -- end");
		return null;
	}

	@Override
	public JobCompletionDto findById(String id) throws Exception {
		LOGGER.debug("JobCompletionServiceImpl -- findById -- start");
		commonUtil.stringNullValidator(id, "JobCompletion Id");
		JobCompletion jobCompletion = jobCompletionDao.findByIdAndStatusNot(id, commonUtil.getSoftDeleteStatus());
		if(jobCompletion == null)
			throw new ApplicationServiceExecption("JobCompletion not found", HttpStatus.BAD_REQUEST);
		
		JobCompletionDto jobCompletionDto = mapEntityToDto.transformBO(jobCompletion, JobCompletionDto.class);
		AttachmentDto attachmentDto = new AttachmentDto();
		attachmentDto.setAttachmentOrigin(dbUtil.getTableName(jobCompletion.getClass()));
		attachmentDto.setRecordId(jobCompletion.getId());
		attachmentDto.setAttachmentType(jobCompletionDto.getJobCompletionAtchFieldName());
		List<String> attachmentPathList = attachmentService.findAttachments(attachmentDto);
		jobCompletionDto.setJobCompletionAtch(attachmentPathList);
		LOGGER.debug("JobCompletionServiceImpl -- findById -- end");
		return jobCompletionDto;
	}

	@Override
	public List<JobCompletionDto> findAll() throws Exception {
		LOGGER.debug("JobCompletionServiceImpl -- findAll -- start");
		List<JobCompletion> jobCompletionList = jobCompletionDao.findAllJobCompletion();
		if(jobCompletionList.isEmpty())
			throw new ApplicationServiceExecption("No JobCompletion found");
		
		LOGGER.debug("JobCompletionServiceImpl -- findAll -- end");
		return mapEntityToDto.transformListOfBO(jobCompletionList, JobCompletionDto.class);
	}

	@Override
	public List<JobCompletionDto> softDelete(List<String> ids) throws Exception {
		LOGGER.debug("JobCompletionServiceImpl -- softDelete -- start");
		commonUtil.stringNullValidator(ids.toArray(), "JobCompletion Id");
		List<JobCompletion> jobCompletionList = jobCompletionDao.findByIdInAndStatusNot(ids, commonUtil.getSoftDeleteStatus());
		if(jobCompletionList.size() < ids.size())
			throw new ApplicationServiceExecption("JobCompletion not found", HttpStatus.BAD_REQUEST);
		
		List<JobCompletionDto> jobCompletionDtoList = mapEntityToDto.transformListOfBO(jobCompletionList, JobCompletionDto.class);
		for (JobCompletion jobCompletion : jobCompletionList) {
			jobCompletion.setUpdateTime(new Date());
			jobCompletion.setStatus(commonUtil.getSoftDeleteStatus());
		}
		jobCompletionDao.saveAll(jobCompletionList);
		Integer count = 0;
		for (JobCompletion jobCompletion : jobCompletionList) {
			syncDataService.syncUpdate(mapDtoToEntity.transformBO(jobCompletionDtoList.get(count), JobCompletion.class), jobCompletion);
			count++;
		}
		jobCompletionList = jobCompletionDao.findAllJobCompletion();
		LOGGER.debug("JobCompletionServiceImpl -- softDelete -- end");
		return mapEntityToDto.transformListOfBO(jobCompletionList, JobCompletionDto.class);
	}

}
