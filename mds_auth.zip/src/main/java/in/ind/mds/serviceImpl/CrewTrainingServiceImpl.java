/**
 * 
 */
package in.ind.mds.serviceImpl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import in.ind.mds.dto.AttachmentDto;
import in.ind.mds.dto.CrewContractDto;
import in.ind.mds.dto.CrewTrainingDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.repo.dao.CrewTrainingDao;
import in.ind.mds.repo.entity.CrewTraining;
import in.ind.mds.repo.entity.Staff;
import in.ind.mds.service.AttachmentService;
import in.ind.mds.service.CrewTrainingService;
import in.ind.mds.service.SyncDataService;
import in.ind.mds.util.BeanTransformerUtil;
import in.ind.mds.util.CommonUtil;
import in.ind.mds.util.DBUtil;

/**
 * @author mds-arockia
 *
 */
@Service("TST_MSSQL_CREW_TRAINING")
public class CrewTrainingServiceImpl implements CrewTrainingService{

	private static final Logger LOGGER = LoggerFactory.getLogger(CrewTrainingServiceImpl.class);

	@Autowired
	private BeanTransformerUtil<CrewTraining, CrewTrainingDto> mapEntityToDto;

	@Autowired
	private BeanTransformerUtil<CrewTrainingDto, CrewTraining> mapDtoToEntity;

	@Autowired
	@Qualifier("TST_MSSQL_SYNC")
	private SyncDataService syncDataService;

	@Autowired
	private CommonUtil<CrewContractDto> commonUtil;

	@Autowired
	private CrewTrainingDao crewTrainingDao;

	@Autowired
	@Qualifier("TST_MSSQL_ATTACHEMENT")
	private AttachmentService attachmentService;

	@Autowired
	private DBUtil dbUtil;
	
	@Override
	public List<CrewTrainingDto> add(Staff staff, List<CrewTrainingDto> trainingDtoList,
			MultipartFile[] attachmentFiles) throws Exception {
		LOGGER.debug("CrewTrainingServicImpl -- add -- start");
		trainingDtoList = addTraining(staff, trainingDtoList, attachmentFiles);
		LOGGER.debug("CrewTrainingServicImpl -- add -- end");
		return trainingDtoList;
	}

	@Override
	public List<CrewTrainingDto> update(Staff staff, List<CrewTrainingDto> trainingDtoList,
			MultipartFile[] attachmentFiles) throws Exception {
		LOGGER.debug("CrewTrainingServicImpl -- update -- start");
		List<CrewTrainingDto> trainingDtoListForAdd = new ArrayList<>();
		List<CrewTrainingDto> trainingDtoListForUpdate = new ArrayList<>();
		for (CrewTrainingDto trainingDto : trainingDtoList) {
			if(trainingDto.getId() == null)
				trainingDtoListForAdd.add(trainingDto);
			else
				trainingDtoListForUpdate.add(trainingDto);
		}
		if(!trainingDtoListForAdd.isEmpty())
			trainingDtoList = addTraining(staff, trainingDtoListForAdd, attachmentFiles);
		
		List<String> trainingIds = trainingDtoListForUpdate.stream().map(i -> i.getId()).collect(Collectors.toList());
		List<CrewTraining> trainingList = crewTrainingDao.findByIdInAndStatusNot(trainingIds, commonUtil.getSoftDeleteStatus());
		if(trainingList.size() < trainingIds.size())
			throw new ApplicationServiceExecption("CrewTraining not found");
		
		List<CrewTrainingDto> existingTrainingDtoList = mapEntityToDto.transformListOfBO(trainingList, CrewTrainingDto.class);
		trainingList = mapDtoToEntity.transformListOfBO(trainingDtoListForUpdate, CrewTraining.class);
		for (CrewTraining training : trainingList) {
			training.setUpdateTime(new Date());
		}
		/**********************delete and add attachments of CrewTraining********start**********/
		List<CrewTrainingDto> returnTrainingDtoList = mapEntityToDto.transformListOfBO(trainingList, CrewTrainingDto.class);
		Integer count = 0;
		for (CrewTrainingDto trainingDto : trainingDtoListForUpdate) {
			if(!trainingDto.getSoftDeleteDocPaths().isEmpty())
				attachmentService.softDeleteByPathList(trainingDto.getSoftDeleteDocPaths());
				
			List<MultipartFile> thisAttachmentFiles = new ArrayList<>();
				for (String trainingDoc : trainingDto.getTrainingDoc()) {
					//Integer index = 0;
					//Integer removeAttachmentIndex = null;
					for (MultipartFile attachment : attachmentFiles) {
						if(trainingDoc.equals(attachment.getOriginalFilename())) {
							thisAttachmentFiles.add(attachment); 
						//	removeAttachmentIndex = index;
						}
						//index++;
					}
					//ArrayUtils.remove(attachmentFiles, removeAttachmentIndex);
				}
			AttachmentDto attachmentDto = new AttachmentDto();
			attachmentDto.setRecordId(trainingList.get(count).getId());
			attachmentDto.setAttachmentOrigin(dbUtil.getTableName((mapDtoToEntity.transformBO(trainingDto, CrewTraining.class)).getClass()));
			attachmentDto.setAttachmentType(trainingDto.getTrainingDocFieldName());
			List<String> trainingDocPathList = attachmentService.add(attachmentDto, thisAttachmentFiles);
			returnTrainingDtoList.get(count).setTrainingDoc(trainingDocPathList);
			count++;
		}
		/**********************delete and add attachments of CrewTraining********end**********/
		crewTrainingDao.saveAll(trainingList);
		count = 0;
		for (CrewTraining training : trainingList) {
			syncDataService.syncUpdate(mapDtoToEntity.transformBO(existingTrainingDtoList.get(count), CrewTraining.class), training);
			count++;
		}
		trainingDtoList.addAll(trainingDtoListForUpdate);
		LOGGER.debug("CrewTrainingServicImpl -- update -- end");
		return trainingDtoList;
	}

	@Override
	public List<CrewTrainingDto> findByStaff(Staff staff) throws Exception {
		LOGGER.debug("CrewTrainingServicImpl -- findByStaff -- start");
		List<CrewTrainingDto> trainingDtoList = new ArrayList<>();
		List<CrewTraining> trainingList = crewTrainingDao.findByStaffAndStatusNot(staff, commonUtil.getSoftDeleteStatus());
		if(trainingList.isEmpty())
			return trainingDtoList;
		
		trainingDtoList = mapEntityToDto.transformListOfBO(trainingList, CrewTrainingDto.class);
		String attachmentOrigin = dbUtil.getTableName(trainingList.get(0).getClass());
		for (CrewTrainingDto trainingDto : trainingDtoList) {
			AttachmentDto attachmentDto = new AttachmentDto();
			attachmentDto.setAttachmentOrigin(attachmentOrigin);
			attachmentDto.setRecordId(trainingDto.getId());
			attachmentDto.setAttachmentType(trainingDto.getTrainingDocFieldName());
			trainingDto.setTrainingDoc(attachmentService.findAttachments(attachmentDto));
		}
		LOGGER.debug("CrewTrainingServicImpl -- findByStaff -- end");
		return trainingDtoList;
	}

	@Override
	public void softDeleteByStaff(Staff staff) throws Exception {
		LOGGER.debug("CrewTrainingServicImpl -- softDelete -- start");
		List<CrewTraining> trainingList = crewTrainingDao.findByStaffAndStatusNot(staff, commonUtil.getSoftDeleteStatus());
		List<CrewTrainingDto> trainingDtoList = mapEntityToDto.transformListOfBO(trainingList, CrewTrainingDto.class);
		for (CrewTraining training : trainingList) {
			training.setUpdateTime(new Date());
			training.setStatus(commonUtil.getSoftDeleteStatus());
		}
		Integer count = 0;
		for (CrewTraining training : trainingList) {
			syncDataService.syncUpdate(mapDtoToEntity.transformBO(trainingDtoList.get(count), CrewTraining.class), training);
			attachmentService.softDelete(training.getId(), dbUtil.getTableName(training.getClass()));
			count++;
		}
		LOGGER.debug("CrewTrainingServicImpl -- softDelete -- end");
	}

	@Override
	public void softDelete(List<String> ids) throws Exception {
		LOGGER.debug("CrewTrainingServicImpl -- softDelete -- start");
		commonUtil.stringNullValidator(ids.toArray(), "CrewTraining Id");
		List<CrewTraining> trainingList = crewTrainingDao.findByIdInAndStatusNot(ids, commonUtil.getSoftDeleteStatus());
		if(trainingList.size() <  ids.size())
			throw new ApplicationServiceExecption("CrewTraining not found");
		
		List<CrewTrainingDto> trainingDtoList = mapEntityToDto.transformListOfBO(trainingList, CrewTrainingDto.class);
		for (CrewTraining training : trainingList) {
			training.setUpdateTime(new Date());
			training.setStatus(commonUtil.getSoftDeleteStatus());
		}
		Integer count = 0;
		for (CrewTraining training : trainingList) {
			syncDataService.syncUpdate(mapDtoToEntity.transformBO(trainingDtoList.get(count), CrewTraining.class), training);
			attachmentService.softDelete(training.getId(), dbUtil.getTableName(training.getClass()));
			count++;
		}
		LOGGER.debug("CrewTrainingServicImpl -- softDelete -- end");
	}
	
	public List<CrewTrainingDto> addTraining(Staff staff, List<CrewTrainingDto> trainingDtoList, MultipartFile[] attachmentFiles) throws Exception{
		LOGGER.debug("CrewTrainingServicImpl -- addTrainingMethod -- start");
		List<CrewTraining> trainingList = mapDtoToEntity.transformListOfBO(trainingDtoList, CrewTraining.class);
		for (CrewTraining training : trainingList) {
			String seqName = dbUtil.getNextSequence(training.getClass());
			if(seqName != null)
				training.setId(seqName);
			
			training.setStaff(staff);
			training.setStatus(commonUtil.getActiveStatus());
			training.setInsertTime(new Date());
			training.setUpdateTime(new Date());
		}
		crewTrainingDao.saveAll(trainingList);
		for (CrewTraining training : trainingList) {
			syncDataService.syncCreation(training);
		}
		List<CrewTrainingDto> returnTrainingDtoList = mapEntityToDto.transformListOfBO(trainingList, CrewTrainingDto.class);
		Integer count = 0;
		for (CrewTrainingDto trainingDto : trainingDtoList) {
			List<MultipartFile> thisAttachmentFiles = new ArrayList<>();
				for (String trainingDoc : trainingDto.getTrainingDoc()) {
					//Integer index = 0;
					//Integer removeAttachmentIndex = null;
					for (MultipartFile attachment : attachmentFiles) {
						if(trainingDoc.equals(attachment.getOriginalFilename())) {
							thisAttachmentFiles.add(attachment); 
						//	removeAttachmentIndex = index;
						}
						//index++;
					}
					//ArrayUtils.remove(attachmentFiles, removeAttachmentIndex);
				}
			AttachmentDto attachmentDto = new AttachmentDto();
			attachmentDto.setRecordId(trainingList.get(count).getId());
			attachmentDto.setAttachmentOrigin(dbUtil.getTableName((mapDtoToEntity.transformBO(trainingDto, CrewTraining.class)).getClass()));
			attachmentDto.setAttachmentType(trainingDto.getTrainingDocFieldName());
			List<String> trainingDocPathList = attachmentService.add(attachmentDto, thisAttachmentFiles);
			returnTrainingDtoList.get(count).setTrainingDoc(trainingDocPathList);
			count++;
		}
		LOGGER.debug("CrewTrainingServicImpl -- addTrainingMethod -- end");
		return returnTrainingDtoList;
	}

}
