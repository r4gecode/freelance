/**
 * 
 */
package in.ind.mds.serviceImpl;

import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import in.ind.mds.dto.ManningAgentDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.repo.dao.ManningAgentDao;
import in.ind.mds.repo.entity.ManningAgent;
import in.ind.mds.service.ManningAgentService;
import in.ind.mds.service.SyncDataService;
import in.ind.mds.util.BeanTransformerUtil;
import in.ind.mds.util.CommonUtil;
import in.ind.mds.util.DBUtil;

/**
 * @author Hinaya
 *
 */
@Service("TST_MSSQL_MANNING_AGENT")
public class ManningAgentServiceImpl implements ManningAgentService{
	
	private static final Logger LOGGER = LoggerFactory.getLogger(ManningAgentServiceImpl.class);

	@Autowired
	private BeanTransformerUtil<ManningAgent, ManningAgentDto> mapEntityToDto;

	@Autowired
	private BeanTransformerUtil<ManningAgentDto, ManningAgent> mapDtoToEntity;

	@Autowired
	@Qualifier("TST_MSSQL_SYNC")
	private SyncDataService syncDataService;
	
	@Autowired
	private ManningAgentDao manningAgentDao;
	
	@Autowired
	private DBUtil dbUtil;
	
	@Autowired
	private CommonUtil<ManningAgentDto> commonUtil;




	@Override
	public ManningAgentDto getById(String manningAgentId) throws Exception {
		LOGGER.debug("ManningAgentServiceImpl -- findByManningAgentId -- Start");
		commonUtil.stringNullValidator(manningAgentId, "manningAgentId");
		ManningAgent manningAgent = manningAgentDao.findByIdAndStatusNot(manningAgentId, commonUtil.getSoftDeleteStatus());
		if (manningAgent == null)
			throw new ApplicationServiceExecption("Severity not found", HttpStatus.NOT_FOUND);

		LOGGER.debug("ManningAgentServiceImpl -- findByManningAgentId -- End");
		return mapEntityToDto.transformBO(manningAgent, ManningAgentDto.class);
	}

	@Override
	public ManningAgentDto add(ManningAgentDto manningAgentDto) throws Exception {
		LOGGER.debug("ManningAgentServiceImpl -- add -- start");
		commonUtil.stringNullValidator(manningAgentDto.getAgentName(),manningAgentDto.getContactPerson(),manningAgentDto.getCountry(),manningAgentDto.getEmail(),manningAgentDto.getAddress(),"AgentName, ContactPerson, Country, Email and Address");
		List<ManningAgent> existingManningAgentList=manningAgentDao.uniqueCheckForAdd(manningAgentDto.getAgentName());
		if(!(existingManningAgentList.isEmpty()))
			throw new ApplicationServiceExecption("Manning Agent already exist", HttpStatus.BAD_REQUEST);
	
		ManningAgent manningAgent = mapDtoToEntity.transformBO(manningAgentDto, ManningAgent.class);
		String seqName = dbUtil.getNextSequence(manningAgent.getClass());
		if(seqName != null)
			manningAgent.setId(seqName);
		
		manningAgent.setInsertTime(new Date());
		manningAgent.setUpdateTime(new Date());
		manningAgent.setStatus(commonUtil.getActiveStatus());
		manningAgent = manningAgentDao.save(manningAgent);
		syncDataService.syncCreation(manningAgent);
		LOGGER.debug("ManningAgentServiceImpl -- add -- end");
		return mapEntityToDto.transformBO(manningAgent, ManningAgentDto.class);
	}

	@Override
	public List<ManningAgentDto> findAllManningAgent() throws Exception {
		LOGGER.debug("ManningAgentServiceImpl -- findAllManningAgent -- start");
		List<ManningAgent> manningAgentList = manningAgentDao.findAllManningAgent();
		if(manningAgentList.size() == 0)
			throw new ApplicationServiceExecption("Manning Agent not found");
		
		LOGGER.debug("ManningAgentServiceImpl -- findAllManningAgent -- end");
		return mapEntityToDto.transformListOfBO(manningAgentList, ManningAgentDto.class);
	}

	@Override
	public List<ManningAgentDto> softDelete(List<String> ids) throws Exception {
		LOGGER.debug("ManningAgentServiceImpl -- softDelete -- start");
		commonUtil.stringNullValidator(ids.toArray(), "Manning Agent Id");
		List<ManningAgent> manningAgentList = manningAgentDao.findByIdInAndStatusNot(ids, commonUtil.getSoftDeleteStatus());
		if(manningAgentList.size() < ids.size())
			throw new ApplicationServiceExecption("Manning Agent not found");
		
		List<ManningAgentDto> manningAgentDtoList = mapEntityToDto.transformListOfBO(manningAgentList, ManningAgentDto.class);
		for (ManningAgent manningAgent : manningAgentList) {
			manningAgent.setStatus(commonUtil.getSoftDeleteStatus());
			manningAgent.setUpdateTime(new Date());
		}
		manningAgentList = manningAgentDao.saveAll(manningAgentList);
		Integer count = 0;
		for (ManningAgent manningAgent : manningAgentList) {
			syncDataService.syncUpdate(mapDtoToEntity.transformBO(manningAgentDtoList.get(count), ManningAgent.class), manningAgent);
			count++;
		}
		manningAgentList = manningAgentDao.findAllManningAgent();
		LOGGER.debug("ManningAgentServiceImpl -- softDelete -- end");
		return mapEntityToDto.transformListOfBO(manningAgentList, ManningAgentDto.class);
	}

	@Override
	public ManningAgentDto update(ManningAgentDto manningAgentDto) throws Exception {
		LOGGER.debug("ManningAgentServiceImpl -- update -- start");
		commonUtil.stringNullValidator(manningAgentDto.getAgentName(), manningAgentDto.getId(), "AgentName Name And Id");
		List<ManningAgent> existingManningAgentList = manningAgentDao.uniqueCheckForUpdate(manningAgentDto.getAgentName(), manningAgentDto.getId());
		if(!existingManningAgentList.isEmpty())
			throw new ApplicationServiceExecption("Staff already exist", HttpStatus.BAD_REQUEST);
		
		ManningAgent manningAgent = manningAgentDao.findByIdAndStatusNot(manningAgentDto.getId(), commonUtil.getSoftDeleteStatus());
		if(manningAgent == null)
			throw new ApplicationServiceExecption("Severity not found", HttpStatus.BAD_REQUEST);
		
		ManningAgentDto existingManningAgentDto = mapEntityToDto.transformBO(manningAgent, ManningAgentDto.class);
		manningAgent = mapDtoToEntity.transformBO(manningAgentDto, ManningAgent.class);
		manningAgent.setUpdateTime(new Date());
		manningAgent = manningAgentDao.save(manningAgent);
		syncDataService.syncUpdate(mapDtoToEntity.transformBO(existingManningAgentDto, ManningAgent.class), manningAgent);
		LOGGER.debug("ManningAgentServiceImpl -- update -- end");
		return mapEntityToDto.transformBO(manningAgent, ManningAgentDto.class);
	}
	
	

}
