package in.ind.mds.serviceImpl;

import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import in.ind.mds.dto.InventoryMainDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.repo.dao.InventoryMainDao;
import in.ind.mds.repo.entity.InventoryMain;
import in.ind.mds.service.InventoryMainService;
import in.ind.mds.service.SyncDataService;
import in.ind.mds.util.BeanTransformerUtil;
import in.ind.mds.util.CommonUtil;
import in.ind.mds.util.DBUtil;

@Service("TST_MSSQL_INVENTORY_MAIN")

public class InventoryMainServiceImpl implements InventoryMainService

{
	private static final Logger LOGGER = LoggerFactory.getLogger(InventoryMainServiceImpl.class);

	@Autowired
	private BeanTransformerUtil<InventoryMain, InventoryMainDto> mapEntityToDto;

	@Autowired
	private BeanTransformerUtil<InventoryMainDto, InventoryMain> mapDtoToEntity;

	@Autowired
	@Qualifier("TST_MSSQL_SYNC")
	private SyncDataService syncDataService;
	/*
	 * @Autowired private UserValidator validator;
	 */
	@Autowired
	private CommonUtil<InventoryMainDto>commonUtil;

	@Autowired
	private InventoryMainDao inventoryMainDao;

	@Autowired
	private DBUtil dbUtil;

	public InventoryMainDto findByCtgyCodeAndCtgyName(final String ctgyCode, final String ctgyName) throws Exception {
		LOGGER.debug("InventoryMainServiceImpl -- getByCtgyCodeAndCtgyName -- Start");

		commonUtil.stringNullValidator(ctgyCode, ctgyName, "CtgyCode and CtgyName");

		InventoryMain inventoryMain = inventoryMainDao.findByCtgyCodeAndCtgyNameAndStatusNot(ctgyCode, ctgyName,
				commonUtil.getSoftDeleteStatus());

		if (inventoryMain == null) {
			throw new ApplicationServiceExecption("InventoryMain not found", HttpStatus.NOT_FOUND);
		}
		final InventoryMainDto dto = mapEntityToDto.transformBO(inventoryMain, InventoryMainDto.class);
		LOGGER.debug("InventoryMainServiceImpl -- getByCtgyCodeAndCtgyName -- End");
		return dto;
	}

	public InventoryMainDto getByCtgyId(final String ctgyId) throws Exception {
		LOGGER.debug("InventoryMainServiceImpl -- getByCtgyId -- Start");

		commonUtil.stringNullValidator(ctgyId, "CtgyId");

		final InventoryMain inventoryMain = inventoryMainDao.findByIdAndStatusNot(ctgyId, commonUtil.getSoftDeleteStatus());

		if (inventoryMain == null)
			throw new ApplicationServiceExecption("Error InventoryMain not found", HttpStatus.NOT_FOUND);

		/*
		 * Date date = user.getServerTime(); Date currentDate = new
		 * Date(System.currentTimeMillis());
		 * 
		 * if (date.before(currentDate) || date.after(currentDate)) {
		 * user.setServerTime(currentDate); userDao.save(user); }
		 */
		final InventoryMainDto dto = mapEntityToDto.transformBO(inventoryMain, InventoryMainDto.class);

		LOGGER.debug("InventoryMainServiceImpl -- getByCtgyId -- End");
		return dto;
	}

	@Override
	public InventoryMainDto findByCtgyName(final String ctgyName) throws Exception {
		LOGGER.debug("InventoryMainServiceImpl -- getByCtgyName -- Start");

		commonUtil.stringNullValidator(ctgyName, "CtgyName");

		final InventoryMain inventoryMain = inventoryMainDao.findByCtgyNameAndStatusNot(ctgyName,commonUtil.getSoftDeleteStatus());

		if (inventoryMain == null)
			throw new ApplicationServiceExecption("Error InventoryMain not found", HttpStatus.NOT_FOUND);

		/*
		 * Date date = user.getServerTime(); Date currentDate = new
		 * Date(System.currentTimeMillis());
		 * 
		 * if (date.before(currentDate) || date.after(currentDate)) {
		 * user.setServerTime(currentDate); userDao.save(user); }
		 */
		final InventoryMainDto dto = mapEntityToDto.transformBO(inventoryMain, InventoryMainDto.class);

		LOGGER.debug("InventoryMainServiceImpl -- getByCtgyName -- End");
		return dto;
	}

	@Override
	public List<InventoryMainDto> findAll() throws Exception {
		LOGGER.debug("InventoryMainServiceImpl -- findByInventoryMainType -- Start");
		List<InventoryMain> inventoryMain = inventoryMainDao.findAllInventoryMain();

		if (inventoryMain.size() == 0)
			throw new ApplicationServiceExecption("InventoryMain not found", HttpStatus.NOT_FOUND);

		final List<InventoryMainDto> dto = mapEntityToDto.transformListOfBO(inventoryMain, InventoryMainDto.class);
		LOGGER.debug("InventoryMainServiceImpl -- findByInventoryMainType -- End");
		return dto;
	}

	@Override
	public InventoryMainDto add(InventoryMainDto inventoryMainDto) throws Exception {
		LOGGER.debug("InventoryMainServiceImpl -- add -- Start");
		// final String errorMessage = validator.validateAdd(userDto);
		// if (errorMessage != null) {
		// throw new GaurageServiceException(errorMessage, HttpStatus.BAD_REQUEST);
		// }
		/*
		 * Optional<InventoryMain> existingInventoryMain =
		 * inventoryMainDao.findById(inventoryMainDto.getId()); if
		 * (existingInventoryMain.isPresent()) { throw new
		 * ApplicationServiceExecption("InventoryMain exist", HttpStatus.BAD_REQUEST); }
		 */
		final InventoryMain inventoryMain = mapDtoToEntity.transformBO(inventoryMainDto, InventoryMain.class);
		String seqName = dbUtil.getNextSequence(inventoryMain.getClass());
		if (seqName != null) {
			inventoryMain.setId(seqName);
		}
		inventoryMain.setInsertTime(new Date());
		inventoryMain.setUpdateTime(new Date());
		inventoryMain.setStatus(commonUtil.getActiveStatus());
		inventoryMainDao.save(inventoryMain);
		syncDataService.syncCreation(inventoryMain);
		LOGGER.debug("InventoryMainServiceImpl -- add -- End");
		return inventoryMainDto;
	}

	@Override
	public void softDeleteInventoryMain(String ctgyId) throws Exception {
		LOGGER.debug("InventoryMainServiceImpl -- delete -- Start");
		// final String errorMessage = validator.validateAdd(userDto);
		// if (errorMessage != null) {
		// throw new GaurageServiceException(errorMessage, HttpStatus.BAD_REQUEST);
		// }
		commonUtil.stringNullValidator(ctgyId, "CtgyId");
		InventoryMain existingInventoryMain = inventoryMainDao.findByIdAndStatusNot(ctgyId, commonUtil.getSoftDeleteStatus());
		if (existingInventoryMain == null)
			throw new ApplicationServiceExecption("InventoryMain not found", HttpStatus.BAD_REQUEST);

		InventoryMainDto existingInventoryMainDto = mapEntityToDto.transformBO(existingInventoryMain,
				InventoryMainDto.class);
		existingInventoryMain.setStatus(commonUtil.getSoftDeleteStatus());
		existingInventoryMain = inventoryMainDao.saveAndFlush(existingInventoryMain);
		syncDataService.syncUpdate(mapDtoToEntity.transformBO(existingInventoryMainDto, InventoryMain.class),
				existingInventoryMain);
		LOGGER.debug("InventoryMainServiceImpl -- delete -- End");
	}

	@Override
	public InventoryMainDto updateInventoryMain(InventoryMainDto inventoryMainDto) throws Exception {
		LOGGER.debug("InventoryMainServiceImpl -- update -- Start");
		// final String errorMessage = validator.validateAdd(userDto);
		// if (errorMessage != null) {
		// throw new GaurageServiceException(errorMessage, HttpStatus.BAD_REQUEST);
		// }
		commonUtil.stringNullValidator(inventoryMainDto.getId(), "InventoryMainId");
		InventoryMain existingInventoryMain = inventoryMainDao.findByIdAndStatusNot(inventoryMainDto.getId(),
				commonUtil.getSoftDeleteStatus());
		if (existingInventoryMain == null)
			throw new ApplicationServiceExecption("InventoryMain not found", HttpStatus.BAD_REQUEST);

		InventoryMainDto existingInventoryMainDto = mapEntityToDto.transformBO(existingInventoryMain,
				InventoryMainDto.class);
		InventoryMain inventoryMain = mapDtoToEntity.transformBO(inventoryMainDto, InventoryMain.class);
		inventoryMainDao.saveAndFlush(inventoryMain);
		syncDataService.syncUpdate(mapDtoToEntity.transformBO(existingInventoryMainDto, InventoryMain.class),
				inventoryMain);
		LOGGER.debug("InventoryMainServiceImpl -- update -- End");
		return inventoryMainDto;
	}

}
