package in.ind.mds.service;

import in.ind.mds.repo.entity.SyncEvent;

public interface SyncEventService {

	boolean syncEventImport(String path) throws Exception;

	String exportSyncDataList(String senderId, String reciverId, String syncType) throws Exception;

	SyncEvent syncEventCreation(String senderId, String receiverId, String syncType, String syncMode) throws Exception;
	
	String importSyncData(String path, String reciverId, String syncType) throws Exception;

}
