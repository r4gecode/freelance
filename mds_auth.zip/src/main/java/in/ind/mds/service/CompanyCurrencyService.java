/**
 * 
 */
package in.ind.mds.service;

import java.util.List;

import in.ind.mds.dto.CompanyCurrencyDto;

/**
 * @author mds-arockia
 *
 */
public interface CompanyCurrencyService {

	List<CompanyCurrencyDto> add(List<CompanyCurrencyDto> companyCurrencyDtos) throws Exception;
	
	List<CompanyCurrencyDto> findByCompanyId(String companyId) throws Exception;
	
	List<CompanyCurrencyDto> softDelete(List<String> companyCurrencyIds) throws Exception;
	
	List<CompanyCurrencyDto> updateBaseCurrency(String companyId, String baseCurrencyId) throws Exception;
}
