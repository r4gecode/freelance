package in.ind.mds.service;

import java.util.List;

import in.ind.mds.dto.RoleDto;

public interface RoleService
{
	RoleDto getByRoleId(final String roleId)throws Exception;

	RoleDto findByRoleName(final String roleName)throws Exception;

	RoleDto findByRoleIdAndRoleName(final String roleId, final String roleName)throws Exception;
	
	List<RoleDto> findAll() throws Exception;
	
	RoleDto add(final RoleDto roleDto) throws Exception;
	
	List<RoleDto> softDeleteRole(List<String> roleIds) throws Exception;
	
	RoleDto updateRole(RoleDto roleDto) throws Exception ;


}
