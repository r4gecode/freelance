/**
 * 
 */
package in.ind.mds.service;

import java.util.List;

import in.ind.mds.dto.NationalityDto;

/**
 * @author mds-arockia
 *
 */
public interface NationalityService {
	
	NationalityDto add(NationalityDto nationalityDto) throws Exception;
	
	NationalityDto getByNationalityId(String nationalityId) throws Exception;

	List<NationalityDto> findAll() throws Exception;

	List<NationalityDto> softDeleteNationality(List<String> nationalityIds) throws Exception;
	
	NationalityDto updateNationality(NationalityDto nationalityDto) throws Exception;
	
}
