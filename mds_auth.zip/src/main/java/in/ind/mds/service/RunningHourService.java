/**
 * 
 */
package in.ind.mds.service;

import java.util.List;

import in.ind.mds.dto.RunningHourDto;

/**
 * @author mds-arockia
 *
 */
public interface RunningHourService {
	
	List<RunningHourDto> add(RunningHourDto runningHourDto) throws Exception;
	
	RunningHourDto udpate(RunningHourDto runningHourDto) throws Exception;

	RunningHourDto findById(String id) throws Exception;
	
	List<RunningHourDto> findAll() throws Exception;
	
	List<RunningHourDto> softDelete(List<String> ids) throws Exception;
	
}
