package in.ind.mds.service;

import java.util.List;

import in.ind.mds.dto.InventoryMainDto;


public interface InventoryMainService 
{
	InventoryMainDto getByCtgyId(final String ctgyId)throws Exception;

	InventoryMainDto findByCtgyName(final String ctgyName)throws Exception;

	InventoryMainDto findByCtgyCodeAndCtgyName(final String ctgyCode, final String ctgyName)throws Exception;
	
	List<InventoryMainDto> findAll() throws Exception;
	
	InventoryMainDto add(final InventoryMainDto inventoryMainDto) throws Exception;
	
	void softDeleteInventoryMain(String ctgyId) throws Exception;
	
	InventoryMainDto updateInventoryMain(InventoryMainDto inventoryMainDto) throws Exception ;


}
