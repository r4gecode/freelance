/**
 * 
 */
package in.ind.mds.service;

import java.util.List;

import in.ind.mds.dto.CrewMedReportTypeDto;

/**
 * @author mds-arockia
 *
 */
public interface CrewMedReportTypeService {
	
	CrewMedReportTypeDto add(CrewMedReportTypeDto crewMedReportTypeDto) throws Exception;
	
	CrewMedReportTypeDto update(CrewMedReportTypeDto crewMedReportTypeDto) throws Exception;

	CrewMedReportTypeDto findById(String id) throws Exception;
	
	List<CrewMedReportTypeDto> softDelete(List<String> ids) throws Exception;
	
	List<CrewMedReportTypeDto> findAll() throws Exception;
}
