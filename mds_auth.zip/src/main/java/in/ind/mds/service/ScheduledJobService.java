/**
 * 
 */
package in.ind.mds.service;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import in.ind.mds.dto.ScheduledJobDto;
import in.ind.mds.repo.entity.JobCompletion;

/**
 * @author mds-arockia
 *
 */
public interface ScheduledJobService {
	
	ScheduledJobDto add(String scheduledJobDetails, MultipartFile[] attachmentFiles) throws Exception;

	ScheduledJobDto update(String scheduledJobDetails, MultipartFile[] attachmentFiles) throws Exception;

	ScheduledJobDto findById(String id) throws Exception;
	
	List<ScheduledJobDto> findAll() throws Exception;
	
	List<ScheduledJobDto> softDelete(List<String> ids) throws Exception;
	
	void updationAtJobCompletion(JobCompletion jobCompletion) throws Exception;
	
	void updationAtAddRH(List<ScheduledJobDto> scheduledJobDtoList) throws Exception;

}
