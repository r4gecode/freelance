/**
 * 
 */
package in.ind.mds.service;

import java.util.List;

import in.ind.mds.dto.InventoryCatalogDto;

/**
 * @author mds-arockia
 *
 */
public interface InventoryCatalogService {
	
	InventoryCatalogDto add(InventoryCatalogDto inventoryCatalogDto) throws Exception;
	
	InventoryCatalogDto update(InventoryCatalogDto inventoryCatalogDto) throws Exception;
	
	List<InventoryCatalogDto> softDelete(List<String> inventoryCatalogIds) throws Exception;
} 
