package in.ind.mds.service;

import java.util.List;

import in.ind.mds.dto.UserDto;

public interface UserService {


	UserDto findByName(final String userName) throws Exception;

	UserDto getByUserNameAndPassword(String userName, String password) throws Exception;

	UserDto saveUser(UserDto userDto) throws Exception;
	
	List<UserDto> findAll() throws Exception;
	
	List<UserDto> softDeleteUser(List<String> userId) throws Exception;
	
	UserDto updateUser(UserDto userDto) throws Exception ;
}
