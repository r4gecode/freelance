package in.ind.mds.service;

import java.util.List;

import in.ind.mds.dto.JobCategoryDto;


public interface JobCategoryService 
{

	JobCategoryDto getByJobCtgyId(String jobCtgyId)throws Exception;

	JobCategoryDto findByJobCtgyName(String jobCtgyName)throws Exception;

	JobCategoryDto findByJobCtgyIdAndJobCtgyName(String jobCtgyId, String jobCtgyName)throws Exception;
	
	List<JobCategoryDto> findAll() throws Exception;
	
	JobCategoryDto add(JobCategoryDto jobCategoryDto) throws Exception;
	
	List<JobCategoryDto> softDeleteJobCategory(List<String> jobCtgyIds) throws Exception;
	
	JobCategoryDto updateJobCategory(JobCategoryDto jobCategoryDto) throws Exception ;

}
