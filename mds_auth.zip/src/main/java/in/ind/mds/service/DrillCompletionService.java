/**
 * 
 */
package in.ind.mds.service;

import java.util.List;
import java.util.Map;

import org.springframework.web.multipart.MultipartFile;

import in.ind.mds.dto.DrillCompletionDto;

/**
 * @author shalini
 *
 */
public interface DrillCompletionService {

	DrillCompletionDto add(String drillCompletionDetails,  Map<String, MultipartFile[]> attachments) throws Exception;

	DrillCompletionDto findById(String drillCompletionId) throws Exception;

	List<DrillCompletionDto> findAll() throws Exception;

	List<DrillCompletionDto> softDelete(List<String> drillCompletionIds) throws Exception;

	DrillCompletionDto update(String drillCompletionDetails, Map<String, MultipartFile[]> attachments) throws Exception;

}
