/**
 * 
 */
package in.ind.mds.service;

import java.util.List;

import in.ind.mds.dto.BankDetailsDto;

/**
 * @author mds-arockia
 *
 */
public interface BankDetailsService {
	
    BankDetailsDto add(BankDetailsDto bankDetailsDto) throws Exception;
	
    BankDetailsDto findById(final String id) throws Exception;

	List<BankDetailsDto> findAll() throws Exception;
	
	List<BankDetailsDto> softDeleteBankDetails(List<String> ids) throws Exception;
	
	BankDetailsDto updateBankDetails(BankDetailsDto bankDetailsDto) throws Exception ;

}
