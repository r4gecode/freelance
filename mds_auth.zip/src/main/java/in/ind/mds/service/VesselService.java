package in.ind.mds.service;

import java.util.List;

import in.ind.mds.dto.VesselDto;


public interface VesselService {

	VesselDto getByVesselId(final String vesselId) throws Exception;
	
	VesselDto findByVesselName(final String vesselName) throws Exception;

	VesselDto add(final VesselDto vesselDto) throws Exception;

	List<VesselDto> findAll() throws Exception;

	List<VesselDto> softDeleteVessel(List<String> vesselId) throws Exception;
	
	VesselDto updateVessel(VesselDto vesselDto) throws Exception ;
}
