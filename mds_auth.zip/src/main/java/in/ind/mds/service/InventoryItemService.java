/**
 * 
 */
package in.ind.mds.service;

import java.util.List;

import in.ind.mds.dto.InventoryItemDto;
import in.ind.mds.dto.QuantityUpdDto;

/**
 * @author DeveloperShalini
 *
 */
public interface InventoryItemService {

	List<QuantityUpdDto> updateQuantity(QuantityUpdDto quantityUpdDto) throws Exception;
	
	List<QuantityUpdDto> findAllQuantityUpdByInventoryItem(String inventoryItemId) throws Exception;
	
	List<InventoryItemDto> findAllInventoryItem() throws Exception;
	
	List<InventoryItemDto> softDeleteInventoryItem(List<String> ids) throws Exception;
	
}
