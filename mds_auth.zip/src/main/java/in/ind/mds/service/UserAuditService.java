package in.ind.mds.service;

import java.util.List;

import in.ind.mds.dto.UserAuditDto;

public interface UserAuditService 
{
	UserAuditDto getByAuditId(final String auditId)throws Exception;

	UserAuditDto findByUserIp(final String userIp)throws Exception;

	UserAuditDto findByUserIdAndAuditId(final String userId, final String auditId)throws Exception;
	
	List<UserAuditDto> findAll() throws Exception;
	
	UserAuditDto add(final UserAuditDto userAuditDto) throws Exception;
	
	void deleteUserAudit(String auditId) throws Exception;
	
	UserAuditDto updateUserAudit(UserAuditDto userAuditDto) throws Exception ;

}
