/**
 * 
 */
package in.ind.mds.service;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import in.ind.mds.dto.JobCompletionDto;

/**
 * @author mds-arockia
 *
 */
public interface JobCompletionService {

	JobCompletionDto add(String jobCompletionDetails, MultipartFile[] attachmentFiles) throws Exception;

	JobCompletionDto update(String jobCompletionDetails, MultipartFile[] attachmentFiles) throws Exception;

	JobCompletionDto findById(String id) throws Exception;
	
	List<JobCompletionDto> findAll() throws Exception;
	
	List<JobCompletionDto> softDelete(List<String> ids) throws Exception;
	
}
