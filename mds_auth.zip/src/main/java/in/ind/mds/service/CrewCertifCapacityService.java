/**
 * 
 */
package in.ind.mds.service;

import java.util.List;

import in.ind.mds.dto.CrewCertifCapacityDto;

/**
 * @author mds-arockia
 *
 */
public interface CrewCertifCapacityService {
	
	CrewCertifCapacityDto add(CrewCertifCapacityDto crewCertifCapacityDto) throws Exception;

	CrewCertifCapacityDto update(CrewCertifCapacityDto crewCertifCapacityDto) throws Exception;

	CrewCertifCapacityDto findById(String id) throws Exception;
	
	List<CrewCertifCapacityDto> findAll() throws Exception;

	List<CrewCertifCapacityDto> softDelete(List<String> ids) throws Exception;
	
}
