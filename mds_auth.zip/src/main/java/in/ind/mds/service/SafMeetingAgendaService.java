/**
 * 
 */
package in.ind.mds.service;

import java.util.List;


import in.ind.mds.dto.SafMeetingAgendaDto;

/**
 * @author Hinaya
 *
 */
public interface SafMeetingAgendaService {

	SafMeetingAgendaDto getById(String id) throws Exception;

	List<SafMeetingAgendaDto> findAll() throws Exception;
	
	SafMeetingAgendaDto add(SafMeetingAgendaDto safMeetingAgendaDto) throws Exception;
	
	List<SafMeetingAgendaDto> softDelete(List<String> ids) throws Exception;
	
	SafMeetingAgendaDto update(SafMeetingAgendaDto safMeetingAgendaDto) throws Exception ;


}
