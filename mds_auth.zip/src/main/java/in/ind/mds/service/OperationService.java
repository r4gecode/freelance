/**
 * 
 */
package in.ind.mds.service;

import java.util.List;

import in.ind.mds.dto.OperationDto;

/**
 * @author dharani
 *
 */
public interface OperationService {
	

	OperationDto add(OperationDto operationDtoList) throws Exception;
	
	OperationDto update(OperationDto operationDtoList) throws Exception;
	
	OperationDto findById(String id) throws Exception;
	
	List<OperationDto> findAll() throws Exception;
	
	List<OperationDto> softDelete(List<String> ids) throws Exception;

	



}
