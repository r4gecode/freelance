package in.ind.mds.service;

import java.util.List;

import in.ind.mds.dto.MenuDto;


public interface MenuService 
{
	MenuDto getByMenuId(String menuId)throws Exception;

	MenuDto findByMenuCode(String menuCode)throws Exception;

	MenuDto findByMenuDescAndMenuUrl(String menuDesc, String menuUrl)throws Exception;
	
	List<MenuDto> findAll() throws Exception;
	
	MenuDto add(MenuDto menuDto) throws Exception;
	
	List<MenuDto> softDeleteMenu(List<String> menuIds) throws Exception;
	
	MenuDto updateMenu(MenuDto menuDto) throws Exception ;


}
