/**
 * 
 */
package in.ind.mds.service;

import java.util.List;

import in.ind.mds.dto.OperationTypeDto;

/**
 * @author dharani
 *
 */
public interface OperationTypeService {
	
	OperationTypeDto findById(String id) throws Exception;
	
	OperationTypeDto add(OperationTypeDto operationTypeDto) throws Exception;
	
	OperationTypeDto update(OperationTypeDto operationTypeDto)throws Exception;
	
	List<OperationTypeDto> softDelete(List<String> id)throws Exception;
	
	List<OperationTypeDto> findAll() throws Exception;

}
