/**
 * 
 */
package in.ind.mds.service;

import java.util.List;

import in.ind.mds.dto.ManningAgentDto;


/**
 * @author Hinaya
 *
 */
public interface ManningAgentService {

	ManningAgentDto getById(String manningAgentId) throws Exception;

	ManningAgentDto add(ManningAgentDto manningAgentDto) throws Exception;

	List<ManningAgentDto> findAllManningAgent() throws Exception;

	List<ManningAgentDto> softDelete(List<String> ids) throws Exception;

	ManningAgentDto update(ManningAgentDto manningAgentDto) throws Exception;

}
