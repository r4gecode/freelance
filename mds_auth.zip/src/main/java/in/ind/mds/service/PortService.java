package in.ind.mds.service;

import java.util.List;

import in.ind.mds.dto.PortDto;

public interface PortService {

	PortDto getByPortId(final String portId) throws Exception;

	PortDto findByPortName(final String portName) throws Exception;

	List<PortDto> findAll() throws Exception;

	PortDto add(final PortDto portDto) throws Exception;

	void softDeletePort(String portId) throws Exception;
	
	List<PortDto> multipleSoftDelete(List<String> portIds) throws Exception;

	PortDto updatePort(PortDto portDto) throws Exception;
}
