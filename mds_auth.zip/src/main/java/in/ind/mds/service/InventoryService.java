package in.ind.mds.service;

import java.util.List;

import in.ind.mds.dto.InventoryDto;


public interface InventoryService 
{
	InventoryDto getByInventoryId(final String inventoryId)throws Exception;

	InventoryDto findByInventoryName(final String inventoryName)throws Exception;

	InventoryDto findByInventoryCodeAndInventoryName(final String inventoryCode, final String inventoryName)throws Exception;

	List<InventoryDto> findAll() throws Exception;
	
	InventoryDto add(final InventoryDto addressDto) throws Exception;
	
	void softDeleteInventory(String inventoryId) throws Exception;
	
	InventoryDto updateInventory(InventoryDto inventoryDto) throws Exception ;
}
