/**
 * 
 */
package in.ind.mds.service;

import java.util.List;

import in.ind.mds.dto.FleetDto;

/**
 * @author mds-arockia
 *
 */
public interface FleetService {
	
	FleetDto add(FleetDto fleetDto) throws Exception;

	FleetDto findByFleetId(String fleetId) throws Exception;
	
	List<FleetDto> findAll() throws Exception;
	
	List<FleetDto> softDeleteFleet(List<String> fleetIds) throws Exception;
	
	FleetDto updateFleet(FleetDto fleetDto) throws Exception;
}
