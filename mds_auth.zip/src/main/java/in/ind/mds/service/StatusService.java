package in.ind.mds.service;

import java.util.List;

import in.ind.mds.dto.StatusDto;

public interface StatusService {

	StatusDto getByStatusId(final String statusId) throws Exception;

	StatusDto findByStatusName(final String statusName) throws Exception;

	List<StatusDto> findAll() throws Exception;
	
	StatusDto add(final StatusDto addressDto) throws Exception;
	
	void  deleteStatus(String statusId) throws Exception;
	
	StatusDto updateStatus(StatusDto statusDto) throws Exception ;

}
