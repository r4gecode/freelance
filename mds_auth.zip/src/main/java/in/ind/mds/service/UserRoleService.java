package in.ind.mds.service;

import java.util.List;

import in.ind.mds.dto.UserDto;
import in.ind.mds.dto.UserRoleDto;
import in.ind.mds.repo.entity.User;
import in.ind.mds.repo.entity.UserRole;


public interface UserRoleService 
{
	UserRoleDto getByUserRoleId(final String userRoleId)throws Exception;

	UserRoleDto findByRoleId(final String roleId)throws Exception;

	UserRoleDto findByRoleIdAndUserId(final String roleId, final String menuId)throws Exception;
	
	List<UserRoleDto> findAll() throws Exception;
	
	UserRoleDto add(final UserRoleDto userRoleDto) throws Exception;
	
	List<UserRoleDto> softDeleteUserRole(List<String> userRoleId) throws Exception;
	
	UserRoleDto updateUserRole(UserRoleDto userRoleDto) throws Exception ;

	UserRoleDto findByUserId(UserDto userDto) throws Exception;

	


}
