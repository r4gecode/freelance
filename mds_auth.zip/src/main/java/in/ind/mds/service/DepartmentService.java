/**
 * 
 */
package in.ind.mds.service;

import java.util.List;

import in.ind.mds.dto.DepartmentDto;

/**
 * @author mds-arockia
 *
 */
public interface DepartmentService {
	
	DepartmentDto findByDepartmentId(final String departmentId) throws Exception;

	List<DepartmentDto> findAll() throws Exception;
	
	DepartmentDto add(final DepartmentDto departmentDto) throws Exception;
	
	List<DepartmentDto> softDeleteDepartment(List<String> departmentIds) throws Exception;
	
	DepartmentDto updateDepartment(DepartmentDto DepartmentDto) throws Exception ;

}
