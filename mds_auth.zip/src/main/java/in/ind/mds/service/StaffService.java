/**
 * 
 */
package in.ind.mds.service;

import java.util.List;
import java.util.Map;

import org.springframework.web.multipart.MultipartFile;

import in.ind.mds.dto.StaffDetailsDto;
import in.ind.mds.dto.StaffDto;

/**
 * @author mds_kiruthika
 *
 */
public interface StaffService {
	
	StaffDetailsDto getByStaffId(String staffId) throws Exception;
	
	StaffDetailsDto add(String staffDetailsDto, Map<String, MultipartFile[]> attachments) throws Exception;
	
	List<StaffDto> findAll() throws Exception;
	
	List<StaffDto> softDeleteStaff(List<String> staffIds) throws Exception;
	
	StaffDetailsDto updateStaff(String staffDetailsDto, Map<String, MultipartFile[]> attachments) throws Exception;

}
