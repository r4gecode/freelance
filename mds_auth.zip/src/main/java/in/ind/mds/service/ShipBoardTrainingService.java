/**
 * 
 */
package in.ind.mds.service;

import java.util.List;
import java.util.Map;

import org.springframework.web.multipart.MultipartFile;


import in.ind.mds.dto.ShipBoardTrainingDto;

/**
 * @author dharani
 *
 */
public interface ShipBoardTrainingService {
	

	ShipBoardTrainingDto add(String shipBoardTrainingDto,Map<String, MultipartFile[]> attachments) throws Exception;
	
	ShipBoardTrainingDto update(String shipBoardTrainingDtoList,Map<String, MultipartFile[]> attachments) throws Exception;

	ShipBoardTrainingDto findById(String id) throws Exception;
	
	List<ShipBoardTrainingDto> findAll() throws Exception;
	
	List<ShipBoardTrainingDto> softDelete(List<String> ids) throws Exception;



	

	


	

}
