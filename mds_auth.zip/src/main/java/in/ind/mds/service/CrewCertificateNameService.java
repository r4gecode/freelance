/**
 * 
 */
package in.ind.mds.service;

import java.util.List;

import in.ind.mds.dto.CrewCertificateNameDto;

/**
 * @author mds_kiruthika
 *
 */
public interface CrewCertificateNameService {
	
	CrewCertificateNameDto add(CrewCertificateNameDto certificateNameDto) throws Exception;
	
	CrewCertificateNameDto findByCertificateNameId(String certificateId) throws Exception;
	
	List<CrewCertificateNameDto> findAllCrewCertificate() throws Exception;
	
	List<CrewCertificateNameDto> softDeleteCertificateName(List<String> cerNameIds) throws Exception;
	
	CrewCertificateNameDto updateCertificateName(CrewCertificateNameDto certificateNameDto) throws Exception;
	

}
