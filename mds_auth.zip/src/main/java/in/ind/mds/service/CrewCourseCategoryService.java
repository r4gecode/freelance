/**
 * 
 */
package in.ind.mds.service;

import java.util.List;

import in.ind.mds.dto.CrewCourseCategoryDto;

/**
 * @author mds_kiruthika
 *
 */
public interface CrewCourseCategoryService {
	
	CrewCourseCategoryDto add(CrewCourseCategoryDto crewCourseCategory) throws Exception;
	
	CrewCourseCategoryDto findByCrewCourseId(String crewCourseId) throws Exception;
	
	
	List<CrewCourseCategoryDto> findAllCrewCourse() throws Exception;
	
	List<CrewCourseCategoryDto> softDeleteCrewCourse(List<String> crewCourseIds) throws Exception;
	
	CrewCourseCategoryDto updateCrewCourse(CrewCourseCategoryDto crewCourseDto) throws Exception;


}
