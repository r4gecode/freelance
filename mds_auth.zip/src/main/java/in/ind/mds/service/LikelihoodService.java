/**
 * 
 */
package in.ind.mds.service;

import java.util.List;

import in.ind.mds.dto.LikelihoodDto;

/**
 * @author shalini
 *
 */
public interface LikelihoodService {

	LikelihoodDto add(LikelihoodDto likelihoodDto)throws Exception;


	LikelihoodDto update(LikelihoodDto likelihoodDto)throws Exception;


	LikelihoodDto findById(String likelihoodId)throws Exception;


	List<LikelihoodDto> findAllLikelihood()throws Exception;


	List<LikelihoodDto> softDelete(List<String> likelihoodId)throws Exception;

}
