/**
 * 
 */
package in.ind.mds.service;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import in.ind.mds.dto.CrewTrainingDto;
import in.ind.mds.repo.entity.Staff;

/**
 * @author mds-arockia
 *
 */
public interface CrewTrainingService {

	List<CrewTrainingDto> add(Staff staff, List<CrewTrainingDto> trainingDtoList, MultipartFile[] attachmentFiles) throws Exception;

	List<CrewTrainingDto> update(Staff staff, List<CrewTrainingDto> trainingDtoList, MultipartFile[] attachmentFiles) throws Exception;

	List<CrewTrainingDto> findByStaff(Staff staff) throws Exception;
	
	void softDeleteByStaff(Staff staff)throws Exception;
	
	void softDelete(List<String> ids)throws Exception;
	
}
