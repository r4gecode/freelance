package in.ind.mds.service;

import java.util.List;

import in.ind.mds.dto.VesselTypeDto;

public interface VesselTypeService {

	VesselTypeDto getVesselTypeId(final String vesselTypeId) throws Exception;

	VesselTypeDto findByVesselTypeName(final String vesselTypeName) throws Exception;

	List<VesselTypeDto> findAll() throws Exception;
	
	VesselTypeDto add(final VesselTypeDto vesselTypeDto) throws Exception;
	
	List<VesselTypeDto> softDeleteVesselType(List<String> vesselTypeIds) throws Exception;
	
	VesselTypeDto updateVesselType(VesselTypeDto vesselTypeDto) throws Exception ;
}
