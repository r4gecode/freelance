package in.ind.mds.service;

import java.util.List;

import in.ind.mds.dto.UomDto;

public interface UomService 
{
	UomDto getUomId(final String uomId) throws Exception;

	UomDto findByMeasureName(final String measureName) throws Exception;

	List<UomDto> findAll() throws Exception;
	
	UomDto add(final UomDto UomDto) throws Exception;
	
	void softDeleteUom(String uomId) throws Exception;
	
	UomDto updateUom(UomDto uomDto) throws Exception ;

	
	List<UomDto> multipleSoftDelete(List<String> uomId) throws Exception;

}
