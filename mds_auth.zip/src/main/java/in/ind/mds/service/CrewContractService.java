/**
 * 
 */
package in.ind.mds.service;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import in.ind.mds.dto.CrewContractDto;
import in.ind.mds.repo.entity.Staff;

/**
 * @author mds-arockia
 *
 */
public interface CrewContractService {
	
	List<CrewContractDto> add(Staff staff, List<CrewContractDto> contractDtoList, MultipartFile[] attachmentFiles) throws Exception;

	List<CrewContractDto> update(Staff staff, List<CrewContractDto> contractDtoList, MultipartFile[] attachmentFiles) throws Exception;

	List<CrewContractDto> findByStaff(Staff staff) throws Exception;
	
	void softDeleteByStaff(Staff staff)throws Exception;
	
	void softDelete(List<String> ids)throws Exception;

}
