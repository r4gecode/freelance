/**
 * 
 */
package in.ind.mds.service;

import java.util.List;

import in.ind.mds.dto.CrewCertificateTypeDto;

/**
 * @author mds-arockia
 *
 */
public interface CrewCertificateTypeService {
	
	CrewCertificateTypeDto add(CrewCertificateTypeDto crewCertificateTypeDto) throws Exception;

	CrewCertificateTypeDto update(CrewCertificateTypeDto crewCertificateTypeDto) throws Exception;

	CrewCertificateTypeDto findById(String id) throws Exception;

	List<CrewCertificateTypeDto> findAll() throws Exception;
	
	List<CrewCertificateTypeDto> softDelete(List<String> ids) throws Exception;
}
