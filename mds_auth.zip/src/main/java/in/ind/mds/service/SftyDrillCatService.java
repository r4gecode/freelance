package in.ind.mds.service;

import java.util.List;

import in.ind.mds.dto.SftyDrillCatDto;

public interface SftyDrillCatService {
	
	SftyDrillCatDto getByCatId(final String catId) throws Exception;

	SftyDrillCatDto findByCatName(final String cattName) throws Exception;

	List<SftyDrillCatDto> findAll() throws Exception;

	SftyDrillCatDto add(final SftyDrillCatDto sftydrillCatDto) throws Exception;

	SftyDrillCatDto softDeleteCat(String catId, int statusNo) throws Exception;
	
	//List<SftyDrillCatDto> softDeleteCat(List<String> catIds) throws Exception;

	SftyDrillCatDto updateCat(SftyDrillCatDto sftydrillCatDto) throws Exception;

}
