package in.ind.mds.service;

import java.util.List;

import in.ind.mds.dto.AddressDto;



public interface AddressService {

	AddressDto getByAddressId(String addressId) throws Exception;

	AddressDto findByAddressType(String addressType) throws Exception;

	List<AddressDto> findAll() throws Exception;
	
	AddressDto add(AddressDto addressDto) throws Exception;
	
	List<AddressDto> softDeleteAddress(List<String> addressIds) throws Exception;
	
	AddressDto updateAddress(AddressDto addressDto) throws Exception ;
}
