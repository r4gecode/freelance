/**
 * 
 */
package in.ind.mds.service;

import java.util.List;

import in.ind.mds.dto.HazardsDto;
import in.ind.mds.repo.entity.Operation;

/**
 * @author dharani
 *
 */
public interface HazardsService {
	
	List<HazardsDto> add(Operation operation,List<HazardsDto> hazardsDtoList)throws Exception;

	List<HazardsDto> update(Operation operation,List<HazardsDto> hazardsDtoList)throws Exception;
	
	List<HazardsDto>findByOperation(Operation operation);
	
	void softDelete(List<String> ids)throws Exception;
	
	void softDeleteByOperation(Operation operation)throws Exception;

}
