/**
 * 
 */
package in.ind.mds.service;

import java.util.List;
import java.util.Map;

import org.springframework.web.multipart.MultipartFile;


import in.ind.mds.dto.DrillSchedulerDto;


import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.repo.entity.DrillCompletion;

/**
 * @author Hinaya
 *
 */
public interface DrillSchedulerService {

	DrillSchedulerDto findById(String DrillSchedulerId) throws Exception;
	
	DrillSchedulerDto add(String drillSchedulerDto, Map<String, MultipartFile[]> attachments) throws Exception;
	
	List<DrillSchedulerDto> findAll() throws Exception;
	
	List<DrillSchedulerDto> softDeleteDrillScheduler(List<String> drillSchedulerIds) throws Exception;
	
	DrillSchedulerDto updateDrillScheduler(String drillSchedulerDto, Map<String, MultipartFile[]> attachments) throws Exception;

	void updationAtDrillCompletion(DrillCompletion drillCompletion) throws ApplicationServiceExecption, Exception;

}
