/**
 * 
 */
package in.ind.mds.service;

import java.util.List;

import in.ind.mds.dto.ActivityTypeDto;

/**
 * @author mds-arockia
 *
 */
public interface ActivityTypeService {
	
	ActivityTypeDto add(ActivityTypeDto activityTypeDto) throws Exception;

	ActivityTypeDto update(ActivityTypeDto activityTypeDto)throws Exception;
	
	List<ActivityTypeDto> softDelete(List<String> ids) throws Exception;
	
	List<ActivityTypeDto> findAllActivityType() throws Exception; 
}
