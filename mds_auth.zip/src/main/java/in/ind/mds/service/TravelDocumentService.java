/**
 * 
 */
package in.ind.mds.service;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import in.ind.mds.dto.TravelDocumentDto;
import in.ind.mds.repo.entity.Staff;

/**
 * @author mds_kiruthika
 *
 */
public interface TravelDocumentService {

	List<TravelDocumentDto> findByStaff( Staff staff) throws Exception;
	
	List<TravelDocumentDto> add(Staff staff,final List<TravelDocumentDto> traveldDocList,MultipartFile[] attachmentFiles) throws Exception;
	
	List<TravelDocumentDto> updateDocument(Staff staff,List<TravelDocumentDto> travelDocumentDtos,MultipartFile[] attachmentFiles) throws Exception;
	
	void softDeleteDocument(List<String> documentIds ) throws Exception;
	
	void softDeleteByStaff(Staff staff)throws Exception;
}
