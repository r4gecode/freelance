package in.ind.mds.service;

import java.util.List;

import in.ind.mds.dto.OwnerDto;

public interface OwnerService {
	
	OwnerDto findByOwnerIdAndOwnerName(String ownerId, String ownerName)throws Exception;

	OwnerDto getByOwnerId(String ownerId) throws Exception;
	
	OwnerDto findByOwnerName(String ownerName) throws Exception;

	List<OwnerDto> findAll() throws Exception;
	
	OwnerDto add(OwnerDto ownerDto) throws Exception;
	
	List<OwnerDto> softDeleteOwner(List<String> ownerIds) throws Exception;
	
	OwnerDto updateOwner(OwnerDto ownerDto) throws Exception ;
}
