package in.ind.mds.service;

import java.util.List;

import in.ind.mds.dto.LocOnboardDto;


public interface LocOnboardService 
{
	LocOnboardDto getByLocationId(String locationId)throws Exception;

	LocOnboardDto findByLocationName(String locationName)throws Exception;

	LocOnboardDto findByLocationIdAndLocationName(String locationId, String locationName)throws Exception;
	
	List<LocOnboardDto> findAll() throws Exception;
	
	LocOnboardDto add(LocOnboardDto locOnboardDto) throws Exception;
	
	List<LocOnboardDto> softDeleteLocOnboard(List<String> locationIds) throws Exception;
	
	LocOnboardDto updateLocOnboard(LocOnboardDto locOnboardDto) throws Exception ;


}
