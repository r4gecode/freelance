/**
 * 
 */
package in.ind.mds.service;

import java.util.List;

import in.ind.mds.dto.CompanyDto;

/**
 * @author mds-arockia
 *
 */
public interface CompanyService {
	
	CompanyDto add(CompanyDto companyDto) throws Exception;
	
	CompanyDto findByCompanyId(String companyId) throws Exception;
	
	List<CompanyDto> findAll() throws Exception;
	
	List<CompanyDto> SoftDeleteCompany(List<String> companyIds) throws Exception;
	
	CompanyDto updateCompany(CompanyDto companyDto) throws Exception;

}
