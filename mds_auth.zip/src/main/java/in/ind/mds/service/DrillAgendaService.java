/**
 * 
 */
package in.ind.mds.service;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;


import in.ind.mds.dto.DrillAgendaDto;
import in.ind.mds.repo.entity.DrillScheduler;


/**
 * @author Hinaya
 *
 */
public interface DrillAgendaService {

	List<DrillAgendaDto> add(DrillScheduler drillScheduler, List<DrillAgendaDto> drillAgendaDtoList,
			MultipartFile[] attachmentFiles) throws Exception;

	

	List<DrillAgendaDto> findByDrillScheduler(DrillScheduler drillScheduler) throws Exception;
	
	void softDeleteByDrillScheduler(DrillScheduler drillScheduler)throws Exception;
	
	void softDelete(List<String> drillAgendaIds)throws Exception;

	List<DrillAgendaDto> update(DrillScheduler drillScheduler, List<DrillAgendaDto> drillAgendaDtoList,
			MultipartFile[] attachmentFiles) throws Exception;

}
