/**
 * 
 */
package in.ind.mds.service;

import java.util.List;

import in.ind.mds.dto.CrewWorkExpDto;
import in.ind.mds.repo.entity.Staff;

/**
 * @author mds-arockia
 *
 */
public interface CrewWorkExpService {

	List<CrewWorkExpDto> add(Staff staff, List<CrewWorkExpDto> workExpDtoList) throws Exception;

	List<CrewWorkExpDto> update(Staff staff, List<CrewWorkExpDto> workExpDtoList) throws Exception;

	List<CrewWorkExpDto> findByStaff(Staff staff) throws Exception;
	
	void softDeleteByStaff(Staff staff)throws Exception;
	
	void softDelete(List<String> ids)throws Exception;
	
}
