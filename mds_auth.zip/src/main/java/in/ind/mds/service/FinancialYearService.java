/**
 * 
 */
package in.ind.mds.service;

import java.util.List;

import in.ind.mds.dto.FinancialYearDto;

/**
 * @author mds-arockia
 *
 */
public interface FinancialYearService {

	FinancialYearDto add(FinancialYearDto financialYearDto) throws Exception;
	
	FinancialYearDto update(FinancialYearDto financialYearDto) throws Exception;
	
	List<FinancialYearDto> multipleSoftDelete(List<String> ids) throws Exception;
}
