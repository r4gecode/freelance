package in.ind.mds.service;

import java.util.List;

import in.ind.mds.dto.ComponentMainDto;


public interface ComponentMainService
{
	ComponentMainDto getByGroupId(final String groupId)throws Exception;

	ComponentMainDto findByGroupCode(final String groupCode)throws Exception;

	ComponentMainDto findByGroupNameAndGroupCode(final String groupName, final String groupCode)throws Exception;

	List<ComponentMainDto> findAll() throws Exception;
	
	ComponentMainDto add(final ComponentMainDto componentMainDto) throws Exception;
	
	List<ComponentMainDto> softDeleteComponentMain(List<String> componentMainIds) throws Exception;
	
	ComponentMainDto updateComponentMain(ComponentMainDto componentMainDto) throws Exception ;
}
