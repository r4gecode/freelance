package in.ind.mds.service;

import in.ind.mds.dto.SyncDataDto;
import in.ind.mds.repo.entity.SyncData;

public interface SyncDataService {

	SyncDataDto syncCreation(final Object entity) throws Exception;

	SyncDataDto syncUpdate(final Object oldEntity, final Object newEntity) throws Exception;

	String getVesselId(final Object newEntity) throws Exception;

	SyncDataDto createSyncRecord(final SyncData sync) throws Exception;

	boolean exportSyncDataList(String vesselId, String syncType) throws Exception;

	boolean exportSyncDataList(String vesselId) throws Exception;

}
