/**
 * 
 */
package in.ind.mds.service;

import java.util.List;

import in.ind.mds.dto.DrillCategoriesDto;


/**
 * @author dharani
 *
 */
public interface DrillCateoriesService {

	DrillCategoriesDto add(DrillCategoriesDto drillCategoriesDto) throws Exception;
	
	DrillCategoriesDto update(DrillCategoriesDto drillCategoriesDto) throws Exception;
	
	List<DrillCategoriesDto> softDeleteDrillCtgy(List<String> drillIds) throws Exception;
	
	List<DrillCategoriesDto>findAll() throws Exception;
	
	DrillCategoriesDto getByDrillCtgyId(String drillId)throws Exception;
	
	DrillCategoriesDto findByDrillCtgyName(String drillCtgyName)throws Exception;
	
	
}
