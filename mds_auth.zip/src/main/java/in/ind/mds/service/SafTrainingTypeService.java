/**
 * 
 */
package in.ind.mds.service;

import java.util.List;

import in.ind.mds.dto.SafTrainingTypeDto;

/**
 * @author shalini
 *
 */
public interface SafTrainingTypeService {

	SafTrainingTypeDto add(SafTrainingTypeDto safTrainingTypeDto) throws Exception;

	SafTrainingTypeDto update(SafTrainingTypeDto safTrainingTypeDto) throws Exception;

	SafTrainingTypeDto findById(String id) throws Exception;
	
	List<SafTrainingTypeDto> findAll() throws Exception;

	List<SafTrainingTypeDto> softDelete(List<String> ids) throws Exception;
}
