package in.ind.mds.service;

import in.ind.mds.dto.AuthenticationDto;
import in.ind.mds.dto.AuthorizationDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.security.auth.request.AuthRequestView;
import in.ind.mds.security.auth.request.LoginRequestView;

public interface AuthHandlerService {

	AuthenticationDto authenticateUser(LoginRequestView requestView) throws ApplicationServiceExecption;

	AuthorizationDto authorizeUser(AuthRequestView requestView) throws ApplicationServiceExecption;

	String generateJWTToken(LoginRequestView loginRequestView);

}
