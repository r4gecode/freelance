package in.ind.mds.service;

public interface ExceptionLogService {
	
	public Integer addNewException(String exception); 
}
