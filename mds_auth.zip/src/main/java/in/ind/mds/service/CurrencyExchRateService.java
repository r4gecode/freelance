/**
 * 
 */
package in.ind.mds.service;

import java.util.List;

import in.ind.mds.dto.CurrencyExchRateDto;

/**
 * @author mds-arockia
 *
 */
public interface CurrencyExchRateService {

	CurrencyExchRateDto add(CurrencyExchRateDto currencyExchRateDto) throws Exception;
	
	List<CurrencyExchRateDto> softDelete(List<String> ids) throws Exception;
	
	CurrencyExchRateDto update(CurrencyExchRateDto currencyExchRateDto) throws Exception;
}
