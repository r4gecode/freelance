package in.ind.mds.service;

import java.util.List;

import in.ind.mds.dto.CountryDto;

public interface CountryService 
{
	CountryDto getCountryId(String countryId) throws Exception;

	CountryDto findByCountryName(String countryName) throws Exception;

	List<CountryDto> findAll() throws Exception;
	
	CountryDto add(CountryDto countryDto) throws Exception;
	
	List<CountryDto> softDeleteCountry(List<String> countryId) throws Exception;
	
	CountryDto updateCountry(CountryDto countryDto) throws Exception ;


}
