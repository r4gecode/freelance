/**
 * 
 */
package in.ind.mds.service;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import in.ind.mds.dto.CrewMedicalReportDto;
import in.ind.mds.repo.entity.Staff;

/**
 * @author mds-arockia
 *
 */
public interface CrewMedicalReportService {
	
	List<CrewMedicalReportDto> add(Staff staff, List<CrewMedicalReportDto> medReportDtoList, MultipartFile[] attachmentFiles) throws Exception;

	List<CrewMedicalReportDto> update(Staff staff, List<CrewMedicalReportDto> medReportDtoList, MultipartFile[] attachmentFiles) throws Exception;

	List<CrewMedicalReportDto> findByStaff(Staff staff) throws Exception;
	
	void softDeleteByStaff(Staff staff)throws Exception;
	
	void softDelete(List<String> ids)throws Exception;

}
