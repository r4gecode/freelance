package in.ind.mds.service;

import java.util.List;

import in.ind.mds.dto.SignOffReasonDto;

public interface SignOffReasonService {

	SignOffReasonDto add(SignOffReasonDto signOffReasonDto) throws Exception;

	List<SignOffReasonDto> findAllSignOffReason() throws Exception;

	List<SignOffReasonDto> softDelete(List<String> ids) throws Exception;

	SignOffReasonDto update(SignOffReasonDto signOffReasonDto) throws Exception;

}
