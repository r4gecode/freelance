package in.ind.mds.service;

import java.util.List;

import in.ind.mds.dto.ComponentDto;
import in.ind.mds.repo.entity.Component;

public interface ComponentService 
{
	ComponentDto getByComponentId(String componentId)throws Exception;

	ComponentDto findBySfiCode(String sfiCode)throws Exception;

	ComponentDto findByComponentNameAndComponentType(String componentName, String componentType)throws Exception;
	
	List<ComponentDto> findAll() throws Exception;
	
	ComponentDto add(ComponentDto componentDto) throws Exception;
	
	List<ComponentDto> softDeleteComponent(List<String> componentIds) throws Exception;
	
	ComponentDto updateComponent(ComponentDto componentDto) throws Exception ;
	
	List<ComponentDto> findByVessel(String vesselId) throws Exception;
	
	List<ComponentDto> findByOnlyRHBasis() throws Exception;

	List<ComponentDto> findByCRBasis() throws Exception;
	
	List<Component> saveAll(List<Component> componentList) throws Exception;
}
