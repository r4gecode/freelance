package in.ind.mds.service;

import java.util.List;

import in.ind.mds.dto.RoleMenuDto;


public interface RoleMenuService 
{
	RoleMenuDto getByRoleMenuId(final String roleMenuId)throws Exception;

	List<RoleMenuDto> findByMenuId(final String menuId)throws Exception;

	RoleMenuDto findByRoleMenuIdAndMenuId(final String roleMenuId, final String menuId)throws Exception;
	
	List<RoleMenuDto> findAll() throws Exception;
	
	RoleMenuDto add(final RoleMenuDto roleMenuDto) throws Exception;
	
	List<RoleMenuDto> softDeleteRoleMenu(List<String> roleMenuIds) throws Exception;
	
	RoleMenuDto updateRoleMenu(RoleMenuDto roleMenuDto) throws Exception ;

	List<RoleMenuDto> findByRoleId(String roleId) throws Exception;



}
