/**
 * 
 */
package in.ind.mds.service;

import java.util.List;

import in.ind.mds.dto.VesselAccessDto;
import in.ind.mds.dto.VesselDto;

/**
 * @author mds-arockia
 *
 */
public interface VesselAccessService {

	public List<VesselAccessDto> addVesselAccess(List<VesselAccessDto> vesselAccessDto) throws Exception;
	
	public List<VesselAccessDto> updateVesselAccess(List<VesselAccessDto> vesselAccessDto) throws Exception;
	
	public List<VesselDto> findVesselByUser(String userId) throws Exception;
	
	public List<VesselAccessDto> findByUser(String userId) throws Exception;
}
