/**
 * 
 */
package in.ind.mds.service;

import java.util.List;

import in.ind.mds.dto.SeverityDto;

/**
 * @author Hinaya
 *
 */
public interface SeverityService  {

	SeverityDto getById(String id) throws Exception;

	SeverityDto add(SeverityDto severityDto) throws Exception;

	List<SeverityDto> findAllSeverity() throws Exception;

	List<SeverityDto> softDelete(List<String> ids) throws Exception;

	SeverityDto update(SeverityDto severityDto) throws Exception;
	
	

}
