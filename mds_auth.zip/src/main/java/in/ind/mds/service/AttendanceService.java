/**
 * 
 */
package in.ind.mds.service;

import java.util.List;
import in.ind.mds.dto.AttendanceDto;

/**
 * @author shalini
 *
 */
public interface AttendanceService {

	AttendanceDto add(AttendanceDto attendanceDto) throws Exception;

	AttendanceDto updateAttendance(AttendanceDto attendanceDto) throws Exception;

	List<AttendanceDto> findAll() throws Exception;

	AttendanceDto findById(String id) throws Exception;

	List<AttendanceDto> softDelete(List<String> ids) throws Exception;

	List<AttendanceDto> findByMaster(String id, String origin)throws Exception;

	List<AttendanceDto> addAll(String id, String origin,List<AttendanceDto> attendanceDtoList) throws Exception;

	void softDeleteByMaster(String id, String origin)throws Exception;

	List<AttendanceDto> updateAll(String id, String origin,List<AttendanceDto> attendanceDtoList) throws Exception;

	

	

}
