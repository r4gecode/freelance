package in.ind.mds;

import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import in.ind.mds.util.RestDataApplicationResponse;
import in.ind.mds.util.RestDataCollection;
import in.ind.mds.util.RestDataCollectionError;

@Component
public class ErrorFilter implements Filter {
	private final Logger log = LoggerFactory.getLogger(ErrorFilter.class);

	public ErrorFilter() {
		log.info("ErrorFilter init");
	}

	@Override
	public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
			throws IOException, ServletException {

		HttpServletRequest request = (HttpServletRequest) req;
		HttpServletResponse response = (HttpServletResponse) res;

		System.out.println(request.getRequestURL().toString());
		Pattern pattern = Pattern.compile("[^&%$#@!~]*");
		Matcher matcher = pattern.matcher(request.getRequestURL().toString());
		if (matcher.matches()) {
			chain.doFilter(req, res);
		} else {
			RestDataCollection restDatacollection = new RestDataCollection();
			restDatacollection.setError(new RestDataCollectionError("URL Deniled: Security vulnerability"));
			restDatacollection.setStatusCode(HttpStatus.NOT_FOUND.value());
			restDatacollection.setVersion("1.0");
			RestDataApplicationResponse restResponse = new RestDataApplicationResponse(restDatacollection);
            response.getWriter().write(convertObjectToJson(restResponse));
		}
	}

	@Override
	public void init(FilterConfig filterConfig) throws ServletException {

	}

	@Override
	public void destroy() {

	}

	public String convertObjectToJson(Object object) throws JsonProcessingException {
		if (object == null) {
			return null;
		}
		ObjectMapper mapper = new ObjectMapper();
		return mapper.writeValueAsString(object);
	}
}