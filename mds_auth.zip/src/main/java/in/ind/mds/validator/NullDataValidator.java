/**
 * 
 */
package in.ind.mds.validator;

import java.lang.reflect.Field;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import in.ind.mds.exception.ApplicationServiceExecption;

/**
 * @author mds-arockia
 *
 */
@Service
public class NullDataValidator<T> {

	private T entity;
	
	public void nullValidator(T entity) throws ApplicationServiceExecption {
		this.entity = entity;
//		if(this.entity.getClass().getName().equals("java.lang.String")) {
//			String fieldValue = (String) entity;
//			if(fieldValue == null)
//				throw new ApplicationServiceExecption(exceptionMessage + " must not be null", HttpStatus.NOT_FOUND);
//		}else {
			try {
				Field field = this.entity.getClass().getDeclaredField("id");
				field.setAccessible(true);
					Object fieldValue = field.get(this.entity);
					if(fieldValue == null)
						throw new ApplicationServiceExecption("Id must not be null", HttpStatus.NOT_FOUND);
			} catch (NoSuchFieldException | SecurityException e) {
				e.printStackTrace();
			}catch (IllegalArgumentException | IllegalAccessException e) {
				e.printStackTrace();
			}
		}
	//}
	
	public void stringNullValidator(String ...fields) throws ApplicationServiceExecption {
		for (String field : fields) {
			if(field == null)
				throw new ApplicationServiceExecption(fields[fields.length - 1] + " must not be null", HttpStatus.NOT_FOUND);
		}
	}
}
