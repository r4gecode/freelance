package in.ind.mds.validator;

import org.springframework.stereotype.Component;

@Component
public class VesselValidator {

	/*public String validateAdd(final VesselDto vesselDto) {
		String errorMessage = null;

		
		 * if (!vesselDto.getMobileNo().matches("\\d{10}")) { errorMessage =
		 * GaurageMessageConstants.INVALID_PHONE.getMessage(); } else if
		 * (!userDto.getEmail().matches("^[A-Za-z0-9+_.-]+@(.+)$")) { errorMessage =
		 * GaurageMessageConstants.INVALID_EMAIL.getMessage(); } else if
		 * (!userDto.getName().matches("^[A-Za-z0-9]{1,}$")) { errorMessage =
		 * GaurageMessageConstants.INVALID_NAME.getMessage(); } else if
		 * (!userDto.getPassword().matches("^[A-Za-z0-9_]{6,}$")) { errorMessage =
		 * GaurageMessageConstants.INVALID_PASSWORD.getMessage(); } else if
		 * (userDto.getGcmRegId() == null || userDto.getGcmRegId().isEmpty()) {
		 * errorMessage = GaurageMessageConstants.GCM_REG_ID_IS_EMPTY.getMessage(); }
		 * return errorMessage; }
		 * 
		 * public String validateUpdate(final VesselDto vesselDto) { String errorMessage
		 * = null;
		 * 
		 * if (!userDto.getMobileNo().matches("\\d{10}")) { errorMessage =
		 * GaurageMessageConstants.INVALID_PHONE.getMessage(); } else if
		 * (!userDto.getEmail().matches("^[A-Za-z0-9+_.-]+@(.+)$")) { errorMessage =
		 * GaurageMessageConstants.INVALID_EMAIL.getMessage(); } else if
		 * (!userDto.getName().matches("^[A-Za-z0-9]{1,}$")) { errorMessage =
		 * GaurageMessageConstants.INVALID_NAME.getMessage(); } return errorMessage; }
		 
	}*/
}
