package in.ind.mds.security.auth.response;

import java.util.Map;

public class AuthResponseView {

	private String username;
	private String userRole;
	private String styleClass;
	private String roles;
	private String profUserRole;
	private String userRoleStr;
	private String environment;
	private String userCompleteName;
	private Map<String, Boolean> rolesPrivilegeMap;
	private Map<String, Boolean> rolesProfPrivilegeMap;

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getUserRole() {
		return userRole;
	}

	public void setUserRole(String userRole) {
		this.userRole = userRole;
	}

	public String getRoles() {
		return roles;
	}

	public void setRoles(String roles) {
		this.roles = roles;
	}

	public String getProfUserRole() {
		return profUserRole;
	}

	public void setProfUserRole(String profUserRole) {
		this.profUserRole = profUserRole;
	}

	public String getUserRoleStr() {
		return userRoleStr;
	}

	public void setUserRoleStr(String userRoleStr) {
		this.userRoleStr = userRoleStr;
	}

	public String getEnvironment() {
		return environment;
	}

	public void setEnvironment(String environment) {
		this.environment = environment;
	}

	public String getUserCompleteName() {
		return userCompleteName;
	}

	public void setUserCompleteName(String userCompleteName) {
		this.userCompleteName = userCompleteName;
	}

	public String getStyleClass() {
		return styleClass;
	}

	public void setStyleClass(String styleClass) {
		this.styleClass = styleClass;
	}

	public Map<String, Boolean> getRolesPrivilegeMap() {
		return rolesPrivilegeMap;
	}

	public void setRolesPrivilegeMap(Map<String, Boolean> rolesPrivilegeMap) {
		this.rolesPrivilegeMap = rolesPrivilegeMap;
	}

	public Map<String, Boolean> getRolesProfPrivilegeMap() {
		return rolesProfPrivilegeMap;
	}

	public void setRolesProfPrivilegeMap(Map<String, Boolean> rolesProfPrivilegeMap) {
		this.rolesProfPrivilegeMap = rolesProfPrivilegeMap;
	}

}
