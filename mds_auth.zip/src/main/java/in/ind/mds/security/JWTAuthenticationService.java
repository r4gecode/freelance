package in.ind.mds.security;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import in.ind.mds.common.constants.AppConstants;
import in.ind.mds.common.constants.SecurityConstants;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

@Component
public class JWTAuthenticationService {

	@Value("${jwt-secret}")
	private  String jwtSecret;

	@Value("${jwt-token-prefix}")
	private   String tokenPrefix;
	/**
	 * Generated the JWT token for each user Id logging in
	 * 
	 * @param res
	 * @param username
	 */
	/*public static void addAuthentication(HttpServletResponse res, String username) {
		String JWT = Jwts.builder().setSubject(username)
				.setExpiration(new Date(System.currentTimeMillis() + SecurityConstants.EXPIRATION_TIME))
				.signWith(SignatureAlgorithm.HS512, SecurityConstants.SECRET).compact();
		res.addHeader(SecurityConstants.JWT_TOKEN_HEADER_PARAM, SecurityConstants.TOKEN_PREFIX + " " + JWT);
		System.out.println("ResponseHeader - "+res.getHeader(SecurityConstants.JWT_TOKEN_HEADER_PARAM));
	}*/
	public String addAuthentication(String username) {
		/*String JWT = Jwts.builder().setSubject(userName).compact();
		TokenRepositoryService tokenRepository = ApplicationContextFactory.getTokenRepository();
		tokenRepository.storeTokenForUserName(userName, JWT);*/
		/*String JWT = Jwts.builder().setSubject(userName).signWith(SignatureAlgorithm.HS512, SecurityConstants.SECRET)
				.compact();
		res.addHeader(SecurityConstants.JWT_TOKEN_HEADER_PARAM, JWT);*/
		String JWT = Jwts.builder().setSubject(username).signWith(SignatureAlgorithm.HS512, jwtSecret).compact();
		return tokenPrefix + " " + JWT;
	}

	/**
	 * Authenticates the token in the header for the user Id logged in
	 * 
	 * @param request
	 * @return
	 * @throws InvalidJwtTokenException 
	 */
	public Authentication getAuthentication(HttpServletRequest request) {
		String userName = request.getHeader(AppConstants.USER_NAME);
		String token = request.getHeader(SecurityConstants.JWT_TOKEN_HEADER_PARAM);
		if (token != null) {
			/*TokenRepositoryService tokenRepository = ApplicationContextFactory.getTokenRepository();
			String user = tokenRepository.getUserForToken(token);*/
			/*String user = Jwts.parser().setSigningKey(SecurityConstants.SECRET)
					.parseClaimsJws(token.replace(SecurityConstants.TOKEN_PREFIX, " ")).getBody().getSubject();*/
			String user = Jwts.parser().setSigningKey(jwtSecret)
					.parseClaimsJws(token.replace(tokenPrefix, "")).getBody().getSubject();

				if (!StringUtils.isEmpty(userName) && !StringUtils.isEmpty(user) && user.equalsIgnoreCase(userName)) {
					return new UsernamePasswordAuthenticationToken(user, null, new ArrayList<>());
				}
		}
	return null;
	}
}
