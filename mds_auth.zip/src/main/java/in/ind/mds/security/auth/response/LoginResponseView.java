package in.ind.mds.security.auth.response;

public class LoginResponseView {

	private String userName;
	private String loginID;
	private String userShortName;
	private int userTitle;
	private String usertype;
	private String authToken;

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getLoginID() {
		return loginID;
	}

	public void setLoginID(String loginID) {
		this.loginID = loginID;
	}

	public String getUserShortName() {
		return userShortName;
	}

	public void setUserShortName(String userShortName) {
		this.userShortName = userShortName;
	}

	public int getUserTitle() {
		return userTitle;
	}

	public void setUserTitle(int userTitle) {
		this.userTitle = userTitle;
	}

	public String getUsertype() {
		return usertype;
	}

	public void setUsertype(String usertype) {
		this.usertype = usertype;
	}

	public String getAuthToken() {
		return authToken;
	}

	public void setAuthToken(String authToken) {
		this.authToken = authToken;
	}

}
