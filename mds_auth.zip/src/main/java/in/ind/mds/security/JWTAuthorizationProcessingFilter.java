package in.ind.mds.security;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.filter.GenericFilterBean;

import in.ind.mds.common.ApplicationContextFactory;
import in.ind.mds.serviceImpl.AddressServiceImpl;

public class JWTAuthorizationProcessingFilter extends GenericFilterBean {

	/**
	 * Logger for class
	 */
	private static final String CLASSNAME = "JWTAuthorizationProcessingFilter";
	private static final Logger LOGGER = LoggerFactory.getLogger(JWTAuthorizationProcessingFilter.class);

	/**
	 * Authorizes every incoming request with the JWT token generated
	 * 
	 * @throws exception
	 *             in case of invalid Authorization token sent
	 */
	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain filterChain)
			throws IOException, ServletException {
		// Authentication authentication =
		// JWTAuthenticationService.getAuthentication((HttpServletRequest)
		// request);
		JWTAuthenticationService tokenAuthService = ApplicationContextFactory.getTokenAuthenticationService();
		Authentication authentication = tokenAuthService.getAuthentication((HttpServletRequest) request);

		SecurityContextHolder.getContext().setAuthentication(authentication);
		filterChain.doFilter(request, response);

	}
}
