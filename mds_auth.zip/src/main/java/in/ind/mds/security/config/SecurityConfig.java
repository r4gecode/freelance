package in.ind.mds.security.config;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.access.AccessDeniedHandler;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import in.ind.mds.common.constants.AppConstants;
import in.ind.mds.common.constants.RequestHeaders;
import in.ind.mds.common.constants.RequestType;
import in.ind.mds.common.constants.SecurityConstants;
import in.ind.mds.security.JWTAuthorizationProcessingFilter;

@Configuration
public class SecurityConfig extends WebSecurityConfigurerAdapter {

	/*@Bean
	public AccessDeniedHandler accessDeniedHandler() {
		return new AppAccessDeniedHandler();
	}*/

	@Bean
	protected PasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}

	@Override
	protected void configure(HttpSecurity http) throws Exception {
		//http.cors();
		http.csrf().disable();
		http.authorizeRequests()
		.antMatchers("/authentication").permitAll()
		.anyRequest().authenticated().and()
		.addFilterBefore(new JWTAuthorizationProcessingFilter(), UsernamePasswordAuthenticationFilter.class)
				/*.exceptionHandling().accessDeniedHandler(accessDeniedHandler())*/;
	}

	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {	
		String password = passwordEncoder().encode(SecurityConstants.ADMIN_PASSWORD);
		auth.inMemoryAuthentication().withUser(SecurityConstants.ADMIN_USER_NAME).password(SecurityConstants.ADMIN_PASSWORD)
				.roles(SecurityConstants.ADMIN_PASSWORD);
	}

	@Bean
	public CorsConfigurationSource corsConfigurationSource() {
		final CorsConfiguration configuration = new CorsConfiguration();
		List<String> originList = new ArrayList<>();
		originList.addAll(SecurityConstants.ORIGIN_LIST);
		configuration.setAllowedOrigins(originList);
		configuration.setAllowedMethods(java.util.Arrays.asList(RequestType.DELETE.name(), RequestType.GET.name(),
				RequestType.HEAD.name(), RequestType.PATCH.name(), RequestType.POST.name(), RequestType.PUT.name()));
		configuration.setAllowCredentials(true);
		configuration.setAllowedHeaders(Arrays.asList(RequestHeaders.AUTHORIZATION.getType(), RequestHeaders.CACHE_CONTROL.getType(),
				RequestHeaders.CONTENT_TYPE.getType(), RequestHeaders.USER_NAME.getType()));
		final UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
		source.registerCorsConfiguration("/**", configuration);
		return source;
	}

}
