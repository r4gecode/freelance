package in.ind.mds.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import in.ind.mds.dto.ComponentDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.service.ComponentService;
import in.ind.mds.util.RestDataApplicationResponse;

@RestController
@RequestMapping("/v1/component")


public class ComponentController extends BaseController 
{
	private static final Logger LOGGER = LoggerFactory.getLogger(ComponentController.class);

	@Autowired
	@Qualifier("TST_MSSQL_COMPONENT")
	private ComponentService componentService;

	//@Autowired
	//private CommonUtil commonUtil;

	@RequestMapping(value = "/doLogin/{componentName}/{componentType}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> doLogin(@PathVariable String componentName,
			@PathVariable String componentType) {
		ResponseEntity<RestDataApplicationResponse> response;
		ComponentDto componentDto = null;

		try {
			componentDto = componentService.findByComponentNameAndComponentType(componentName, componentType);
			response = buildSuccessMessage(componentDto, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in ComponentController.doLogin");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}

	@RequestMapping(value = "findByComponentId/{componentId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> getUser(@PathVariable String componentId) {
		ComponentDto componentDto = null;
		ResponseEntity<RestDataApplicationResponse> response;
		try {
			componentDto = componentService.getByComponentId(componentId);
			response = buildSuccessMessage(componentDto, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in ComponentController.getByComponentId");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}

	@RequestMapping(value = "/findBySfiCode/{sfiCode}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> getUserByName(@PathVariable String sfiCode) {
		ComponentDto componentDto = null;
		ResponseEntity<RestDataApplicationResponse> response;
		try {
			componentDto = componentService.findBySfiCode(sfiCode);
			response = buildSuccessMessage(componentDto, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in ComponentController.findBySfiCode");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
	
	@RequestMapping(value = "/all", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> findAll() {
		ResponseEntity<RestDataApplicationResponse> response;
		List<ComponentDto> componentDto = null;

		try {
			componentDto = componentService.findAll();
			response = buildSuccessMessage(componentDto, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in ComponentController.findAll");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}

	@RequestMapping(method = RequestMethod.PUT, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> add(@RequestBody ComponentDto componentDto) {
		ResponseEntity<RestDataApplicationResponse> response = null;

		try {
			componentDto = componentService.add(componentDto);
			response = buildSuccessMessage(componentDto, HttpStatus.CREATED);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in ComponentController.add");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}

	@RequestMapping(value = "/softDelete", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> deleteComponent(@RequestBody List<String> componentIds) {
		ResponseEntity<RestDataApplicationResponse> response;
		try {
			List<ComponentDto> componentDtoList = componentService.softDeleteComponent(componentIds);
			response = buildSuccessMessage(componentDtoList, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in ComponentController.del");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
	
	@RequestMapping(value = "/update", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> updateComponent(@RequestBody ComponentDto componentDto) {
		ResponseEntity<RestDataApplicationResponse> response;
		try {
			componentDto = componentService.updateComponent(componentDto);
			response = buildSuccessMessage(componentDto, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in ComponentController.update");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
	
	@RequestMapping(value = "/findByVesselId/{vesselId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> findByVesselId(@PathVariable("vesselId") String vesselId) {
		ResponseEntity<RestDataApplicationResponse> response;
		List<ComponentDto> componentDto = null;

		try {
			componentDto = componentService.findByVessel(vesselId);
			response = buildSuccessMessage(componentDto, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in ComponentController.findByVesselId");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
	
	@RequestMapping(value = "/findByOnlyRHBasis", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> findByOnlyRHBasis() {
		ResponseEntity<RestDataApplicationResponse> response;
		List<ComponentDto> componentDto = null;

		try {
			componentDto = componentService.findByOnlyRHBasis();
			response = buildSuccessMessage(componentDto, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in ComponentController.findByOnlyRHBasis");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
	
	@RequestMapping(value = "/findByCRBasis", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> findByCRBasis() {
		ResponseEntity<RestDataApplicationResponse> response;
		List<ComponentDto> componentDto = null;

		try {
			componentDto = componentService.findByCRBasis();
			response = buildSuccessMessage(componentDto, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in ComponentController.findByCRBasis");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
	
}
