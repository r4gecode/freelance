package in.ind.mds.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import in.ind.mds.dto.MenuDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.service.MenuService;
import in.ind.mds.util.RestDataApplicationResponse;

@RestController
@RequestMapping("/v1/menu")

public class MenuController extends BaseController
{
	private static final Logger LOGGER = LoggerFactory.getLogger(MenuController.class);

	@Autowired
	@Qualifier("TST_MSSQL_MENU")
	private MenuService menuService;

	//@Autowired
	//private CommonUtil commonUtil;

	@RequestMapping(value = "/doLogin/{menuDesc}/{menuUrl}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> doLogin(@PathVariable String menuDesc,
			@PathVariable String menuUrl) {
		ResponseEntity<RestDataApplicationResponse> response;
		MenuDto menuDto = null;

		try {
			menuDto = menuService.findByMenuDescAndMenuUrl(menuDesc,menuUrl);
			response = buildSuccessMessage(menuDto, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in MenuController.doLogin");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}

	@RequestMapping(value = "/getByMenuId/{menuId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> getByMenuId(@PathVariable String menuId) {
		MenuDto menuDto = null;
		ResponseEntity<RestDataApplicationResponse> response;
		try {
			menuDto = menuService.getByMenuId(menuId);
			response = buildSuccessMessage(menuDto, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in MenuController.getByMenuId");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}

	@RequestMapping(value = "/getByMenuCode/{menuCode}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> findByMenuCode(@PathVariable String menuCode) {
		MenuDto menuDto = null;
		ResponseEntity<RestDataApplicationResponse> response;
		try {
			menuDto = menuService.findByMenuCode(menuCode);
			response = buildSuccessMessage(menuDto, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in MenuController.findByMenuCode");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
	
	@RequestMapping(value = "/all", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> findAll() {
		ResponseEntity<RestDataApplicationResponse> response;
		List<MenuDto> menuDto = null;

		try {
			menuDto = menuService.findAll();
			response = buildSuccessMessage(menuDto, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in MenuController.findAll");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}

	@RequestMapping(method = RequestMethod.PUT, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> add(@RequestBody MenuDto menuDto) {
		ResponseEntity<RestDataApplicationResponse> response = null;

		try {
			menuDto = menuService.add(menuDto);
			response = buildSuccessMessage(menuDto, HttpStatus.CREATED);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in MenuController.add");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}

	@RequestMapping(value = "/softDelete", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> softDeleteMenu(@RequestBody List<String> menuIds) {
		ResponseEntity<RestDataApplicationResponse> response;
		try {
			List<MenuDto> menuDtoList = menuService.softDeleteMenu(menuIds);
			response = buildSuccessMessage(menuDtoList, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in MenuController.softDelete");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
	
	@RequestMapping(value = "/update", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> updateAddress(@RequestBody MenuDto menuDto) {
		ResponseEntity<RestDataApplicationResponse> response;
		try {
			menuDto = menuService.updateMenu(menuDto);
			response = buildSuccessMessage(menuDto, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in MenuController.update");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
	


}