/**
 * 
 */
package in.ind.mds.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;


import in.ind.mds.dto.OperationTypeDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.service.OperationTypeService;
import in.ind.mds.util.RestDataApplicationResponse;

/**
 * @author dharani
 *
 */

@RestController
@RequestMapping("/v1/operationType")
public class OperationTypeController extends BaseController{
	
	private static final Logger LOGGER = LoggerFactory.getLogger(OperationTypeController.class);

	@Autowired
	@Qualifier("TST_MSSQL_OPERATION_TYPE")
	private OperationTypeService operationTypeService;
	
	
	@RequestMapping(method = RequestMethod.PUT, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> add(@RequestBody OperationTypeDto operationTypeDto) {
		ResponseEntity<RestDataApplicationResponse> response = null;

		try {
			operationTypeDto = operationTypeService.add(operationTypeDto);
			response = buildSuccessMessage(operationTypeDto, HttpStatus.CREATED);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in OperationTypeController.add");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}

	@RequestMapping(value = "/update", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> update(@RequestBody OperationTypeDto operationTypeDto) {
		ResponseEntity<RestDataApplicationResponse> response;
		try {
			operationTypeDto = operationTypeService.update(operationTypeDto);
			response = buildSuccessMessage(operationTypeDto, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in OperationTYpeController.update");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
	
	@RequestMapping(value = "/all", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> findAll() {
		ResponseEntity<RestDataApplicationResponse> response;
		List<OperationTypeDto> operationTypeDto = null;

		try {
			operationTypeDto = operationTypeService.findAll();
			response = buildSuccessMessage(operationTypeDto, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in OperationTypeController.findAll");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}

	@RequestMapping(value = "/findById/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> findById(@PathVariable String id) {
		OperationTypeDto operationTypeDto = null;
		ResponseEntity<RestDataApplicationResponse> response;
		try {
			operationTypeDto = operationTypeService.findById(id);
			response = buildSuccessMessage(operationTypeDto, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in OPerationTypeController.getByJobCtgyId");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
	@RequestMapping(value = "/softDelete", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> softDelete(@RequestBody List<String> id) {
		ResponseEntity<RestDataApplicationResponse> response;
		try {
			List<OperationTypeDto> operationTypeDtoList = operationTypeService.softDelete(id);
			response = buildSuccessMessage(operationTypeDtoList, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in OPerationTypeController.softDelete");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}


}
