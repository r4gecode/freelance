/**
 * 
 */
package in.ind.mds.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.ind.mds.dto.FleetDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.service.FleetService;
import in.ind.mds.util.RestDataApplicationResponse;

/**
 * @author mds-arockia
 *
 */	
@RestController
@RequestMapping("/v1/fleet")
public class FleetController extends BaseController{
	
	private static final Logger LOGGER = LoggerFactory.getLogger(FleetController.class);

	@Autowired
	@Qualifier("TST_MSSQL_FLEET")
	private FleetService fleetService;

	@PutMapping(produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> add(@RequestBody FleetDto fleetDto){
		ResponseEntity<RestDataApplicationResponse> response = null;
		
		try {
			fleetDto = fleetService.add(fleetDto);
			response = buildSuccessMessage(fleetDto, HttpStatus.CREATED);
		}catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(), e);
		} catch (Exception e) {
			LOGGER.error("Exception in FleetController.add()");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR, e);
		}
		return response;
	}
	
	@GetMapping(value = "/getByFleetId/{fleetId}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> getByFleetId(@PathVariable String fleetId) {
		ResponseEntity<RestDataApplicationResponse> response;
		FleetDto fleetDto = null;
		try {
			fleetDto = fleetService.findByFleetId(fleetId);
			response = buildSuccessMessage(fleetDto, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in FleetController.getByCompanyId");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}

	@GetMapping(value = "/all", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> findAll() {
		ResponseEntity<RestDataApplicationResponse> response;
		List<FleetDto> fleetDto = null;
		try {
			fleetDto = fleetService.findAll();
			response = buildSuccessMessage(fleetDto, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in FleetController.findAll");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}

	@PostMapping(value = "/softDelete", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> softDeleteFleet(@RequestBody List<String> fleetIds) {
		ResponseEntity<RestDataApplicationResponse> response;
		try {
			List<FleetDto> fleetDtoList = fleetService.softDeleteFleet(fleetIds);
			response = buildSuccessMessage(fleetDtoList, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in CompanyController.softDeleteFleet");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
	
	@PostMapping(value = "/update", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> updateFleet(@RequestBody FleetDto fleetDto) {
		ResponseEntity<RestDataApplicationResponse> response;
		try {
			fleetDto = fleetService.updateFleet(fleetDto);
			response = buildSuccessMessage(fleetDto, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in FleetController.updateFleet");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
}
