/**
 * 
 */
package in.ind.mds.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;

import in.ind.mds.dto.DrillCompletionDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.service.DrillCompletionService;
import in.ind.mds.util.RestDataApplicationResponse;

/**
 * @author shalini
 *
 */
@RestController
@RequestMapping(value="/v1/drillCompletion")
public class DrillCompletionController extends BaseController{

	private static final Logger LOGGER = LoggerFactory.getLogger(DrillCompletionController.class);

	@Autowired
	@Qualifier("TST_MSSQL_DRILL_COMPLETION")
	private DrillCompletionService drillCompletionService;
	
	@RequestMapping(value = "/findById/{drillSchedulerId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> findById(@PathVariable String drillSchedulerId) {
		ResponseEntity<RestDataApplicationResponse> response;
		DrillCompletionDto drillCompletionDto = null;
		try {
			drillCompletionDto = drillCompletionService.findById(drillSchedulerId);
			response = buildSuccessMessage(drillCompletionDto, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in DrillCompletionController.findById");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
	
	@RequestMapping(method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> add(@RequestParam("drillCompletion") String drillCompletionDetails, @RequestParam("drillCompletionDoc") MultipartFile[] drillComplAtch
			,@RequestParam("officeReviewAtch") MultipartFile[] officeReviewAtch) throws JsonParseException, JsonMappingException, IOException {
		ResponseEntity<RestDataApplicationResponse> response = null;
		DrillCompletionDto drillCompletionDto = null;
		try {
			Map<String, MultipartFile[]> attachments = new HashMap<>();
			attachments.put("drillCompletionDoc", drillComplAtch);
			attachments.put("officeReviewAtch", officeReviewAtch);
			
			drillCompletionDto = drillCompletionService.add(drillCompletionDetails, attachments);
			response = buildSuccessMessage(drillCompletionDto, HttpStatus.CREATED);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in DrillCompletionController.add");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
	
	@RequestMapping(value = "/all", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> findAll() {
		ResponseEntity<RestDataApplicationResponse> response = null;
		List<DrillCompletionDto> drillCompletionDtoList = new ArrayList<>();
		try {
			drillCompletionDtoList = drillCompletionService.findAll();
			response = buildSuccessMessage(drillCompletionDtoList, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in DrillCompletionController.findAll");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
	
	@RequestMapping(value = "/softDelete", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> softDelete(@RequestBody List<String> drillCompletionId) {
		ResponseEntity<RestDataApplicationResponse> response = null;
		try {
			List<DrillCompletionDto> drillCompletionDtoList=drillCompletionService.softDelete(drillCompletionId);
			response = buildSuccessMessage(drillCompletionDtoList, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in DrillCompletionController.softDelete");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
	
	@RequestMapping(value = "/update", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> update(@RequestParam("drillCompletion") String drillCompletionDetails, @RequestParam("drillCompletionDoc") MultipartFile[] drillComplAtch
			, @RequestParam("officeReviewAtch") MultipartFile[] officeReviewAtch) throws JsonParseException, JsonMappingException, IOException {
		ResponseEntity<RestDataApplicationResponse> response = null;
		DrillCompletionDto drillCompletionDto = null;
		try {
			Map<String, MultipartFile[]> attachments = new HashMap<>();
			attachments.put("drillCompletionDoc", drillComplAtch);
			attachments.put("officeReviewAtch", officeReviewAtch);
			drillCompletionDto = drillCompletionService.update(drillCompletionDetails, attachments);
			response = buildSuccessMessage(drillCompletionDto, HttpStatus.CREATED);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in DrillCompletionController.update");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
}
