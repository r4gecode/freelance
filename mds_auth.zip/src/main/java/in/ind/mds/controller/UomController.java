package in.ind.mds.controller;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import in.ind.mds.dto.UomDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.service.UomService;
import in.ind.mds.util.RestDataApplicationResponse;

@RestController
@RequestMapping("/v1/uom")

public class UomController extends BaseController
{

	private static final Logger LOGGER = LoggerFactory.getLogger(UomController.class);

	@Autowired
	@Qualifier("TST_MSSQL_UOM")
	private UomService uomService;

	//@Autowired
	//private CommonUtil commonUtil;
		
	@RequestMapping(value = "/getUomId/{uomId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> getUomId(@PathVariable String uomId) {
		ResponseEntity<RestDataApplicationResponse> response;
		UomDto uomDto = null;

		try {
			uomDto = uomService.getUomId(uomId);
			response = buildSuccessMessage(uomDto, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in UomController.getCountryId");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}

	@RequestMapping(value = "/all", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> findAllUom() {
		ResponseEntity<RestDataApplicationResponse> response;
		List<UomDto> listUomDto = new ArrayList<>();

		try {
			listUomDto = uomService.findAll();
			response = buildSuccessMessage(listUomDto, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in UomController.findAllUom");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
	
	@RequestMapping(method = RequestMethod.PUT, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> add(@RequestBody UomDto uomDto) {
		ResponseEntity<RestDataApplicationResponse> response = null;

		try {
			uomDto = uomService.add(uomDto);
			response = buildSuccessMessage(uomDto, HttpStatus.CREATED);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in UomController.add");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}

	@RequestMapping(value = "/softDelete/{uomId}", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> softDeleteUom(@PathVariable String uomId) {
		ResponseEntity<RestDataApplicationResponse> response;
		try {
			uomService.softDeleteUom(uomId);
			response = buildBooleanStatus(true, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in UomController.del");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
	
	@RequestMapping(value = "/update", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> updateUom(@RequestBody UomDto uomDto) {
		ResponseEntity<RestDataApplicationResponse> response;
		try {
			uomDto = uomService.updateUom(uomDto);
			response = buildSuccessMessage(uomDto, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in UomController.update");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
	
	
	@RequestMapping(value = "/softDelete", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> softDelete(@RequestBody List<String>  uomIds) {
		ResponseEntity<RestDataApplicationResponse> response;
		try {
			List<UomDto> uomDtoList=uomService.multipleSoftDelete(uomIds);
			response = buildSuccessMessage(uomDtoList, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in PortController.softDeleteUom");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}



}
