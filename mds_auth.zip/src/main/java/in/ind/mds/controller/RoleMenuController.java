package in.ind.mds.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import in.ind.mds.dto.RoleMenuDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.service.RoleMenuService;
import in.ind.mds.util.RestDataApplicationResponse;

@RestController
@RequestMapping("/v1/roleMenu")
public class RoleMenuController extends BaseController
{
	private static final Logger LOGGER = LoggerFactory.getLogger(RoleMenuController.class);

	@Autowired
	@Qualifier("TST_MSSQL_ROLE_MENU")
	private RoleMenuService roleMenuService;

	//@Autowired
	//private CommonUtil commonUtil;

	@RequestMapping(value = "/doLogin/{roleMenuId}/{menuId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> doLogin(@PathVariable String roleMenuId,
			@PathVariable String menuId) {
		ResponseEntity<RestDataApplicationResponse> response;
		RoleMenuDto roleMenuDto = null;

		try {
			roleMenuDto = roleMenuService.findByRoleMenuIdAndMenuId(roleMenuId,menuId);
			response = buildSuccessMessage(roleMenuDto, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in RoleMenuController.doLogin");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}

	@RequestMapping(value = "getByRoleMenuId/{roleMenuId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> getByRoleMenuId(@PathVariable String roleMenuId) {
		RoleMenuDto roleMenuDto = null;
		ResponseEntity<RestDataApplicationResponse> response;
		try {
			roleMenuDto = roleMenuService.getByRoleMenuId(roleMenuId);
			response = buildSuccessMessage(roleMenuDto, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in RoleMenuController.getByRoleMenuId");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}

	@RequestMapping(value = "/getByMenuId/{menuId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> findByMenuId(@PathVariable String menuId) {
		List<RoleMenuDto> roleMenuDto = null;
		ResponseEntity<RestDataApplicationResponse> response;
		try {
			roleMenuDto = roleMenuService.findByMenuId(menuId);
			response = buildSuccessMessage(roleMenuDto, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in RoleMenuController.findByMenuId");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
	@RequestMapping(value = "/all", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> findAll() {
		ResponseEntity<RestDataApplicationResponse> response;
		List<RoleMenuDto> roleMenuDto = null;

		try {
			roleMenuDto = roleMenuService.findAll();
			response = buildSuccessMessage(roleMenuDto, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in RoleMenuController.findAll");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}

	@RequestMapping(method = RequestMethod.PUT, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> add(@RequestBody RoleMenuDto roleMenuDto) {
		ResponseEntity<RestDataApplicationResponse> response = null;

		try {
			roleMenuDto = roleMenuService.add(roleMenuDto);
			response = buildSuccessMessage(roleMenuDto, HttpStatus.CREATED);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in RoleMenuController.add");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}

	@RequestMapping(value = "/softDelete", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> softDeleteRoleMenu(@RequestBody List<String> roleMenuIds) {
		ResponseEntity<RestDataApplicationResponse> response;
		try {
			List<RoleMenuDto> roleMenuListDto=roleMenuService.softDeleteRoleMenu(roleMenuIds);
			response = buildSuccessMessage(roleMenuListDto, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in RoleMenuController.softDelete");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
	
	@RequestMapping(value = "/update", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> updateRoleMenu(@RequestBody RoleMenuDto roleMenuDto) {
		ResponseEntity<RestDataApplicationResponse> response;
		try {
			roleMenuDto = roleMenuService.updateRoleMenu(roleMenuDto);
			response = buildSuccessMessage(roleMenuDto, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in RoleMenuController.update");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
	

}