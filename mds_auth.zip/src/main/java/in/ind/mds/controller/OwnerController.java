package in.ind.mds.controller;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import in.ind.mds.dto.OwnerDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.service.OwnerService;
import in.ind.mds.util.RestDataApplicationResponse;
@RestController
@RequestMapping("/v1/owner")
public class OwnerController extends BaseController {

	private static final Logger LOGGER = LoggerFactory.getLogger(OwnerController.class);

	@Autowired
	@Qualifier("TST_MSSQL_OWNER")
	private OwnerService ownerService;

	//@Autowired
	//private CommonUtil commonUtil;
	
	@RequestMapping(value = "/doLogin/{ownerId}/{ownerName}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> doLogin(@PathVariable String ownerId,
			@PathVariable String ownerName) {
		ResponseEntity<RestDataApplicationResponse> response;
		OwnerDto ownerDto = null;

		try {
			ownerDto = ownerService.findByOwnerIdAndOwnerName(ownerId,ownerName);
			response = buildSuccessMessage(ownerDto, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in OwnerController.doLogin");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}

	@RequestMapping(value = "/getByOwnerId/{ownerId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> getByOwnerId(@PathVariable String ownerId) {
		ResponseEntity<RestDataApplicationResponse> response;
		OwnerDto ownerDto = null;

		try {
			ownerDto = ownerService.getByOwnerId(ownerId);
			response = buildSuccessMessage(ownerDto, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in OwnerController.getByOwnerId");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}

	@RequestMapping(value = "/findByOwnerName/{ownerName}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> findByOwnerName(@PathVariable String ownerName) {
		ResponseEntity<RestDataApplicationResponse> response;
		OwnerDto ownerDto = null;

		try {
			ownerDto = ownerService.findByOwnerName(ownerName);
			response = buildSuccessMessage(ownerDto, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in OwnerController.findByOwnerName");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}

	@RequestMapping(value = "/all", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> findAllOwner() {
		ResponseEntity<RestDataApplicationResponse> response;
		List<OwnerDto> listOwnerDto = new ArrayList<>();

		try {
			listOwnerDto = ownerService.findAll();
			response = buildSuccessMessage(listOwnerDto, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in OwnerController.findAllOwner");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
	@RequestMapping(method = RequestMethod.PUT, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> add(@RequestBody OwnerDto ownerDto) {
		ResponseEntity<RestDataApplicationResponse> response = null;

		try {
			ownerDto = ownerService.add(ownerDto);
			response = buildSuccessMessage(ownerDto, HttpStatus.CREATED);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in OwnerController.add");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}

	@RequestMapping(value = "/softDelete", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> softDeleteOwner(@RequestBody List<String> ownerIds) {
		ResponseEntity<RestDataApplicationResponse> response;
		try {
			List<OwnerDto> ownerDtoList = ownerService.softDeleteOwner(ownerIds);
			response = buildSuccessMessage(ownerDtoList, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in OwnerController.softDeleteOwner");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
	
	@RequestMapping(value = "/update", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> updateOwner(@RequestBody OwnerDto ownerDto) {
		ResponseEntity<RestDataApplicationResponse> response;
		try {
			ownerDto = ownerService.updateOwner(ownerDto);
			response = buildSuccessMessage(ownerDto, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in OwnerController.updateOwner");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
	
}
