package in.ind.mds.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.ind.mds.dto.SignOffReasonDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.service.SignOffReasonService;
import in.ind.mds.util.RestDataApplicationResponse;

@RestController
@RequestMapping(value = "/v1/signOffReason")
public class SignOffReasonController extends BaseController {

	private static final Logger LOGGER = LoggerFactory.getLogger(SignOffReasonController.class);
	
	@Autowired
	@Qualifier("TST_MSSQL_CREW_SIGN_OFF_REASON")
	private SignOffReasonService signOffReasonService;
	
	@PutMapping(produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> add(@RequestBody SignOffReasonDto signOffReasonDto) {
		ResponseEntity<RestDataApplicationResponse> response = null;
		try {
			signOffReasonDto = signOffReasonService.add(signOffReasonDto);
			response = buildSuccessMessage(signOffReasonDto, HttpStatus.CREATED);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in SignOffReasonController.add");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
	
	@GetMapping(value = "/all", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> findAll() {
		ResponseEntity<RestDataApplicationResponse> response;
		List<SignOffReasonDto> signOffReasonList = null;
		try {
			signOffReasonList = signOffReasonService.findAllSignOffReason();
			response = buildSuccessMessage(signOffReasonList, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in SignOffReasonController.findAll");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}


	@PostMapping(value = "/softDelete", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> softDelete(@RequestBody List<String> ids) {
		ResponseEntity<RestDataApplicationResponse> response;
		try {
			List<SignOffReasonDto> signOffReasonDtoList = signOffReasonService.softDelete(ids);
			response = buildSuccessMessage(signOffReasonDtoList, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in SignOffReasonController.softDelete");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
	
	@PostMapping(value = "/update", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> update(@RequestBody SignOffReasonDto signOffReasonDto) {
		ResponseEntity<RestDataApplicationResponse> response;
		try {
			signOffReasonDto = signOffReasonService.update(signOffReasonDto);
			response = buildSuccessMessage(signOffReasonDto, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in SignOffReasonController.update");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}

	
	
}
