/**
 * 
 */
package in.ind.mds.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.ind.mds.dto.RunningHourDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.service.RunningHourService;
import in.ind.mds.util.RestDataApplicationResponse;

/**
 * @author mds-arockia
 *
 */
@RestController
@RequestMapping(value = "/v1/runningHour")
public class RunningHourController extends BaseController{

	private static final Logger LOGGER = LoggerFactory.getLogger(RunningHourController.class);
	
	@Autowired
	@Qualifier("TST_MSSQL_RUNNING_HOUR")
	private RunningHourService runningHourService;
	
	@PostMapping(produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> add(@RequestBody RunningHourDto runningHourDto) {
		ResponseEntity<RestDataApplicationResponse> response = null;
		List<RunningHourDto> runningHourDtoList = null;
		try {
			runningHourDtoList = runningHourService.add(runningHourDto);
			response = buildSuccessMessage(runningHourDtoList, HttpStatus.CREATED);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in RunningHourController.add");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
}
