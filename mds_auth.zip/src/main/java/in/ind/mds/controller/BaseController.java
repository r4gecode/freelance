package in.ind.mds.controller;

import java.io.Serializable;
import java.util.List;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.service.ExceptionLogService;
import in.ind.mds.util.RestDataApplicationResponse;
import in.ind.mds.util.RestDataCollection;
import in.ind.mds.util.RestDataCollectionError;

public abstract class BaseController {

	private static final String VERSION = "1.0";

	@Autowired
	private ExceptionLogService exceptionLogService;

	protected ResponseEntity<RestDataApplicationResponse> buildSuccessMessage(final Serializable dto,
			final HttpStatus status) {

		RestDataCollection restDatacollection = new RestDataCollection();
		restDatacollection.setData(dto);
		restDatacollection.setStatusCode(HttpStatus.OK.value());
		restDatacollection.setVersion(VERSION);
		return new ResponseEntity<RestDataApplicationResponse>(new RestDataApplicationResponse(restDatacollection),
				status);
	}

	protected ResponseEntity<RestDataApplicationResponse> buildSuccessMessage(final List<? extends Serializable> dto,
			final HttpStatus status) {

		RestDataCollection restDatacollection = new RestDataCollection();
		restDatacollection.setData(dto);
		restDatacollection.setStatusCode(HttpStatus.OK.value());
		restDatacollection.setVersion(VERSION);
		return new ResponseEntity<RestDataApplicationResponse>(new RestDataApplicationResponse(restDatacollection),
				status);
	}

//	protected ResponseEntity<RestDataApplicationResponse> buildErrorMessage(final String errorMessage,
//	final HttpStatus status) {
////if(e instanceof ApplicationServiceExecption) {
////	RestDataCollection restDatacollection = new RestDataCollection();
////	restDatacollection.setError(new RestDataCollectionError(errorMessage, null));
////	restDatacollection.setStatusCode(status.value());
////	restDatacollection.setVersion(VERSION);
////	return new ResponseEntity<RestDataApplicationResponse>(new RestDataApplicationResponse(restDatacollection),
////			status);
//////	ApplicationServiceExecption ex = (ApplicationServiceExecption) e;
//////	response = buildErrorMessage(ex.getErrorMessage(), ex.getStatus());
////}else 
////	return logException(errorMessage, status, e);			
//return null;
//}

	protected ResponseEntity<RestDataApplicationResponse> buildErrorMessage(final String errorMessage,
			final HttpStatus status, Throwable e) {
		ResponseEntity<RestDataApplicationResponse> response = null;
		if (e instanceof ApplicationServiceExecption) {
			response = buildErrorResponse(errorMessage, status, null);
		} else {
			response = logException(errorMessage, status, e);
		}

		return response;
	}

	private ResponseEntity<RestDataApplicationResponse> buildErrorResponse(final String errorMessage,
			final HttpStatus status, Integer exceptionId) {
		RestDataCollection restDatacollection = new RestDataCollection();
		restDatacollection.setError(new RestDataCollectionError(errorMessage, exceptionId));
		restDatacollection.setStatusCode(status.value());
		restDatacollection.setVersion(VERSION);
		return new ResponseEntity<RestDataApplicationResponse>(new RestDataApplicationResponse(restDatacollection),
				status);
	}

	private ResponseEntity<RestDataApplicationResponse> logException(final String errorMessage, final HttpStatus status,
			Throwable e) {
		ResponseEntity<RestDataApplicationResponse> response;
		Integer exceptionId = exceptionLogService.addNewException(ExceptionUtils.getStackTrace(e).toString());
		response =  buildErrorResponse(errorMessage, status, exceptionId);
		return response;
	}

	protected ResponseEntity<RestDataApplicationResponse> buildBooleanStatus(final Boolean booleanStatus,
			final HttpStatus status) {
		return new ResponseEntity<RestDataApplicationResponse>(new RestDataApplicationResponse(booleanStatus), status);
	}

}