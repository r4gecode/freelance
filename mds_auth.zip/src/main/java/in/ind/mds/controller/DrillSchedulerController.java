/**
 * 
 */
package in.ind.mds.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;


import in.ind.mds.dto.DrillSchedulerDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.service.DrillSchedulerService;
import in.ind.mds.util.RestDataApplicationResponse;


/**
 * @author Hinaya
 *
 */
@RestController
@RequestMapping("/v1/drillScheduler")
public class DrillSchedulerController extends BaseController{
	
	private static final Logger LOGGER = LoggerFactory.getLogger(DrillSchedulerController.class);

	@Autowired
	@Qualifier("TST_MSSQL_DRILL_SCHEDULER")
	private DrillSchedulerService DrillSchedulerService;
	
	@RequestMapping(value = "/getDrillSchedulerById/{drillSchedulerId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> getDrillSchedulerById(@PathVariable String drillSchedulerId) {
		ResponseEntity<RestDataApplicationResponse> response;
		DrillSchedulerDto drillSchedulerDto = null;
		try {
			drillSchedulerDto = DrillSchedulerService.findById(drillSchedulerId);
			response = buildSuccessMessage(drillSchedulerDto, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in DrillSchedulerController.getStaffById");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
	
	@RequestMapping(method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> add(@RequestParam("drillScheduler") String drillSchedulerDetails
			, @RequestParam("drillSchedulerDocs") MultipartFile[] drillSchedulerDocs
			,@RequestParam("drillAgendaDocs") MultipartFile[] drillAgendaDocs) throws JsonParseException, JsonMappingException, IOException {
		ResponseEntity<RestDataApplicationResponse> response = null;
		DrillSchedulerDto drillSchedulerDto = null;
		try {
			Map<String, MultipartFile[]> attachments = new HashMap<>();
			attachments.put("drillSchedulerDocs", drillSchedulerDocs);
			attachments.put("drillAgendaDocs", drillAgendaDocs);
			drillSchedulerDto = DrillSchedulerService.add(drillSchedulerDetails, attachments);
			response = buildSuccessMessage(drillSchedulerDto, HttpStatus.CREATED);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in DrillSchedulerController.add");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
	
	@RequestMapping(value = "/all", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> findAllStaff() {
		ResponseEntity<RestDataApplicationResponse> response = null;
		List<DrillSchedulerDto> drillSchedulerDtoList = new ArrayList<>();
		try {
			drillSchedulerDtoList = DrillSchedulerService.findAll();
			response = buildSuccessMessage(drillSchedulerDtoList, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in DrillSchedulerController.findAllStaff");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
	

	@RequestMapping(value = "/softDelete", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> softDeleteDrillScheduler(@RequestBody List<String> drillSchedulerId) {
		ResponseEntity<RestDataApplicationResponse> response = null;
		try {
			List<DrillSchedulerDto> drillSchedulerDtoList=DrillSchedulerService.softDeleteDrillScheduler(drillSchedulerId);
			response = buildSuccessMessage(drillSchedulerDtoList, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in DrillSchedulerController.softDeleteDrillScheduler");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
	
	@RequestMapping(value = "/update", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> update(@RequestParam("drillScheduler") String drillScheduler
			, @RequestParam("drillSchedulerDocs") MultipartFile[] drillSchedulerDocs
			,@RequestParam("drillAgendaDocs") MultipartFile[] drillAgendaDocs) throws JsonParseException, JsonMappingException, IOException {
		ResponseEntity<RestDataApplicationResponse> response = null;
		DrillSchedulerDto drillSchedulerDto = null;
		try {
			Map<String, MultipartFile[]> attachments = new HashMap<>();
			attachments.put("drillSchedulerDocs", drillSchedulerDocs);
			attachments.put("drillAgendaDocs", drillAgendaDocs);
			drillSchedulerDto = DrillSchedulerService.updateDrillScheduler(drillScheduler, attachments);
			response = buildSuccessMessage(drillSchedulerDto, HttpStatus.CREATED);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in StaffController.update");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}


	
}
