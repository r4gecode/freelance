/**
 * 
 */
package in.ind.mds.controller;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import in.ind.mds.dto.LikelihoodDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.service.LikelihoodService;
import in.ind.mds.util.RestDataApplicationResponse;

/**
 * @author shalini
 *
 */
@RestController
@RequestMapping(value="/v1/likelihood")
public class LikelihoodController extends BaseController{
	private static final Logger LOGGER = LoggerFactory.getLogger(LikelihoodController.class);
	
	@Autowired
	@Qualifier("TST_MSSQL_LIKELIHOOD")
	private LikelihoodService likelihoodService;
	
	@RequestMapping(method = RequestMethod.PUT, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> add(@RequestBody LikelihoodDto likelihoodDto) {
		ResponseEntity<RestDataApplicationResponse> response = null;

		try {
			likelihoodDto = likelihoodService.add(likelihoodDto);
			response = buildSuccessMessage(likelihoodDto, HttpStatus.CREATED);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in LikelihoodController.add");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
	
	@RequestMapping(value = "/update", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> update(@RequestBody LikelihoodDto likelihoodDto) {
		ResponseEntity<RestDataApplicationResponse> response;
		try {
			likelihoodDto = likelihoodService.update(likelihoodDto);
			response = buildSuccessMessage(likelihoodDto, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in LikelihoodController.update");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}


	
	@RequestMapping(value = "/findById/{likelihoodId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> getCrewCourseById(@PathVariable String likelihoodId) {
	
		ResponseEntity<RestDataApplicationResponse> response;
		LikelihoodDto likelihoodDto = null;
		
		try
		{
			likelihoodDto= likelihoodService.findById(likelihoodId);
			response=buildSuccessMessage(likelihoodDto, HttpStatus.OK);
			
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in LikelihoodController.findById");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
	
	@RequestMapping(value = "/all", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> findAllLikelihood() {
		ResponseEntity<RestDataApplicationResponse> response;
		List<LikelihoodDto> likelihoodDtoList = new ArrayList<>();

		try {
			likelihoodDtoList = likelihoodService.findAllLikelihood();
			response = buildSuccessMessage(likelihoodDtoList, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in CrewCourseCategoryController.findAllLikelihood");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
	
	@RequestMapping(value = "/softDelete", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> softDelete(@RequestBody List<String> likelihoodId) {
		ResponseEntity<RestDataApplicationResponse> response;
		try {
			List<LikelihoodDto> likelihoodDtoList =likelihoodService.softDelete(likelihoodId);
			response = buildSuccessMessage(likelihoodDtoList, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in CrewCourseCategoryController.softDelete");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
	
}
