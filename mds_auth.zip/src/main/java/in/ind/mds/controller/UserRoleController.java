package in.ind.mds.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import in.ind.mds.dto.UserRoleDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.service.UserRoleService;
import in.ind.mds.util.RestDataApplicationResponse;

@RestController
@RequestMapping("/v1/userRole")

public class UserRoleController extends BaseController
{
	private static final Logger LOGGER = LoggerFactory.getLogger(UserRoleController.class);

	@Autowired
	@Qualifier("TST_MSSQL_USER_ROLE")
	private UserRoleService userRoleService;

	//@Autowired
	//private CommonUtil commonUtil;

	@RequestMapping(value = "/doLogin/{roleId}/{userId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> doLogin(@PathVariable String roleId,
			@PathVariable String userId) {
		ResponseEntity<RestDataApplicationResponse> response;
		UserRoleDto userRoleDto = null;

		try {
			userRoleDto = userRoleService.findByRoleIdAndUserId(roleId,userId);
			response = buildSuccessMessage(userRoleDto, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in UserRoleController.doLogin");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}

	@RequestMapping(value = "/{userRoleId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> getByUserRoleId(@PathVariable String userRoleId) {
		UserRoleDto userRoleDto = null;
		ResponseEntity<RestDataApplicationResponse> response;
		try {
			userRoleDto = userRoleService.getByUserRoleId(userRoleId);
			response = buildSuccessMessage(userRoleDto, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in UserRoleController.getByUserRoleId");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}

	@RequestMapping(value = "/byRoleId/{roleId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> findByRoleId(@PathVariable String roleId) {
		UserRoleDto userRoleDto = null;
		ResponseEntity<RestDataApplicationResponse> response;
		try {
			userRoleDto = userRoleService.findByRoleId(roleId);
			response = buildSuccessMessage(userRoleDto, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in UserRoleController.findByRoleId");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
	
	@RequestMapping(value = "/all", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> findAll() {
		ResponseEntity<RestDataApplicationResponse> response;
		List<UserRoleDto> userRoleDto = null;

		try {
			userRoleDto = userRoleService.findAll();
			response = buildSuccessMessage(userRoleDto, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in UserRoleController.findAll");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}

	@RequestMapping(method = RequestMethod.PUT, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> add(@RequestBody UserRoleDto userRoleDto) {
		ResponseEntity<RestDataApplicationResponse> response = null;

		try {
			userRoleDto = userRoleService.add(userRoleDto);
			response = buildSuccessMessage(userRoleDto, HttpStatus.CREATED);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in UserRoleController.add");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}

	@RequestMapping(value = "/softDelete", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> deleteUserRole(@RequestBody List<String> userRoleIds) {
		ResponseEntity<RestDataApplicationResponse> response;
		try {
			List<UserRoleDto> userRoleDtoList=userRoleService.softDeleteUserRole(userRoleIds);
			//success = true;
			response = buildSuccessMessage(userRoleDtoList, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in UserRoleController.del");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
	
	@RequestMapping(value = "/update", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> updateUserRole(@RequestBody UserRoleDto userRoleDto) {
		ResponseEntity<RestDataApplicationResponse> response;
		try {
			userRoleDto = userRoleService.updateUserRole(userRoleDto);
			response = buildSuccessMessage(userRoleDto, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in UserRoleController.update");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}

}
