/**
 * 
 */
package in.ind.mds.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.ind.mds.dto.CompanyDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.service.CompanyService;
import in.ind.mds.util.RestDataApplicationResponse;

/**
 * @author mds-arockia
 *
 */
@RestController
@RequestMapping(value = "/v1/company")
public class CompanyController extends BaseController{

	private static final Logger LOGGER = LoggerFactory.getLogger(CompanyController.class);

	@Autowired
	@Qualifier("TST_MSSQL_COMPANY")
	private CompanyService companyService;
	
	@GetMapping(value = "/getByCompanyId/{companyId}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> getByCompanyId(@PathVariable String companyId) {
		ResponseEntity<RestDataApplicationResponse> response;
		CompanyDto companyDto = null;
		try {
			companyDto = companyService.findByCompanyId(companyId);
			response = buildSuccessMessage(companyDto, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in CompanyController.getByCompanyId");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}

	@GetMapping(value = "/all", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> findAll() {
		ResponseEntity<RestDataApplicationResponse> response;
		List<CompanyDto> companyDto = null;
		try {
			companyDto = companyService.findAll();
			response = buildSuccessMessage(companyDto, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in CompanyController.findAll");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}

	@PutMapping(produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> add(@RequestBody CompanyDto companyDto) {
		ResponseEntity<RestDataApplicationResponse> response = null;
		try {
			companyDto = companyService.add(companyDto);
			response = buildSuccessMessage(companyDto, HttpStatus.CREATED);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in CompanyController.add");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}

	@PostMapping(value = "/softDelete", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> softDeleteCompany(@RequestBody List<String> companyIds) {
		ResponseEntity<RestDataApplicationResponse> response;
		try {
			List<CompanyDto> companyDto = companyService.SoftDeleteCompany(companyIds);
			response = buildSuccessMessage(companyDto, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in CompanyController.softDeleteCompany");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
	
	@PostMapping(value = "/update", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> updateCompany(@RequestBody CompanyDto companyDto) {
		ResponseEntity<RestDataApplicationResponse> response;
		try {
			companyDto = companyService.updateCompany(companyDto);
			response = buildSuccessMessage(companyDto, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in CompanyController.update");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
	
}
