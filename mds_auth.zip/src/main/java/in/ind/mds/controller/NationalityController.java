/**
 * 
 */
package in.ind.mds.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import in.ind.mds.dto.NationalityDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.service.NationalityService;
import in.ind.mds.util.RestDataApplicationResponse;

/**
 * @author mds-arockia
 *
 */
@RestController
@RequestMapping(value = "/v1/nationality")
public class NationalityController extends BaseController{

	private static final Logger LOGGER = LoggerFactory.getLogger(AddressController.class);

	@Autowired
	@Qualifier("TST_MSSQL_NATIONALITY")
	private NationalityService nationalityService;
	
	@GetMapping(value = "/getByNationalityId/{nationalityId}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> getByNationalityId(@PathVariable String nationalityId) {
		ResponseEntity<RestDataApplicationResponse> response;
		NationalityDto nationalityDto = null;

		try {
			nationalityDto = nationalityService.getByNationalityId(nationalityId);
			response = buildSuccessMessage(nationalityDto, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in NationalityController.getByAddressId");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
	
	@RequestMapping(value = "/all", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> findAll() {
		ResponseEntity<RestDataApplicationResponse> response;
		List<NationalityDto> nationalityDto = null;

		try {
			nationalityDto = nationalityService.findAll();
			response = buildSuccessMessage(nationalityDto, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in NationalityController.findAll");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}

	@PutMapping(produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> add(@RequestBody NationalityDto nationalityDto) {
		ResponseEntity<RestDataApplicationResponse> response = null;

		try {
			nationalityDto = nationalityService.add(nationalityDto);
			response = buildSuccessMessage(nationalityDto, HttpStatus.CREATED);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in NationalityController.add");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
	
	@PostMapping(value = "/softDelete", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> softDeleteNationality(@RequestBody List<String> nationalityIds) {
		ResponseEntity<RestDataApplicationResponse> response;
		try {
			List<NationalityDto> nationalityDtoList = nationalityService.softDeleteNationality(nationalityIds);
			response = buildSuccessMessage(nationalityDtoList, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in NationalityController.softDeleteNationality");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
	
	@PostMapping(value = "/update",produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> updateNationality(@RequestBody NationalityDto nationalityDto) {
		ResponseEntity<RestDataApplicationResponse> response;
		try {
			nationalityDto = nationalityService.updateNationality(nationalityDto);
			response = buildSuccessMessage(nationalityDto, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in NationalityController.update");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
 	
}
