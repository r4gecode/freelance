/**
 * 
 */
package in.ind.mds.controller;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import in.ind.mds.dto.CrewCourseCategoryDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.service.CrewCourseCategoryService;
import in.ind.mds.util.RestDataApplicationResponse;

/**
 * @author mds_kiruthika
 *
 */
@RestController
@RequestMapping("/v1/crewCourseCategory")
public class CrewCourseCategoryController extends BaseController{
	
	private static final Logger LOGGER = LoggerFactory.getLogger(CrewCourseCategoryController.class);

	@Autowired
	@Qualifier("TST_MSSQL_CREWCOURSE")
	private CrewCourseCategoryService crewCourseService;
	
	@RequestMapping(value = "/getCrewCourseById/{crewCourseId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> getCrewCourseById(@PathVariable String crewCourseId) {
	
		ResponseEntity<RestDataApplicationResponse> response;
		CrewCourseCategoryDto crewCourseCategoryDto = null;
		
		try
		{
			crewCourseCategoryDto= crewCourseService.findByCrewCourseId(crewCourseId);
			response=buildSuccessMessage(crewCourseCategoryDto, HttpStatus.OK);
			
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in CrewCourseCategoryController.getCrewCourseById");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}

	@RequestMapping(method = RequestMethod.PUT, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> add(@RequestBody CrewCourseCategoryDto crewCourseCategoryDto) {
		ResponseEntity<RestDataApplicationResponse> response = null;

		try {
			crewCourseCategoryDto = crewCourseService.add(crewCourseCategoryDto);
			response = buildSuccessMessage(crewCourseCategoryDto, HttpStatus.CREATED);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in CrewCourseCategoryController.add");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
	
	@RequestMapping(value = "/all", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> findAllCrewCourse() {
		ResponseEntity<RestDataApplicationResponse> response;
		List<CrewCourseCategoryDto> crewCourseDtoList = new ArrayList<>();

		try {
			crewCourseDtoList = crewCourseService.findAllCrewCourse();
			response = buildSuccessMessage(crewCourseDtoList, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in CrewCourseCategoryController.findAllCrewCourse");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
	
	@RequestMapping(value = "/softDelete", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> softDeleteCrewCourse(@RequestBody List<String> crewCourseCategoryId) {
		ResponseEntity<RestDataApplicationResponse> response;
		try {
			List<CrewCourseCategoryDto> crewCourseDtoList =crewCourseService.softDeleteCrewCourse(crewCourseCategoryId);
			response = buildSuccessMessage(crewCourseDtoList, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in CrewCourseCategoryController.softDeleteCrewCourse");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
	
	@RequestMapping(value = "/update", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> updateCrewCourse(@RequestBody CrewCourseCategoryDto crewCourseDto) {
		ResponseEntity<RestDataApplicationResponse> response;
		try {
			crewCourseDto = crewCourseService.updateCrewCourse(crewCourseDto);
			response = buildSuccessMessage(crewCourseDto, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in VesselController.updateCrewCourse");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
	
}
