/**
 * 
 */
package in.ind.mds.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.ind.mds.dto.InventoryItemDto;
import in.ind.mds.dto.QuantityUpdDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.service.InventoryItemService;
import in.ind.mds.util.RestDataApplicationResponse;

/**
 * @author mds-arockia
 *
 */
@RestController
@RequestMapping(value = "/v1/inventoryItem")
public class InventoryItemController extends BaseController{

	private static final Logger LOGGER = LoggerFactory.getLogger(InventoryItemController.class);
	
	@Autowired
	@Qualifier("TST_MSSQL_INVENTORY_ITEM")
	private InventoryItemService inventoryItemService;
	
	@PostMapping(value = "/updateQuantity", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> updateQuantity(@RequestBody QuantityUpdDto quantityUpdDto){
		ResponseEntity<RestDataApplicationResponse> response = null;
		try {
			List<QuantityUpdDto> quantityUpdDtoList = inventoryItemService.updateQuantity(quantityUpdDto);
			response = buildSuccessMessage(quantityUpdDtoList, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in InventoryItemController.add");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
	
	@PostMapping(value = "/findAllQuantityUpd/{inventoryItemId}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> findAllQuantityUpd(@PathVariable String inventoryItemId){
		ResponseEntity<RestDataApplicationResponse> response = null;
		try {
			List<QuantityUpdDto> quantityUpdDtoList = inventoryItemService.findAllQuantityUpdByInventoryItem(inventoryItemId);
			response = buildSuccessMessage(quantityUpdDtoList, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in InventoryItemController.add");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
	
	@PostMapping(value = "/findAllInventoryItem", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> findAllInventoryItem(){
		ResponseEntity<RestDataApplicationResponse> response = null;
		try {
			List<InventoryItemDto> inventoryItemDtoList = inventoryItemService.findAllInventoryItem();
			response = buildSuccessMessage(inventoryItemDtoList, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in InventoryItemController.findAllInventoryItem");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
	
	@PostMapping(value = "/softDleteInventoryItem", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> softDeleteInventoryItem(@RequestBody List<String> ids){
		ResponseEntity<RestDataApplicationResponse> response = null;
		try {
			List<InventoryItemDto> inventoryItemDtoList = inventoryItemService.softDeleteInventoryItem(ids);
			response = buildSuccessMessage(inventoryItemDtoList, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in InventoryItemController.softDeleteInventoryItem");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
}
