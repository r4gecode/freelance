package in.ind.mds.controller;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import in.ind.mds.dto.VesselDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.service.VesselService;
import in.ind.mds.util.RestDataApplicationResponse;

@RestController
@RequestMapping("/v1/vessel")
public class VesselController extends BaseController {

	private static final Logger LOGGER = LoggerFactory.getLogger(VesselController.class);

	@Autowired
	@Qualifier("TST_MSSQL_VESSEL")
	private VesselService vesselService;

	//@Autowired
	//private CommonUtil commonUtil;

	@RequestMapping(value = "/getVesselById/{vesselId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> getVesselById(@PathVariable String vesselId) {
		ResponseEntity<RestDataApplicationResponse> response;
		VesselDto vesselDto = null;

		try {
			vesselDto = vesselService.getByVesselId(vesselId);
			response = buildSuccessMessage(vesselDto, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in VesselController.getVesselById");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}

	@RequestMapping(method = RequestMethod.PUT, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> add(@RequestBody VesselDto vesselDto) {
		ResponseEntity<RestDataApplicationResponse> response = null;

		try {
			vesselDto = vesselService.add(vesselDto);
			response = buildSuccessMessage(vesselDto, HttpStatus.CREATED);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in VesselController.add");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}

	

	@RequestMapping(value = "/all", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> findAllVessel() {
		ResponseEntity<RestDataApplicationResponse> response;
		List<VesselDto> listVesselDto = new ArrayList<>();

		try {
			listVesselDto = vesselService.findAll();
			response = buildSuccessMessage(listVesselDto, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in VesselController.findAllVessel");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}

	@RequestMapping(value = "/softDelete", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> softDeleteVessel(@RequestBody List<String> vesselId) {
		ResponseEntity<RestDataApplicationResponse> response;
		try {
			List<VesselDto> vesselDtoList=vesselService.softDeleteVessel(vesselId);
			response = buildSuccessMessage(vesselDtoList, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in VesselController.softDeleteVessel");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
	
	@RequestMapping(value = "/update", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> updateVessel(@RequestBody VesselDto vesselDto) {
		ResponseEntity<RestDataApplicationResponse> response;
		try {
			vesselDto = vesselService.updateVessel(vesselDto);
			response = buildSuccessMessage(vesselDto, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in VesselController.updateVessel");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}

}
