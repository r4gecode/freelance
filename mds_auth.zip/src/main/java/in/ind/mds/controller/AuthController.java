package in.ind.mds.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import in.ind.mds.dto.AuthenticationDto;
import in.ind.mds.dto.AuthorizationDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.security.auth.request.AuthRequestView;
import in.ind.mds.security.auth.request.LoginRequestView;
import in.ind.mds.serviceImpl.AuthHandlerServiceImpl;
import in.ind.mds.util.RestDataApplicationResponse;

@RestController
//@RequestMapping("/v1/user")
public class AuthController extends BaseController {

	private static final Logger LOGGER = LoggerFactory.getLogger(AddressController.class);
	private static final String CLASSNAME = "AuthController";
	
	@Autowired
	@Qualifier("TST_MSSQL_AUTH")
	private AuthHandlerServiceImpl authService;

	@RequestMapping(value = "/authentication", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> authenticateUser(@RequestBody LoginRequestView requestView) {
		
		final String METHOD_NAME = "authenticateUser";
		ResponseEntity<RestDataApplicationResponse> response;
		AuthenticationDto authenticateDto = null;

		try {
			authenticateDto = authService.authenticateUser(requestView);
			response = buildSuccessMessage(authenticateDto, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in "+CLASSNAME+" "+METHOD_NAME);
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
	
	@RequestMapping(value = "/authorization", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> authorizeUser(@RequestBody AuthRequestView requestView) {
		
		final String METHOD_NAME = "authenticateUser";
		ResponseEntity<RestDataApplicationResponse> response;
		AuthorizationDto authorizeDto = null;

		try {
			authorizeDto = authService.authorizeUser(requestView);
			response = buildSuccessMessage(authorizeDto, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in "+CLASSNAME+" "+METHOD_NAME);
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
}
