package in.ind.mds.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import in.ind.mds.dto.SftyDrillCatDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.service.SftyDrillCatService;
import in.ind.mds.util.RestDataApplicationResponse;

@RestController
@RequestMapping("/v1/drill")
public class SftyCategoryController extends BaseController{

	private static final Logger LOGGER = LoggerFactory.getLogger(SftyCategoryController.class);
	
	@Autowired
	@Qualifier("TST_MSSQL_SAFETY_CATEGORY")
	private SftyDrillCatService drillCatService;
	
	@RequestMapping(value = "/getByCategoryId/{catId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> getByCatId(@PathVariable String catId) {
		ResponseEntity<RestDataApplicationResponse> response;
		SftyDrillCatDto sftyDrillCatDto = null;

		try {
			sftyDrillCatDto = drillCatService.getByCatId(catId);
			response = buildSuccessMessage(sftyDrillCatDto, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in SftyCategoryController.getByCatId");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
	@RequestMapping(value = "/findByCategoryName/{catName}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> findByPortName(@PathVariable String catName) {
		ResponseEntity<RestDataApplicationResponse> response;
		SftyDrillCatDto sftyDrillCatDto = null;

		try {
			sftyDrillCatDto = drillCatService.findByCatName(catName);
			response = buildSuccessMessage(sftyDrillCatDto, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in SftyCategoryController.findByCatName");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
	
	@RequestMapping(value = "/all", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> findAll() {
		ResponseEntity<RestDataApplicationResponse> response;
		List<SftyDrillCatDto> sftyDrillCatDtos = null;

		try {
			sftyDrillCatDtos = drillCatService.findAll();
			response = buildSuccessMessage(sftyDrillCatDtos, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in SftyCategoryController.findAll");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}

	@RequestMapping(method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> add(@RequestBody SftyDrillCatDto sftyDrillCatDto) {
		ResponseEntity<RestDataApplicationResponse> response = null;

		try {
			sftyDrillCatDto = drillCatService.add(sftyDrillCatDto);
			response = buildSuccessMessage(sftyDrillCatDto, HttpStatus.CREATED);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in SftyCategoryController.add");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
	
	@RequestMapping(value = "/softDelete/{catId}/{statusNo}", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> softDeletePort(@PathVariable String catId,
			@PathVariable int statusNo) {
		ResponseEntity<RestDataApplicationResponse> response;
		SftyDrillCatDto sftyDrillCatDto = null;
		try {
			drillCatService.softDeleteCat(catId, statusNo);
			response = buildSuccessMessage(sftyDrillCatDto, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in SftyCategoryController.del");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}

	
	/*@RequestMapping(value = "/softDelete", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> softDeletePort(@RequestBody List<String> categoryIds) {
			ResponseEntity<RestDataApplicationResponse> response;
			try {
				List<SftyDrillCatDto> sftDrillcaDtoList = drillCatService.softDeleteCat(categoryIds);
				response = buildSuccessMessage(sftDrillcaDtoList, HttpStatus.OK);
			} catch (ApplicationServiceExecption e) {
				LOGGER.error(e.getErrorMessage());
				response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
			} catch (Exception e) {
				LOGGER.error("Exception in OwnerController.softDeleteOwner");
				response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
			}
			return response;
	
	}*/
	
	@RequestMapping(value = "/update", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> updatePort(@RequestBody SftyDrillCatDto sftyDrillCatDto) {
		ResponseEntity<RestDataApplicationResponse> response;
		try {
			sftyDrillCatDto = drillCatService.updateCat(sftyDrillCatDto);
			response = buildSuccessMessage(sftyDrillCatDto, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in SftyCategoryController.update");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}


}
