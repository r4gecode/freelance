package in.ind.mds.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import in.ind.mds.dto.JobCategoryDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.service.JobCategoryService;
import in.ind.mds.util.RestDataApplicationResponse;

@RestController
@RequestMapping("/v1/jobCategory")
public class JobCategoryController extends BaseController  
{
	private static final Logger LOGGER = LoggerFactory.getLogger(JobCategoryController.class);

	@Autowired
	@Qualifier("TST_MSSQL_JOB_CATEGORY")
	private JobCategoryService jobCategoryService;

	//@Autowired
	//private CommonUtil commonUtil;

	@RequestMapping(value = "/doLogin/{jobCtgyId}/{jobCtgyName}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> doLogin(@PathVariable String jobCtgyId,
			@PathVariable String jobCtgyName) {
		ResponseEntity<RestDataApplicationResponse> response;
		JobCategoryDto jobCategoryDto = null;

		try {
			jobCategoryDto = jobCategoryService.findByJobCtgyIdAndJobCtgyName(jobCtgyId,jobCtgyName);
			response = buildSuccessMessage(jobCategoryDto, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in JobCategoryController.doLogin");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}

	@RequestMapping(value = "/getByJobCtgyId/{jobCtgyId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> getByJobCtgyId(@PathVariable String jobCtgyId) {
		JobCategoryDto jobCategoryDto = null;
		ResponseEntity<RestDataApplicationResponse> response;
		try {
			jobCategoryDto = jobCategoryService.getByJobCtgyId(jobCtgyId);
			response = buildSuccessMessage(jobCategoryDto, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in JobCategoryController.getByJobCtgyId");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}

	@RequestMapping(value = "/getByJobCtgyName/{jobCtgyName}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> findByJobCtgyName(@PathVariable String jobCtgyName) {
		JobCategoryDto jobCategoryDto = null;
		ResponseEntity<RestDataApplicationResponse> response;
		try {
			jobCategoryDto = jobCategoryService.findByJobCtgyName(jobCtgyName);
			response = buildSuccessMessage(jobCategoryDto, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in JobCategoryController.findByJobCtgyName");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}

	@RequestMapping(value = "/all", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> findAll() {
		ResponseEntity<RestDataApplicationResponse> response;
		List<JobCategoryDto> jobCategoryDto = null;

		try {
			jobCategoryDto = jobCategoryService.findAll();
			response = buildSuccessMessage(jobCategoryDto, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in JobCategoryController.findAll");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}

	@RequestMapping(method = RequestMethod.PUT, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> add(@RequestBody JobCategoryDto jobCategoryDto) {
		ResponseEntity<RestDataApplicationResponse> response = null;

		try {
			jobCategoryDto = jobCategoryService.add(jobCategoryDto);
			response = buildSuccessMessage(jobCategoryDto, HttpStatus.CREATED);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in JobCategoryController.add");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}

	@RequestMapping(value = "/softDelete", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> softDeleteJobCategory(@RequestBody List<String> jobCtgyIds) {
		ResponseEntity<RestDataApplicationResponse> response;
		try {
			List<JobCategoryDto> jobCategoryDtoList = jobCategoryService.softDeleteJobCategory(jobCtgyIds);
			response = buildSuccessMessage(jobCategoryDtoList, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in JobCategoryController.softDelete");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
	
	@RequestMapping(value = "/update", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> updateAddress(@RequestBody JobCategoryDto jobCategoryDto) {
		ResponseEntity<RestDataApplicationResponse> response;
		try {
			jobCategoryDto = jobCategoryService.updateJobCategory(jobCategoryDto);
			response = buildSuccessMessage(jobCategoryDto, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in JobCategoryController.update");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
	

}
