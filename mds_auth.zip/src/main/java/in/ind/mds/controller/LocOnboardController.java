package in.ind.mds.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import in.ind.mds.dto.LocOnboardDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.service.LocOnboardService;
import in.ind.mds.util.RestDataApplicationResponse;

@RestController
@RequestMapping("/v1/locOnboard")

public class LocOnboardController extends BaseController
{

	private static final Logger LOGGER = LoggerFactory.getLogger(LocOnboardController.class);

	@Autowired
	@Qualifier("TST_MSSQL_LOC_ONBOARD")
	private LocOnboardService locOnboardService;

	//@Autowired
	//private CommonUtil commonUtil;

	@RequestMapping(value = "/doLogin/{locationId}/{locationName}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> doLogin(@PathVariable String locationId,
			@PathVariable String locationName) {
		ResponseEntity<RestDataApplicationResponse> response;
		LocOnboardDto locOnboardDto = null;

		try {
			locOnboardDto = locOnboardService.findByLocationIdAndLocationName(locationId,locationName);
			response = buildSuccessMessage(locOnboardDto, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in LocOnboardController.doLogin");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}

	@RequestMapping(value = "/getByLocationId/{locationId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> getByLocationId(@PathVariable String locationId) {
		LocOnboardDto locOnboardDto = null;
		ResponseEntity<RestDataApplicationResponse> response;
		try {
			locOnboardDto = locOnboardService.getByLocationId(locationId);
			response = buildSuccessMessage(locOnboardDto, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in LocOnboardController.getByLocationId");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}

	@RequestMapping(value = "/getByLocationName/{locationName}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> findByLocationName(@PathVariable String locationName) {
		LocOnboardDto locOnboardDto = null;
		ResponseEntity<RestDataApplicationResponse> response;
		try {
			locOnboardDto = locOnboardService.findByLocationName(locationName);
			response = buildSuccessMessage(locOnboardDto, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in LocOnboardController.findByLocationName");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}

	@RequestMapping(value = "/all", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> findAll() {
		ResponseEntity<RestDataApplicationResponse> response;
		List<LocOnboardDto> locOnboardDto = null;

		try {
			locOnboardDto = locOnboardService.findAll();
			response = buildSuccessMessage(locOnboardDto, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in LocOnboardController.findAll");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}

	@RequestMapping(method = RequestMethod.PUT, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> add(@RequestBody LocOnboardDto locOnboardDto) {
		ResponseEntity<RestDataApplicationResponse> response = null;

		try {
			locOnboardDto = locOnboardService.add(locOnboardDto);
			response = buildSuccessMessage(locOnboardDto, HttpStatus.CREATED);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in LocOnboardController.add");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}

	@RequestMapping(value = "/softDelete", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> deleteLocOnboard(@RequestBody List<String> locationIds) {
		ResponseEntity<RestDataApplicationResponse> response;
		try {
			List<LocOnboardDto> locOnboardDtoList = locOnboardService.softDeleteLocOnboard(locationIds);
			response = buildSuccessMessage(locOnboardDtoList, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in LocOnboardController.del");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
	
	@RequestMapping(value = "/update", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> updateLocOnboard(@RequestBody LocOnboardDto locOnboardDto) {
		ResponseEntity<RestDataApplicationResponse> response;
		try {
			locOnboardDto = locOnboardService.updateLocOnboard(locOnboardDto);
			response = buildSuccessMessage(locOnboardDto, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in LocOnboardController.update");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
	

}
