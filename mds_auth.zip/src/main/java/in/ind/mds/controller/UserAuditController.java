package in.ind.mds.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import in.ind.mds.dto.UserAuditDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.service.UserAuditService;
import in.ind.mds.util.RestDataApplicationResponse;

@RestController
@RequestMapping("/v1/userAudit")
public class UserAuditController extends BaseController
{
	private static final Logger LOGGER = LoggerFactory.getLogger(UserAuditController.class);

	@Autowired
	@Qualifier("TST_MSSQL_USER_AUDIT")
	private UserAuditService userAuditService;

	//@Autowired
	//private CommonUtil commonUtil;

	@RequestMapping(value = "/doLogin/{userId}/{auditId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> doLogin(@PathVariable String userId,
			@PathVariable String auditId) {
		ResponseEntity<RestDataApplicationResponse> response;
		UserAuditDto userAuditDto = null;

		try {
			userAuditDto = userAuditService.findByUserIdAndAuditId(userId,auditId);
			response = buildSuccessMessage(userAuditDto, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in UserAuditController.doLogin");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}

	@RequestMapping(value = "/{auditId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> getByAuditId(@PathVariable String auditId) {
		UserAuditDto userAuditDto = null;
		ResponseEntity<RestDataApplicationResponse> response;
		try {
			userAuditDto = userAuditService.getByAuditId(auditId);
			response = buildSuccessMessage(userAuditDto, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in UserAuditController.getByAuditId");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}

	@RequestMapping(value = "/byUserIp/{userIp}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> findByUserIp(@PathVariable String userIp) {
		UserAuditDto userAuditDto = null;
		ResponseEntity<RestDataApplicationResponse> response;
		try {
			userAuditDto = userAuditService.findByUserIp(userIp);
			response = buildSuccessMessage(userAuditDto, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in UserAuditController.findByUserIp");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
	
	@RequestMapping(value = "/all", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> findAll() {
		ResponseEntity<RestDataApplicationResponse> response;
		List<UserAuditDto> userAuditDto = null;

		try {
			userAuditDto = userAuditService.findAll();
			response = buildSuccessMessage(userAuditDto, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in UserAuditController.findAll");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}

	@RequestMapping(method = RequestMethod.PUT, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> add(@RequestBody UserAuditDto userAuditDto) {
		ResponseEntity<RestDataApplicationResponse> response = null;

		try {
			userAuditDto = userAuditService.add(userAuditDto);
			response = buildSuccessMessage(userAuditDto, HttpStatus.CREATED);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in UserAuditController.add");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}

	/*@RequestMapping(value = "/delete/{auditId}", method = RequestMethod.DELETE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> deleteUserAudit(@PathVariable String auditId) {
		ResponseEntity<RestDataApplicationResponse> response;
		boolean success = false;
		try {
			userAuditService.deleteUserAudit(auditId);
			response = buildBooleanStatus(success, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in UserAuditController.del");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}*/
	
	@RequestMapping(value = "/update", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> updateUserAudit(@RequestBody UserAuditDto userAuditDto) {
		ResponseEntity<RestDataApplicationResponse> response;
		try {
			userAuditDto = userAuditService.updateUserAudit(userAuditDto);
			response = buildSuccessMessage(userAuditDto, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in UserAuditController.update");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}

}
