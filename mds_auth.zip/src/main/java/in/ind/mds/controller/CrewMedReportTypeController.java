/**
 * 
 */
package in.ind.mds.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.ind.mds.dto.CrewMedReportTypeDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.service.CrewMedReportTypeService;
import in.ind.mds.util.RestDataApplicationResponse;

/**
 * @author mds-arockia
 *
 */
@RestController
@RequestMapping(value = "/v1/crewMedReportType")
public class CrewMedReportTypeController extends BaseController{

	private static final Logger LOGGER = LoggerFactory.getLogger(CrewMedReportTypeController.class);
	
	@Autowired
	@Qualifier("TST_MSSQL_CREW_MED_REPORT_TYPE")
	private CrewMedReportTypeService crewMedReportTypeService;
	
	@PutMapping(produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> add(@RequestBody CrewMedReportTypeDto crewMedReportTypeDto) {
		ResponseEntity<RestDataApplicationResponse> response = null;
		try {
			crewMedReportTypeDto = crewMedReportTypeService.add(crewMedReportTypeDto);
			response = buildSuccessMessage(crewMedReportTypeDto, HttpStatus.CREATED);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in CrewMedReportTypeController.add");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
	
	@PostMapping(value = "/update",produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> update(@RequestBody CrewMedReportTypeDto crewMedReportTypeDto) {
		ResponseEntity<RestDataApplicationResponse> response = null;
		try {
			crewMedReportTypeDto = crewMedReportTypeService.update(crewMedReportTypeDto);
			response = buildSuccessMessage(crewMedReportTypeDto, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in CrewMedReportTypeController.update");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
	
	@GetMapping(value = "/findAll",produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> findAll() {
		ResponseEntity<RestDataApplicationResponse> response = null;
		try {
			List<CrewMedReportTypeDto> crewMedReportTypeDtoList = crewMedReportTypeService.findAll();
			response = buildSuccessMessage(crewMedReportTypeDtoList, HttpStatus.CREATED);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in CrewMedReportTypeController.findAll");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
	
	@GetMapping(value = "/findById/{id}",produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> findById(@PathVariable("id") String id) {
		ResponseEntity<RestDataApplicationResponse> response = null;
		try {
			CrewMedReportTypeDto crewMedReportTypeDto = crewMedReportTypeService.findById(id);
			response = buildSuccessMessage(crewMedReportTypeDto, HttpStatus.CREATED);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in CrewMedReportTypeController.findById");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
	
	@PostMapping(value = "/softDelete",produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> softDelete(@RequestBody List<String> ids) {
		ResponseEntity<RestDataApplicationResponse> response = null;
		try {
			List<CrewMedReportTypeDto> crewMedReportTypeDtoList = crewMedReportTypeService.softDelete(ids);
			response = buildSuccessMessage(crewMedReportTypeDtoList, HttpStatus.CREATED);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in CrewMedReportTypeController.softDelete");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
}
