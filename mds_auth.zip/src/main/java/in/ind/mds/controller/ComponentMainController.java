package in.ind.mds.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import in.ind.mds.dto.ComponentMainDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.service.ComponentMainService;
import in.ind.mds.util.RestDataApplicationResponse;

@RestController
@RequestMapping("/v1/componentMain")

public class ComponentMainController extends BaseController
{
	private static final Logger LOGGER = LoggerFactory.getLogger(ComponentMainController.class);

	@Autowired
	@Qualifier("TST_MSSQL_COMPONENT_MAIN")
	private ComponentMainService componentMainService;

	//@Autowired
	//private CommonUtil commonUtil;

	@RequestMapping(value = "/doLogin/{groupName}/{groupCode}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> doLogin(@PathVariable String groupName,
			@PathVariable String groupCode) {
		ResponseEntity<RestDataApplicationResponse> response;
		ComponentMainDto componentMainDto = null;

		try {
			componentMainDto = componentMainService.findByGroupNameAndGroupCode(groupName,groupCode);
			response = buildSuccessMessage(componentMainDto, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in ComponentMainController.doLogin");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}

	@RequestMapping(value = "/getByGroupId/{groupId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> getByGroupId(@PathVariable String groupId) {
		ComponentMainDto componentMainDto = null;
		ResponseEntity<RestDataApplicationResponse> response;
		try {
			componentMainDto = componentMainService.getByGroupId(groupId);
			response = buildSuccessMessage(componentMainDto, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in ComponentMainController.getByGroupId");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}

	@RequestMapping(value = "/getByGroupCode/{groupCode}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> findByGroupCode(@PathVariable String groupCode) {
		ComponentMainDto componentMainDto = null;
		ResponseEntity<RestDataApplicationResponse> response;
		try {
			componentMainDto = componentMainService.findByGroupCode(groupCode);
			response = buildSuccessMessage(componentMainDto, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in ComponentMainController.findByGroupCode");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}

	@RequestMapping(value = "/all", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> findAll() {
		ResponseEntity<RestDataApplicationResponse> response;
		List<ComponentMainDto> componentMainDto = null;

		try {
			componentMainDto = componentMainService.findAll();
			response = buildSuccessMessage(componentMainDto, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in ComponentMainController.findAll");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}

	@RequestMapping(method = RequestMethod.PUT, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> add(@RequestBody ComponentMainDto componentMainDto) {
		ResponseEntity<RestDataApplicationResponse> response = null;

		try {
			componentMainDto = componentMainService.add(componentMainDto);
			response = buildSuccessMessage(componentMainDto, HttpStatus.CREATED);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in ComponentMainController.add");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}

	@RequestMapping(value = "/softDelete", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> softDeleteComponentMain(@RequestBody List<String> groupIds) {
		ResponseEntity<RestDataApplicationResponse> response;
		try {
			List<ComponentMainDto> componentMainDtoList = componentMainService.softDeleteComponentMain(groupIds);
			response = buildSuccessMessage(componentMainDtoList, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in ComponentMainController.softDelete");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
	
	@RequestMapping(value = "/update", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> updateComponentMain(@RequestBody ComponentMainDto componentMainDto) {
		ResponseEntity<RestDataApplicationResponse> response;
		try {
			componentMainDto = componentMainService.updateComponentMain(componentMainDto);
			response = buildSuccessMessage(componentMainDto, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in ComponentMainController.update");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
	


	
}
