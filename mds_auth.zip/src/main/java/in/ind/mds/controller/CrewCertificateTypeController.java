/**
 * 
 */
package in.ind.mds.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.ind.mds.dto.CrewCertificateTypeDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.service.CrewCertificateTypeService;
import in.ind.mds.util.RestDataApplicationResponse;

/**
 * @author mds-arockia
 *
 */
@RestController
@RequestMapping(value = "/v1/crewCertificateType")
public class CrewCertificateTypeController extends BaseController{

	private static final Logger LOGGER = LoggerFactory.getLogger(CrewCertificateTypeController.class);
	
	@Autowired
	@Qualifier("TST_MSSQL_CREW_CERTIFICATE_TYPE")
	private CrewCertificateTypeService crewCertificateTypeService;
	
	@PutMapping(produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> add(@RequestBody CrewCertificateTypeDto certificateTypeDto) {
		ResponseEntity<RestDataApplicationResponse> response = null;
		try {
			certificateTypeDto = crewCertificateTypeService.add(certificateTypeDto);
			response = buildSuccessMessage(certificateTypeDto, HttpStatus.CREATED);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in CrewCertificateTypeController.add");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
	
	@PostMapping(value = "/update",produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> update(@RequestBody CrewCertificateTypeDto certificateTypeDto) {
		ResponseEntity<RestDataApplicationResponse> response = null;
		try {
			certificateTypeDto = crewCertificateTypeService.update(certificateTypeDto);
			response = buildSuccessMessage(certificateTypeDto, HttpStatus.CREATED);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in CrewCertificateTypeController.update");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
	
	@GetMapping(value = "/findById/{id}",produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> findById(@PathVariable("id") String id) {
		ResponseEntity<RestDataApplicationResponse> response = null;
		try {
			CrewCertificateTypeDto certificateTypeDto = crewCertificateTypeService.findById(id);
			response = buildSuccessMessage(certificateTypeDto, HttpStatus.CREATED);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in CrewCertificateTypeController.findById");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
	
	@GetMapping(value = "/findAll",produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> findAll() {
		ResponseEntity<RestDataApplicationResponse> response = null;
		try {
			List<CrewCertificateTypeDto> certificateTypeDtoList = crewCertificateTypeService.findAll();
			response = buildSuccessMessage(certificateTypeDtoList, HttpStatus.CREATED);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in CrewCertificateTypeController.findAll");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
	
	@PostMapping(value = "/softDelete",produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> softDelete(@RequestBody List<String> ids) {
		ResponseEntity<RestDataApplicationResponse> response = null;
		try {
			List<CrewCertificateTypeDto> certificateTypeDtoList = crewCertificateTypeService.softDelete(ids);
			response = buildSuccessMessage(certificateTypeDtoList, HttpStatus.CREATED);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in CrewCertificateTypeController.softDelete");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
}
