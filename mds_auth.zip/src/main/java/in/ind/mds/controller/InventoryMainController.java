package in.ind.mds.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import in.ind.mds.dto.InventoryMainDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.service.InventoryMainService;
import in.ind.mds.util.RestDataApplicationResponse;

@RestController
@RequestMapping("/v1/inventoryMain")

public class InventoryMainController extends BaseController
{
	private static final Logger LOGGER = LoggerFactory.getLogger(InventoryMainController.class);

	@Autowired
	@Qualifier("TST_MSSQL_INVENTORY_MAIN")
	private InventoryMainService inventoryMainService;

	//@Autowired
	//private CommonUtil commonUtil;

	@RequestMapping(value = "/doLogin/{ctgyCode}/{ctgyName}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> doLogin(@PathVariable String ctgyCode,
			@PathVariable String ctgyName) {
		ResponseEntity<RestDataApplicationResponse> response;
		InventoryMainDto inventoryMainDto = null;

		try {
			inventoryMainDto = inventoryMainService.findByCtgyCodeAndCtgyName(ctgyCode,ctgyName);
			response = buildSuccessMessage(inventoryMainDto, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in InventoryMainController.doLogin");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}

	@RequestMapping(value = "/{ctgyId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> getByCtgyId(@PathVariable String ctgyId) {
		InventoryMainDto inventoryMainDto = null;
		ResponseEntity<RestDataApplicationResponse> response;
		try {
			inventoryMainDto = inventoryMainService.getByCtgyId(ctgyId);
			response = buildSuccessMessage(inventoryMainDto, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in InventoryMainController.getByCtgyId");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}

	@RequestMapping(value = "/byCtgyName/{ctgyName}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> getUserByName(@PathVariable String ctgyName) {
		InventoryMainDto inventoryMainDto = null;
		ResponseEntity<RestDataApplicationResponse> response;
		try {
			inventoryMainDto = inventoryMainService.findByCtgyName(ctgyName);
			response = buildSuccessMessage(inventoryMainDto, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in InventoryMainController.findByCtgyName");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}

	@RequestMapping(value = "/all", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> findAll() {
		ResponseEntity<RestDataApplicationResponse> response;
		List<InventoryMainDto> inventoryMainDto = null;

		try {
			inventoryMainDto = inventoryMainService.findAll();
			response = buildSuccessMessage(inventoryMainDto, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in InventoryMainController.findAll");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}

	@RequestMapping(method = RequestMethod.PUT, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> add(@RequestBody InventoryMainDto inventoryMainDto) {
		ResponseEntity<RestDataApplicationResponse> response = null;

		try {
			inventoryMainDto = inventoryMainService.add(inventoryMainDto);
			response = buildSuccessMessage(inventoryMainDto, HttpStatus.CREATED);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in InventoryMainController.add");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}

	@RequestMapping(value = "/softDelete/{ctgyId}", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> deleteInventoryMain(@PathVariable String ctgyId) {
		ResponseEntity<RestDataApplicationResponse> response;
		boolean success = false;
		try {
			inventoryMainService.softDeleteInventoryMain(ctgyId);
			success = true;
			response = buildBooleanStatus(success, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in InventoryMainController.del");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
	
	@RequestMapping(value = "/update", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> updateInventoryMain(@RequestBody InventoryMainDto inventoryMainDto) {
		ResponseEntity<RestDataApplicationResponse> response;
		try {
			inventoryMainDto = inventoryMainService.updateInventoryMain(inventoryMainDto);
			response = buildSuccessMessage(inventoryMainDto, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in InventoryMainController.update");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
	


}
