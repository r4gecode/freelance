/**
 * 
 */
package in.ind.mds.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.ind.mds.dto.CrewCertifCapacityDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.service.CrewCertifCapacityService;
import in.ind.mds.util.RestDataApplicationResponse;

/**
 * @author mds-arockia
 *
 */
@RestController
@RequestMapping(value = "/v1/crewCertifCapacity")
public class CrewCertifCapacityController extends BaseController{
		
	private static final Logger LOGGER = LoggerFactory.getLogger(CrewCertifCapacityController.class);
	
	@Autowired
	@Qualifier("TST_MSSQL_CREW_CERTIF_CAPACITY")
	private CrewCertifCapacityService crewCertifCapacityService;
	
	@PutMapping(produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> add(@RequestBody CrewCertifCapacityDto certifCapacityDto) {
		ResponseEntity<RestDataApplicationResponse> response = null;
		try {
			certifCapacityDto = crewCertifCapacityService.add(certifCapacityDto);
			response = buildSuccessMessage(certifCapacityDto, HttpStatus.CREATED);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in CrewCertifCapacityController.add");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
	
	@PostMapping(value = "/udpate",produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> update(@RequestBody CrewCertifCapacityDto certifCapacityDto) {
		ResponseEntity<RestDataApplicationResponse> response = null;
		try {
			certifCapacityDto = crewCertifCapacityService.update(certifCapacityDto);
			response = buildSuccessMessage(certifCapacityDto, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in CrewCertifCapacityController.update");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
	
	@GetMapping(value = "/findById/{id}",produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> findById(@PathVariable("id") String id) {
		ResponseEntity<RestDataApplicationResponse> response = null;
		try {
			CrewCertifCapacityDto certifCapacityDto = crewCertifCapacityService.findById(id);
			response = buildSuccessMessage(certifCapacityDto, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in CrewCertifCapacityController.findById");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
	
	@GetMapping(value = "/findAll",produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> findAll() {
		ResponseEntity<RestDataApplicationResponse> response = null;
		try {
			List<CrewCertifCapacityDto> certifCapacityDtoList = crewCertifCapacityService.findAll();
			response = buildSuccessMessage(certifCapacityDtoList, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in CrewCertifCapacityController.findAll");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
	
	@PostMapping(value = "/softDelete",produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> softDelete(@RequestBody List<String> ids) {
		ResponseEntity<RestDataApplicationResponse> response = null;
		try {
			List<CrewCertifCapacityDto> certifCapacityDtoList = crewCertifCapacityService.softDelete(ids);
			response = buildSuccessMessage(certifCapacityDtoList, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in CrewCertifCapacityController.softDelete");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
}
