package in.ind.mds.controller;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.service.SyncEventService;
import in.ind.mds.util.RestDataApplicationResponse;

@RestController
@RequestMapping("/v1/syncEvent")
public class SyncEventController extends BaseController {

	private static final Logger LOGGER = LoggerFactory.getLogger(SyncEventController.class);

	@Autowired
	@Qualifier("TST_MSSQL_SYNCEVENT")
	private SyncEventService syncService;

	@RequestMapping(value = "/export/{senderId}/{receiverId}/{syncType}", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> exportSyncData(
			@PathVariable String senderId,
			@PathVariable String receiverId,
			@PathVariable String syncType) {
		ResponseEntity<RestDataApplicationResponse> response;
		boolean booleanStatus = false;
		String filePath = null;
		try {
			Integer a = 8/0;
			System.out.println(a);
			filePath = syncService.exportSyncDataList(senderId, receiverId, syncType);
			if(filePath != null) {
				booleanStatus = true;
			}
			response = buildBooleanStatus(booleanStatus, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(), e);
		} catch (Exception e) {
			LOGGER.error("Exception in SyncEventController.createSyncEvent :"+ExceptionUtils.getStackTrace(e));
			response = buildErrorMessage("Exception in SyncEventController.createSyncEvent : ",HttpStatus.INTERNAL_SERVER_ERROR, e);
			//response = buildErrorMessageWithId("Error", HttpStatus.INTERNAL_SERVER_ERROR, exceptionId);
		}
		return response;
	}

	@RequestMapping(value = "/import/{path}/{receiverId}/{syncType}", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> importSyncData(
			@PathVariable String path,
			@PathVariable String receiverId,
			@PathVariable String syncType) {
		ResponseEntity<RestDataApplicationResponse> response;
		boolean booleanStatus = false;
		String filePath = null;
		try {
			filePath = syncService.importSyncData(path, receiverId, syncType);
			if(filePath != null) {
				booleanStatus = true;
			}
			response = buildBooleanStatus(booleanStatus, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in SyncEventController.importSyncData :"+ExceptionUtils.getStackTrace(e));
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
	
}
