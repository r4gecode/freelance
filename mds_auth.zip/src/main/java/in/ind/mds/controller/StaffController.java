/**
 * 
 */
package in.ind.mds.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;

import in.ind.mds.dto.StaffDetailsDto;
import in.ind.mds.dto.StaffDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.service.StaffService;
import in.ind.mds.util.RestDataApplicationResponse;

/**
 * @author mds_kiruthika
 *
 */

@RestController
@RequestMapping("/v1/staff")
public class StaffController extends BaseController {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(StaffController.class);

	@Autowired
	@Qualifier("TST_MSSQL_STAFF")
	private StaffService staffService;
	
	@RequestMapping(value = "/getStaffById/{staffId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> getStaffById(@PathVariable String staffId) {
		ResponseEntity<RestDataApplicationResponse> response;
		StaffDetailsDto staffDetailsDto = null;
		try {
			staffDetailsDto = staffService.getByStaffId(staffId);
			response = buildSuccessMessage(staffDetailsDto, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in StaffController.getStaffById");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
	
	@RequestMapping(method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> add(@RequestParam("staff") String staffDetails, @RequestParam("staffPic") MultipartFile[] staffPic
			,@RequestParam("staffDoc") MultipartFile[] staffDoc, @RequestParam("bankAccountDoc") MultipartFile[] bankAccountDoc
			,@RequestParam("activityDoc") MultipartFile[] activityDoc, @RequestParam("medicalReportDoc") MultipartFile[] medicalReportDoc
			,@RequestParam("trainingDoc") MultipartFile[] trainingDoc, @RequestParam("certificateDoc") MultipartFile[] certificateDoc
			,@RequestParam("travelDoc") MultipartFile[] travelDoc,@RequestParam("contractDoc") MultipartFile[] contractDoc) throws JsonParseException, JsonMappingException, IOException {
		ResponseEntity<RestDataApplicationResponse> response = null;
		StaffDetailsDto staffDetailsDto = null;
		try {
			Map<String, MultipartFile[]> attachments = new HashMap<>();
			attachments.put("staffPic", staffPic);
			attachments.put("staffDoc", staffDoc);
			attachments.put("bankAccountDoc", bankAccountDoc);
			attachments.put("activityDoc", activityDoc);
			attachments.put("medicalReportDoc", medicalReportDoc);
			attachments.put("trainingDoc", trainingDoc);
			attachments.put("certificateDoc", certificateDoc);
			attachments.put("travelDoc", travelDoc);
			attachments.put("contractDoc", contractDoc);
			staffDetailsDto = staffService.add(staffDetails, attachments);
			response = buildSuccessMessage(staffDetailsDto, HttpStatus.CREATED);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in StaffController.add");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}

	@RequestMapping(value = "/all", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> findAllStaff() {
		ResponseEntity<RestDataApplicationResponse> response = null;
		List<StaffDto> staffDtoList = new ArrayList<>();
		try {
			staffDtoList = staffService.findAll();
			response = buildSuccessMessage(staffDtoList, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in StaffController.findAllStaff");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
	
	@RequestMapping(value = "/softDelete", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> softDeleteStaff(@RequestBody List<String> staffId) {
		ResponseEntity<RestDataApplicationResponse> response = null;
		try {
			List<StaffDto> staffDtoList=staffService.softDeleteStaff(staffId);
			response = buildSuccessMessage(staffDtoList, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in StaffController.softDeleteStaff");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
	
	@RequestMapping(value = "/update", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> update(@RequestParam("staff") String staffDetails, @RequestParam("staffPic") MultipartFile[] staffPic
			,@RequestParam("staffDoc") MultipartFile[] staffDoc, @RequestParam("bankAccountDoc") MultipartFile[] bankAccountDoc
			,@RequestParam("activityDoc") MultipartFile[] activityDoc, @RequestParam("medicalReportDoc") MultipartFile[] medicalReportDoc
			,@RequestParam("trainingDoc") MultipartFile[] trainingDoc, @RequestParam("certificateDoc") MultipartFile[] certificateDoc
			,@RequestParam("travelDoc") MultipartFile[] travelDoc,@RequestParam("contractDoc") MultipartFile[] contractDoc) throws JsonParseException, JsonMappingException, IOException {
		ResponseEntity<RestDataApplicationResponse> response = null;
		StaffDetailsDto staffDetailsDto = null;
		try {
			Map<String, MultipartFile[]> attachments = new HashMap<>();
			attachments.put("staffPic", staffPic);
			attachments.put("staffDoc", staffDoc);
			attachments.put("bankAccountDoc", bankAccountDoc);
			attachments.put("activityDoc", activityDoc);
			attachments.put("medicalReportDoc", medicalReportDoc);
			attachments.put("trainingDoc", trainingDoc);
			attachments.put("certificateDoc", certificateDoc);
			attachments.put("travelDoc", travelDoc);
			attachments.put("contractDoc", contractDoc);
			staffDetailsDto = staffService.updateStaff(staffDetails, attachments);
			response = buildSuccessMessage(staffDetailsDto, HttpStatus.CREATED);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in StaffController.update");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
	
}
