package in.ind.mds.controller;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import in.ind.mds.dto.CountryDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.service.CountryService;
import in.ind.mds.util.RestDataApplicationResponse;

@RestController
@RequestMapping("/v1/country")

public class CountryController extends BaseController  {
	private static final Logger LOGGER = LoggerFactory.getLogger(CountryController.class);

	@Autowired
	@Qualifier("TST_MSSQL_COUNTRY")
	private CountryService countryService;

	//@Autowired
	//private CommonUtil commonUtil;
		
	@RequestMapping(value = "/getCountryId/{countryId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> getCountryId(@PathVariable String countryId) {
		ResponseEntity<RestDataApplicationResponse> response;
		CountryDto countryDto = null;

		try {
			countryDto = countryService.getCountryId(countryId);
			response = buildSuccessMessage(countryDto, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in CountryController.getCountryId");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}

	@RequestMapping(value = "/all", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> findAllCountry() {
		ResponseEntity<RestDataApplicationResponse> response;
		List<CountryDto> listCountryDto = new ArrayList<>();

		try {
			listCountryDto = countryService.findAll();
			response = buildSuccessMessage(listCountryDto, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in CountryController.findAllCountry");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
	
	@RequestMapping(method = RequestMethod.PUT, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> add(@RequestBody CountryDto countryDto) {
		ResponseEntity<RestDataApplicationResponse> response = null;

		try {
			countryDto = countryService.add(countryDto);
			response = buildSuccessMessage(countryDto, HttpStatus.CREATED);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in CountryController.add");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}

	@RequestMapping(value = "/softDelete", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> softDeleteCountry(@RequestBody List<String> countryIds) {
		ResponseEntity<RestDataApplicationResponse> response;
		try {
			List<CountryDto> countryDtoList = countryService.softDeleteCountry(countryIds);
			response = buildSuccessMessage(countryDtoList, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in CountryController.softDeleteCountry");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
	
	@RequestMapping(value = "/update", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> updateCountry(@RequestBody CountryDto countryDto) {
		ResponseEntity<RestDataApplicationResponse> response;
		try {
			countryDto = countryService.updateCountry(countryDto);
			response = buildSuccessMessage(countryDto, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in CountryController.update");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}

}
