/**
 * 
 */
package in.ind.mds.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.ind.mds.dto.InventoryCatalogDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.service.InventoryCatalogService;
import in.ind.mds.util.RestDataApplicationResponse;

/**
 * @author mds-arockia
 *
 */
@RestController
@RequestMapping("/v1/invCatalog")
public class InventoryCatalogController extends BaseController{
	private static final Logger LOGGER = LoggerFactory.getLogger(InventoryCatalogController.class);

	@Autowired
	@Qualifier("TST_MSSQL_INVENTORY_CATALOG")
	private InventoryCatalogService inventoryCatalogService;
	
	@PutMapping(produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> add(@RequestBody InventoryCatalogDto inventoryCatalogDto) {
		ResponseEntity<RestDataApplicationResponse> response = null;
		try {
			inventoryCatalogDto = inventoryCatalogService.add(inventoryCatalogDto);
			response = buildSuccessMessage(inventoryCatalogDto, HttpStatus.CREATED);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in InventoryCatalogController.add");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}

	@PostMapping(value = "/softDelete", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> softDelete(@RequestBody List<String> invCatalogIds) {
		ResponseEntity<RestDataApplicationResponse> response;
		try {
			List<InventoryCatalogDto> invCatalogDtoList = inventoryCatalogService.softDelete(invCatalogIds);
			response = buildSuccessMessage(invCatalogDtoList, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in InventoryCatalogController.softDelete");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
	
	@PostMapping(value = "/update", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> baseCurencyUpdation(@RequestBody InventoryCatalogDto inventoryCatalogDto) {
		ResponseEntity<RestDataApplicationResponse> response;
		try {
			InventoryCatalogDto invCatalogDto = inventoryCatalogService.update(inventoryCatalogDto);
			response = buildSuccessMessage(invCatalogDto, HttpStatus.OK);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in InventoryController.update");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
}
