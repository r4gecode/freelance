/**
 * 
 */
package in.ind.mds.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import in.ind.mds.dto.ScheduledJobDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.service.ScheduledJobService;
import in.ind.mds.util.RestDataApplicationResponse;

/**
 * @author mds-arockia
 *
 */
@RestController
@RequestMapping(value = "/v1/scheduledJob")
public class ScheduledJobController extends BaseController{

	private static final Logger LOGGER = LoggerFactory.getLogger(ScheduledJobController.class);
	
	@Autowired
	@Qualifier("TST_MSSQL_SCHEDULED_JOB")
	private ScheduledJobService scheduledJobService;
	
	@PostMapping(produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> add(@RequestParam("scheduledJobDetails") String scheduledJobDetails, @RequestParam("attachmentFiles") MultipartFile[] attachmentFiles) {
		ResponseEntity<RestDataApplicationResponse> response = null;
		try {
			ScheduledJobDto scheduledJobDto = scheduledJobService.add(scheduledJobDetails, attachmentFiles);
			response = buildSuccessMessage(scheduledJobDto, HttpStatus.CREATED);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in ScheduledJobController.add");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
	
	@PostMapping(value = "/update",produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> update(@RequestParam("scheduledJobDetails") String scheduledJobDetails, @RequestParam("attachmentFiles") MultipartFile[] attachmentFiles) {
		ResponseEntity<RestDataApplicationResponse> response = null;
		try {
			ScheduledJobDto scheduledJobDto = scheduledJobService.update(scheduledJobDetails, attachmentFiles);
			response = buildSuccessMessage(scheduledJobDto, HttpStatus.CREATED);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in ScheduledJobController.update");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
	
	@GetMapping(value = "/findById/{id}",produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> findById(@PathVariable("id") String id) {
		ResponseEntity<RestDataApplicationResponse> response = null;
		try {
			ScheduledJobDto scheduledJobDto = scheduledJobService.findById(id);
			response = buildSuccessMessage(scheduledJobDto, HttpStatus.CREATED);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in ScheduledJobController.findById");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
	
	@GetMapping(value = "/findAll",produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> findAll() {
		ResponseEntity<RestDataApplicationResponse> response = null;
		try {
			List<ScheduledJobDto> scheduledJobDtoList = scheduledJobService.findAll();
			response = buildSuccessMessage(scheduledJobDtoList, HttpStatus.CREATED);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in ScheduledJobController.findAll");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
	
	@PostMapping(value = "/softDelete",produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> softDelete(@RequestBody List<String> ids) {
		ResponseEntity<RestDataApplicationResponse> response = null;
		try {
			List<ScheduledJobDto> scheduledJobDtoList = scheduledJobService.softDelete(ids);
			response = buildSuccessMessage(scheduledJobDtoList, HttpStatus.CREATED);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in ScheduledJobController.softDelete");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
}
