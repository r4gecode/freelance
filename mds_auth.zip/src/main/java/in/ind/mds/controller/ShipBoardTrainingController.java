/**
 * 
 */
package in.ind.mds.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;


import in.ind.mds.dto.ShipBoardTrainingDto;
import in.ind.mds.dto.StaffDetailsDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.repo.entity.ShipBoardTraining;
import in.ind.mds.service.ShipBoardTrainingService;
import in.ind.mds.util.RestDataApplicationResponse;

/**
 * @author dharani
 *
 */

@RestController
@RequestMapping(value="/v1/shipBoardTraining")
public class ShipBoardTrainingController extends BaseController{
	private static final Logger LOGGER = LoggerFactory.getLogger(ShipBoardTraining.class);
	
	@Autowired
	@Qualifier("TST_MSSQL_SHIPBOARD_TRAINING")
	private ShipBoardTrainingService shipBoardTrainingService;
	
	@RequestMapping(method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> add(@RequestParam("shipBoardTraining") String shipBoardTrainingDto, @RequestParam("officeReviewAtch") MultipartFile[] officeReviewAtch
						) throws JsonParseException, JsonMappingException, IOException {
		ResponseEntity<RestDataApplicationResponse> response = null;
		ShipBoardTrainingDto shipBoardTrainingDtoList = null;
		try {
			Map<String, MultipartFile[]> attachments = new HashMap<>();
			attachments.put("officeReviewAtch", officeReviewAtch);
			shipBoardTrainingDtoList = shipBoardTrainingService.add(shipBoardTrainingDto, attachments);
			response = buildSuccessMessage(shipBoardTrainingDtoList, HttpStatus.CREATED);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in ShipBoardTrainingController.add");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
		}
	
	@GetMapping(value="/findById/{id}",produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> findById(@PathVariable("id") String id) {
		ResponseEntity<RestDataApplicationResponse> response = null;
		
		try {
		
			ShipBoardTrainingDto shipBoardTrainingDto=shipBoardTrainingService.findById(id);
			response = buildSuccessMessage(shipBoardTrainingDto, HttpStatus.OK);
		}catch(ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		}catch(Exception e) {
			LOGGER.error("Exception in ShipBoardTrainingController.findById");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);	
		}
				
		return response;	
	}
	
	@GetMapping(value="/findAll",produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> findAll() {
		ResponseEntity<RestDataApplicationResponse> response = null;
		try {
			List<ShipBoardTrainingDto> shipBoardTrainingDtoList=shipBoardTrainingService.findAll();
			response = buildSuccessMessage(shipBoardTrainingDtoList, HttpStatus.OK);
		}catch(ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
		response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		}catch(Exception e) {
			LOGGER.error("Exception in shipBoardTraining.findAll");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}
	
	@PostMapping(value = "/softDelete",produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> softDelete(@RequestBody List<String> ids) {
		ResponseEntity<RestDataApplicationResponse> response = null;
		try {
			List<ShipBoardTrainingDto> shipBoardTrainingDtoList=shipBoardTrainingService.softDelete(ids);
			response = buildSuccessMessage(shipBoardTrainingDtoList, HttpStatus.OK);
		}catch(ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in shipBoardTraining.softDelete");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
	}	
	@RequestMapping(value = "/update", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestDataApplicationResponse> update(@RequestParam("shipBoardTRaining") String shipBoardTrainingDtoList, @RequestParam("officeReviewAtch") MultipartFile[] attachmentFiles
						) throws JsonParseException, JsonMappingException, IOException {
		ResponseEntity<RestDataApplicationResponse> response = null;
		ShipBoardTrainingDto shipBoardTrainingDto = null;
		try {
			Map<String, MultipartFile[]> attachments = new HashMap<>();
			attachments.put("officeReviewAtch", attachmentFiles);
			shipBoardTrainingDto = shipBoardTrainingService.update(shipBoardTrainingDtoList, attachments);
			response = buildSuccessMessage(shipBoardTrainingDto, HttpStatus.CREATED);
		} catch (ApplicationServiceExecption e) {
			LOGGER.error(e.getErrorMessage());
			response = buildErrorMessage(e.getErrorMessage(), e.getStatus(),e);
		} catch (Exception e) {
			LOGGER.error("Exception in ShipBoardTrainingController.add");
			response = buildErrorMessage("Error", HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
		return response;
		}
}
