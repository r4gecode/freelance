/**
 * 
 */
package in.ind.mds.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import org.dozer.Mapping;

/**
 * @author mds-arockia
 *
 */
public class InventoryItemDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 117488936243458L;
	
	private String id;
	
	@Mapping("invCatalog")
	private InventoryCatalogDto invCatalog; 
	
	@Mapping("fleet")
	private FleetDto fleet;
	
	@Mapping("vessel")
	private VesselDto vessel;
	
	private Float currQty;
	private BigDecimal avgPrice;
	private BigDecimal latestPrice;
	private BigDecimal totalPrice;
	private Date insertTime;
	private Integer insertedBy;
	private Date updateTime;
	private Integer updatedBy;
	
	@Mapping("status")
	private StatusDto status;
	
	private String syncRequired;
	private String fwcInventory;
	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}
	/**
	 * @return the invCatalog
	 */
	public InventoryCatalogDto getInvCatalog() {
		return invCatalog;
	}
	/**
	 * @param invCatalog the invCatalog to set
	 */
	public void setInvCatalog(InventoryCatalogDto invCatalog) {
		this.invCatalog = invCatalog;
	}
	/**
	 * @return the fleet
	 */
	public FleetDto getFleet() {
		return fleet;
	}
	/**
	 * @param fleet the fleet to set
	 */
	public void setFleet(FleetDto fleet) {
		this.fleet = fleet;
	}
	/**
	 * @return the vessel
	 */
	public VesselDto getVessel() {
		return vessel;
	}
	/**
	 * @param vessel the vessel to set
	 */
	public void setVessel(VesselDto vessel) {
		this.vessel = vessel;
	}
	/**
	 * @return the currQty
	 */
	public Float getCurrQty() {
		return currQty;
	}
	/**
	 * @param currQty the currQty to set
	 */
	public void setCurrQty(Float currQty) {
		this.currQty = currQty;
	}
	/**
	 * @return the avgPrice
	 */
	public BigDecimal getAvgPrice() {
		return avgPrice;
	}
	/**
	 * @param avgPrice the avgPrice to set
	 */
	public void setAvgPrice(BigDecimal avgPrice) {
		this.avgPrice = avgPrice;
	}
	/**
	 * @return the latestPrice
	 */
	public BigDecimal getLatestPrice() {
		return latestPrice;
	}
	/**
	 * @param latestPrice the latestPrice to set
	 */
	public void setLatestPrice(BigDecimal latestPrice) {
		this.latestPrice = latestPrice;
	}
	/**
	 * @return the totalPrice
	 */
	public BigDecimal getTotalPrice() {
		return totalPrice;
	}
	/**
	 * @param totalPrice the totalPrice to set
	 */
	public void setTotalPrice(BigDecimal totalPrice) {
		this.totalPrice = totalPrice;
	}
	/**
	 * @return the insertTime
	 */
	public Date getInsertTime() {
		return insertTime;
	}
	/**
	 * @param insertTime the insertTime to set
	 */
	public void setInsertTime(Date insertTime) {
		this.insertTime = insertTime;
	}
	/**
	 * @return the insertedBy
	 */
	public Integer getInsertedBy() {
		return insertedBy;
	}
	/**
	 * @param insertedBy the insertedBy to set
	 */
	public void setInsertedBy(Integer insertedBy) {
		this.insertedBy = insertedBy;
	}
	/**
	 * @return the updateTime
	 */
	public Date getUpdateTime() {
		return updateTime;
	}
	/**
	 * @param updateTime the updateTime to set
	 */
	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}
	/**
	 * @return the updatedBy
	 */
	public Integer getUpdatedBy() {
		return updatedBy;
	}
	/**
	 * @param updatedBy the updatedBy to set
	 */
	public void setUpdatedBy(Integer updatedBy) {
		this.updatedBy = updatedBy;
	}
	/**
	 * @return the status
	 */
	public StatusDto getStatus() {
		return status;
	}
	/**
	 * @param status the status to set
	 */
	public void setStatus(StatusDto status) {
		this.status = status;
	}
	/**
	 * @return the syncRequired
	 */
	public String getSyncRequired() {
		return syncRequired;
	}
	/**
	 * @param syncRequired the syncRequired to set
	 */
	public void setSyncRequired(String syncRequired) {
		this.syncRequired = syncRequired;
	}
	/**
	 * @return the fwcInventory
	 */
	public String getFwcInventory() {
		return fwcInventory;
	}
	/**
	 * @param fwcInventory the fwcInventory to set
	 */
	public void setFwcInventory(String fwcInventory) {
		this.fwcInventory = fwcInventory;
	}
	
}
