/**
 * 
 */
package in.ind.mds.dto;

import java.io.Serializable;
import java.util.Date;





import org.dozer.Mapping;


/**
 * @author dharani
 *
 */
public class HazardsDto implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 174857757567L;

	
	private String id;
	
    @Mapping("operationId")
	private OperationDto operationId;
	

	private Integer siNo;
	
	
	private String harzards;
	
	
	
	private String impactOrConsequences;
	
	

	private String existingControlMeasures;
	
	
	private String additionalMeasures;
	
	
	private String followUp;
	

	private String syncRequired;
	
	
	private Date insertTime;



	private Date updateTime;

	
	@Mapping("insertedBy")
	private UserDto insertedBy;
	
	@Mapping("updatedBy")
	private UserDto updatedBy;

	
	@Mapping("status")
	private StatusDto status;


	public String getId() {
		return id;
	}


	public void setId(String id) {
		this.id = id;
	}


	public OperationDto getOperationId() {
		return operationId;
	}


	public void setOperationId(OperationDto operationId) {
		this.operationId = operationId;
	}


	public Integer getSiNo() {
		return siNo;
	}


	public void setSiNo(Integer siNo) {
		this.siNo = siNo;
	}


	public String getHarzards() {
		return harzards;
	}


	public void setHarzards(String harzards) {
		this.harzards = harzards;
	}


	public String getImpactOrConsequences() {
		return impactOrConsequences;
	}


	public void setImpactOrConsequences(String impactOrConsequences) {
		this.impactOrConsequences = impactOrConsequences;
	}


	public String getExistingControlMeasures() {
		return existingControlMeasures;
	}


	public void setExistingControlMeasures(String existingControlMeasures) {
		this.existingControlMeasures = existingControlMeasures;
	}


	public String getAdditionalMeasures() {
		return additionalMeasures;
	}


	public void setAdditionalMeasures(String additionalMeasures) {
		this.additionalMeasures = additionalMeasures;
	}


	public String getFollowUp() {
		return followUp;
	}


	public void setFollowUp(String followUp) {
		this.followUp = followUp;
	}


	public String getSyncRequired() {
		return syncRequired;
	}


	public void setSyncRequired(String syncRequired) {
		this.syncRequired = syncRequired;
	}


	public Date getInsertTime() {
		return insertTime;
	}


	public void setInsertTime(Date insertTime) {
		this.insertTime = insertTime;
	}


	public Date getUpdateTime() {
		return updateTime;
	}


	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}


	public UserDto getInsertedBy() {
		return insertedBy;
	}


	public void setInsertedBy(UserDto insertedBy) {
		this.insertedBy = insertedBy;
	}


	public UserDto getUpdatedBy() {
		return updatedBy;
	}


	public void setUpdatedBy(UserDto updatedBy) {
		this.updatedBy = updatedBy;
	}


	public StatusDto getStatus() {
		return status;
	}


	public void setStatus(StatusDto status) {
		this.status = status;
	}

    
	

}
