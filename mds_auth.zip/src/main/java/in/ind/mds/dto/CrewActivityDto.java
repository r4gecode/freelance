/**
 * 
 */
package in.ind.mds.dto;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import org.dozer.Mapping;

/**
 * @author dharani
 *
 */
public class CrewActivityDto implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 122334455667L;
	
	private String id;
	
	private String activity;
	
	private Date fromDate;
	
	private Date toDate;
	
	private Integer years;
	
	private Integer months;
	
	private Integer days;
	
	private String remarks;
	
	private String syncRequired;
	
	private Date insertTime;
	
	private Date updateTime;
	
	@Mapping("staff")
	private StaffDto staff;
	
	
	@Mapping("vessel")
	private VesselDto vessel;
	
	
	@Mapping("role")
	private RoleDto role;
	
	@Mapping("status")
	private StatusDto status;
	
	@Mapping("insertedBy")
	private UserDto insertedBy;
	
	@Mapping("updatedBy")
	private UserDto updatedBy;
	
	List<String> activityDoc;
	
	List<String> softDeleteDocPaths;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getActivity() {
		return activity;
	}

	public void setActivity(String activity) {
		this.activity = activity;
	}

	public Date getFromDate() {
		return fromDate;
	}

	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}

	public Date getToDate() {
		return toDate;
	}

	public void setToDate(Date toDate) {
		this.toDate = toDate;
	}

	public Integer getYears() {
		return years;
	}

	public void setYears(Integer years) {
		this.years = years;
	}

	public Integer getMonths() {
		return months;
	}

	public void setMonths(Integer months) {
		this.months = months;
	}

	public Integer getDays() {
		return days;
	}

	public void setDays(Integer days) {
		this.days = days;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getSyncRequired() {
		return syncRequired;
	}

	public void setSyncRequired(String syncRequired) {
		this.syncRequired = syncRequired;
	}

	public Date getInsertTime() {
		return insertTime;
	}

	public void setInsertTime(Date insertTime) {
		this.insertTime = insertTime;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public StaffDto getStaff() {
		return staff;
	}

	public void setStaff(StaffDto staff) {
		this.staff = staff;
	}

	public VesselDto getVessel() {
		return vessel;
	}

	public void setVessel(VesselDto vessel) {
		this.vessel = vessel;
	}

	public RoleDto getRole() {
		return role;
	}

	public void setRole(RoleDto role) {
		this.role = role;
	}

	public StatusDto getStatus() {
		return status;
	}

	public void setStatus(StatusDto status) {
		this.status = status;
	}

	public UserDto getInsertedBy() {
		return insertedBy;
	}

	public void setInsertedBy(UserDto insertedBy) {
		this.insertedBy = insertedBy;
	}

	public UserDto getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(UserDto updatedBy) {
		this.updatedBy = updatedBy;
	}


	public List<String> getActivityDoc() {
		return activityDoc;
	}

	public void setActivityDoc(List<String> activityDoc) {
		this.activityDoc = activityDoc;
	}

	public String getActivityDocFieldName() {
		
		return "ActivityDoc";
	}

	/**
	 * @return the softDeleteDocPaths
	 */
	public List<String> getSoftDeleteDocPaths() {
		return softDeleteDocPaths;
	}

	/**
	 * @param softDeleteDocPaths the softDeleteDocPaths to set
	 */
	public void setSoftDeleteDocPaths(List<String> softDeleteDocPaths) {
		this.softDeleteDocPaths = softDeleteDocPaths;
	}
	
}
