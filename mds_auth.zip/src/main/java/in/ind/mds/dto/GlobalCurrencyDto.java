/**
 * 
 */
package in.ind.mds.dto;

import java.io.Serializable;

/**
 * @author mds-arockia
 *
 */
public class GlobalCurrencyDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 118889343326248L;
	
	private Integer id;
	private String currencyCode;
	private String currency;
	/**
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(Integer id) {
		this.id = id;
	}
	/**
	 * @return the currencyCode
	 */
	public String getCurrencyCode() {
		return currencyCode;
	}
	/**
	 * @param currencyCode the currencyCode to set
	 */
	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}
	/**
	 * @return the currency
	 */
	public String getCurrency() {
		return currency;
	}
	/**
	 * @param currency the currency to set
	 */
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	
}
