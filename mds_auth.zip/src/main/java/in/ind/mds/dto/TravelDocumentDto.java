/**
 * 
 */
package in.ind.mds.dto;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import org.dozer.Mapping;

import in.ind.mds.repo.entity.User;

/**
 * @author mds_kiruthika
 *
 */
public class TravelDocumentDto implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 9863413124583664L;
	
	private String id;
	private String documentType;
	private String documentNumber;
	private String placeOfIssue;
	private String issuedBy;
	private String syncRequired;
	private Date insertTime;
	private Date updateTime;
	
	@Mapping("staff")
	private StaffDto staff;
	
	@Mapping("status")
	private StatusDto status;
	
	@Mapping("country")
	private CountryDto country;
	
	/*@Mapping("attachment")
	private AttachmentDto attachment;*/
	
	@Mapping("insertedBy")
	private User insertedBy;
	
	@Mapping("updatedBy")
	private User updatedBy;
	
	List<String> travelDoc;
	
	List<String> softDeleteDocPaths;
	
	public String getTraveDocFieldName() {
		return "TravelDoc";
	}


	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getDocumentType() {
		return documentType;
	}

	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}

	public String getDocumentNumber() {
		return documentNumber;
	}

	public void setDocumentNumber(String documentNumber) {
		this.documentNumber = documentNumber;
	}

	public String getPlaceOfIssue() {
		return placeOfIssue;
	}

	public void setPlaceOfIssue(String placeOfIssue) {
		this.placeOfIssue = placeOfIssue;
	}

	public String getIssuedBy() {
		return issuedBy;
	}

	public void setIssuedBy(String issuedBy) {
		this.issuedBy = issuedBy;
	}

	public String getSyncRequired() {
		return syncRequired;
	}

	public void setSyncRequired(String syncRequired) {
		this.syncRequired = syncRequired;
	}

	public Date getInsertTime() {
		return insertTime;
	}

	public void setInsertTime(Date insertTime) {
		this.insertTime = insertTime;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public StaffDto getStaff() {
		return staff;
	}

	public void setStaff(StaffDto staff) {
		this.staff = staff;
	}

	public StatusDto getStatus() {
		return status;
	}

	public void setStatus(StatusDto status) {
		this.status = status;
	}

	public CountryDto getCountry() {
		return country;
	}

	public void setCountry(CountryDto country) {
		this.country = country;
	}

	/*public AttachmentDto getAttachment() {
		return attachment;
	}

	public void setAttachment(AttachmentDto attachment) {
		this.attachment = attachment;
	}*/

	

	public User getInsertedBy() {
		return insertedBy;
	}


	public void setInsertedBy(User insertedBy) {
		this.insertedBy = insertedBy;
	}


	public User getUpdatedBy() {
		return updatedBy;
	}


	public void setUpdatedBy(User updatedBy) {
		this.updatedBy = updatedBy;
	}


	/**
	 * @return the travelDoc
	 */
	public List<String> getTravelDoc() {
		return travelDoc;
	}


	/**
	 * @param travelDoc the travelDoc to set
	 */
	public void setTravelDoc(List<String> travelDoc) {
		this.travelDoc = travelDoc;
	}


	/**
	 * @return the softDeleteDocPaths
	 */
	public List<String> getSoftDeleteDocPaths() {
		return softDeleteDocPaths;
	}


	/**
	 * @param softDeleteDocPaths the softDeleteDocPaths to set
	 */
	public void setSoftDeleteDocPaths(List<String> softDeleteDocPaths) {
		this.softDeleteDocPaths = softDeleteDocPaths;
	}
	
}
