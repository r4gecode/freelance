/**
 * 
 */
package in.ind.mds.dto;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import org.dozer.Mapping;

/**
 * @author mds-arockia
 *
 */
public class ScheduledJobDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1174889946148L;
	
	private String id;
	
	@Mapping("fleet")
	private FleetDto fleet;
	
	@Mapping("vessel")
	private VesselDto vessel;
	
	private String jobCode;
	private String jobName;
	
	@Mapping("jobCategory")
	private JobCategoryDto jobCategory;
	
	private String jobProcedure;
	
	@Mapping("component")
	private ComponentDto component;
	
	@Mapping("role")
	private RoleDto role;
	
	private String criticalJobIndi;
	private int fromFrequency; 
	private int toFrequency;
	private String frequencyType;
	private float totalRH;
	private float avgRunningHour;
	private Date lastDoneDate;
	private Date nextDueDate;
	private Date rescheduledDueDate;
	private float rhAtLastCompletion;
	private float rhFromLastCompletion;
	private int totalNODComponentRun;
	
	@Mapping("status")
	private StatusDto status;
	
	private String syncRequired;
	private Date insertTime;
	
	@Mapping("insertedBy")
	private UserDto insertedBy;
	
	private Date updateTime;
	
	@Mapping("updatedBy")
	private UserDto updatedBy;

	private List<String> scheduledJobAtch;

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the fleet
	 */
	public FleetDto getFleet() {
		return fleet;
	}

	/**
	 * @param fleet the fleet to set
	 */
	public void setFleet(FleetDto fleet) {
		this.fleet = fleet;
	}

	/**
	 * @return the vessel
	 */
	public VesselDto getVessel() {
		return vessel;
	}

	/**
	 * @param vessel the vessel to set
	 */
	public void setVessel(VesselDto vessel) {
		this.vessel = vessel;
	}

	/**
	 * @return the jobCode
	 */
	public String getJobCode() {
		return jobCode;
	}

	/**
	 * @param jobCode the jobCode to set
	 */
	public void setJobCode(String jobCode) {
		this.jobCode = jobCode;
	}

	/**
	 * @return the jobName
	 */
	public String getJobName() {
		return jobName;
	}

	/**
	 * @param jobName the jobName to set
	 */
	public void setJobName(String jobName) {
		this.jobName = jobName;
	}

	/**
	 * @return the jobCategory
	 */
	public JobCategoryDto getJobCategory() {
		return jobCategory;
	}

	/**
	 * @param jobCategory the jobCategory to set
	 */
	public void setJobCategory(JobCategoryDto jobCategory) {
		this.jobCategory = jobCategory;
	}

	/**
	 * @return the jobProcedure
	 */
	public String getJobProcedure() {
		return jobProcedure;
	}

	/**
	 * @param jobProcedure the jobProcedure to set
	 */
	public void setJobProcedure(String jobProcedure) {
		this.jobProcedure = jobProcedure;
	}

	/**
	 * @return the component
	 */
	public ComponentDto getComponent() {
		return component;
	}

	/**
	 * @param component the component to set
	 */
	public void setComponent(ComponentDto component) {
		this.component = component;
	}

	/**
	 * @return the role
	 */
	public RoleDto getRole() {
		return role;
	}

	/**
	 * @param role the role to set
	 */
	public void setRole(RoleDto role) {
		this.role = role;
	}

	/**
	 * @return the criticalJobIndi
	 */
	public String getCriticalJobIndi() {
		return criticalJobIndi;
	}

	/**
	 * @param criticalJobIndi the criticalJobIndi to set
	 */
	public void setCriticalJobIndi(String criticalJobIndi) {
		this.criticalJobIndi = criticalJobIndi;
	}

	/**
	 * @return the fromFrequency
	 */
	public int getFromFrequency() {
		return fromFrequency;
	}

	/**
	 * @param fromFrequency the fromFrequency to set
	 */
	public void setFromFrequency(int fromFrequency) {
		this.fromFrequency = fromFrequency;
	}

	/**
	 * @return the toFrequency
	 */
	public int getToFrequency() {
		return toFrequency;
	}

	/**
	 * @param toFrequency the toFrequency to set
	 */
	public void setToFrequency(int toFrequency) {
		this.toFrequency = toFrequency;
	}

	/**
	 * @return the frequencyType
	 */
	public String getFrequencyType() {
		return frequencyType;
	}

	/**
	 * @param frequencyType the frequencyType to set
	 */
	public void setFrequencyType(String frequencyType) {
		this.frequencyType = frequencyType;
	}

	/**
	 * @return the totalRH
	 */
	public float getTotalRH() {
		return totalRH;
	}

	/**
	 * @param totalRH the totalRH to set
	 */
	public void setTotalRH(float totalRH) {
		this.totalRH = totalRH;
	}

	/**
	 * @return the avgRunningHour
	 */
	public float getAvgRunningHour() {
		return avgRunningHour;
	}

	/**
	 * @param avgRunningHour the avgRunningHour to set
	 */
	public void setAvgRunningHour(float avgRunningHour) {
		this.avgRunningHour = avgRunningHour;
	}

	/**
	 * @return the lastDoneDate
	 */
	public Date getLastDoneDate() {
		return lastDoneDate;
	}

	/**
	 * @param lastDoneDate the lastDoneDate to set
	 */
	public void setLastDoneDate(Date lastDoneDate) {
		this.lastDoneDate = lastDoneDate;
	}

	/**
	 * @return the nextDueDate
	 */
	public Date getNextDueDate() {
		return nextDueDate;
	}

	/**
	 * @param nextDueDate the nextDueDate to set
	 */
	public void setNextDueDate(Date nextDueDate) {
		this.nextDueDate = nextDueDate;
	}

	/**
	 * @return the rescheduledDueDate
	 */
	public Date getRescheduledDueDate() {
		return rescheduledDueDate;
	}

	/**
	 * @param rescheduledDueDate the rescheduledDueDate to set
	 */
	public void setRescheduledDueDate(Date rescheduledDueDate) {
		this.rescheduledDueDate = rescheduledDueDate;
	}

	/**
	 * @return the rhAtLastCompletion
	 */
	public float getRhAtLastCompletion() {
		return rhAtLastCompletion;
	}

	/**
	 * @param rhAtLastCompletion the rhAtLastCompletion to set
	 */
	public void setRhAtLastCompletion(float rhAtLastCompletion) {
		this.rhAtLastCompletion = rhAtLastCompletion;
	}

	/**
	 * @return the rhFromLastCompletion
	 */
	public float getRhFromLastCompletion() {
		return rhFromLastCompletion;
	}

	/**
	 * @param rhFromLastCompletion the rhFromLastCompletion to set
	 */
	public void setRhFromLastCompletion(float rhFromLastCompletion) {
		this.rhFromLastCompletion = rhFromLastCompletion;
	}

	/**
	 * @return the totalNODComponentRun
	 */
	public int getTotalNODComponentRun() {
		return totalNODComponentRun;
	}

	/**
	 * @param totalNODComponentRun the totalNODComponentRun to set
	 */
	public void setTotalNODComponentRun(int totalNODComponentRun) {
		this.totalNODComponentRun = totalNODComponentRun;
	}

	/**
	 * @return the status
	 */
	public StatusDto getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(StatusDto status) {
		this.status = status;
	}

	/**
	 * @return the syncRequired
	 */
	public String getSyncRequired() {
		return syncRequired;
	}

	/**
	 * @param syncRequired the syncRequired to set
	 */
	public void setSyncRequired(String syncRequired) {
		this.syncRequired = syncRequired;
	}

	/**
	 * @return the insertTime
	 */
	public Date getInsertTime() {
		return insertTime;
	}

	/**
	 * @param insertTime the insertTime to set
	 */
	public void setInsertTime(Date insertTime) {
		this.insertTime = insertTime;
	}

	/**
	 * @return the insertedBy
	 */
	public UserDto getInsertedBy() {
		return insertedBy;
	}

	/**
	 * @param insertedBy the insertedBy to set
	 */
	public void setInsertedBy(UserDto insertedBy) {
		this.insertedBy = insertedBy;
	}

	/**
	 * @return the updateTime
	 */
	public Date getUpdateTime() {
		return updateTime;
	}

	/**
	 * @param updateTime the updateTime to set
	 */
	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	/**
	 * @return the updatedBy
	 */
	public UserDto getUpdatedBy() {
		return updatedBy;
	}

	/**
	 * @param updatedBy the updatedBy to set
	 */
	public void setUpdatedBy(UserDto updatedBy) {
		this.updatedBy = updatedBy;
	}

	/**
	 * @return the scheduledJobAtch
	 */
	public List<String> getScheduledJobAtch() {
		return scheduledJobAtch;
	}

	/**
	 * @param scheduledJobAtch the scheduledJobAtch to set
	 */
	public void setScheduledJobAtch(List<String> scheduledJobAtch) {
		this.scheduledJobAtch = scheduledJobAtch;
	}
	
	public String getScheduledJobAtchFieldName() {	
		return "ScheduledJobAttach";
	}
}