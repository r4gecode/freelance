package in.ind.mds.dto;

import java.io.Serializable;

public class AuthenticationDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5019710742492951139L;

	private String userName;
	private String loginID;
	private String userShortName;
	private int userTitle;
	private String userRole;
	private String userRoleID;
	private String userType;
	private String authToken;

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getLoginID() {
		return loginID;
	}

	public void setLoginID(String loginID) {
		this.loginID = loginID;
	}

	public String getUserShortName() {
		return userShortName;
	}

	public void setUserShortName(String userShortName) {
		this.userShortName = userShortName;
	}

	public int getUserTitle() {
		return userTitle;
	}

	public void setUserTitle(int userTitle) {
		this.userTitle = userTitle;
	}

	public String getUserRoleID() {
		return userRoleID;
	}

	public void setUserRoleID(String userRoleID) {
		this.userRoleID = userRoleID;
	}

	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}

	public String getAuthToken() {
		return authToken;
	}

	public void setAuthToken(String authToken) {
		this.authToken = authToken;
	}

	public String getUserRole() {
		return userRole;
	}

	public void setUserRole(String userRole) {
		this.userRole = userRole;
	}

}
