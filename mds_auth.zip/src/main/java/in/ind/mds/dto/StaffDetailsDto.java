/**
 * 
 */
package in.ind.mds.dto;

import java.io.Serializable;
import java.util.List;

/**
 * @author mds-arockia
 *
 */
public class StaffDetailsDto implements Serializable {

	private static final long serialVersionUID = 11548736824248L;

	private StaffDto staff;

	private List<BankAccountDto> bankAccountDtoList;
	
	private List<CrewContractDto> contractDtoList;
	
	private List<CrewActivityDto> activityDtoList;
	
	private List<CrewMedicalReportDto> medicalReportList;
	
	private List<CrewTrainingDto> trainingList;
	
	private List<CrewWorkExpDto> workExpList;
	
	private List<CrewCertificateDto> certificateDtoList;
	
	private List<TravelDocumentDto> travelDocumentDtoList;
	
	private List<String> bankAccountIds;
	
	private List<String> contractIds;
	
	private List<String> activityIds;
	
	private List<String> medicalReportIds;
	
	private List<String> trainingIds;
	
	private List<String> workExpIds;
	
	private List<String> certificateIds;
	
	private List<String> travelDocumentIds;
	
	/**
	 * @return the staff
	 */
	public StaffDto getStaff() {
		return staff;
	}

	/**
	 * @param staff
	 *            the staff to set
	 */
	public void setStaff(StaffDto staff) {
		this.staff = staff;
	}

	/**
	 * @return the bankAccountDtoList
	 */
	public List<BankAccountDto> getBankAccountDtoList() {
		return bankAccountDtoList;
	}

	/**
	 * @param bankAccountDtoList
	 *            the bankAccountDtoList to set
	 */
	public void setBankAccountDtoList(List<BankAccountDto> bankAccountDtoList) {
		this.bankAccountDtoList = bankAccountDtoList;
	}

	/**
	 * @return the contractDtoList
	 */
	public List<CrewContractDto> getContractDtoList() {
		return contractDtoList;
	}

	/**
	 * @param contractDtoList the contractDtoList to set
	 */
	public void setContractDtoList(List<CrewContractDto> contractDtoList) {
		this.contractDtoList = contractDtoList;
	}

	/**
	 * @return the activityDtoList
	 */
	public List<CrewActivityDto> getActivityDtoList() {
		return activityDtoList;
	}

	/**
	 * @param activityDtoList the activityDtoList to set
	 */
	public void setActivityDtoList(List<CrewActivityDto> crewActivityDtoList) {
		this.activityDtoList = crewActivityDtoList;
	}

	/**
	 * @return the medicalReportList
	 */
	public List<CrewMedicalReportDto> getMedicalReportList() {
		return medicalReportList;
	}

	/**
	 * @param medicalReportList the medicalReportList to set
	 */
	public void setMedicalReportList(List<CrewMedicalReportDto> medReportDtoList) {
		this.medicalReportList = medReportDtoList;
	}

	/**
	 * @return the trainingList
	 */
	public List<CrewTrainingDto> getTrainingList() {
		return trainingList;
	}

	/**
	 * @param trainingList the trainingList to set
	 */
	public void setTrainingList(List<CrewTrainingDto> trainingList) {
		this.trainingList = trainingList;
	}

	/**
	 * @return the workExpList
	 */
	public List<CrewWorkExpDto> getWorkExpList() {
		return workExpList;
	}

	/**
	 * @param workExpList the workExpList to set
	 */
	public void setWorkExpList(List<CrewWorkExpDto> workExpList) {
		this.workExpList = workExpList;
	}

	/**
	 * @return the certificateDtoList
	 */
	public List<CrewCertificateDto> getCertificateDtoList() {
		return certificateDtoList;
	}

	/**
	 * @param certificateDtoList the certificateDtoList to set
	 */
	public void setCertificateDtoList(List<CrewCertificateDto> certificateDtoList) {
		this.certificateDtoList = certificateDtoList;
	}

	/**
	 * @return the travelDocumentDtoList
	 */
	public List<TravelDocumentDto> getTravelDocumentDtoList() {
		return travelDocumentDtoList;
	}

	/**
	 * @param travelDocumentDtoList the travelDocumentDtoList to set
	 */
	public void setTravelDocumentDtoList(List<TravelDocumentDto> travelDocumentDtoList) {
		this.travelDocumentDtoList = travelDocumentDtoList;
	}

	/**
	 * @return the bankAccountIds
	 */
	public List<String> getBankAccountIds() {
		return bankAccountIds;
	}

	/**
	 * @param bankAccountIds the bankAccountIds to set
	 */
	public void setBankAccountIds(List<String> bankAccountIds) {
		this.bankAccountIds = bankAccountIds;
	}

	/**
	 * @return the contractIds
	 */
	public List<String> getContractIds() {
		return contractIds;
	}

	/**
	 * @param contractIds the contractIds to set
	 */
	public void setContractIds(List<String> contractIds) {
		this.contractIds = contractIds;
	}

	/**
	 * @return the activityIds
	 */
	public List<String> getActivityIds() {
		return activityIds;
	}

	/**
	 * @param activityIds the activityIds to set
	 */
	public void setActivityIds(List<String> activityIds) {
		this.activityIds = activityIds;
	}

	/**
	 * @return the medicalReportIds
	 */
	public List<String> getMedicalReportIds() {
		return medicalReportIds;
	}

	/**
	 * @param medicalReportIds the medicalReportIds to set
	 */
	public void setMedicalReportIds(List<String> medicalReportIds) {
		this.medicalReportIds = medicalReportIds;
	}

	/**
	 * @return the trainingIds
	 */
	public List<String> getTrainingIds() {
		return trainingIds;
	}

	/**
	 * @param trainingIds the trainingIds to set
	 */
	public void setTrainingIds(List<String> trainingIds) {
		this.trainingIds = trainingIds;
	}

	/**
	 * @return the workExpIds
	 */
	public List<String> getWorkExpIds() {
		return workExpIds;
	}

	/**
	 * @param workExpIds the workExpIds to set
	 */
	public void setWorkExpIds(List<String> workExpIds) {
		this.workExpIds = workExpIds;
	}

	/**
	 * @return the certificateIds
	 */
	public List<String> getCertificateIds() {
		return certificateIds;
	}

	/**
	 * @param certificateIds the certificateIds to set
	 */
	public void setCertificateIds(List<String> certificateIds) {
		this.certificateIds = certificateIds;
	}

	/**
	 * @return the travelDocumentIds
	 */
	public List<String> getTravelDocumentIds() {
		return travelDocumentIds;
	}

	/**
	 * @param travelDocumentIds the travelDocumentIds to set
	 */
	public void setTravelDocumentIds(List<String> travelDocumentIds) {
		this.travelDocumentIds = travelDocumentIds;
	}
	
}
