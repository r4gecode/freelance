/**
 * 
 */
package in.ind.mds.dto;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import org.dozer.Mapping;

/**
 * @author shalini
 *
 */
public class CrewMedicalReportDto implements Serializable{
	
	private static final long serialVersionUID = 1174776158193L;
	
	private String id;
	private Date reportDate;
	private Date validUpto;
	private String remarks;
	private Date insertTime;
	private Date updateTime;
	private String syncRequired;
	
	@Mapping("staff")
	private StaffDto staff;
	
	private List<String> medicalReportDoc;
	
	List<String> softDeleteDocPaths;
	
	@Mapping("crewMedReportType")
	private CrewMedReportTypeDto crewMedReportType;
	
	@Mapping("status")
	private StatusDto status;
	
	@Mapping("insertedBy")
	private UserDto insertedBy;
	
	@Mapping("updatedBy")
	private UserDto updatedBy;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Date getReportDate() {
		return reportDate;
	}

	public void setReportDate(Date reportDate) {
		this.reportDate = reportDate;
	}

	public Date getValidUpto() {
		return validUpto;
	}

	public void setValidUpto(Date validUpto) {
		this.validUpto = validUpto;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public Date getInsertTime() {
		return insertTime;
	}

	public void setInsertTime(Date insertTime) {
		this.insertTime = insertTime;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public String getSyncRequired() {
		return syncRequired;
	}

	public void setSyncRequired(String syncRequired) {
		this.syncRequired = syncRequired;
	}

	/**
	 * @return the staff
	 */
	public StaffDto getStaff() {
		return staff;
	}

	/**
	 * @param staff the staff to set
	 */
	public void setStaff(StaffDto staff) {
		this.staff = staff;
	}

	/**
	 * @return the medicalReportDoc
	 */
	public List<String> getMedicalReportDoc() {
		return medicalReportDoc;
	}

	/**
	 * @param medicalReportDoc the medicalReportDoc to set
	 */
	public void setMedicalReportDoc(List<String> medicalReportDoc) {
		this.medicalReportDoc = medicalReportDoc;
	}

	public String getMedicalReportDocFieldName() {
		return "MedicalReportDoc";
	}

	public CrewMedReportTypeDto getCrewMedReportType() {
		return crewMedReportType;
	}

	public void setCrewMedReportType(CrewMedReportTypeDto crewMedReportType) {
		this.crewMedReportType = crewMedReportType;
	}

	public StatusDto getStatus() {
		return status;
	}

	public void setStatus(StatusDto status) {
		this.status = status;
	}

	public UserDto getInsertedBy() {
		return insertedBy;
	}

	public void setInsertedBy(UserDto insertedBy) {
		this.insertedBy = insertedBy;
	}

	public UserDto getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(UserDto updatedBy) {
		this.updatedBy = updatedBy;
	}

	/**
	 * @return the softDeleteDocPaths
	 */
	public List<String> getSoftDeleteDocPaths() {
		return softDeleteDocPaths;
	}

	/**
	 * @param softDeleteDocPaths the softDeleteDocPaths to set
	 */
	public void setSoftDeleteDocPaths(List<String> softDeleteDocPaths) {
		this.softDeleteDocPaths = softDeleteDocPaths;
	}

}
