/**
 * 
 */
package in.ind.mds.dto;

import java.io.Serializable;
import java.util.Date;

import org.dozer.Mapping;

/**
 * @author mds_kiruthika
 *
 */
public class AttachmentDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 115680904768583664L;
	
	private String id;
	private String recordId;
	private String attachmentOrigin;
	private String attachmentType;
	private String attachmentPath;
	private String syncRequired;
	private Date insertTime;
	private Date updateTime;
	
	@Mapping("insertedBy")
	private UserDto insertedBy;
	
	@Mapping("updatedBy")
	private UserDto updatedBy;
	
	@Mapping("status")
	private StatusDto status;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the recordId
	 */
	public String getRecordId() {
		return recordId;
	}

	/**
	 * @param recordId the recordId to set
	 */
	public void setRecordId(String recordId) {
		this.recordId = recordId;
	}

	/**
	 * @return the attachmentOrigin
	 */
	public String getAttachmentOrigin() {
		return attachmentOrigin;
	}

	/**
	 * @param attachmentOrigin the attachmentOrigin to set
	 */
	public void setAttachmentOrigin(String attachmentOrigin) {
		this.attachmentOrigin = attachmentOrigin;
	}

	public String getAttachmentType() {
		return attachmentType;
	}

	public void setAttachmentType(String attachmentType) {
		this.attachmentType = attachmentType;
	}

	public String getAttachmentPath() {
		return attachmentPath;
	}

	public void setAttachmentPath(String attachmentPath) {
		this.attachmentPath = attachmentPath;
	}

	public String getSyncRequired() {
		return syncRequired;
	}

	public void setSyncRequired(String syncRequired) {
		this.syncRequired = syncRequired;
	}

	public Date getInsertTime() {
		return insertTime;
	}

	public void setInsertTime(Date insertTime) {
		this.insertTime = insertTime;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	/**
	 * @return the insertedBy
	 */
	public UserDto getInsertedBy() {
		return insertedBy;
	}

	/**
	 * @param insertedBy the insertedBy to set
	 */
	public void setInsertedBy(UserDto insertedBy) {
		this.insertedBy = insertedBy;
	}

	/**
	 * @return the updatedBy
	 */
	public UserDto getUpdatedBy() {
		return updatedBy;
	}

	/**
	 * @param updatedBy the updatedBy to set
	 */
	public void setUpdatedBy(UserDto updatedBy) {
		this.updatedBy = updatedBy;
	}

	/**
	 * @return the status
	 */
	public StatusDto getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(StatusDto status) {
		this.status = status;
	}


}
