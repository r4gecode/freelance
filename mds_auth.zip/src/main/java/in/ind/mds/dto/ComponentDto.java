package in.ind.mds.dto;

import java.io.Serializable;
import java.util.Date;

import org.dozer.Mapping;

public class ComponentDto implements Serializable {

	/**
	 * 
	 */
	
	private static final long serialVersionUID = -1213146618194407332L;
	
	private String id;
	
	@Mapping("vessel")
	private VesselDto vessel;
	
	private String componentName;
	private String code;
	private String componentType;
	private String make;
	private String sfiCode;
	private String capacity;
	
	private int initialRunningHours;
	private String remarks;
	private int mfgYear;
	private String mfgContact;
	private int drawNumber;
	private int classCompCode;
	private String maker;
	private String criticalIndi;
	private String modelNumber;
	private String serialNumber;
	
	@Mapping("component")
	private ComponentDto component;
	
	private String classComponent;
	private String oilConsumption;
	private String attachment;
	
	@Mapping("componentMain")
	private ComponentMainDto componentMain;
	
	@Mapping("inventory")
	private InventoryDto inventory;
	
	/************running hours*******************/
	private String rHRequired;
	private float runningHours;
	private float totalRH;
	private float avgRH;
	private Date lastRHEntryDate;
	private String comments;
	private int totalNODComponentRun;
	private String cRRequired;
	private Date cRStartDate;

	
	private Date insertTime;
	private int insertedBy;
	private Date updateTime;
	private int updatedBy;
	private String syncRequired;
	
	@Mapping("status")
	private StatusDto status;

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the vessel
	 */
	public VesselDto getVessel() {
		return vessel;
	}

	/**
	 * @param vessel the vessel to set
	 */
	public void setVessel(VesselDto vessel) {
		this.vessel = vessel;
	}

	/**
	 * @return the componentName
	 */
	public String getComponentName() {
		return componentName;
	}

	/**
	 * @param componentName the componentName to set
	 */
	public void setComponentName(String componentName) {
		this.componentName = componentName;
	}

	/**
	 * @return the code
	 */
	public String getCode() {
		return code;
	}

	/**
	 * @param code the code to set
	 */
	public void setCode(String code) {
		this.code = code;
	}

	/**
	 * @return the componentType
	 */
	public String getComponentType() {
		return componentType;
	}

	/**
	 * @param componentType the componentType to set
	 */
	public void setComponentType(String componentType) {
		this.componentType = componentType;
	}

	/**
	 * @return the make
	 */
	public String getMake() {
		return make;
	}

	/**
	 * @param make the make to set
	 */
	public void setMake(String make) {
		this.make = make;
	}

	/**
	 * @return the sfiCode
	 */
	public String getSfiCode() {
		return sfiCode;
	}

	/**
	 * @param sfiCode the sfiCode to set
	 */
	public void setSfiCode(String sfiCode) {
		this.sfiCode = sfiCode;
	}

	/**
	 * @return the capacity
	 */
	public String getCapacity() {
		return capacity;
	}

	/**
	 * @param capacity the capacity to set
	 */
	public void setCapacity(String capacity) {
		this.capacity = capacity;
	}

	/**
	 * @return the initialRunningHours
	 */
	public int getInitialRunningHours() {
		return initialRunningHours;
	}

	/**
	 * @param initialRunningHours the initialRunningHours to set
	 */
	public void setInitialRunningHours(int initialRunningHours) {
		this.initialRunningHours = initialRunningHours;
	}

	/**
	 * @return the remarks
	 */
	public String getRemarks() {
		return remarks;
	}

	/**
	 * @param remarks the remarks to set
	 */
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	/**
	 * @return the mfgYear
	 */
	public int getMfgYear() {
		return mfgYear;
	}

	/**
	 * @param mfgYear the mfgYear to set
	 */
	public void setMfgYear(int mfgYear) {
		this.mfgYear = mfgYear;
	}

	/**
	 * @return the mfgContact
	 */
	public String getMfgContact() {
		return mfgContact;
	}

	/**
	 * @param mfgContact the mfgContact to set
	 */
	public void setMfgContact(String mfgContact) {
		this.mfgContact = mfgContact;
	}

	/**
	 * @return the drawNumber
	 */
	public int getDrawNumber() {
		return drawNumber;
	}

	/**
	 * @param drawNumber the drawNumber to set
	 */
	public void setDrawNumber(int drawNumber) {
		this.drawNumber = drawNumber;
	}

	/**
	 * @return the classCompCode
	 */
	public int getClassCompCode() {
		return classCompCode;
	}

	/**
	 * @param classCompCode the classCompCode to set
	 */
	public void setClassCompCode(int classCompCode) {
		this.classCompCode = classCompCode;
	}

	/**
	 * @return the maker
	 */
	public String getMaker() {
		return maker;
	}

	/**
	 * @param maker the maker to set
	 */
	public void setMaker(String maker) {
		this.maker = maker;
	}

	/**
	 * @return the criticalIndi
	 */
	public String getCriticalIndi() {
		return criticalIndi;
	}

	/**
	 * @param criticalIndi the criticalIndi to set
	 */
	public void setCriticalIndi(String criticalIndi) {
		this.criticalIndi = criticalIndi;
	}

	/**
	 * @return the modelNumber
	 */
	public String getModelNumber() {
		return modelNumber;
	}

	/**
	 * @param modelNumber the modelNumber to set
	 */
	public void setModelNumber(String modelNumber) {
		this.modelNumber = modelNumber;
	}

	/**
	 * @return the serialNumber
	 */
	public String getSerialNumber() {
		return serialNumber;
	}

	/**
	 * @param serialNumber the serialNumber to set
	 */
	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}

	/**
	 * @return the component
	 */
	public ComponentDto getComponent() {
		return component;
	}

	/**
	 * @param component the component to set
	 */
	public void setComponent(ComponentDto component) {
		this.component = component;
	}

	/**
	 * @return the classComponent
	 */
	public String getClassComponent() {
		return classComponent;
	}

	/**
	 * @param classComponent the classComponent to set
	 */
	public void setClassComponent(String classComponent) {
		this.classComponent = classComponent;
	}

	/**
	 * @return the oilConsumption
	 */
	public String getOilConsumption() {
		return oilConsumption;
	}

	/**
	 * @param oilConsumption the oilConsumption to set
	 */
	public void setOilConsumption(String oilConsumption) {
		this.oilConsumption = oilConsumption;
	}

	/**
	 * @return the attachment
	 */
	public String getAttachment() {
		return attachment;
	}

	/**
	 * @param attachment the attachment to set
	 */
	public void setAttachment(String attachment) {
		this.attachment = attachment;
	}

	/**
	 * @return the componentMain
	 */
	public ComponentMainDto getComponentMain() {
		return componentMain;
	}

	/**
	 * @param componentMain the componentMain to set
	 */
	public void setComponentMain(ComponentMainDto componentMain) {
		this.componentMain = componentMain;
	}

	/**
	 * @return the inventory
	 */
	public InventoryDto getInventory() {
		return inventory;
	}

	/**
	 * @param inventory the inventory to set
	 */
	public void setInventory(InventoryDto inventory) {
		this.inventory = inventory;
	}

	/**
	 * @return the rHRequired
	 */
	public String getrHRequired() {
		return rHRequired;
	}

	/**
	 * @param rHRequired the rHRequired to set
	 */
	public void setrHRequired(String rHRequired) {
		this.rHRequired = rHRequired;
	}

	/**
	 * @return the runningHours
	 */
	public float getRunningHours() {
		return runningHours;
	}

	/**
	 * @param runningHours the runningHours to set
	 */
	public void setRunningHours(float runningHours) {
		this.runningHours = runningHours;
	}

	/**
	 * @return the totalRH
	 */
	public float getTotalRH() {
		return totalRH;
	}

	/**
	 * @param totalRH the totalRH to set
	 */
	public void setTotalRH(float totalRH) {
		this.totalRH = totalRH;
	}

	/**
	 * @return the avgRH
	 */
	public float getAvgRH() {
		return avgRH;
	}

	/**
	 * @param avgRH the avgRH to set
	 */
	public void setAvgRH(float avgRH) {
		this.avgRH = avgRH;
	}

	/**
	 * @return the lastRHEntryDate
	 */
	public Date getLastRHEntryDate() {
		return lastRHEntryDate;
	}

	/**
	 * @param lastRHEntryDate the lastRHEntryDate to set
	 */
	public void setLastRHEntryDate(Date lastRHEntryDate) {
		this.lastRHEntryDate = lastRHEntryDate;
	}

	/**
	 * @return the comments
	 */
	public String getComments() {
		return comments;
	}

	/**
	 * @param comments the comments to set
	 */
	public void setComments(String comments) {
		this.comments = comments;
	}

	/**
	 * @return the totalNODComponentRun
	 */
	public int getTotalNODComponentRun() {
		return totalNODComponentRun;
	}

	/**
	 * @param totalNODComponentRun the totalNODComponentRun to set
	 */
	public void setTotalNODComponentRun(int totalNODComponentRun) {
		this.totalNODComponentRun = totalNODComponentRun;
	}

	/**
	 * @return the cRRequired
	 */
	public String getcRRequired() {
		return cRRequired;
	}

	/**
	 * @param cRRequired the cRRequired to set
	 */
	public void setcRRequired(String cRRequired) {
		this.cRRequired = cRRequired;
	}

	/**
	 * @return the cRStartDate
	 */
	public Date getcRStartDate() {
		return cRStartDate;
	}

	/**
	 * @param cRStartDate the cRStartDate to set
	 */
	public void setcRStartDate(Date cRStartDate) {
		this.cRStartDate = cRStartDate;
	}

	/**
	 * @return the insertTime
	 */
	public Date getInsertTime() {
		return insertTime;
	}

	/**
	 * @param insertTime the insertTime to set
	 */
	public void setInsertTime(Date insertTime) {
		this.insertTime = insertTime;
	}

	/**
	 * @return the insertedBy
	 */
	public int getInsertedBy() {
		return insertedBy;
	}

	/**
	 * @param insertedBy the insertedBy to set
	 */
	public void setInsertedBy(int insertedBy) {
		this.insertedBy = insertedBy;
	}

	/**
	 * @return the updateTime
	 */
	public Date getUpdateTime() {
		return updateTime;
	}

	/**
	 * @param updateTime the updateTime to set
	 */
	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	/**
	 * @return the updatedBy
	 */
	public int getUpdatedBy() {
		return updatedBy;
	}

	/**
	 * @param updatedBy the updatedBy to set
	 */
	public void setUpdatedBy(int updatedBy) {
		this.updatedBy = updatedBy;
	}

	/**
	 * @return the syncRequired
	 */
	public String getSyncRequired() {
		return syncRequired;
	}

	/**
	 * @param syncRequired the syncRequired to set
	 */
	public void setSyncRequired(String syncRequired) {
		this.syncRequired = syncRequired;
	}

	/**
	 * @return the status
	 */
	public StatusDto getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(StatusDto status) {
		this.status = status;
	}

}