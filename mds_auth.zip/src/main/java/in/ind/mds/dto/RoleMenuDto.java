package in.ind.mds.dto;

import java.io.Serializable;
import java.util.Date;

import org.dozer.Mapping;

public class RoleMenuDto implements Serializable {

	/**
	 * 
	 */
	
	private static final long serialVersionUID = -6819281974661612906L;
	private String id;
	private String roleMenu;
	/*private String menuId;*/
	private Date insertTime;
	private int insertedBy;
	private Date updateTime;
	private int updatedBy;
	private String syncRequired;
	
	@Mapping("role")
	private RoleDto role;
	
	@Mapping("menu")
	private MenuDto menu;
	
	private String addAccess;
	private String updAccess;
	private String delAccess;
	private String viewAccess;
	private String emailAccess;
	
	@Mapping("status")
	private StatusDto status;
	
	public RoleDto getRole() {
		return role;
	}
	public void setRole(RoleDto role) {
		this.role = role;
	}
	public MenuDto getMenu() {
		return menu;
	}
	public void setMenu(MenuDto menu) {
		this.menu = menu;
	}
	public String getAddAccess() {
		return addAccess;
	}
	public void setAddAccess(String addAccess) {
		this.addAccess = addAccess;
	}
	public String getUpdAccess() {
		return updAccess;
	}
	public void setUpdAccess(String updAccess) {
		this.updAccess = updAccess;
	}
	public String getDelAccess() {
		return delAccess;
	}
	public void setDelAccess(String delAccess) {
		this.delAccess = delAccess;
	}
	public String getViewAccess() {
		return viewAccess;
	}
	public void setViewAccess(String viewAccess) {
		this.viewAccess = viewAccess;
	}
	public String getEmailAccess() {
		return emailAccess;
	}
	public void setEmailAccess(String emailAccess) {
		this.emailAccess = emailAccess;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getRoleMenu() {
		return roleMenu;
	}
	public void setRoleMenu(String roleMenu) {
		this.roleMenu = roleMenu;
	}
	/*public String getMenuId() {
		return menuId;
	}
	public void setMenuId(String menuId) {
		this.menuId = menuId;
	}*/
	public Date getInsertTime() {
		return insertTime;
	}
	public void setInsertTime(Date insertTime) {
		this.insertTime = insertTime;
	}
	public int getInsertedBy() {
		return insertedBy;
	}
	public void setInsertedBy(int insertedBy) {
		this.insertedBy = insertedBy;
	}
	public Date getUpdateTime() {
		return updateTime;
	}
	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}
	public int getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(int updatedBy) {
		this.updatedBy = updatedBy;
	}
	public String getSyncRequired() {
		return syncRequired;
	}
	public void setSyncRequired(String syncRequired) {
		this.syncRequired = syncRequired;
	}
	/**
	 * @return the status
	 */
	public StatusDto getStatus() {
		return status;
	}
	/**
	 * @param status the status to set
	 */
	public void setStatus(StatusDto status) {
		this.status = status;
	}
	
	
	/*@Mapping("menu")
	private MenuDto menuDto;
	*/
	
	
	
}
	