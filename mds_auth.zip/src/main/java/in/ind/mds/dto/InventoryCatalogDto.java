/**
 * 
 */
package in.ind.mds.dto;

import java.io.Serializable;
import java.util.Date;

import org.dozer.Mapping;

/**
 * @author mds-arockia
 *
 */
public class InventoryCatalogDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 117488936248L;

	private String id;
	
	@Mapping("inventoryCtgy")
	private InventoryMainDto inventoryCtgy;
	
	@Mapping("componentGroup")
	private ComponentMainDto componentGroup;
	
	@Mapping("fleet")
	private FleetDto fleet;
	
	@Mapping("vessel")
	private VesselDto vessel;
	
	@Mapping("component")
	private ComponentDto component;
	
	private String inventoryName;
	private String inventoryCode;
	
	@Mapping("uom")
	private UomDto uom;
	
	private String make;
	private String partNumber;
	private String drawNumber;
	private String modelNumber;
	private String positionNumber;
	private String serialNumber;
	
	@Mapping("locOnboard")
	private LocOnboardDto locOnboard;
	
	private String criticalIndi;
	private Date expiryDate;
	private String remarks;
	private String attachement; 
	private Float reOrderLevel;
	private Float reOrderQty;
	private Float maxQty;
	private Date insertTime;
	private Integer insertedBy;
	private Date updateTime;
	private Integer updatedBy;
	
	@Mapping("status")
	private StatusDto status;
	
	private String syncRequired;

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the inventoryCtgy
	 */
	public InventoryMainDto getInventoryCtgy() {
		return inventoryCtgy;
	}

	/**
	 * @param inventoryCtgy the inventoryCtgy to set
	 */
	public void setInventoryCtgy(InventoryMainDto inventoryCtgy) {
		this.inventoryCtgy = inventoryCtgy;
	}

	/**
	 * @return the componentGroup
	 */
	public ComponentMainDto getComponentGroup() {
		return componentGroup;
	}

	/**
	 * @param componentGroup the componentGroup to set
	 */
	public void setComponentGroup(ComponentMainDto componentGroup) {
		this.componentGroup = componentGroup;
	}

	/**
	 * @return the fleet
	 */
	public FleetDto getFleet() {
		return fleet;
	}

	/**
	 * @param fleet the fleet to set
	 */
	public void setFleet(FleetDto fleet) {
		this.fleet = fleet;
	}

	/**
	 * @return the vessel
	 */
	public VesselDto getVessel() {
		return vessel;
	}

	/**
	 * @param vessel the vessel to set
	 */
	public void setVessel(VesselDto vessel) {
		this.vessel = vessel;
	}

	/**
	 * @return the component
	 */
	public ComponentDto getComponent() {
		return component;
	}

	/**
	 * @param component the component to set
	 */
	public void setComponent(ComponentDto component) {
		this.component = component;
	}

	/**
	 * @return the inventoryName
	 */
	public String getInventoryName() {
		return inventoryName;
	}

	/**
	 * @param inventoryName the inventoryName to set
	 */
	public void setInventoryName(String inventoryName) {
		this.inventoryName = inventoryName;
	}

	/**
	 * @return the inventoryCode
	 */
	public String getInventoryCode() {
		return inventoryCode;
	}

	/**
	 * @param inventoryCode the inventoryCode to set
	 */
	public void setInventoryCode(String inventoryCode) {
		this.inventoryCode = inventoryCode;
	}

	/**
	 * @return the uom
	 */
	public UomDto getUom() {
		return uom;
	}

	/**
	 * @param uom the uom to set
	 */
	public void setUom(UomDto uom) {
		this.uom = uom;
	}

	/**
	 * @return the make
	 */
	public String getMake() {
		return make;
	}

	/**
	 * @param make the make to set
	 */
	public void setMake(String make) {
		this.make = make;
	}

	/**
	 * @return the partNumber
	 */
	public String getPartNumber() {
		return partNumber;
	}

	/**
	 * @param partNumber the partNumber to set
	 */
	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}

	/**
	 * @return the drawNumber
	 */
	public String getDrawNumber() {
		return drawNumber;
	}

	/**
	 * @param drawNumber the drawNumber to set
	 */
	public void setDrawNumber(String drawNumber) {
		this.drawNumber = drawNumber;
	}

	/**
	 * @return the modelNumber
	 */
	public String getModelNumber() {
		return modelNumber;
	}

	/**
	 * @param modelNumber the modelNumber to set
	 */
	public void setModelNumber(String modelNumber) {
		this.modelNumber = modelNumber;
	}

	/**
	 * @return the positionNumber
	 */
	public String getPositionNumber() {
		return positionNumber;
	}

	/**
	 * @param positionNumber the positionNumber to set
	 */
	public void setPositionNumber(String positionNumber) {
		this.positionNumber = positionNumber;
	}

	/**
	 * @return the serialNumber
	 */
	public String getSerialNumber() {
		return serialNumber;
	}

	/**
	 * @param serialNumber the serialNumber to set
	 */
	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}

	/**
	 * @return the locOnboard
	 */
	public LocOnboardDto getLocOnboard() {
		return locOnboard;
	}

	/**
	 * @param locOnboard the locOnboard to set
	 */
	public void setLocOnboard(LocOnboardDto locOnboard) {
		this.locOnboard = locOnboard;
	}

	/**
	 * @return the criticalIndi
	 */
	public String getCriticalIndi() {
		return criticalIndi;
	}

	/**
	 * @param criticalIndi the criticalIndi to set
	 */
	public void setCriticalIndi(String criticalIndi) {
		this.criticalIndi = criticalIndi;
	}

	/**
	 * @return the expiryDate
	 */
	public Date getExpiryDate() {
		return expiryDate;
	}

	/**
	 * @param expiryDate the expiryDate to set
	 */
	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}

	/**
	 * @return the remarks
	 */
	public String getRemarks() {
		return remarks;
	}

	/**
	 * @param remarks the remarks to set
	 */
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	/**
	 * @return the attachement
	 */
	public String getAttachement() {
		return attachement;
	}

	/**
	 * @param attachement the attachement to set
	 */
	public void setAttachement(String attachement) {
		this.attachement = attachement;
	}

	/**
	 * @return the reOrderLevel
	 */
	public Float getReOrderLevel() {
		return reOrderLevel;
	}

	/**
	 * @param reOrderLevel the reOrderLevel to set
	 */
	public void setReOrderLevel(Float reOrderLevel) {
		this.reOrderLevel = reOrderLevel;
	}

	/**
	 * @return the reOrderQty
	 */
	public Float getReOrderQty() {
		return reOrderQty;
	}

	/**
	 * @param reOrderQty the reOrderQty to set
	 */
	public void setReOrderQty(Float reOrderQty) {
		this.reOrderQty = reOrderQty;
	}

	/**
	 * @return the maxQty
	 */
	public Float getMaxQty() {
		return maxQty;
	}

	/**
	 * @param maxQty the maxQty to set
	 */
	public void setMaxQty(Float maxQty) {
		this.maxQty = maxQty;
	}

	/**
	 * @return the insertTime
	 */
	public Date getInsertTime() {
		return insertTime;
	}

	/**
	 * @param insertTime the insertTime to set
	 */
	public void setInsertTime(Date insertTime) {
		this.insertTime = insertTime;
	}

	/**
	 * @return the insertedBy
	 */
	public Integer getInsertedBy() {
		return insertedBy;
	}

	/**
	 * @param insertedBy the insertedBy to set
	 */
	public void setInsertedBy(Integer insertedBy) {
		this.insertedBy = insertedBy;
	}

	/**
	 * @return the updateTime
	 */
	public Date getUpdateTime() {
		return updateTime;
	}

	/**
	 * @param updateTime the updateTime to set
	 */
	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	/**
	 * @return the updatedBy
	 */
	public Integer getUpdatedBy() {
		return updatedBy;
	}

	/**
	 * @param updatedBy the updatedBy to set
	 */
	public void setUpdatedBy(Integer updatedBy) {
		this.updatedBy = updatedBy;
	}

	/**
	 * @return the status
	 */
	public StatusDto getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(StatusDto status) {
		this.status = status;
	}

	/**
	 * @return the syncRequired
	 */
	public String getSyncRequired() {
		return syncRequired;
	}

	/**
	 * @param syncRequired the syncRequired to set
	 */
	public void setSyncRequired(String syncRequired) {
		this.syncRequired = syncRequired;
	}

}
