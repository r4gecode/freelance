/**
 * 
 */
package in.ind.mds.dto;

import java.io.Serializable;
import java.util.Date;

import org.dozer.Mapping;

/**
 * @author mds-arockia
 *
 */
public class CompanyCurrencyDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 117488975433468L;
	
	private String id;
	
	@Mapping("company")
	private CompanyDto company;
	
	@Mapping("currency")
	private GlobalCurrencyDto currency;
	
	@Mapping("baseCurrency")
	private GlobalCurrencyDto baseCurrency;
	
	private Date insertTime;
	private int insertedBy;
	private Date updateTime;
	private int updatedBy;
	private String syncRequired;
	
	@Mapping("status")
	private StatusDto status;
	
	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}
	/**
	 * @return the company
	 */
	public CompanyDto getCompany() {
		return company;
	}
	/**
	 * @param company the company to set
	 */
	public void setCompany(CompanyDto company) {
		this.company = company;
	}
	/**
	 * @return the currency
	 */
	public GlobalCurrencyDto getCurrency() {
		return currency;
	}
	/**
	 * @param currency the currency to set
	 */
	public void setCurrency(GlobalCurrencyDto currency) {
		this.currency = currency;
	}
	/**
	 * @return the baseCurrency
	 */
	public GlobalCurrencyDto getBaseCurrency() {
		return baseCurrency;
	}
	/**
	 * @param baseCurrency the baseCurrency to set
	 */
	public void setBaseCurrency(GlobalCurrencyDto baseCurrency) {
		this.baseCurrency = baseCurrency;
	}
	/**
	 * @return the insertTime
	 */
	public Date getInsertTime() {
		return insertTime;
	}
	/**
	 * @param insertTime the insertTime to set
	 */
	public void setInsertTime(Date insertTime) {
		this.insertTime = insertTime;
	}
	/**
	 * @return the insertedBy
	 */
	public int getInsertedBy() {
		return insertedBy;
	}
	/**
	 * @param insertedBy the insertedBy to set
	 */
	public void setInsertedBy(int insertedBy) {
		this.insertedBy = insertedBy;
	}
	/**
	 * @return the updateTime
	 */
	public Date getUpdateTime() {
		return updateTime;
	}
	/**
	 * @param updateTime the updateTime to set
	 */
	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}
	/**
	 * @return the updatedBy
	 */
	public int getUpdatedBy() {
		return updatedBy;
	}
	/**
	 * @param updatedBy the updatedBy to set
	 */
	public void setUpdatedBy(int updatedBy) {
		this.updatedBy = updatedBy;
	}
	/**
	 * @return the syncRequired
	 */
	public String getSyncRequired() {
		return syncRequired;
	}
	/**
	 * @param syncRequired the syncRequired to set
	 */
	public void setSyncRequired(String syncRequired) {
		this.syncRequired = syncRequired;
	}
	/**
	 * @return the status
	 */
	public StatusDto getStatus() {
		return status;
	}
	/**
	 * @param status the status to set
	 */
	public void setStatus(StatusDto status) {
		this.status = status;
	}
	
}
