/**
 * 
 */
package in.ind.mds.dto;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import org.dozer.Mapping;
import in.ind.mds.repo.entity.SafTrainingType;
import in.ind.mds.repo.entity.User;

/**
 * @author dharani
 *
 */
public class ShipBoardTrainingDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 134657283647L;

	private String id;

	@Mapping("fleet")
	private FleetDto fleet;

	@Mapping("vessel")
	private VesselDto vessel;

	@Mapping("conductedBy")
	private StaffDto conductedBy;

	@Mapping("conductedDate")
	private Date conductedDate;

	private String topic;

	private Date startTime;

	private Date endTime;

	private Float totalHours;

	private String shipComments;

	private String syncRequired;

	@Mapping("status")
	private StatusDto status;

	private Date insertTime;

	@Mapping("insertedBy")
	private UserDto insertedBy;

	private Date updateTime;

	@Mapping("updatedBy")
	private User updatedBy;

	@Mapping("typeOfTraining")
	private SafTrainingType typeOfTraining;

	private List<OfficeReviewDto> officeReviewDtoList;

	private List<AttendanceDto> attendanceDtoList;

	
     

	private List<String> officeIds;

	private List<String> attendanceIds;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public FleetDto getFleet() {
		return fleet;
	}

	public void setFleet(FleetDto fleet) {
		this.fleet = fleet;
	}

	public VesselDto getVessel() {
		return vessel;
	}

	public void setVessel(VesselDto vessel) {
		this.vessel = vessel;
	}

	public StaffDto getConductedBy() {
		return conductedBy;
	}

	public void setConductedBy(StaffDto conductedBy) {
		this.conductedBy = conductedBy;
	}

	public Date getConductedDate() {
		return conductedDate;
	}

	public void setConductedDate(Date conductedDate) {
		this.conductedDate = conductedDate;
	}

	public String getTopic() {
		return topic;
	}

	public void setTopic(String topic) {
		this.topic = topic;
	}

	public Date getStartTime() {
		return startTime;
	}

	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}

	public Date getEndTime() {
		return endTime;
	}

	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}

	public Float getTotalHours() {
		return totalHours;
	}

	public void setTotalHours(Float totalHours) {
		this.totalHours = totalHours;
	}

	public String getShipComments() {
		return shipComments;
	}

	public void setShipComments(String shipComments) {
		this.shipComments = shipComments;
	}

	public String getSyncRequired() {
		return syncRequired;
	}

	public void setSyncRequired(String syncRequired) {
		this.syncRequired = syncRequired;
	}

	public StatusDto getStatus() {
		return status;
	}

	public void setStatus(StatusDto status) {
		this.status = status;
	}

	public Date getInsertTime() {
		return insertTime;
	}

	public void setInsertTime(Date insertTime) {
		this.insertTime = insertTime;
	}

	public UserDto getInsertedBy() {
		return insertedBy;
	}

	public void setInsertedBy(UserDto insertedBy) {
		this.insertedBy = insertedBy;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public User getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(User updatedBy) {
		this.updatedBy = updatedBy;
	}

	public SafTrainingType getTypeOfTraining() {
		return typeOfTraining;
	}

	public void setTypeOfTraining(SafTrainingType typeOfTraining) {
		this.typeOfTraining = typeOfTraining;
	}

	public List<OfficeReviewDto> getOfficeReviewDtoList() {
		return officeReviewDtoList;
	}

	public void setOfficeReviewDtoList(List<OfficeReviewDto> officeReviewDtoList) {
		this.officeReviewDtoList = officeReviewDtoList;
	}

	public List<AttendanceDto> getAttendanceDtoList() {
		return attendanceDtoList;
	}

	public void setAttendanceDtoList(List<AttendanceDto> attendanceDtoList) {
		this.attendanceDtoList = attendanceDtoList;
	}

	

	public List<String> getOfficeIds() {
		return officeIds;
	}

	public void setOfficeIds(List<String> officeIds) {
		this.officeIds = officeIds;
	}

	public List<String> getAttendanceIds() {
		return attendanceIds;
	}

	public void setAttendanceIds(List<String> attendanceIds) {
		this.attendanceIds = attendanceIds;
	}

	

}
