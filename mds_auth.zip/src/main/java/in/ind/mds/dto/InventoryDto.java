package in.ind.mds.dto;

import java.io.Serializable;
import java.util.Date;

import org.dozer.Mapping;

public class InventoryDto implements Serializable {

	/**
	 * 
	 */
	

	private static final long serialVersionUID = -2028862443829790466L;
	private String id;
	/*private String vesselId;
	private String inventoryCtgyId;*/
	private String inventoryName;
	private String inventoryCode;
	/*private String recordStatus;*/
	private float measure;
	private String make;
	private String partNumber;
	private String drawNumber;
	private String modelNumber;
	private String positionNumber;
	private String serialNumber;
	/*private String locationsOnBoardId;*/
	private String criticalIndi;
	private Date expiryDate;
	private String remarks;
	private String attachment;
	private float reorderLevel;
	private float reorderQty;
	private float maxQty;
	private float curQty;
	private Date insertTime;
	private int insertedBy;
	private Date updateTime;
	private int updatedBy;
	private String syncRequired;
	
	@Mapping("status")
	private StatusDto status;
	
	@Mapping("component")
	private ComponentDto component;
	@Mapping("componentMain")
	private ComponentMainDto componentMain;
	
	@Mapping("inventoryMain")
	private InventoryMainDto inventoryMain;
	
	@Mapping("locOnboard")
	private LocOnboardDto locOnboard;
	
	@Mapping("vessel")
	private VesselDto vessel;
	
	
	
	public String getId() {
		return id;
	}
	public StatusDto getStatus() {
		return status;
	}
	public void setStatus(StatusDto status) {
		this.status = status;
	}
	public ComponentDto getComponent() {
		return component;
	}
	public void setComponent(ComponentDto component) {
		this.component = component;
	}
	public ComponentMainDto getComponentMain() {
		return componentMain;
	}
	public void setComponentMain(ComponentMainDto componentMain) {
		this.componentMain = componentMain;
	}
	public InventoryMainDto getInventoryMain() {
		return inventoryMain;
	}
	public void setInventoryMain(InventoryMainDto inventoryMain) {
		this.inventoryMain = inventoryMain;
	}
	public LocOnboardDto getLocOnboard() {
		return locOnboard;
	}
	public void setLocOnboard(LocOnboardDto locOnboard) {
		this.locOnboard = locOnboard;
	}
	public VesselDto getVessel() {
		return vessel;
	}
	public void setVessel(VesselDto vessel) {
		this.vessel = vessel;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getInventoryName() {
		return inventoryName;
	}
	public void setInventoryName(String inventoryName) {
		this.inventoryName = inventoryName;
	}
	public String getInventoryCode() {
		return inventoryCode;
	}
	public void setInventoryCode(String inventoryCode) {
		this.inventoryCode = inventoryCode;
	}
	
	public float getMeasure() {
		return measure;
	}
	public void setMeasure(float measure) {
		this.measure = measure;
	}
	public String getMake() {
		return make;
	}
	public void setMake(String make) {
		this.make = make;
	}
	public String getPartNumber() {
		return partNumber;
	}
	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}
	public String getDrawNumber() {
		return drawNumber;
	}
	public void setDrawNumber(String drawNumber) {
		this.drawNumber = drawNumber;
	}
	public String getModelNumber() {
		return modelNumber;
	}
	public void setModelNumber(String modelNumber) {
		this.modelNumber = modelNumber;
	}
	public String getPositionNumber() {
		return positionNumber;
	}
	public void setPositionNumber(String positionNumber) {
		this.positionNumber = positionNumber;
	}
	public String getSerialNumber() {
		return serialNumber;
	}
	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}
	
	public String getCriticalIndi() {
		return criticalIndi;
	}
	public void setCriticalIndi(String criticalIndi) {
		this.criticalIndi = criticalIndi;
	}
	public Date getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public String getAttachment() {
		return attachment;
	}
	public void setAttachment(String attachment) {
		this.attachment = attachment;
	}
	public float getReorderLevel() {
		return reorderLevel;
	}
	public void setReorderLevel(float reorderLevel) {
		this.reorderLevel = reorderLevel;
	}
	public float getReorderQty() {
		return reorderQty;
	}
	public void setReorderQty(float reorderQty) {
		this.reorderQty = reorderQty;
	}
	public float getMaxQty() {
		return maxQty;
	}
	public void setMaxQty(float maxQty) {
		this.maxQty = maxQty;
	}
	public float getCurQty() {
		return curQty;
	}
	public void setCurQty(float curQty) {
		this.curQty = curQty;
	}
	public Date getInsertTime() {
		return insertTime;
	}
	public void setInsertTime(Date insertTime) {
		this.insertTime = insertTime;
	}
	public int getInsertedBy() {
		return insertedBy;
	}
	public void setInsertedBy(int insertedBy) {
		this.insertedBy = insertedBy;
	}
	public Date getUpdateTime() {
		return updateTime;
	}
	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}
	public int getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(int updatedBy) {
		this.updatedBy = updatedBy;
	}
	public String getSyncRequired() {
		return syncRequired;
	}
	public void setSyncRequired(String syncRequired) {
		this.syncRequired = syncRequired;
	}
	
/*
	@Mapping("inventorStatus")
	private StatusDto statusDto;

	@Mapping("vessel")
	private VesselDto vesselDto;

	@Mapping("inventoryMain")
	private InventoryMainDto inventoryMainDto;

*/
}