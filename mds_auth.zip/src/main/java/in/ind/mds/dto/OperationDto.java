/**
 * 
 */
package in.ind.mds.dto;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.dozer.Mapping;

import in.ind.mds.repo.entity.OperationType;
import in.ind.mds.repo.entity.User;

/**
 * @author dharani
 *
 */
public class OperationDto implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1324549856L;
	
	
	private String id;
	
	
	private String operation;
	
	
	@Mapping("operationType")
	private OperationTypeDto operationType;
	
	
	private String syncRequired;
	
	
	private Date insertTime;

	private Date updateTime;

	@Mapping("insertedBy")
	private UserDto insertedBy;
	
	@Mapping("updatedBy")
	private UserDto updatedBy;
	
	@Mapping("status")
	private StatusDto status;
	
private List<HazardsDto>hazardsDtoList;
	
	private List<String>hazardIds;



	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getOperation() {
		return operation;
	}

	public void setOperation(String operation) {
		this.operation = operation;
	}

	public OperationTypeDto getOperationType() {
		return operationType;
	}

	public void setOperationType(OperationTypeDto operationType) {
		this.operationType = operationType;
	}

	public String getSyncRequired() {
		return syncRequired;
	}

	public void setSyncRequired(String syncRequired) {
		this.syncRequired = syncRequired;
	}

	public Date getInsertTime() {
		return insertTime;
	}

	public void setInsertTime(Date insertTime) {
		this.insertTime = insertTime;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public UserDto getInsertedBy() {
		return insertedBy;
	}

	public void setInsertedBy(UserDto insertedBy) {
		this.insertedBy = insertedBy;
	}

	public UserDto getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(UserDto updatedBy) {
		this.updatedBy = updatedBy;
	}

	public StatusDto getStatus() {
		return status;
	}

	public void setStatus(StatusDto status) {
		this.status = status;
	}

	public List<HazardsDto> getHazardsDtoList() {
		return hazardsDtoList;
	}

	public void setHazardsDtoList(List<HazardsDto> hazardsDtoList) {
		this.hazardsDtoList = hazardsDtoList;
	}

	public List<String> getHazardIds() {
		return hazardIds;
	}

	public void setHazardIds(List<String> hazardIds) {
		this.hazardIds = hazardIds;
	}
	
	

	}


	
	
	
	
	



