package in.ind.mds.dto;

import java.io.Serializable;
import java.util.Date;

import org.dozer.Mapping;

public class UserAuditDto implements Serializable

{

	/**
	 * 
	 */
	
	private static final long serialVersionUID = -3902914140839717407L;
	public MenuDto getMenu() {
		return menu;
	}
	public void setMenu(MenuDto menu) {
		this.menu = menu;
	}
	public UserDto getUser() {
		return user;
	}
	public void setUser(UserDto user) {
		this.user = user;
	}
	private String id;
	/*private String userId;*/
	private String userIp;
	private Date insertTime;
	private int insertedBy;
	private String syncRequired;
	
	@Mapping("menu")
	private MenuDto menu;

	@Mapping("user")
	private UserDto user;

	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	
	/*public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}*/
	
	public String getUserIp() {
		return userIp;
	}
	public void setUserIp(String userIp) {
		this.userIp = userIp;
	}
	public Date getInsertTime() {
		return insertTime;
	}
	public void setInsertTime(Date insertTime) {
		this.insertTime = insertTime;
	}
	public int getInsertedBy() {
		return insertedBy;
	}
	public void setInsertedBy(int insertedBy) {
		this.insertedBy = insertedBy;
	}
	public String getSyncRequired() {
		return syncRequired;
	}
	public void setSyncRequired(String syncRequired) {
		this.syncRequired = syncRequired;
	}

}