/**
 * 
 */
package in.ind.mds.dto;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import org.dozer.Mapping;



/**
 * @author mds-arockia
 *
 */
public class JobCompletionDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1174839746248L;

	private String id;
	
	@Mapping("scheduledJob")
	private ScheduledJobDto scheduledJob;
	
	private String jobStatus;
	private Date completedDate;
	private String consumptionIndi;
	
	@Mapping("completedBy")
	private UserDto completedBy;
	
	private String jobComments;
	private String reasonForDelay;
	private String syncRequired;
	private Integer totalRunningHour;
	private Integer avgRunningHour;
	private Date lastDoneDate;
	private Date nextDueDate;
	private Date reScheduledDueDate;
	private String reviewedIndi;
	
	@Mapping("reviewedBy")
	private UserDto reviewedBy;
	
	private Date reviewedDate;
	private String reviewComments;
	private Integer rhAtCompletion;
	private Date insertTime;
	
	@Mapping("status")
	private StatusDto status;
	
	@Mapping("insertedBy")
	private UserDto insertedBy;
	
	private Date updateTime;
	
	@Mapping("updatedBy")
	private UserDto updatedBy;
	
	private List<String> jobCompletionAtch;

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the scheduledJob
	 */
	public ScheduledJobDto getScheduledJob() {
		return scheduledJob;
	}

	/**
	 * @param scheduledJob the scheduledJob to set
	 */
	public void setScheduledJob(ScheduledJobDto scheduledJob) {
		this.scheduledJob = scheduledJob;
	}

	/**
	 * @return the jobStatus
	 */
	public String getJobStatus() {
		return jobStatus;
	}

	/**
	 * @param jobStatus the jobStatus to set
	 */
	public void setJobStatus(String jobStatus) {
		this.jobStatus = jobStatus;
	}

	/**
	 * @return the completedDate
	 */
	public Date getCompletedDate() {
		return completedDate;
	}

	/**
	 * @param completedDate the completedDate to set
	 */
	public void setCompletedDate(Date completedDate) {
		this.completedDate = completedDate;
	}

	/**
	 * @return the consumptionIndi
	 */
	public String getConsumptionIndi() {
		return consumptionIndi;
	}

	/**
	 * @param consumptionIndi the consumptionIndi to set
	 */
	public void setConsumptionIndi(String consumptionIndi) {
		this.consumptionIndi = consumptionIndi;
	}

	/**
	 * @return the completedBy
	 */
	public UserDto getCompletedBy() {
		return completedBy;
	}

	/**
	 * @param completedBy the completedBy to set
	 */
	public void setCompletedBy(UserDto completedBy) {
		this.completedBy = completedBy;
	}

	/**
	 * @return the jobComments
	 */
	public String getJobComments() {
		return jobComments;
	}

	/**
	 * @param jobComments the jobComments to set
	 */
	public void setJobComments(String jobComments) {
		this.jobComments = jobComments;
	}

	/**
	 * @return the reasonForDelay
	 */
	public String getReasonForDelay() {
		return reasonForDelay;
	}

	/**
	 * @param reasonForDelay the reasonForDelay to set
	 */
	public void setReasonForDelay(String reasonForDelay) {
		this.reasonForDelay = reasonForDelay;
	}

	/**
	 * @return the syncRequired
	 */
	public String getSyncRequired() {
		return syncRequired;
	}

	/**
	 * @param syncRequired the syncRequired to set
	 */
	public void setSyncRequired(String syncRequired) {
		this.syncRequired = syncRequired;
	}

	/**
	 * @return the totalRunningHour
	 */
	public Integer getTotalRunningHour() {
		return totalRunningHour;
	}

	/**
	 * @param totalRunningHour the totalRunningHour to set
	 */
	public void setTotalRunningHour(Integer totalRunningHour) {
		this.totalRunningHour = totalRunningHour;
	}

	/**
	 * @return the avgRunningHour
	 */
	public Integer getAvgRunningHour() {
		return avgRunningHour;
	}

	/**
	 * @param avgRunningHour the avgRunningHour to set
	 */
	public void setAvgRunningHour(Integer avgRunningHour) {
		this.avgRunningHour = avgRunningHour;
	}

	/**
	 * @return the lastDoneDate
	 */
	public Date getLastDoneDate() {
		return lastDoneDate;
	}

	/**
	 * @param lastDoneDate the lastDoneDate to set
	 */
	public void setLastDoneDate(Date lastDoneDate) {
		this.lastDoneDate = lastDoneDate;
	}

	/**
	 * @return the nextDueDate
	 */
	public Date getNextDueDate() {
		return nextDueDate;
	}

	/**
	 * @param nextDueDate the nextDueDate to set
	 */
	public void setNextDueDate(Date nextDueDate) {
		this.nextDueDate = nextDueDate;
	}

	/**
	 * @return the reScheduledDueDate
	 */
	public Date getReScheduledDueDate() {
		return reScheduledDueDate;
	}

	/**
	 * @param reScheduledDueDate the reScheduledDueDate to set
	 */
	public void setReScheduledDueDate(Date reScheduledDueDate) {
		this.reScheduledDueDate = reScheduledDueDate;
	}

	/**
	 * @return the reviewedIndi
	 */
	public String getReviewedIndi() {
		return reviewedIndi;
	}

	/**
	 * @param reviewedIndi the reviewedIndi to set
	 */
	public void setReviewedIndi(String reviewedIndi) {
		this.reviewedIndi = reviewedIndi;
	}

	/**
	 * @return the reviewedBy
	 */
	public UserDto getReviewedBy() {
		return reviewedBy;
	}

	/**
	 * @param reviewedBy the reviewedBy to set
	 */
	public void setReviewedBy(UserDto reviewedBy) {
		this.reviewedBy = reviewedBy;
	}

	/**
	 * @return the reviewedDate
	 */
	public Date getReviewedDate() {
		return reviewedDate;
	}

	/**
	 * @param reviewedDate the reviewedDate to set
	 */
	public void setReviewedDate(Date reviewedDate) {
		this.reviewedDate = reviewedDate;
	}

	/**
	 * @return the reviewComments
	 */
	public String getReviewComments() {
		return reviewComments;
	}

	/**
	 * @param reviewComments the reviewComments to set
	 */
	public void setReviewComments(String reviewComments) {
		this.reviewComments = reviewComments;
	}

	/**
	 * @return the rhAtCompletion
	 */
	public Integer getRhAtCompletion() {
		return rhAtCompletion;
	}

	/**
	 * @param rhAtCompletion the rhAtCompletion to set
	 */
	public void setRhAtCompletion(Integer rhAtCompletion) {
		this.rhAtCompletion = rhAtCompletion;
	}

	/**
	 * @return the insertTime
	 */
	public Date getInsertTime() {
		return insertTime;
	}

	/**
	 * @param insertTime the insertTime to set
	 */
	public void setInsertTime(Date insertTime) {
		this.insertTime = insertTime;
	}

	/**
	 * @return the insertedBy
	 */
	public UserDto getInsertedBy() {
		return insertedBy;
	}

	/**
	 * @param insertedBy the insertedBy to set
	 */
	public void setInsertedBy(UserDto insertedBy) {
		this.insertedBy = insertedBy;
	}

	/**
	 * @return the updateTime
	 */
	public Date getUpdateTime() {
		return updateTime;
	}

	/**
	 * @param updateTime the updateTime to set
	 */
	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	/**
	 * @return the updatedBy
	 */
	public UserDto getUpdatedBy() {
		return updatedBy;
	}

	/**
	 * @param updatedBy the updatedBy to set
	 */
	public void setUpdatedBy(UserDto updatedBy) {
		this.updatedBy = updatedBy;
	}

	/**
	 * @return the jobCompletionAtch
	 */
	public List<String> getJobCompletionAtch() {
		return jobCompletionAtch;
	}

	/**
	 * @param jobCompletionAtch the jobCompletionAtch to set
	 */
	public void setJobCompletionAtch(List<String> jobCompletionAtch) {
		this.jobCompletionAtch = jobCompletionAtch;
	}
	
	public String getJobCompletionAtchFieldName() {
		return "JobCompletionAtch";
	}

	/**
	 * @return the status
	 */
	public StatusDto getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(StatusDto status) {
		this.status = status;
	}
	
	
}
