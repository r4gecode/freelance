/**
 * 
 */
package in.ind.mds.dto;


import java.io.Serializable;
import java.util.Date;
import java.util.List;

import org.dozer.Mapping;

/**
 * @author Hinaya
 *
 */
public class CrewContractDto implements Serializable{
	
	private static final long serialVersionUID = 1124989417621513664L;
	
	private String id;
	
	private Date startDate;

	private Date endDate;
	
	private String comments;
	
	private Date standByFrom;
	
	private Date standByTo;
	
	private Date actualSignOnDate;
	
	private Date expectedSignOffDate;
	
	private Date actualSignOffDate;
	
	private Date signOffStandByFrom;
	
	private Date signOffStandByTo;
	
	private String syncRequired;
	
	private Date insertTime;	
	
	private Date updateTime;
	
	@Mapping("staff")
	private StaffDto staff;
	
	@Mapping("role")
	private RoleDto role;
	
	@Mapping("status")
	private StatusDto status;
	
	List<String> contractDoc;
	
	List<String> softDeleteDocPaths;
	
	@Mapping("insertedBy")
	private UserDto insertedBy;
	
	@Mapping("updatedBy")
	private UserDto updatedBy;

	@Mapping("signOnPort")
	private PortDto signOnPort;
	
	@Mapping("signOffPort")
	private PortDto signOffPort;
	
	@Mapping("vessel")
	private VesselDto vessel;
	
	@Mapping("signOffReason")
	private SignOffReasonDto signOffReason;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}


	/**
	 * @return the standByFrom
	 */
	public Date getStandByFrom() {
		return standByFrom;
	}

	/**
	 * @param standByFrom the standByFrom to set
	 */
	public void setStandByFrom(Date standByFrom) {
		this.standByFrom = standByFrom;
	}

	/**
	 * @return the standByTo
	 */
	public Date getStandByTo() {
		return standByTo;
	}

	/**
	 * @param standByTo the standByTo to set
	 */
	public void setStandByTo(Date standByTo) {
		this.standByTo = standByTo;
	}

	/**
	 * @return the actualSignOnDate
	 */
	public Date getActualSignOnDate() {
		return actualSignOnDate;
	}

	/**
	 * @param actualSignOnDate the actualSignOnDate to set
	 */
	public void setActualSignOnDate(Date actualSignOnDate) {
		this.actualSignOnDate = actualSignOnDate;
	}

	/**
	 * @return the expectedSignOffDate
	 */
	public Date getExpectedSignOffDate() {
		return expectedSignOffDate;
	}

	/**
	 * @param expectedSignOffDate the expectedSignOffDate to set
	 */
	public void setExpectedSignOffDate(Date expectedSignOffDate) {
		this.expectedSignOffDate = expectedSignOffDate;
	}

	/**
	 * @return the actualSignOffDate
	 */
	public Date getActualSignOffDate() {
		return actualSignOffDate;
	}

	/**
	 * @param actualSignOffDate the actualSignOffDate to set
	 */
	public void setActualSignOffDate(Date actualSignOffDate) {
		this.actualSignOffDate = actualSignOffDate;
	}

	/**
	 * @return the signOffStandByFrom
	 */
	public Date getSignOffStandByFrom() {
		return signOffStandByFrom;
	}

	/**
	 * @param signOffStandByFrom the signOffStandByFrom to set
	 */
	public void setSignOffStandByFrom(Date signOffStandByFrom) {
		this.signOffStandByFrom = signOffStandByFrom;
	}

	/**
	 * @return the signOffStandByTo
	 */
	public Date getSignOffStandByTo() {
		return signOffStandByTo;
	}

	/**
	 * @param signOffStandByTo the signOffStandByTo to set
	 */
	public void setSignOffStandByTo(Date signOffStandByTo) {
		this.signOffStandByTo = signOffStandByTo;
	}

	/**
	 * @return the syncRequired
	 */
	public String getSyncRequired() {
		return syncRequired;
	}

	/**
	 * @param syncRequired the syncRequired to set
	 */
	public void setSyncRequired(String syncRequired) {
		this.syncRequired = syncRequired;
	}

	/**
	 * @return the insertTime
	 */
	public Date getInsertTime() {
		return insertTime;
	}

	/**
	 * @param insertTime the insertTime to set
	 */
	public void setInsertTime(Date insertTime) {
		this.insertTime = insertTime;
	}

	/**
	 * @return the updateTime
	 */
	public Date getUpdateTime() {
		return updateTime;
	}

	/**
	 * @param updateTime the updateTime to set
	 */
	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	/**
	 * @return the staff
	 */
	public StaffDto getStaff() {
		return staff;
	}

	/**
	 * @param staff the staff to set
	 */
	public void setStaff(StaffDto staff) {
		this.staff = staff;
	}

	/**
	 * @return the role
	 */
	public RoleDto getRole() {
		return role;
	}

	/**
	 * @param role the role to set
	 */
	public void setRole(RoleDto role) {
		this.role = role;
	}

	/**
	 * @return the status
	 */
	public StatusDto getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(StatusDto status) {
		this.status = status;
	}

	/**
	 * @return the contractDoc
	 */
	public List<String> getContractDoc() {
		return contractDoc;
	}

	/**
	 * @param contractDoc the contractDoc to set
	 */
	public void setContractDoc(List<String> contractDoc) {
		this.contractDoc = contractDoc;
	}

	/**
	 * @return the insertedBy
	 */
	public UserDto getInsertedBy() {
		return insertedBy;
	}

	/**
	 * @param insertedBy the insertedBy to set
	 */
	public void setInsertedBy(UserDto insertedBy) {
		this.insertedBy = insertedBy;
	}

	/**
	 * @return the updatedBy
	 */
	public UserDto getUpdatedBy() {
		return updatedBy;
	}

	/**
	 * @param updatedBy the updatedBy to set
	 */
	public void setUpdatedBy(UserDto updatedBy) {
		this.updatedBy = updatedBy;
	}

	/**
	 * @return the signOnPort
	 */
	public PortDto getSignOnPort() {
		return signOnPort;
	}

	/**
	 * @param signOnPort the signOnPort to set
	 */
	public void setSignOnPort(PortDto signOnPort) {
		this.signOnPort = signOnPort;
	}

	/**
	 * @return the signOffPort
	 */
	public PortDto getSignOffPort() {
		return signOffPort;
	}

	/**
	 * @param signOffPort the signOffPort to set
	 */
	public void setSignOffPort(PortDto signOffPort) {
		this.signOffPort = signOffPort;
	}

	/**
	 * @return the vessel
	 */
	public VesselDto getVessel() {
		return vessel;
	}

	/**
	 * @param vessel the vessel to set
	 */
	public void setVessel(VesselDto vessel) {
		this.vessel = vessel;
	}

	/**
	 * @return the signOffReason
	 */
	public SignOffReasonDto getSignOffReason() {
		return signOffReason;
	}

	/**
	 * @param signOffReason the signOffReason to set
	 */
	public void setSignOffReason(SignOffReasonDto signOffReason) {
		this.signOffReason = signOffReason;
	}

	public String getContractDocFieldName() {
		return "ContractDoc";
	}

	/**
	 * @return the softDeleteDocPaths
	 */
	public List<String> getSoftDeleteDocPaths() {
		return softDeleteDocPaths;
	}

	/**
	 * @param softDeleteDocPaths the softDeleteDocPaths to set
	 */
	public void setSoftDeleteDocPaths(List<String> softDeleteDocPaths) {
		this.softDeleteDocPaths = softDeleteDocPaths;
	}

}
