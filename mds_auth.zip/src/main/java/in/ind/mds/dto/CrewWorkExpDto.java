/**
 * 
 */
package in.ind.mds.dto;

import java.io.Serializable;
import java.util.Date;

import org.dozer.Mapping;

/**
 * @author shalini
 *
 */
public class CrewWorkExpDto implements  Serializable{
	private static final long serialVersionUID = -3502039145676202977L;
	private String id;
	private String currentCompany;
	private String companyName;
	private String vesselName;
	private String flag;
	private String grt;
	private String bhp;
	private String nrt;
	private String dwt;
	private Date signOn;
	private Date signOff;
	private int years;
	private int months;
	private int days;
	private int mtDays;
	private int basicSalary;
	private Date insertTime;
	private Date updateTime;
	private String syncRequired;
	
	@Mapping("status")
	private StatusDto status;

	@Mapping("staff")
	private StaffDto staff;

	
	@Mapping("vesselType")
	private VesselTypeDto vesselType;

	
	@Mapping("role")
	private RoleDto role;

	
	@Mapping("engagePort")
	private PortDto engagePort;

	@Mapping("insertedBy")
	private UserDto insertedBy;

	@Mapping("updatedBy")
	private UserDto updatedBy;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCurrentCompany() {
		return currentCompany;
	}

	public void setCurrentCompany(String currentCompany) {
		this.currentCompany = currentCompany;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getVesselName() {
		return vesselName;
	}

	public void setVesselName(String vesselName) {
		this.vesselName = vesselName;
	}

	public String getFlag() {
		return flag;
	}

	public void setFlag(String flag) {
		this.flag = flag;
	}

	public String getGrt() {
		return grt;
	}

	public void setGrt(String grt) {
		this.grt = grt;
	}

	public String getBhp() {
		return bhp;
	}

	public void setBhp(String bhp) {
		this.bhp = bhp;
	}

	public String getNrt() {
		return nrt;
	}

	public void setNrt(String nrt) {
		this.nrt = nrt;
	}

	public String getDwt() {
		return dwt;
	}

	public void setDwt(String dwt) {
		this.dwt = dwt;
	}

	public Date getSignOn() {
		return signOn;
	}

	public void setSignOn(Date signOn) {
		this.signOn = signOn;
	}

	public Date getSignOff() {
		return signOff;
	}

	public void setSignOff(Date signOff) {
		this.signOff = signOff;
	}

	public int getYears() {
		return years;
	}

	public void setYears(int years) {
		this.years = years;
	}

	public int getMonths() {
		return months;
	}

	public void setMonths(int months) {
		this.months = months;
	}

	public int getDays() {
		return days;
	}

	public void setDays(int days) {
		this.days = days;
	}

	public int getMtDays() {
		return mtDays;
	}

	public void setMtDays(int mtDays) {
		this.mtDays = mtDays;
	}

	public int getBasicSalary() {
		return basicSalary;
	}

	public void setBasicSalary(int basicSalary) {
		this.basicSalary = basicSalary;
	}

	public Date getInsertTime() {
		return insertTime;
	}

	public void setInsertTime(Date insertTime) {
		this.insertTime = insertTime;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public String getSyncRequired() {
		return syncRequired;
	}

	public void setSyncRequired(String syncRequired) {
		this.syncRequired = syncRequired;
	}

	public StatusDto getStatus() {
		return status;
	}

	public void setStatus(StatusDto status) {
		this.status = status;
	}

	public StaffDto getStaff() {
		return staff;
	}

	public void setStaff(StaffDto staff) {
		this.staff = staff;
	}

	public VesselTypeDto getVesselType() {
		return vesselType;
	}

	public void setVesselType(VesselTypeDto vesselType) {
		this.vesselType = vesselType;
	}

	public RoleDto getRole() {
		return role;
	}

	public void setRole(RoleDto role) {
		this.role = role;
	}

	public PortDto getEngagePort() {
		return engagePort;
	}

	public void setEngagePort(PortDto engagePort) {
		this.engagePort = engagePort;
	}

	public UserDto getInsertedBy() {
		return insertedBy;
	}

	public void setInsertedBy(UserDto insertedBy) {
		this.insertedBy = insertedBy;
	}

	public UserDto getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(UserDto updatedBy) {
		this.updatedBy = updatedBy;
	}

}
