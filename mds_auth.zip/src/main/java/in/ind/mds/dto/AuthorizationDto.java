package in.ind.mds.dto;

import java.io.Serializable;
import java.util.Map;

public class AuthorizationDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5293032235512172357L;

	private String userName;
	private String firstName;
	private String lastName;
	private String userFullName;
	private String userRole;
	private Map<String, Map<String, Boolean>> accessMap;

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getUserFullName() {
		return userFullName;
	}

	public void setUserFullName(String userFullName) {
		this.userFullName = userFullName;
	}

	public String getUserRole() {
		return userRole;
	}

	public void setUserRole(String userRole) {
		this.userRole = userRole;
	}

	public Map<String, Map<String, Boolean>> getAccessMap() {
		return accessMap;
	}

	public void setAccessMap(Map<String, Map<String, Boolean>> accessMap) {
		this.accessMap = accessMap;
	}

}
