package in.ind.mds.dto;

import java.io.Serializable;
import java.util.Date;

import org.dozer.Mapping;

public class InventoryMainDto implements Serializable {

	/**
	 * 
	 */


	private static final long serialVersionUID = -1169183552530950337L;
	private String id;
	private String ctgyName;
	private String ctgyCode;
	/*private String status;*/
	/*private String parentId;*/
	private Date insertTime;
	private int insertedBy;
	private Date updateTime;
	private int updatedBy;
	private String syncRequired;
	private String fleetWideCommonInventory;
	
	@Mapping("status")
	private StatusDto status;
	@Mapping("inventoryMain")
	private InventoryMainDto inventoryMain;
	
	

	
	public String getFleetWideCommonInventory() {
		return fleetWideCommonInventory;
	}
	public void setFleetWideCommonInventory(String fleetWideCommonInventory) {
		this.fleetWideCommonInventory = fleetWideCommonInventory;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getCtgyName() {
		return ctgyName;
	}
	public void setCtgyName(String ctgyName) {
		this.ctgyName = ctgyName;
	}
	public String getCtgyCode() {
		return ctgyCode;
	}
	public void setCtgyCode(String ctgyCode) {
		this.ctgyCode = ctgyCode;
	}
	
	
	
	public StatusDto getStatus() {
		return status;
	}
	public void setStatus(StatusDto status) {
		this.status = status;
	}
	public InventoryMainDto getInventoryMain() {
		return inventoryMain;
	}
	public void setInventoryMain(InventoryMainDto inventoryMain) {
		this.inventoryMain = inventoryMain;
	}
	public Date getInsertTime() {
		return insertTime;
	}
	public void setInsertTime(Date insertTime) {
		this.insertTime = insertTime;
	}
	public int getInsertedBy() {
		return insertedBy;
	}
	public void setInsertedBy(int insertedBy) {
		this.insertedBy = insertedBy;
	}
	public Date getUpdateTime() {
		return updateTime;
	}
	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}
	public int getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(int updatedBy) {
		this.updatedBy = updatedBy;
	}
	public String getSyncRequired() {
		return syncRequired;
	}
	public void setSyncRequired(String syncRequired) {
		this.syncRequired = syncRequired;
	}
	/*
	@Mapping("inventorMainStatus")
	private StatusDto statusDto;*/

}