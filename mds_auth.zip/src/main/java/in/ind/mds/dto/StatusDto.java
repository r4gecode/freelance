package in.ind.mds.dto;

import java.io.Serializable;

public class StatusDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5020118895183071552L;

	private String id;
	private String statusName;
	private String statusDesc;
	private String syncRequired;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getStatusName() {
		return statusName;
	}

	public void setStatusName(String statusName) {
		this.statusName = statusName;
	}

	public String getStatusDesc() {
		return statusDesc;
	}

	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}

	public String getSyncRequired() {
		return syncRequired;
	}

	public void setSyncRequired(String syncRequired) {
		this.syncRequired = syncRequired;
	}

}