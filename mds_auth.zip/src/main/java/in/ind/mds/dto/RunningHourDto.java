/**
 * 
 */
package in.ind.mds.dto;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import org.dozer.Mapping;

/**
 * @author mds-arockia
 *
 */
public class RunningHourDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1174886716248L;

	private String id;

	@Mapping("fleet")
	private FleetDto fleet;

	@Mapping("vessel")
	private VesselDto vessel;

	private Date entryDate;

	private String rHType;

	private Date fromDate;

	private Date toDate;

	private int numOfDays;

	@Mapping("component")
	private ComponentDto component;

	private String syncRequired;

	@Mapping("status")
	private StatusDto status;

	private Date insertTime;

	@Mapping("insertedBy")
	private UserDto insertedBy;

	private Date updateTime;

	@Mapping("updatedBy")
	private UserDto updatedBy;

	private List<ComponentDto> components;

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the fleet
	 */
	public FleetDto getFleet() {
		return fleet;
	}

	/**
	 * @param fleet the fleet to set
	 */
	public void setFleet(FleetDto fleet) {
		this.fleet = fleet;
	}

	/**
	 * @return the vessel
	 */
	public VesselDto getVessel() {
		return vessel;
	}

	/**
	 * @param vessel the vessel to set
	 */
	public void setVessel(VesselDto vessel) {
		this.vessel = vessel;
	}

	/**
	 * @return the entryDate
	 */
	public Date getEntryDate() {
		return entryDate;
	}

	/**
	 * @param entryDate the entryDate to set
	 */
	public void setEntryDate(Date entryDate) {
		this.entryDate = entryDate;
	}

	/**
	 * @return the rHType
	 */
	public String getrHType() {
		return rHType;
	}

	/**
	 * @param rHType the rHType to set
	 */
	public void setrHType(String rHType) {
		this.rHType = rHType;
	}

	/**
	 * @return the fromDate
	 */
	public Date getFromDate() {
		return fromDate;
	}

	/**
	 * @param fromDate the fromDate to set
	 */
	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}

	/**
	 * @return the toDate
	 */
	public Date getToDate() {
		return toDate;
	}

	/**
	 * @param toDate the toDate to set
	 */
	public void setToDate(Date toDate) {
		this.toDate = toDate;
	}

	/**
	 * @return the numOfDays
	 */
	public int getNumOfDays() {
		return numOfDays;
	}

	/**
	 * @param numOfDays the numOfDays to set
	 */
	public void setNumOfDays(int numOfDays) {
		this.numOfDays = numOfDays;
	}

	/**
	 * @return the component
	 */
	public ComponentDto getComponent() {
		return component;
	}

	/**
	 * @param component the component to set
	 */
	public void setComponent(ComponentDto component) {
		this.component = component;
	}

	/**
	 * @return the syncRequired
	 */
	public String getSyncRequired() {
		return syncRequired;
	}

	/**
	 * @param syncRequired the syncRequired to set
	 */
	public void setSyncRequired(String syncRequired) {
		this.syncRequired = syncRequired;
	}

	/**
	 * @return the status
	 */
	public StatusDto getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(StatusDto status) {
		this.status = status;
	}

	/**
	 * @return the insertTime
	 */
	public Date getInsertTime() {
		return insertTime;
	}

	/**
	 * @param insertTime the insertTime to set
	 */
	public void setInsertTime(Date insertTime) {
		this.insertTime = insertTime;
	}

	/**
	 * @return the insertedBy
	 */
	public UserDto getInsertedBy() {
		return insertedBy;
	}

	/**
	 * @param insertedBy the insertedBy to set
	 */
	public void setInsertedBy(UserDto insertedBy) {
		this.insertedBy = insertedBy;
	}

	/**
	 * @return the updateTime
	 */
	public Date getUpdateTime() {
		return updateTime;
	}

	/**
	 * @param updateTime the updateTime to set
	 */
	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	/**
	 * @return the updatedBy
	 */
	public UserDto getUpdatedBy() {
		return updatedBy;
	}

	/**
	 * @param updatedBy the updatedBy to set
	 */
	public void setUpdatedBy(UserDto updatedBy) {
		this.updatedBy = updatedBy;
	}

	/**
	 * @return the components
	 */
	public List<ComponentDto> getComponents() {
		return components;
	}

	/**
	 * @param components the components to set
	 */
	public void setComponents(List<ComponentDto> components) {
		this.components = components;
	}

}
