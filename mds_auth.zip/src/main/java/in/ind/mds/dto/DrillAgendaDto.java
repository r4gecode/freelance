/**
 * 
 */
package in.ind.mds.dto;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import org.dozer.Mapping;

/**
 * @author Hinaya
 *
 */
public class DrillAgendaDto implements Serializable{
	
	private static final long serialVersionUID = 1154322825648L;
	
	private String id;
	
	private String agendaName;
	
	private String procedure;	
	
	private String vesselComment;
	
	private String officeComment;
	
	private String syncRequired;
	
	private Date insertTime;	
	
	private Date updateTime;

	@Mapping("insertedBy")
	private UserDto insertedBy;
	
	@Mapping("updatedBy")
	private UserDto updatedBy;
	
	@Mapping("drillScheduler")
	private DrillSchedulerDto drillScheduler;

	@Mapping("status")
	private StatusDto status;
	
	public List<String> drillAgendaDocs;
	
	public List<String> softDeleteDocPaths;
	
	public List<String> getSoftDeleteDocPaths() {
		return softDeleteDocPaths;
	}


	public void setSoftDeleteDocPaths(List<String> softDeleteDocPaths) {
		this.softDeleteDocPaths = softDeleteDocPaths;
	}


	public String getDrillAgendaDocFieldName() {
		// TODO Auto-generated method stub
		return "drillAgendaDocs";
	}

	
	public String getProcedure() {
		return procedure;
	}


	public void setProcedure(String procedure) {
		this.procedure = procedure;
	}


	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getAgendaName() {
		return agendaName;
	}

	public void setAgendaName(String agendaName) {
		this.agendaName = agendaName;
	}

	

	public String getVesselComment() {
		return vesselComment;
	}

	public void setVesselComment(String vesselComment) {
		this.vesselComment = vesselComment;
	}

	public String getOfficeComment() {
		return officeComment;
	}

	public void setOfficeComment(String officeComment) {
		this.officeComment = officeComment;
	}

	public String getSyncRequired() {
		return syncRequired;
	}

	public void setSyncRequired(String syncRequired) {
		this.syncRequired = syncRequired;
	}

	public Date getInsertTime() {
		return insertTime;
	}

	public void setInsertTime(Date insertTime) {
		this.insertTime = insertTime;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public UserDto getInsertedBy() {
		return insertedBy;
	}

	public void setInsertedBy(UserDto insertedBy) {
		this.insertedBy = insertedBy;
	}

	public UserDto getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(UserDto updatedBy) {
		this.updatedBy = updatedBy;
	}

	public DrillSchedulerDto getDrillScheduler() {
		return drillScheduler;
	}

	public void setDrillScheduler(DrillSchedulerDto drillScheduler) {
		this.drillScheduler = drillScheduler;
	}

	public StatusDto getStatus() {
		return status;
	}

	public void setStatus(StatusDto status) {
		this.status = status;
	}

	public List<String> getDrillAgendaDocs() {
		return drillAgendaDocs;
	}

	public void setDrillAgendaDocs(List<String> drillAgendaDocs) {
		this.drillAgendaDocs = drillAgendaDocs;
	}


	

	
	


}
