/**
 * 
 */
package in.ind.mds.dto;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import org.dozer.Mapping;

/**
 * @author Hinaya
 *
 */
public class BankAccountDto implements Serializable {
	
private static final long serialVersionUID = 1154322824248L;
	
	private String id;
	
	private String accountHolderName;
		
	private String accountNumber;
		
	private String accountType;
	
	private String iban;
	
	private String branchName;
	
	private String branchCity;
	
	private String address;
	
	private String swiftCode;
	
	private String iifscCode;
	
	private String remarks;
	
	private String syncRequired;
	
	private Date insertTime;	
	
	private Date updateTime;

	@Mapping("staff")
	private StaffDto staff;
	
	@Mapping("bankdetails")
	private BankDetailsDto bankdetails;
		
	@Mapping("country")
	private CountryDto country;
	
	@Mapping("status")
	private StatusDto status;
	
	@Mapping("insertedBy")
	private UserDto insertedBy;
	
	@Mapping("updatedBy")
	private UserDto updatedBy;
	
	List<String> bankAccountDoc;
	
	List<String> softDeleteDocPaths;
	
	public String getBankAccountDocFieldName() {
		return "BankAccountDoc";
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getAccountHolderName() {
		return accountHolderName;
	}

	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public String getIban() {
		return iban;
	}

	public void setIban(String iban) {
		this.iban = iban;
	}

	public String getBranchName() {
		return branchName;
	}

	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}

	public String getBranchCity() {
		return branchCity;
	}

	public void setBranchCity(String branchCity) {
		this.branchCity = branchCity;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getSwiftCode() {
		return swiftCode;
	}

	public void setSwiftCode(String swiftCode) {
		this.swiftCode = swiftCode;
	}

	public String getIifscCode() {
		return iifscCode;
	}

	public void setIifscCode(String iifscCode) {
		this.iifscCode = iifscCode;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getSyncRequired() {
		return syncRequired;
	}

	public void setSyncRequired(String syncRequired) {
		this.syncRequired = syncRequired;
	}

	public Date getInsertTime() {
		return insertTime;
	}

	public void setInsertTime(Date insertTime) {
		this.insertTime = insertTime;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public StaffDto getStaff() {
		return staff;
	}

	public void setStaff(StaffDto staff) {
		this.staff = staff;
	}

	public BankDetailsDto getBankdetails() {
		return bankdetails;
	}

	public void setBankdetails(BankDetailsDto bankdetails) {
		this.bankdetails = bankdetails;
	}

	public CountryDto getCountry() {
		return country;
	}

	public void setCountry(CountryDto country) {
		this.country = country;
	}

	public StatusDto getStatus() {
		return status;
	}

	public void setStatus(StatusDto status) {
		this.status = status;
	}

	/**
	 * @return the bankAccountDoc
	 */
	public List<String> getBankAccountDoc() {
		return bankAccountDoc;
	}

	/**
	 * @param bankAccountDoc the bankAccountDoc to set
	 */
	public void setBankAccountDoc(List<String> bankAccountDoc) {
		this.bankAccountDoc = bankAccountDoc;
	}

	public UserDto getInsertedBy() {
		return insertedBy;
	}

	public void setInsertedBy(UserDto insertedBy) {
		this.insertedBy = insertedBy;
	}

	public UserDto getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(UserDto updatedBy) {
		this.updatedBy = updatedBy;
	}

	/**
	 * @return the softDeleteDocPaths
	 */
	public List<String> getSoftDeleteDocPaths() {
		return softDeleteDocPaths;
	}

	/**
	 * @param softDeleteDocPaths the softDeleteDocPaths to set
	 */
	public void setSoftDeleteDocPaths(List<String> softDeleteDocPaths) {
		this.softDeleteDocPaths = softDeleteDocPaths;
	}
	
}
