package in.ind.mds.dto;

import java.io.Serializable;
import java.util.Date;

import org.dozer.Mapping;

public class UserDto implements Serializable {

	/**
	 * 
	 */
	
	
	private static final long serialVersionUID = -3502039122676202977L;

	private String id;

	private String userLoginId;

	private String password;

	private Integer userTitle;

	private String userType;

	private String userName;

	private String userShortName;

	private Date userValidTo;

	/*private String userStatus;*/

	private String userStatusRemark;

	private String userLockedFlag;

	private Date insertTime;

	private Integer insertedBy;

	private Date updateTime;

	private Integer updatedBy;

	private String syncRequired;

	@Mapping("status")
	private StatusDto status;
/*
	@Mapping("userRole")
	private UserRoleDto userRoleDto;*/

	/*public UserRoleDto getUserRoleDto() {
		return userRoleDto;
	}

	public void setUserRoleDto(UserRoleDto userRoleDto) {
		this.userRoleDto = userRoleDto;
	}*/
	

		

	/*public StatusDto getStatusDto() {
		return statusDto;
	}

	public void setStatusDto(StatusDto statusDto) {
		this.statusDto = statusDto;
	}*/

	public String getId() {
		return id;
	}

	public StatusDto getStatus() {
		return status;
	}

	public void setStatus(StatusDto status) {
		this.status = status;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getUserLoginId() {
		return userLoginId;
	}

	public void setUserLoginId(String userLoginId) {
		this.userLoginId = userLoginId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public int getUserTitle() {
		return userTitle;
	}

	public void setUserTitle(int userTitle) {
		this.userTitle = userTitle;
	}

	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserShortName() {
		return userShortName;
	}

	public void setUserShortName(String userShortName) {
		this.userShortName = userShortName;
	}

	public Date getUserValidTo() {
		return userValidTo;
	}

	public void setUserValidTo(Date userValidTo) {
		this.userValidTo = userValidTo;
	}

	/*public String getUserStatus() {
		return userStatus;
	}

	public void setUserStatus(String userStatus) {
		this.userStatus = userStatus;
	}
*/
	public String getUserStatusRemark() {
		return userStatusRemark;
	}

	public void setUserStatusRemark(String userStatusRemark) {
		this.userStatusRemark = userStatusRemark;
	}

	public String getUserLockedFlag() {
		return userLockedFlag;
	}

	public void setUserLockedFlag(String userLockedFlag) {
		this.userLockedFlag = userLockedFlag;
	}

	public Date getInsertTime() {
		return insertTime;
	}

	public void setInsertTime(Date insertTime) {
		this.insertTime = insertTime;
	}

	public Integer getInsertedBy() {
		return insertedBy;
	}

	public void setInsertedBy(Integer insertedBy) {
		this.insertedBy = insertedBy;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public Integer getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(Integer updatedBy) {
		this.updatedBy = updatedBy;
	}

	/*
	 * public StatusDto getStatusDto() { return statusDto; }
	 * 
	 * public void setStatusDto(StatusDto statusDto) { this.statusDto = statusDto; }
	 */

	public String getSyncRequired() {
		return syncRequired;
	}

	public void setSyncRequired(String syncRequired) {
		this.syncRequired = syncRequired;
	}
}