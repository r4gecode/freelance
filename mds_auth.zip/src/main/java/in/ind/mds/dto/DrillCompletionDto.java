/**
 * 
 */
package in.ind.mds.dto;

import java.io.Serializable;

import java.util.Date;
import java.util.List;

import org.dozer.Mapping;

/**
 * @author shalini
 *
 */
public class DrillCompletionDto implements Serializable{
	
	private static final long serialVersionUID = 11554321824248L;

	private String id;
	private String jobStatus;
	private String carriedOutAt;
	private Date carriedOutDate;
	public Date getCarriedOutDate() {
		return carriedOutDate;
	}

	public void setCarriedOutDate(Date carriedOutDate) {
		this.carriedOutDate = carriedOutDate;
	}

	private String drillComplRemark;
	private Date startDate;
	private Date endTime;
	private float totalHours;
	private String syncRequired;
	private Date insertTime;	
	private Date updateTime;

	
	@Mapping("drillScheduler")
	private DrillSchedulerDto drillScheduler;

	@Mapping("drillSupervisedBy")
	private RoleDto drillSupervisedBy;

	@Mapping("port")
	private PortDto port;

	@Mapping("status")
	private StatusDto status;
	
	@Mapping("insertedBy")
	private UserDto insertedBy;
	
	@Mapping("updatedBy")
	private UserDto updatedBy;
	
	List<String> drillCompletionDoc;
	private List<String> attendanceIds;
	private List<String> officeReviewIds;
	
	public String getDrillCompletionDocFieldName() {
		return "DrillCompletionDoc";
	}
	
	private List<OfficeReviewDto> officeReviewDtoList;
	
	private List<AttendanceDto> attendanceDtoList;
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getJobStatus() {
		return jobStatus;
	}

	public void setJobStatus(String jobStatus) {
		this.jobStatus = jobStatus;
	}

	public String getCarriedOutAt() {
		return carriedOutAt;
	}

	public void setCarriedOutAt(String carriedOutAt) {
		this.carriedOutAt = carriedOutAt;
	}

	public String getDrillComplRemark() {
		return drillComplRemark;
	}

	public void setDrillComplRemark(String drillComplRemark) {
		this.drillComplRemark = drillComplRemark;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndTime() {
		return endTime;
	}

	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}

	public float getTotalHours() {
		return totalHours;
	}

	public void setTotalHours(float totalHours) {
		this.totalHours = totalHours;
	}

	public String getSyncRequired() {
		return syncRequired;
	}

	public void setSyncRequired(String syncRequired) {
		this.syncRequired = syncRequired;
	}

	public Date getInsertTime() {
		return insertTime;
	}

	public void setInsertTime(Date insertTime) {
		this.insertTime = insertTime;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public DrillSchedulerDto getDrillScheduler() {
		return drillScheduler;
	}

	public void setDrillScheduler(DrillSchedulerDto drillScheduler) {
		this.drillScheduler = drillScheduler;
	}

	public RoleDto getDrillSupervisedBy() {
		return drillSupervisedBy;
	}

	public void setDrillSupervisedBy(RoleDto drillSupervisedBy) {
		this.drillSupervisedBy = drillSupervisedBy;
	}

	public PortDto getPort() {
		return port;
	}

	public void setPort(PortDto port) {
		this.port = port;
	}

	public StatusDto getStatus() {
		return status;
	}

	public void setStatus(StatusDto status) {
		this.status = status;
	}

	public UserDto getInsertedBy() {
		return insertedBy;
	}

	public void setInsertedBy(UserDto insertedBy) {
		this.insertedBy = insertedBy;
	}

	public UserDto getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(UserDto updatedBy) {
		this.updatedBy = updatedBy;
	}

	public List<String> getDrillCompletionDoc() {
		return drillCompletionDoc;
	}

	public void setDrillCompletionDoc(List<String> drillCompletionDoc) {
		this.drillCompletionDoc = drillCompletionDoc;
	}

	public List<OfficeReviewDto> getOfficeReviewDtoList() {
		return officeReviewDtoList;
	}

	public void setOfficeReviewDtoList(List<OfficeReviewDto> officeReviewDtoList) {
		this.officeReviewDtoList = officeReviewDtoList;
	}

	public List<AttendanceDto> getAttendanceDtoList() {
		return attendanceDtoList;
	}

	public void setAttendanceDtoList(List<AttendanceDto> attendanceDtoList) {
		this.attendanceDtoList = attendanceDtoList;
	}

	public List<String> getAttendanceIds() {
		return attendanceIds;
	}

	public void setAttendanceIds(List<String> attendanceIds) {
		this.attendanceIds = attendanceIds;
	}

	public List<String> getOfficeReviewIds() {
		return officeReviewIds;
	}

	public void setOfficeReviewIds(List<String> officeReviewIds) {
		this.officeReviewIds = officeReviewIds;
	}

	/*public List<String> getAttendanceIds() {
List<String> ids=new ArrayList<String>();
for(AttendanceDto attendanceDto:attendanceDtoList) {
	ids.add(attendanceDto.getId());
}
		return ids;
	}

	public List<String> getOfficeReviewIds() {
		List<String> ids=new ArrayList<String>();
		for(OfficeReviewDto officeReviewDto:officeReviewDtoList) {
			ids.add(officeReviewDto.getId());
		}
		return ids;
	}*/


}
