/**
 * 
 */
package in.ind.mds.dto;

import java.io.Serializable;
import java.util.Date;

import org.dozer.Mapping;

/**
 * @author shalini
 *
 */
public class LikelihoodDto implements Serializable{
	private static final long serialVersionUID = 87674889796248L;

	private String id; 
	
	private int itemNumber;
	
	private String typeOfLikelihood;
	
	private Date insertTime;
	
	private Date updateTime;
	
	private String syncRequired;
	
	@Mapping("status")
	private StatusDto status;

	@Mapping("insertedBy")
	private UserDto insertedBy;

	@Mapping("updatedBy")
	private UserDto updatedBy;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public int getItemNumber() {
		return itemNumber;
	}

	public void setItemNumber(int itemNumber) {
		this.itemNumber = itemNumber;
	}

	public String getTypeOfLikelihood() {
		return typeOfLikelihood;
	}

	public void setTypeOfLikelihood(String typeOfLikelihood) {
		this.typeOfLikelihood = typeOfLikelihood;
	}

	public Date getInsertTime() {
		return insertTime;
	}

	public void setInsertTime(Date insertTime) {
		this.insertTime = insertTime;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public String getSyncRequired() {
		return syncRequired;
	}

	public void setSyncRequired(String syncRequired) {
		this.syncRequired = syncRequired;
	}

	public StatusDto getStatus() {
		return status;
	}

	public void setStatus(StatusDto status) {
		this.status = status;
	}

	public UserDto getInsertedBy() {
		return insertedBy;
	}

	public void setInsertedBy(UserDto insertedBy) {
		this.insertedBy = insertedBy;
	}

	public UserDto getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(UserDto updatedBy) {
		this.updatedBy = updatedBy;
	}
	
}
