package in.ind.mds.dto;

import java.io.Serializable;
import java.util.Date;

import org.dozer.Mapping;

public class VesselDto implements Serializable {
	/**
	 * 
	 */
	
	private static final long serialVersionUID = -1994264639215306864L;

	private String id;

	private String vesselCode;

	private String vesselName;
	
    /*
	private String vesselType;

	private String vesselStatus;

	private String vesselFlag;
	
	private String ownerId;
	
	private String portOfRegistry;*/
	
	
	private String vesselDescription;

	private String vesselEmail;

	

	private String vesselCallSign;

	private String classNotation;

	private String className;

	private int inmarsatSatcomNumber;

	private String vesselBhp;

	private String serviceSpeed;

	private String vesselDwt;

	private String engineNumber;

	private float vesselLength;

	private String modelNumber;

	private int crewStrength;

	private String hullNumber;

	private String operator;

	

	private Date preDryDockDate;

	private String shipBuilder;

	private int builtYear;

	private String mainEngineMake;

	private float grossTonnage;

	private float netTonnage;

	private int engineStroke;

	private String licenseStatus;

	private String registeredAddress;

	private String imoNo;

	

	private Date insertTime;

	private int insertedBy;

	private Date updateTime;

	private int updateBy;

	private String syncRequired;

	private String officialNumber;
	
	private String attachment;

	@Mapping("status")
	private StatusDto status;
	
	@Mapping("veselType")
	private VesselTypeDto vesselType;
	
	
	@Mapping("owner")
	private OwnerDto owner;
	
	@Mapping("port")
	private PortDto port;
	
	@Mapping("country")
	private CountryDto country;
	
	@Mapping("fleet")
	private FleetDto fleet;
	
		
	
	public StatusDto getStatus() {
		return status;
	}

	public void setStatus(StatusDto status) {
		this.status = status;
	}

	public VesselTypeDto getVesselType() {
		return vesselType;
	}

	public void setVesselType(VesselTypeDto vesselType) {
		this.vesselType = vesselType;
	}

	public OwnerDto getOwner() {
		return owner;
	}

	public void setOwner(OwnerDto owner) {
		this.owner = owner;
	}

	public PortDto getPort() {
		return port;
	}

	public void setPort(PortDto port) {
		this.port = port;
	}

	public CountryDto getCountry() {
		return country;
	}

	public void setCountry(CountryDto country) {
		this.country = country;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getVesselCode() {
		return vesselCode;
	}

	public void setVesselCode(String vesselCode) {
		this.vesselCode = vesselCode;
	}

	public String getVesselName() {
		return vesselName;
	}

	public void setVesselName(String vesselName) {
		this.vesselName = vesselName;
	}

	
	public String getVesselDescription() {
		return vesselDescription;
	}

	public void setVesselDescription(String vesselDescription) {
		this.vesselDescription = vesselDescription;
	}

	public String getVesselEmail() {
		return vesselEmail;
	}

	public void setVesselEmail(String vesselEmail) {
		this.vesselEmail = vesselEmail;
	}


	public String getVesselCallSign() {
		return vesselCallSign;
	}

	public void setVesselCallSign(String vesselCallSign) {
		this.vesselCallSign = vesselCallSign;
	}

	public String getClassNotation() {
		return classNotation;
	}

	public void setClassNotation(String classNotation) {
		this.classNotation = classNotation;
	}

	public String getClassName() {
		return className;
	}

	public void setClassName(String className) {
		this.className = className;
	}

	public int getInmarsatSatcomNumber() {
		return inmarsatSatcomNumber;
	}

	public void setInmarsatSatcomNumber(int inmarsatSatcomNumber) {
		this.inmarsatSatcomNumber = inmarsatSatcomNumber;
	}

	public String getVesselBhp() {
		return vesselBhp;
	}

	public void setVesselBhp(String vesselBhp) {
		this.vesselBhp = vesselBhp;
	}

	public String getServiceSpeed() {
		return serviceSpeed;
	}

	public void setServiceSpeed(String serviceSpeed) {
		this.serviceSpeed = serviceSpeed;
	}

	public String getVesselDwt() {
		return vesselDwt;
	}

	public void setVesselDwt(String vesselDwt) {
		this.vesselDwt = vesselDwt;
	}

	public String getEngineNumber() {
		return engineNumber;
	}

	public void setEngineNumber(String engineNumber) {
		this.engineNumber = engineNumber;
	}

	public float getVesselLength() {
		return vesselLength;
	}

	public void setVesselLength(float vesselLength) {
		this.vesselLength = vesselLength;
	}

	public String getModelNumber() {
		return modelNumber;
	}

	public void setModelNumber(String modelNumber) {
		this.modelNumber = modelNumber;
	}

	public int getCrewStrength() {
		return crewStrength;
	}

	public void setCrewStrength(int crewStrength) {
		this.crewStrength = crewStrength;
	}

	public String getHullNumber() {
		return hullNumber;
	}

	public void setHullNumber(String hullNumber) {
		this.hullNumber = hullNumber;
	}

	public String getOperator() {
		return operator;
	}

	public void setOperator(String operator) {
		this.operator = operator;
	}


	public Date getPreDryDockDate() {
		return preDryDockDate;
	}

	public void setPreDryDockDate(Date preDryDockDate) {
		this.preDryDockDate = preDryDockDate;
	}

	public String getShipBuilder() {
		return shipBuilder;
	}

	public void setShipBuilder(String shipBuilder) {
		this.shipBuilder = shipBuilder;
	}

	public int getBuiltYear() {
		return builtYear;
	}

	public void setBuiltYear(int builtYear) {
		this.builtYear = builtYear;
	}

	public String getMainEngineMake() {
		return mainEngineMake;
	}

	public void setMainEngineMake(String mainEngineMake) {
		this.mainEngineMake = mainEngineMake;
	}

	public float getGrossTonnage() {
		return grossTonnage;
	}

	public void setGrossTonnage(float grossTonnage) {
		this.grossTonnage = grossTonnage;
	}

	public float getNetTonnage() {
		return netTonnage;
	}

	public void setNetTonnage(float netTonnage) {
		this.netTonnage = netTonnage;
	}

	public int getEngineStroke() {
		return engineStroke;
	}

	public void setEngineStroke(int engineStroke) {
		this.engineStroke = engineStroke;
	}

	public String getLicenseStatus() {
		return licenseStatus;
	}

	public void setLicenseStatus(String licenseStatus) {
		this.licenseStatus = licenseStatus;
	}

	public String getRegisteredAddress() {
		return registeredAddress;
	}

	public void setRegisteredAddress(String registeredAddress) {
		this.registeredAddress = registeredAddress;
	}

	public String getImoNo() {
		return imoNo;
	}

	public void setImoNo(String imoNo) {
		this.imoNo = imoNo;
	}


	public Date getInsertTime() {
		return insertTime;
	}

	public void setInsertTime(Date insertTime) {
		this.insertTime = insertTime;
	}

	public int getInsertedBy() {
		return insertedBy;
	}

	public void setInsertedBy(int insertedBy) {
		this.insertedBy = insertedBy;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public int getUpdateBy() {
		return updateBy;
	}

	public void setUpdateBy(int updateBy) {
		this.updateBy = updateBy;
	}

	public String getSyncRequired() {
		return syncRequired;
	}

	public void setSyncRequired(String syncRequired) {
		this.syncRequired = syncRequired;
	}

	public String getOfficialNumber() {
		return officialNumber;
	}

	public void setOfficialNumber(String officialNumber) {
		this.officialNumber = officialNumber;
	}

	public String getAttachment() {
		return attachment;
	}

	public void setAttachment(String attachment) {
		this.attachment = attachment;
	}

	public FleetDto getFleet() {
		return fleet;
	}

	public void setFleet(FleetDto fleet) {
		this.fleet = fleet;
	}
	
	
	
/*	
	public String getVesselType() {
		return vesselType;
	}

	public void setVesselType(String vesselType) {
		this.vesselType = vesselType;
	}

	public String getVesselStatus() {
		return vesselStatus;
	}

	public void setVesselStatus(String vesselStatus) {
		this.vesselStatus = vesselStatus;
	}
	
	public String getOwnerId() {
		return ownerId;
	}

	public void setOwnerId(String ownerId) {
		this.ownerId = ownerId;
	}

	
	public String getPortOfRegistry() {
		return portOfRegistry;
	}

	public void setPortOfRegistry(String portOfRegistry) {
		this.portOfRegistry = portOfRegistry;
	}
	public String getVesselFlag() {
		return vesselFlag;
	}

	public void setVesselFlag(String vesselFlag) {
		this.vesselFlag = vesselFlag;
	}
*/

	
	

	/*
	 * @Mapping("status") private StatusDto statusDto;
	 */

	/*@Mapping("veselType")
	private VesselTypeDto vesselTypeDto;
*//*
	@Mapping("engneType")
	private EngineTypeDto engineTypeDto;*/

/*	@Mapping("owner")
	private OwnerDto ownerDto;

	@Mapping("port")
	private PortDto portDto;
*/
}
	