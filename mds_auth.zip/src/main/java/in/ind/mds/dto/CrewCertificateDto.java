/**
 * 
 */
package in.ind.mds.dto;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import org.dozer.Mapping;

/**
 * @author shalini
 *
 */
public class CrewCertificateDto implements Serializable{
	private static final long serialVersionUID = 1174889796248L;
	private String id;
	private String certNo;
	private String issuedAt;
	private Date issuedDate;
	private Date expiryDate;
	private String issuedBy;
	private String remarks;
	private String activeStatus;
	private Date insertTime;
	private Date updateTime;
	private String syncRequired;

	@Mapping("status")
	private StatusDto status;
	
	@Mapping("staff")
	private StaffDto staff;
	
	@Mapping("crewCertificateType")
	private CrewCertificateTypeDto crewCertificateType;
	
	@Mapping("crewCertificateName")
	private CrewCertificateNameDto crewCertificateName;
	
	@Mapping("crewCertificateCapacity")
	private  CrewCertifCapacityDto crewCertificateCapacity;
	
	private List<String> certificateDoc;
	
	List<String> softDeleteDocPaths;
	
	@Mapping("insertedBy")
	private UserDto insertedBy;
	
	@Mapping("updatedBy")
	private UserDto updatedBy;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCertNo() {
		return certNo;
	}

	public void setCertNo(String certNo) {
		this.certNo = certNo;
	}

	public String getIssuedAt() {
		return issuedAt;
	}

	public void setIssuedAt(String issuedAt) {
		this.issuedAt = issuedAt;
	}

	public Date getIssuedDate() {
		return issuedDate;
	}

	public void setIssuedDate(Date issuedDate) {
		this.issuedDate = issuedDate;
	}

	public Date getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}

	public String getIssuedBy() {
		return issuedBy;
	}

	public void setIssuedBy(String issuedBy) {
		this.issuedBy = issuedBy;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getActiveStatus() {
		return activeStatus;
	}

	public void setActiveStatus(String activeStatus) {
		this.activeStatus = activeStatus;
	}

	public Date getInsertTime() {
		return insertTime;
	}

	public void setInsertTime(Date insertTime) {
		this.insertTime = insertTime;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public String getSyncRequired() {
		return syncRequired;
	}

	public void setSyncRequired(String syncRequired) {
		this.syncRequired = syncRequired;
	}

	public StatusDto getStatus() {
		return status;
	}

	public void setStatus(StatusDto status) {
		this.status = status;
	}

	public StaffDto getStaff() {
		return staff;
	}

	public void setStaff(StaffDto staff) {
		this.staff = staff;
	}

	public String getCertificateDocFieldName() {
		return "CertificateDoc";
	}

	/**
	 * @return the certificateDoc
	 */
	public List<String> getCertificateDoc() {
		return certificateDoc;
	}

	/**
	 * @param certificateDoc the certificateDoc to set
	 */
	public void setCertificateDoc(List<String> certificateDoc) {
		this.certificateDoc = certificateDoc;
	}

	public CrewCertificateTypeDto getCrewCertificateType() {
		return crewCertificateType;
	}

	public void setCrewCertificateType(CrewCertificateTypeDto crewCertificateType) {
		this.crewCertificateType = crewCertificateType;
	}

	public CrewCertificateNameDto getCrewCertificateName() {
		return crewCertificateName;
	}

	public void setCrewCertificateName(CrewCertificateNameDto crewCertificateName) {
		this.crewCertificateName = crewCertificateName;
	}

	public CrewCertifCapacityDto getCrewCertificateCapacity() {
		return crewCertificateCapacity;
	}

	public void setCrewCertificateCapacity(CrewCertifCapacityDto crewCertificateCapacity) {
		this.crewCertificateCapacity = crewCertificateCapacity;
	}
	
	public UserDto getInsertedBy() {
		return insertedBy;
	}

	public void setInsertedBy(UserDto insertedBy) {
		this.insertedBy = insertedBy;
	}

	public UserDto getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(UserDto updatedBy) {
		this.updatedBy = updatedBy;
	}

	/**
	 * @return the softDeleteDocPaths
	 */
	public List<String> getSoftDeleteDocPaths() {
		return softDeleteDocPaths;
	}

	/**
	 * @param softDeleteDocPaths the softDeleteDocPaths to set
	 */
	public void setSoftDeleteDocPaths(List<String> softDeleteDocPaths) {
		this.softDeleteDocPaths = softDeleteDocPaths;
	}

}
