/**
 * 
 */
package in.ind.mds.dto;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import org.dozer.Mapping;

/**
 * @author mds_kiruthika
 *
 */
public class StaffDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 199420742105306864L;
	
	private String id;
	private String staffType;
	private String staffCode;
	private String firstName;
	private String lastName;
	private String fullName;
	private String passportNumber;
	private String dob;
	private int age;
	private char gender;
	private String maritalStatus;
	private String placeOfBirth;
	private long height;
	private long weight;
	private String phone;
	private String mobile;
	private String email;
	private String fax;
	private String city;
	private String religion;
	private String qualification;
	private String presentAddress;
	private String homeAddress;
	private String remarks;
	private char hasLogin;
	private String userName;
	private String password;
	private String repeatPassword;
	private Date joinDate;
	private String bloodGroup;
	private String syncRequired;
	private Date insertTime;
	private Date updateTime;
	
	@Mapping("country")
	private CountryDto country;
	
	@Mapping("companyName")
	private CompanyDto companyName;
	
	@Mapping("role")
	private RoleDto role;
	
	@Mapping("nationality")
	private NationalityDto nationality;
	
	@Mapping("status")
	private StatusDto status;
	
	@Mapping("staffStatus")
	private StatusDto staffStatus;
	
	@Mapping("insertedBy")
	private UserDto insertedBy;
	
	@Mapping("updatedBy")
	private UserDto updatedBy;
	
	private List<String> staffPic;
	
	private List<String> staffDoc;
	
	public String getStaffPicFieldName() {
		return "StaffPic";
	}
	
	public String getStaffDocFieldName() {
		return "StaffDoc";
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getStaffType() {
		return staffType;
	}

	public void setStaffType(String staffType) {
		this.staffType = staffType;
	}

	public String getStaffCode() {
		return staffCode;
	}

	public void setStaffCode(String staffCode) {
		this.staffCode = staffCode;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getPassportNumber() {
		return passportNumber;
	}

	public void setPassportNumber(String passportNumber) {
		this.passportNumber = passportNumber;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public char getGender() {
		return gender;
	}

	public void setGender(char gender) {
		this.gender = gender;
	}

	public String getMaritalStatus() {
		return maritalStatus;
	}

	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}

	public String getPlaceOfBirth() {
		return placeOfBirth;
	}

	public void setPlaceOfBirth(String placeOfBirth) {
		this.placeOfBirth = placeOfBirth;
	}

	public long getHeight() {
		return height;
	}

	public void setHeight(long height) {
		this.height = height;
	}

	public long getWeight() {
		return weight;
	}

	public void setWeight(long weight) {
		this.weight = weight;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getFax() {
		return fax;
	}

	public void setFax(String fax) {
		this.fax = fax;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getReligion() {
		return religion;
	}

	public void setReligion(String religion) {
		this.religion = religion;
	}

	public String getQualification() {
		return qualification;
	}

	public void setQualification(String qualification) {
		this.qualification = qualification;
	}

	public String getPresentAddress() {
		return presentAddress;
	}

	public void setPresentAddress(String presentAddress) {
		this.presentAddress = presentAddress;
	}

	public String getHomeAddress() {
		return homeAddress;
	}

	public void setHomeAddress(String homeAddress) {
		this.homeAddress = homeAddress;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public char getHasLogin() {
		return hasLogin;
	}

	public void setHasLogin(char hasLogin) {
		this.hasLogin = hasLogin;
	}

	public Date getJoinDate() {
		return joinDate;
	}

	public void setJoinDate(Date joinDate) {
		this.joinDate = joinDate;
	}

	public String getBloodGroup() {
		return bloodGroup;
	}

	public void setBloodGroup(String bloodGroup) {
		this.bloodGroup = bloodGroup;
	}

	public String getSyncRequired() {
		return syncRequired;
	}

	public void setSyncRequired(String syncRequired) {
		this.syncRequired = syncRequired;
	}

	public Date getInsertTime() {
		return insertTime;
	}

	public void setInsertTime(Date insertTime) {
		this.insertTime = insertTime;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public CountryDto getCountry() {
		return country;
	}

	public void setCountry(CountryDto country) {
		this.country = country;
	}

	public CompanyDto getCompanyName() {
		return companyName;
	}

	public void setCompanyName(CompanyDto companyName) {
		this.companyName = companyName;
	}

	public RoleDto getRole() {
		return role;
	}

	public void setRole(RoleDto role) {
		this.role = role;
	}

	public NationalityDto getNationality() {
		return nationality;
	}

	public void setNationality(NationalityDto nationality) {
		this.nationality = nationality;
	}

	public StatusDto getStatus() {
		return status;
	}

	public void setStatus(StatusDto status) {
		this.status = status;
	}

	public StatusDto getStaffStatus() {
		return staffStatus;
	}

	public void setStaffStatus(StatusDto staffStatus) {
		this.staffStatus = staffStatus;
	}

	public UserDto getInsertedBy() {
		return insertedBy;
	}

	public void setInsertedBy(UserDto insertedBy) {
		this.insertedBy = insertedBy;
	}

	public UserDto getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(UserDto updatedBy) {
		this.updatedBy = updatedBy;
	}

	/**
	 * @return the staffPic
	 */
	public List<String> getStaffPic() {
		return staffPic;
	}

	/**
	 * @param staffPic the staffPic to set
	 */
	public void setStaffPic(List<String> staffPic) {
		this.staffPic = staffPic;
	}

	/**
	 * @return the staffDoc
	 */
	public List<String> getStaffDoc() {
		return staffDoc;
	}

	/**
	 * @param staffDoc the staffDoc to set
	 */
	public void setStaffDoc(List<String> staffDoc) {
		this.staffDoc = staffDoc;
	}

	/**
	 * @return the userName
	 */
	public String getUserName() {
		return userName;
	}

	/**
	 * @param userName the userName to set
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}

	/**
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * @param password the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 * @return the repeatPassword
	 */
	public String getRepeatPassword() {
		return repeatPassword;
	}

	/**
	 * @param repeatPassword the repeatPassword to set
	 */
	public void setRepeatPassword(String repeatPassword) {
		this.repeatPassword = repeatPassword;
	}
	
}
