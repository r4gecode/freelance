/**
 * 
 */
package in.ind.mds.dto;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import org.dozer.Mapping;

/**
 * @author shalini
 *
 */
public class CrewTrainingDto implements Serializable{
	
	private static final long serialVersionUID = 1174352096248L;
	
	private String id;
	private String courseName;
	private String trainingInstitute;
	private Date startDate;
	private Date endDate;
	private String certNo;
	private Date validTill;
	private String syncRequired;
	private Date insertTime;
	private Date updateTime;

	@Mapping("staff")
	private StaffDto staff;
	
	private List<String> trainingDoc;
	
	List<String> softDeleteDocPaths;

	@Mapping("status")
	private StatusDto status;

	@Mapping("crewCourseCategory")
	private CrewCourseCategoryDto crewCourseCategory;
	
	@Mapping("insertedBy")
	private UserDto insertedBy;
	
	@Mapping("updatedBy")
	private UserDto updatedBy;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCourseName() {
		return courseName;
	}

	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}

	public String getTrainingInstitute() {
		return trainingInstitute;
	}

	public void setTrainingInstitute(String trainingInstitute) {
		this.trainingInstitute = trainingInstitute;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public String getCertNo() {
		return certNo;
	}

	public void setCertNo(String certNo) {
		this.certNo = certNo;
	}

	public Date getValidTill() {
		return validTill;
	}

	public void setValidTill(Date validTill) {
		this.validTill = validTill;
	}

	public String getSyncRequired() {
		return syncRequired;
	}

	public void setSyncRequired(String syncRequired) {
		this.syncRequired = syncRequired;
	}

	public Date getInsertTime() {
		return insertTime;
	}

	public void setInsertTime(Date insertTime) {
		this.insertTime = insertTime;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	/**
	 * @return the staff
	 */
	public StaffDto getStaff() {
		return staff;
	}

	/**
	 * @param staff the staff to set
	 */
	public void setStaff(StaffDto staff) {
		this.staff = staff;
	}

	/**
	 * @return the trainingDoc
	 */
	public List<String> getTrainingDoc() {
		return trainingDoc;
	}

	/**
	 * @param trainingDoc the trainingDoc to set
	 */
	public void setTrainingDoc(List<String> trainingDoc) {
		this.trainingDoc = trainingDoc;
	}

	public String getTrainingDocFieldName() {
		return "TrainingDoc";
	}
	
	public StatusDto getStatus() {
		return status;
	}

	public void setStatus(StatusDto status) {
		this.status = status;
	}

	public CrewCourseCategoryDto getCrewCourseCategory() {
		return crewCourseCategory;
	}

	public void setCrewCourseCategory(CrewCourseCategoryDto crewCourseCategory) {
		this.crewCourseCategory = crewCourseCategory;
	}

	public UserDto getInsertedBy() {
		return insertedBy;
	}

	public void setInsertedBy(UserDto insertedBy) {
		this.insertedBy = insertedBy;
	}

	public UserDto getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(UserDto updatedBy) {
		this.updatedBy = updatedBy;
	}

	/**
	 * @return the softDeleteDocPaths
	 */
	public List<String> getSoftDeleteDocPaths() {
		return softDeleteDocPaths;
	}

	/**
	 * @param softDeleteDocPaths the softDeleteDocPaths to set
	 */
	public void setSoftDeleteDocPaths(List<String> softDeleteDocPaths) {
		this.softDeleteDocPaths = softDeleteDocPaths;
	}

}
