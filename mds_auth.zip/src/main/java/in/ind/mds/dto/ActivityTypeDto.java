/**
 * 
 */
package in.ind.mds.dto;

import java.io.Serializable;
import java.util.Date;

import org.dozer.Mapping;

/**
 * @author mds-arockia
 *
 */
public class ActivityTypeDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 117478938384548L;
	
	private String id;
	private String activityName;
	private String direction;
	private Date insertTime;
	private Integer insertedBy;
	private Date updateTime;
	private Integer updatedBy;

	@Mapping("status")
	private StatusDto status;
	
	private String syncRequired;

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the activityName
	 */
	public String getActivityName() {
		return activityName;
	}

	/**
	 * @param activityName the activityName to set
	 */
	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}

	/**
	 * @return the direction
	 */
	public String getDirection() {
		return direction;
	}

	/**
	 * @param direction the direction to set
	 */
	public void setDirection(String direction) {
		this.direction = direction;
	}

	/**
	 * @return the insertTime
	 */
	public Date getInsertTime() {
		return insertTime;
	}

	/**
	 * @param insertTime the insertTime to set
	 */
	public void setInsertTime(Date insertTime) {
		this.insertTime = insertTime;
	}

	/**
	 * @return the insertedBy
	 */
	public Integer getInsertedBy() {
		return insertedBy;
	}

	/**
	 * @param insertedBy the insertedBy to set
	 */
	public void setInsertedBy(Integer insertedBy) {
		this.insertedBy = insertedBy;
	}

	/**
	 * @return the updateTime
	 */
	public Date getUpdateTime() {
		return updateTime;
	}

	/**
	 * @param updateTime the updateTime to set
	 */
	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	/**
	 * @return the updatedBy
	 */
	public Integer getUpdatedBy() {
		return updatedBy;
	}

	/**
	 * @param updatedBy the updatedBy to set
	 */
	public void setUpdatedBy(Integer updatedBy) {
		this.updatedBy = updatedBy;
	}

	/**
	 * @return the status
	 */
	public StatusDto getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(StatusDto status) {
		this.status = status;
	}

	/**
	 * @return the syncRequired
	 */
	public String getSyncRequired() {
		return syncRequired;
	}

	/**
	 * @param syncRequired the syncRequired to set
	 */
	public void setSyncRequired(String syncRequired) {
		this.syncRequired = syncRequired;
	}

}
