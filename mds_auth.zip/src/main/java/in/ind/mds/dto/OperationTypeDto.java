/**
 * 
 */
package in.ind.mds.dto;

import java.io.Serializable;
import java.util.Date;

import org.dozer.Mapping;

/**
 * @author dharani
 *
 */
public class OperationTypeDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 154686366326L;
	
	private String id;
	private String operationTypeName;
	private Date insertTime;
	
	@Mapping("insertedBy")
	private UserDto insertedBy;
	
	private Date updateTime;
	
@Mapping("updatedBy")
	private UserDto updatedBy;
	
	
	@Mapping("status")
	private StatusDto status;


	public String getId() {
		return id;
	}


	public void setId(String id) {
		this.id = id;
	}


	public String getOperationTypeName() {
		return operationTypeName;
	}


	public void setOperationTypeName(String operationTypeName) {
		this.operationTypeName = operationTypeName;
	}


	public Date getInsertTime() {
		return insertTime;
	}


	public void setInsertTime(Date insertTime) {
		this.insertTime = insertTime;
	}


	public UserDto getInsertedBy() {
		return insertedBy;
	}


	public void setInsertedBy(UserDto insertedBy) {
		this.insertedBy = insertedBy;
	}


	public Date getUpdateTime() {
		return updateTime;
	}


	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}


	public UserDto getUpdatedBy() {
		return updatedBy;
	}


	public void setUpdatedBy(UserDto updatedBy) {
		this.updatedBy = updatedBy;
	}


	public StatusDto getStatus() {
		return status;
	}


	public void setStatus(StatusDto status) {
		this.status = status;
	}


}
