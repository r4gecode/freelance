package in.ind.mds.dto;

import java.io.Serializable;
import java.util.Date;

import org.dozer.Mapping;

public class UserRoleDto implements Serializable

{

	/**
	 * 
	 */
	private static final long serialVersionUID = -3760632039813605537L;

	private String id;
	private Date insertTime;
	private Integer insertedBy;
	private Date updateTime;
	private Integer updatedBy;
	private String syncRequired;
	
	@Mapping("status")
	private StatusDto status;

	@Mapping("user")
	private UserDto user;
	
	@Mapping("role")
	private RoleDto role;


	public StatusDto getStatus() {
		return status;
	}
	public void setStatus(StatusDto status) {
		this.status = status;
	}
	public UserDto getUser() {
		return user;
	}
	public void setUser(UserDto user) {
		this.user = user;
	}

	public RoleDto getRole() {
		return role;
	}
	public void setRole(RoleDto role) {
		this.role = role;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public Date getInsertTime() {
		return insertTime;
	}
	public void setInsertTime(Date insertTime) {
		this.insertTime = insertTime;
	}
	public Integer getInsertedBy() {
		return insertedBy;
	}
	public void setInsertedBy(Integer insertedBy) {
		this.insertedBy = insertedBy;
	}
	public Date getUpdateTime() {
		return updateTime;
	}
	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}
	public Integer getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(Integer updatedBy) {
		this.updatedBy = updatedBy;
	}
	public String getSyncRequired() {
		return syncRequired;
	}
	public void setSyncRequired(String syncRequired) {
		this.syncRequired = syncRequired;
	}
	
	/*@Mapping("status")
	private StatusDto statusDto;
	
	@Mapping("role")
	private RoleDto roleDto;

*/	
	
}