package in.ind.mds.dto;

import java.io.Serializable;
import java.util.Date;

public class SyncDataDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3748840933784413563L;
	private transient String id;
	private transient String vesselId;
	private transient String entityClassName;
	private transient String action;
	private transient String syncData;
	private transient String fleetWideSync;
	private transient String origin;
	private transient Date utcTime;
	private transient String syncModule;
	private transient Date insertTime;
	private transient int insertedBy;
	private transient Date updateTime;
	private transient int updatedBy;

	public SyncDataDto() {
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getVesselId() {
		return vesselId;
	}

	public void setVesselId(String vesselId) {
		this.vesselId = vesselId;
	}

	public String getEntityClassName() {
		return entityClassName;
	}

	public void setEntityClassName(String entityClassName) {
		this.entityClassName = entityClassName;
	}

	public String getSyncData() {
		return syncData;
	}

	public void setSyncData(String syncData) {
		this.syncData = syncData;
	}

	public String getFleetWideSync() {
		return fleetWideSync;
	}

	public void setFleetWideSync(String fleetWideSync) {
		this.fleetWideSync = fleetWideSync;
	}

	public String getOrigin() {
		return origin;
	}

	public void setOrigin(String origin) {
		this.origin = origin;
	}

	public Date getUtcTime() {
		return utcTime;
	}

	public void setUtcTime(Date utcTime) {
		this.utcTime = utcTime;
	}

	public String getSyncModule() {
		return syncModule;
	}

	public void setSyncModule(String syncModule) {
		this.syncModule = syncModule;
	}

	public Date getInsertTime() {
		return insertTime;
	}

	public void setInsertTime(Date insertTime) {
		this.insertTime = insertTime;
	}

	public int getInsertedBy() {
		return insertedBy;
	}

	public void setInsertedBy(int insertedBy) {
		this.insertedBy = insertedBy;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public int getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(int updatedBy) {
		this.updatedBy = updatedBy;
	}

}
