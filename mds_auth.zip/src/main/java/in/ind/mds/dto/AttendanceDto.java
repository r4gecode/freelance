/**
 * 
 */
package in.ind.mds.dto;

import java.io.Serializable;
import java.util.Date;


import org.dozer.Mapping;




/**
 * @author shalini
 *
 */
public class AttendanceDto implements Serializable{
	
	private static final long serialVersionUID = 11554322824248L;
	
	private String id;

	private String recordId;

	private String attendanceOrigin;

	private String syncRequired;

	private Date insertTime;

	private Date updateTime;
	
	@Mapping("staff")
	private StaffDto staff;

	@Mapping("status")
	private StatusDto status;
	
	@Mapping("insertedBy")
	private UserDto insertedBy;

	@Mapping("updatedBy")
	private UserDto updatedBy;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getRecordId() {
		return recordId;
	}

	public void setRecordId(String recordId) {
		this.recordId = recordId;
	}

	

	public String getAttendanceOrigin() {
		return attendanceOrigin;
	}

	public void setAttendanceOrigin(String attendanceOrigin) {
		this.attendanceOrigin = attendanceOrigin;
	}

	public String getSyncRequired() {
		return syncRequired;
	}

	public void setSyncRequired(String syncRequired) {
		this.syncRequired = syncRequired;
	}

	public Date getInsertTime() {
		return insertTime;
	}

	public void setInsertTime(Date insertTime) {
		this.insertTime = insertTime;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public StaffDto getStaff() {
		return staff;
	}

	public void setStaff(StaffDto staff) {
		this.staff = staff;
	}

	public StatusDto getStatus() {
		return status;
	}

	public void setStatus(StatusDto status) {
		this.status = status;
	}

	public UserDto getInsertedBy() {
		return insertedBy;
	}

	public void setInsertedBy(UserDto insertedBy) {
		this.insertedBy = insertedBy;
	}

	public UserDto getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(UserDto updatedBy) {
		this.updatedBy = updatedBy;
	}

}
