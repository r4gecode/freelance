/**
 * 
 */
package in.ind.mds.dto;

import java.io.Serializable;
import java.util.Date;

import org.dozer.Mapping;

/**
 * @author mds-arockia
 *
 */
public class CompanyDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 11889756248L;

	private String id;
	
	@Mapping("parentCompany")
	private CompanyDto parentCompany;
	
	private String companyName;
	private String city;

	@Mapping("country")
	private CountryDto country;
	
	private String fax;
	private String companyAddress;
	private String phoneNumber;
	private String companyLogo;
	private String companyInformation;
	private String licenseActive;
	private Date insertTime;
	private int insertedBy;
	private Date updateTime;
	private int updatedBy;
	private String syncRequired;
	private String runningHours;
	private String counterReading;
	private Date counterReadingStartDate;
	
	@Mapping("status")
	private StatusDto status;
	
	
	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}
	/**
	 * @return the parentCompany
	 */
	/**
	 * @return the companyName
	 */
	public String getCompanyName() {
		return companyName;
	}
	/**
	 * @return the parentCompany
	 */
	public CompanyDto getParentCompany() {
		return parentCompany;
	}
	/**
	 * @param parentCompany the parentCompany to set
	 */
	public void setParentCompany(CompanyDto parentCompany) {
		this.parentCompany = parentCompany;
	}
	/**
	 * @param companyName the companyName to set
	 */
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	/**
	 * @return the city
	 */
	public String getCity() {
		return city;
	}
	/**
	 * @param city the city to set
	 */
	public void setCity(String city) {
		this.city = city;
	}
	/**
	 * @return the country
	 */
	public CountryDto getCountry() {
		return country;
	}
	/**
	 * @param country the country to set
	 */
	public void setCountry(CountryDto country) {
		this.country = country;
	}
	/**
	 * @return the fax
	 */
	public String getFax() {
		return fax;
	}
	/**
	 * @param fax the fax to set
	 */
	public void setFax(String fax) {
		this.fax = fax;
	}
	/**
	 * @return the companyAddress
	 */
	public String getCompanyAddress() {
		return companyAddress;
	}
	/**
	 * @param companyAddress the companyAddress to set
	 */
	public void setCompanyAddress(String companyAddress) {
		this.companyAddress = companyAddress;
	}
	/**
	 * @return the phoneNumber
	 */
	public String getPhoneNumber() {
		return phoneNumber;
	}
	/**
	 * @param phoneNumber the phoneNumber to set
	 */
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	/**
	 * @return the companyLogo
	 */
	public String getCompanyLogo() {
		return companyLogo;
	}
	/**
	 * @param companyLogo the companyLogo to set
	 */
	public void setCompanyLogo(String companyLogo) {
		this.companyLogo = companyLogo;
	}
	/**
	 * @return the companyInformation
	 */
	public String getCompanyInformation() {
		return companyInformation;
	}
	/**
	 * @param companyInformation the companyInformation to set
	 */
	public void setCompanyInformation(String companyInformation) {
		this.companyInformation = companyInformation;
	}
	/**
	 * @return the licenseActive
	 */
	public String getLicenseActive() {
		return licenseActive;
	}
	/**
	 * @param licenseActive the licenseActive to set
	 */
	public void setLicenseActive(String licenseActive) {
		this.licenseActive = licenseActive;
	}
	/**
	 * @return the insertTime
	 */
	public Date getInsertTime() {
		return insertTime;
	}
	/**
	 * @param insertTime the insertTime to set
	 */
	public void setInsertTime(Date insertTime) {
		this.insertTime = insertTime;
	}
	/**
	 * @return the insertedBy
	 */
	public int getInsertedBy() {
		return insertedBy;
	}
	/**
	 * @param insertedBy the insertedBy to set
	 */
	public void setInsertedBy(int insertedBy) {
		this.insertedBy = insertedBy;
	}
	/**
	 * @return the updateTime
	 */
	public Date getUpdateTime() {
		return updateTime;
	}
	/**
	 * @param updateTime the updateTime to set
	 */
	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}
	/**
	 * @return the updatedBy
	 */
	public int getUpdatedBy() {
		return updatedBy;
	}
	/**
	 * @param updatedBy the updatedBy to set
	 */
	public void setUpdatedBy(int updatedBy) {
		this.updatedBy = updatedBy;
	}
	/**
	 * @return the syncRequired
	 */
	public String getSyncRequired() {
		return syncRequired;
	}
	/**
	 * @param syncRequired the syncRequired to set
	 */
	public void setSyncRequired(String syncRequired) {
		this.syncRequired = syncRequired;
	}
	/**
	 * @return the status
	 */
	public StatusDto getStatus() {
		return status;
	}
	/**
	 * @param status the status to set
	 */
	public void setStatus(StatusDto status) {
		this.status = status;
	}
	public String getRunningHours() {
		return runningHours;
	}
	public void setRunningHours(String runningHours) {
		this.runningHours = runningHours;
	}
	public String getCounterReading() {
		return counterReading;
	}
	public void setCounterReading(String counterReading) {
		this.counterReading = counterReading;
	}
	public Date getCounterReadingStartDate() {
		return counterReadingStartDate;
	}
	public void setCounterReadingStartDate(Date counterReadingStartDate) {
		this.counterReadingStartDate = counterReadingStartDate;
	}
	
	
	
}
