/**
 * 
 */
package in.ind.mds.dto;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import org.dozer.Mapping;

/**
 * @author Hinaya
 *
 */
public class DrillSchedulerDto implements Serializable{
	
	private static final long serialVersionUID = 1154322823448L;
	
	private String id;

	private String drillNumber;
	
	private String procedure;
	
	private int frequency;
	
	private String frequencyType;
	
	private Date lastDoneDate;
	
	private Date nextDueDate;
	
	private String syncRequired;

	private String drillName;
	
	private Date insertTime;	
	
	private Date updateTime;

	@Mapping("insertedBy")
	private UserDto insertedBy;
	
	@Mapping("updatedBy")
	private UserDto updatedBy;
	
	@Mapping("drillCategories")
	private DrillCategoriesDto drillCategories;
	
	@Mapping("fleet")
	private FleetDto fleet;
	
	@Mapping("vessel")
	private VesselDto vessel;

	@Mapping("status")
	private StatusDto status;
	
	private List<String> drillSchedulerDocs;
	
	private List<DrillAgendaDto> drillAgenda;
		
	private List<String> drillAgendaIds;
	

	public List<String> getDrillAgendaIds() {
		return drillAgendaIds;
	}

	public void setDrillAgendaIds(List<String> drillAgendaId) {
		this.drillAgendaIds = drillAgendaId;
	}

	public List<DrillAgendaDto> getDrillAgenda() {
		return drillAgenda;
	}

	public void setDrillAgenda(List<DrillAgendaDto> drillAgenda) {
		this.drillAgenda = drillAgenda;
	}

	public DrillCategoriesDto getDrillCategories() {
		return drillCategories;
	}

	public String getDrillSchedulerDocsFieldName() {
		return "drillSchedulerDocs";
	}
	
	public void setDrillCategories(DrillCategoriesDto drillCategories) {
		this.drillCategories = drillCategories;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getDrillNumber() {
		return drillNumber;
	}

	public void setDrillNumber(String drillNumber) {
		this.drillNumber = drillNumber;
	}

	

	public String getProcedure() {
		return procedure;
	}

	public void setProcedure(String procedure) {
		this.procedure = procedure;
	}

	public int getFrequency() {
		return frequency;
	}

	public void setFrequency(int frequency) {
		this.frequency = frequency;
	}

	public String getFrequencyType() {
		return frequencyType;
	}

	public void setFrequencyType(String frequencyType) {
		this.frequencyType = frequencyType;
	}

	public Date getLastDoneDate() {
		return lastDoneDate;
	}

	public void setLastDoneDate(Date lastDoneDate) {
		this.lastDoneDate = lastDoneDate;
	}

	public Date getNextDueDate() {
		return nextDueDate;
	}

	public void setNextDueDate(Date nextDueDate) {
		this.nextDueDate = nextDueDate;
	}

	public String getSyncRequired() {
		return syncRequired;
	}

	public void setSyncRequired(String syncRequired) {
		this.syncRequired = syncRequired;
	}

	public String getDrillName() {
		return drillName;
	}

	public void setDrillName(String drillName) {
		this.drillName = drillName;
	}

	public Date getInsertTime() {
		return insertTime;
	}

	public void setInsertTime(Date insertTime) {
		this.insertTime = insertTime;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public UserDto getInsertedBy() {
		return insertedBy;
	}

	public void setInsertedBy(UserDto insertedBy) {
		this.insertedBy = insertedBy;
	}

	public UserDto getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(UserDto updatedBy) {
		this.updatedBy = updatedBy;
	}

	public FleetDto getFleet() {
		return fleet;
	}

	public void setFleet(FleetDto fleet) {
		this.fleet = fleet;
	}

	public VesselDto getVessel() {
		return vessel;
	}

	public void setVessel(VesselDto vessel) {
		this.vessel = vessel;
	}

	public StatusDto getStatus() {
		return status;
	}

	public void setStatus(StatusDto status) {
		this.status = status;
	}

	public List<String> getDrillSchedulerDocs() {
		return drillSchedulerDocs;
	}

	public void setDrillSchedulerDocs(List<String> drillSchedulerDocs) {
		this.drillSchedulerDocs = drillSchedulerDocs;
	}
	
	
	
}
