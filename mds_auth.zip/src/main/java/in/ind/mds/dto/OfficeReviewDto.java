/**
 * 
 */
package in.ind.mds.dto;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import org.dozer.Mapping;

/**
 * @author shalini
 *
 */
public class OfficeReviewDto implements Serializable{
	private static final long serialVersionUID = 85997873558676103L;

	private String id;

	private String recordId;

	private String officeOrigin;

	private Date reviewedDate;

	private String reviewerComment;

	private String syncRequired;

	private Date insertTime;

	private Date updateTime;

	@Mapping("reviewedBy")
	private StaffDto reviewedBy;
	
	@Mapping("status")
	private StatusDto status;
	
	@Mapping("insertedBy")
	private UserDto insertedBy;
	

	
	@Mapping("updatedBy")
	private UserDto updatedBy;
	
	private List<String> officeReviewAtch;
	
	List<String> softDeleteDocPaths;


	public List<String> getOfficeReviewAtch() {
		return officeReviewAtch;
	}

	public void setOfficeReviewAtch(List<String> officeReviewAtch) {
		this.officeReviewAtch = officeReviewAtch;
	}

	public List<String> getSoftDeleteDocPaths() {
		return softDeleteDocPaths;
	}

	public void setSoftDeleteDocPaths(List<String> softDeleteDocPaths) {
		this.softDeleteDocPaths = softDeleteDocPaths;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getRecordId() {
		return recordId;
	}

	public void setRecordId(String recordId) {
		this.recordId = recordId;
	}

	

	public String getOfficeOrigin() {
		return officeOrigin;
	}

	public void setOfficeOrigin(String officeOrigin) {
		this.officeOrigin = officeOrigin;
	}

	public Date getReviewedDate() {
		return reviewedDate;
	}

	public void setReviewedDate(Date reviewedDate) {
		this.reviewedDate = reviewedDate;
	}

	public String getReviewerComment() {
		return reviewerComment;
	}

	public void setReviewerComment(String reviewerComment) {
		this.reviewerComment = reviewerComment;
	}

	public String getSyncRequired() {
		return syncRequired;
	}

	public void setSyncRequired(String syncRequired) {
		this.syncRequired = syncRequired;
	}

	public Date getInsertTime() {
		return insertTime;
	}

	public void setInsertTime(Date insertTime) {
		this.insertTime = insertTime;
	}

	

	public StaffDto getReviewedBy() {
		return reviewedBy;
	}

	public void setReviewedBy(StaffDto reviewedBy) {
		this.reviewedBy = reviewedBy;
	}

	public StatusDto getStatus() {
		return status;
	}

	public void setStatus(StatusDto status) {
		this.status = status;
	}

	public UserDto getInsertedBy() {
		return insertedBy;
	}

	public void setInsertedBy(UserDto insertedBy) {
		this.insertedBy = insertedBy;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public UserDto getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(UserDto updatedBy) {
		this.updatedBy = updatedBy;
	}

	/*public List<String> getOffcReviewAtch() {
		return officeReviewAtch;
	}

	public void setOffcReviewAtch(List<String> officeReviewAtch) {
		this.officeReviewAtch = officeReviewAtch;
	}*/
	
	public String getOfficeReviewAtchFieldName() {
		return "OfficeReviewAtch";
	}


}
