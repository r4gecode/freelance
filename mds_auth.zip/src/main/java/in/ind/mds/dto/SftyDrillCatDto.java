package in.ind.mds.dto;

import java.io.Serializable;
import java.util.Date;

import org.dozer.Mapping;

public class SftyDrillCatDto implements Serializable{
	
	private static final long serialVersionUID = 6135232812178026753L;
	private String id;
	private String catgName;
	private Date insertTime;
	private int insertedBy;
	private Date updateTime;
	private int updatedBy;
	private String syncRequired;
	private String recordStatus;
	
	@Mapping("status")
	private StatusDto statusDto;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCatgName() {
		return catgName;
	}

	public void setCatgName(String catgName) {
		this.catgName = catgName;
	}

	public Date getInsertTime() {
		return insertTime;
	}

	public void setInsertTime(Date insertTime) {
		this.insertTime = insertTime;
	}

	public int getInsertedBy() {
		return insertedBy;
	}

	public void setInsertedBy(int insertedBy) {
		this.insertedBy = insertedBy;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public int getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(int updatedBy) {
		this.updatedBy = updatedBy;
	}

	public String getSyncRequired() {
		return syncRequired;
	}

	public void setSyncRequired(String syncRequired) {
		this.syncRequired = syncRequired;
	}

	public String getRecordStatus() {
		return recordStatus;
	}

	public void setRecordStatus(String recordStatus) {
		this.recordStatus = recordStatus;
	}

	public StatusDto getStatusDto() {
		return statusDto;
	}

	public void setStatusDto(StatusDto statusDto) {
		this.statusDto = statusDto;
	}
	

}
