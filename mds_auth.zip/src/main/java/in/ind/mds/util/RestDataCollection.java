package in.ind.mds.util;

/**
 * Class is used to maintain the json response details with the proper structure
 *
 */
public class RestDataCollection {
	private String version = "1.0";
	private Object data;
	private RestDataCollectionError error;
	private int statusCode;

	/**
	 * @return the error
	 */
	public RestDataCollectionError getError() {
		return error;
	}

	/**
	 * @param error
	 *            the error to set
	 */
	public void setError(RestDataCollectionError error) {
		this.error = error;
	}

	/**
	 * @return the version
	 */
	public String getVersion() {
		return version;
	}

	/**
	 * @param version
	 *            the version to set
	 */
	public void setVersion(String version) {
		this.version = version;
	}

	/**
	 * @return the data
	 */
	public Object getData() {
		return data;
	}

	/**
	 * @param data
	 *            the data to set
	 */
	public void setData(Object data) {
		this.data = data;
	}

	public int getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(final int statusCode) {
		this.statusCode = statusCode;
	}
}
