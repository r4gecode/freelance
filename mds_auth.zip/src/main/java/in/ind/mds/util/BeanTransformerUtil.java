package in.ind.mds.util;

import java.util.ArrayList;
import java.util.List;

import org.dozer.DozerBeanMapper;
import org.dozer.loader.api.BeanMappingBuilder;
import org.dozer.loader.api.TypeMappingOptions;
import org.springframework.stereotype.Component;

/**
 * Class is used for bean to bean transform mapping using Dozer
 * 
 * @param <S> Source Object
 * @param <D> Transformer Bean Object
 */
@Component
public class BeanTransformerUtil<S, D> {

	/**
	 * Method is used to transform list of business object
	 * 
	 * @param entities
	 * @param transformer
	 * @return Transformer Object
	 */
	public List<D> transformListOfBO(final List<S> entities, final Class<D> transformer) {
		final List<D> transformers = new ArrayList<D>();
		for (S entity : entities) {
			final D transformObj = transformBO(entity, transformer);
			transformers.add(transformObj);
		}
		return transformers;
	}

	/**
	 * Method is used to transform a single business object
	 * 
	 * @param entity
	 * @param transformer
	 * @return
	 */
	public D transformBO(final S entity, final Class<D> transformer) {
		final DozerBeanMapper mapper = new DozerBeanMapper();
		mapper.addMapping(getBeanMappingBuilder(entity.getClass(), transformer));
		return (D) mapper.map(entity, transformer);
	}
	
	/**
	 * Bean Mapping builder to enable bean to bean mapping using annotation
	 * 
	 * @param source
	 * @param destination
	 * @return
	 */
	private BeanMappingBuilder getBeanMappingBuilder(final Class<?> source, final Class<?> destination) {
		final BeanMappingBuilder mappingBuilder = new BeanMappingBuilder() {
			@Override
			protected void configure() {
				mapping(source, destination, TypeMappingOptions.wildcard(true),
						TypeMappingOptions.dateFormat("yyyy-MM-dd HH:mm:ss"));
			}
		};
		return mappingBuilder;
	}
}
