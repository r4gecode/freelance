package in.ind.mds.util;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.TimeZone;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import in.ind.mds.dto.OfficeReviewDto;
import in.ind.mds.dto.StaffDetailsDto;
import in.ind.mds.exception.ApplicationServiceExecption;
import in.ind.mds.repo.dao.StatusDao;
import in.ind.mds.repo.entity.Status;

@Component
public class CommonUtil<T>{

	private static final Logger LOGGER = LoggerFactory.getLogger(CommonUtil.class);
	
	@Autowired
	private StatusDao statusDao;
	
	
	public Status getActiveStatus() {
		Optional<Status> status = statusDao.findById("1");
		return status.get();
	}
	
	public Status getSoftDeleteStatus() {
		Optional<Status> status = statusDao.findById("2");
		return status.get();
	}
	
	public void stringNullValidator(Object ...fields) throws ApplicationServiceExecption {
		for (Object field : fields) {
			if(field == null)
				throw new ApplicationServiceExecption(fields[fields.length - 1] + " must not be null", HttpStatus.NOT_FOUND);
		}
	}
	
	public void nullValidatorOnList(List<T> entityList) throws ApplicationServiceExecption{
		for (T entity : entityList) {
			try {
				Field field = entity.getClass().getDeclaredField("id");
				field.setAccessible(true);
					Object fieldValue = field.get(entity);
					if(fieldValue == null)
						throw new ApplicationServiceExecption("Id must not be null", HttpStatus.NOT_FOUND);
			} catch (NoSuchFieldException | SecurityException e) {
				e.printStackTrace();
			}catch (IllegalArgumentException | IllegalAccessException e) {
				e.printStackTrace();
			}
		}
	}
	
	public T stringJsonToEntity(final String jsonData, final Class<T> dtoClass) throws JsonParseException, JsonMappingException, IOException {
		ObjectMapper mapper = new ObjectMapper();
		T dto = mapper.readValue(jsonData, dtoClass);
		return dto;
	}
	
	public Pageable getPageable(final PageOrderBean pageBean) {
		PageRequest pageable = null;

		if (pageBean != null && pageBean.getOrderList() != null && !pageBean.getOrderList().isEmpty()) {
			pageable = new PageRequest(pageBean.getPageIndex() - 1, pageBean.getPageCount(),
					new Sort(pageBean.getOrderList()));
		} else {
			pageable = new PageRequest(0, 25); 
		}

		return pageable;
	}
	/*
	 * public void sendEmail(String text) throws TooveServiceExecption { final
	 * String username = "campaigngaurage@gmail.com"; final String password =
	 * "center@even";
	 * 
	 * Properties props = new Properties(); props.put("mail.smtp.auth", "true");
	 * props.put("mail.smtp.starttls.enable", "true"); props.put("mail.smtp.host",
	 * "smtp.gmail.com"); props.put("mail.smtp.port", "587");
	 * 
	 * Session session = Session.getInstance(props, new javax.mail.Authenticator() {
	 * protected PasswordAuthentication getPasswordAuthentication() { return new
	 * PasswordAuthentication(username, password); } });
	 * 
	 * try { Message message = new MimeMessage(session); message.setFrom(new
	 * InternetAddress("campaigngaurage@gmail.com"));
	 * message.setRecipients(Message.RecipientType.TO,
	 * InternetAddress.parse("s.puspharaj@gmail.com"));
	 * message.setSubject("Testing Subject"); message.setText("" + text + "");
	 * 
	 * Transport.send(message);
	 * 
	 * } catch (MessagingException e) {
	 * LOGGER.debug("Exception while sending a mail : " + e.getMessage()); throw new
	 * GaurageServiceException("Unable to send a mail",
	 * HttpStatus.INTERNAL_SERVER_ERROR); } }
	 */

	public String formatCell(String value, Object... args) {
		return String.format(value, args);
	}

	public String systemHomeFolder(String rootFolder) {

		String osName = System.getProperty("os.name");
		String folder = System.getProperty("user.home");

		if (osName.equalsIgnoreCase("Linux") || osName.equalsIgnoreCase("Unix")) {
			folder += "/SyncDataFiles/";
		} else if (osName.equalsIgnoreCase("Windows")) {
			folder += "\\SyncDataFiles\\";
		}

		final File filePath = new File(folder);
		if (!filePath.exists()) {
			filePath.mkdirs();
		}

		return folder;
	}
	
	/**
	 * @param newObj
	 * @param oldObject
	 * @return
	 * @description Method used to dynamically get the json output of updated fields alone  : ensure all the entity passed have id as primary key
	 */
	public static StringBuilder getDeltaChange(Object newObj, Object oldObject) {
		StringBuilder updatedValues = null;
		ObjectMapper mapper  = new ObjectMapper();		
		if (newObj != null && oldObject != null) {
			Method[] methodsArr = oldObject.getClass().getDeclaredMethods();
			for (Method method : methodsArr) {

				if (method != null && method.getName().toUpperCase().startsWith("GET")) {
					Object oldValue = null;
					Object newValue = null;
					try {
						oldValue = method.invoke(oldObject, null);
						newValue = method.invoke(newObj, null);


					} catch (IllegalAccessException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IllegalArgumentException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (InvocationTargetException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					// Find if there is difference
					// collect in object : form a json					
					if ((oldValue != null && newValue == null) || (oldValue == null && newValue != null)
							|| (oldValue != null && newValue != null
									&& !oldValue.toString().equals(newValue.toString()))

					) {
						if (updatedValues == null) {
							updatedValues = new StringBuilder();
							updatedValues.append("{");
						}

						String methodName = method.getName().substring(3, 4).toLowerCase() +method.getName().substring(4);
						try {
							updatedValues.append("\"").append(methodName).append("\":").append(mapper.writeValueAsString(newValue)).append(",");
						} catch (JsonProcessingException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();//TODO : exception logging
						}

					} 
				}
			}
			if(!isNullOrEmpty(updatedValues)) {
				//updatedValues = updatedValues.replace(updatedValues.length()-1, updatedValues.length(), "");
				//Append Primary Key
				try {
					Method method = oldObject.getClass().getDeclaredMethod("getId",null);
					Object obj = method.invoke(oldObject, null);				
					updatedValues.append("\"").append("id").append("\":").append(mapper.writeValueAsString(obj));
				}catch(Exception e) {
					e.printStackTrace();
					updatedValues = updatedValues.replace(updatedValues.length()-1, updatedValues.length(), "");
				}
				updatedValues.append("}");
			}			
		}

		return updatedValues;
	}
	
	public static boolean isNullOrEmpty(Object data) {
		boolean isNull=true;
		if(data != null && 
				!data.toString().trim().equals("")) {
			isNull = false;
		}
		return isNull;
	}
	
	public static Date getUTCTime() {
		Date gmtDate = null;
		SimpleDateFormat dateFormatGmt = new SimpleDateFormat("yyyy-MMM-dd HH:mm:ss");
		dateFormatGmt.setTimeZone(TimeZone.getTimeZone("GMT"));

		//Local time zone   
		SimpleDateFormat dateFormatLocal = new SimpleDateFormat("yyyy-MMM-dd HH:mm:ss");

		//Time in GMT
		try {
			gmtDate =  dateFormatLocal.parse( dateFormatGmt.format(new Date()));
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();//TODO : exception logging
		}	
		
		return gmtDate;
        
	}
	
	public static String getUTCTimeString(String dateFormart) {
		String gmtStr = null;
		SimpleDateFormat dateFormatGmt = new SimpleDateFormat(dateFormart);
		dateFormatGmt.setTimeZone(TimeZone.getTimeZone("GMT"));

		//Time in GMT
		try {
			gmtStr = dateFormatGmt.format(new Date());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();//TODO : exception logging
		}	
		
		return gmtStr;
        
	
        
	}

}
