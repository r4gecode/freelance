package in.ind.mds.util;

import java.util.List;

import org.springframework.data.domain.Sort.Order;

public class PageOrderBean {

	private int pageIndex;

	private int pageCount;

	private List<Order> orderList;

	public int getPageIndex() {
		return pageIndex;
	}

	public void setPageIndex(int pageIndex) {
		this.pageIndex = pageIndex;
	}

	public int getPageCount() {
		return pageCount;
	}

	public void setPageCount(int pageCount) {
		this.pageCount = pageCount;
	}

	public List<Order> getOrderList() {
		return orderList;
	}

	public void setOrderList(List<Order> orderList) {
		this.orderList = orderList;
	}

}
