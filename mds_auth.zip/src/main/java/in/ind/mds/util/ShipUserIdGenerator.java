package in.ind.mds.util;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;

import org.hibernate.HibernateException;
import org.hibernate.annotations.GenericGenerators;
import org.hibernate.engine.spi.SharedSessionContractImplementor;
import org.hibernate.id.IdentifierGenerator;


public class ShipUserIdGenerator implements IdentifierGenerator {

	@Override
	public Serializable generate(SharedSessionContractImplementor session, Object object) throws HibernateException {
		String prefix = "SHIP-";
		Connection connection = session.connection();
		try {
			/*
			 * ArrayList<Integer> list = new ArrayList<Integer>(); for (int i = 1; i < 100;
			 * i++) { list.add(new Integer(i)); }
			 */ PreparedStatement ps = connection.prepareStatement("SELECT MAX(value) as value from office.TB_USER");

			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				int id = rs.getInt("value");

				String code = UniqueRandomIdGenerator.getUniqueRandomId(prefix, UniqueRandomIdGenerator.Type.PREFIX)
						+ id;
				System.out.println("Generated Stock Code: " + code);
				return code;
			}

//			Collections.shuffle(list);
//			for (int i = 0; i < 3; i++) {
//				System.out.println(list.get(i));
//			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

}