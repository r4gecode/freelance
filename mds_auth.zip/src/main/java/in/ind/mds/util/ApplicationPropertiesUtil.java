package in.ind.mds.util;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;

@Configuration
@PropertySource("classpath:application-config.properties")
public class ApplicationPropertiesUtil {
	
    @Autowired
    Environment env;

    public String syncRootFolder() {
    	return getPropertyValue("mds.path.rootPath");
    }
    
    
    
    public String dateFormat() {
    	return getPropertyValue("mds.export.dateFormat");
    }
    
    private String getPropertyValue(String property) {
    	return env.getProperty(property);
    }
        
}
