package in.ind.mds.util;

/**
 * Parent class to maintain the response object
 */
public class RestDataApplicationResponse {
	private RestDataCollection restDatacollection;
	private Boolean booleanStatus;

	/**
	 * @param collection
	 */
	public RestDataApplicationResponse(RestDataCollection restDatacollection) {
		super();
		this.restDatacollection = restDatacollection;
	}

	public RestDataApplicationResponse(Boolean booleanStatus) {
		super();
		this.booleanStatus = booleanStatus;
	}

	public RestDataCollection getCollection() {
		return restDatacollection;
	}

	public void setCollection(RestDataCollection restDatacollection) {
		this.restDatacollection = restDatacollection;
	}

	public Boolean getBooleanStatus() {
		return booleanStatus;
	}

	public void setBooleanStatus(Boolean booleanStatus) {
		this.booleanStatus = booleanStatus;
	}

}
