package in.ind.mds.util;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.Table;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class DBUtil {


	@Autowired
	EntityManager entityManager;
	
	public <T> String getTableName(Class entityClass) {
	    //Check whether @Table annotation is present on the class.
	    Table t = (Table) entityClass.getAnnotation(Table.class);
	    //System.out.println("table =="+t);
	    String tableName =  t.name();
	    return tableName;
	}
	
	public String getNextSequence(Class entityClass) {
		Object seqObject 		= null;
		Query q 			= null;
		String sequenceName = null;
		String tableName 	= null;
		String generatedSeq = null;
		Integer seqInt = null;
		synchronized(this) {		
			tableName = getTableName(entityClass);
			
			if(tableName != null) {
				sequenceName = "S_"+tableName;

				q = entityManager.createNativeQuery("select next value for "+sequenceName);
				seqObject = (Object) q.getSingleResult();	
				System.out.println("getNextSequence--"+seqObject.toString());
				generatedSeq = "OFF"+seqObject.toString();//TODO : Get prefix (OFF/VESSELCODE) dynamically 			
			}
		}
		
		return generatedSeq;
	}
	
	public void saveEntity(Object entityObj) {
		entityManager.persist(entityObj);
	}

	public void updateEntity(Object entityObj) {
		entityManager.merge(entityObj);
	}

	
}
