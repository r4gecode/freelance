/**
 * 
 */
package in.ind.mds.repo.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import in.ind.mds.repo.entity.CrewCertifCapacity;
import in.ind.mds.repo.entity.Status;

/**
 * @author mds-arockia
 *
 */
public interface CrewCertifCapacityDao extends JpaRepository<CrewCertifCapacity, String>{
	
	List<CrewCertifCapacity> findByCertifCapacityAndStatusNot(String certifCapacity, Status status);

	List<CrewCertifCapacity> findByCertifCapacityAndStatusNotAndIdNot(String certifCapacity, Status status, String id);
	
	CrewCertifCapacity findByIdAndStatusNot(String id, Status status);
	
	List<CrewCertifCapacity> findByIdInAndStatusNot(List<String> id, Status status);
	
	@Modifying
	@Transactional
	@Query(value = "SELECT * FROM TB_CREW_CERTIFICATE_CAPACITY WHERE RECORD_STATUS != 2", nativeQuery = true)
	List<CrewCertifCapacity> findAllCrewCertifCapacity();
	
}
