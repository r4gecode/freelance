/**
 * 
 */
package in.ind.mds.repo.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import in.ind.mds.repo.entity.Likelihood;
import in.ind.mds.repo.entity.Status;

/**
 * @author shalini
 *
 */
public interface LikelihoodDao extends JpaRepository<Likelihood, String>{

	Likelihood findByItemNumberAndStatusNot(int itemNumber, Status softDeleteStatus);

	
	@Query(value = "SELECT * FROM TB_LIKELIHOOD WHERE (TYPE_OF_LIKELIHOOD != ?3 AND ITEM_NUMBER != ?2) AND RECORD_STATUS !=2 AND ID != ?1", nativeQuery = true)
	List<Likelihood> uniqueCheckForUpdate(String id, int itemNumber, String typeOfLikelihood);

	Likelihood findByIdAndStatusNot(String id, Status softDeleteStatus);

	
	@Modifying
	@Transactional
	@Query(value = "SELECT * FROM TB_LIKELIHOOD WHERE RECORD_STATUS != 2", nativeQuery = true)
	List<Likelihood> findAllLikelihood();

	//List<Likelihood> saveAll(List<Likelihood> existingLikelihoodList);

	List<Likelihood> findByIdInAndStatusNot(List<String> likelihoodId, Status softDeleteStatus);

}
