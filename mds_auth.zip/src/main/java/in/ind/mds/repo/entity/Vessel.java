package in.ind.mds.repo.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "TB_VESSEL")
public class Vessel implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1156035417621513664L;

	@Id
	@Column(name = "ID", nullable = false, unique = true)
	private String id;

	@Column(name = "VESSEL_CODE")
	private String vesselCode;

	@Column(name = "VESSEL_NAME")
	private String vesselName;

	
	@Column(name = "VESSEL_DESCRIPTION")
	private String vesselDescription;

	@Column(name = "VESSEL_EMAIL")
	private String vesselEmail;

	@Column(name = "VESSEL_CALL_SIGN")
	private String vesselCallSign;

	@Column(name = "CLASS_NOTATION")
	private String classNotation;

	@Column(name = "CLASS_NAME")
	private String className;

	@Column(name = "INMARSAT_SATCOM_NUMBER")
	private int inmarsatSatcomNumber;

	@Column(name = "VESSEL_BHP")
	private String vesselBhp;

	@Column(name = "SERVICE_SPEED")
	private String serviceSpeed;

	@Column(name = "VESSEL_DWT")
	private String vesselDwt;

	@Column(name = "ENGINE_NUMBER")
	private String engineNumber;

	@Column(name = "VESSEL_LENGTH")
	private float vesselLength;

	@Column(name = "MODEL_NUMBER")
	private String modelNumber;

	@Column(name = "NO_OF_CREW")
	private int crewStrength;

	@Column(name = "HULL_NUMBER")
	private String hullNumber;

	@Column(name = "OPERATOR")
	private String operator;

	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "PREV_DRY_DOCK_DATE")
	private Date preDryDockDate;

	@Column(name = "SHIP_BUILDER")
	private String shipBuilder;

	@Column(name = "BUILT_YEAR")
	private int builtYear;

	@Column(name = "MAIN_ENGINE_MAKE")
	private String mainEngineMake;

	@Column(name = "GROSS_TONNAGE")
	private float grossTonnage;

	@Column(name = "NET_TONNAGE")
	private float netTonnage;

	@Column(name = "ENGINE_STROKE")
	private int engineStroke;

	@Column(name = "LICENSE_STATUS")
	private String licenseStatus;

	@Column(name = "REGISTERED_ADDRESS")
	private String registeredAddress;

	@Column(name = "IMO_NO")
	private String imoNo;


	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "INSERT_TIME")
	private Date insertTime;

	@Column(name = "INSERTED_BY")
	private int insertedBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "UPDATE_TIME")
	private Date updateTime;

	@Column(name = "UPDATED_BY")
	private int updateBy;

	@Column(name = "SYNC_REQUIRED")
	private String syncRequired;

	@Column(name = "OFFICIAL_NUMBER")
	private String officialNumber;
	
	@Column(name="ATTACHMENT")
	private String attachment;
	
	
	
	/*@Column(name = "OWNER_ID")
	private String ownerId;

	@Column(name = "PORT_OF_REGISTRY")
	private String portOfRegistry;

	@Column(name = "VESSEL_TYPE")
	private String vesselType;

	@Column(name = "RECORD_STATUS")
	private String vesselStatus;

	@Column(name = "VESSEL_FLAG")
	private String vesselFlag;
*/
	
	
	@ManyToOne
	@JoinColumn(name="VESSEL_TYPE")
	private VesselType veselType;
	
	@ManyToOne
	@JoinColumn(name="RECORD_STATUS")
	private Status status;
	
	@ManyToOne
	@JoinColumn(name="OWNER_ID")
	private Owner owner;
	
	@ManyToOne
	@JoinColumn(name="PORT_OF_REGISTRY")
	private Port port;
	
	@ManyToOne
	@JoinColumn(name="VESSEL_FLAG")
	private Country country;
	
	@ManyToOne
	@JoinColumn(name = "FLEET_NAME")
	private Fleet fleet;


	public Country getCountry() {
		return country;
	}

	public void setCountry(Country country) {
		this.country = country;
	}

	public VesselType getVeselType() {
		return veselType;
	}

	public void setVeselType(VesselType veselType) {
		this.veselType = veselType;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	public Owner getOwner() {
		return owner;
	}

	public void setOwner(Owner owner) {
		this.owner = owner;
	}

	public Port getPort() {
		return port;
	}

	public void setPort(Port port) {
		this.port = port;
	}
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getVesselCode() {
		return vesselCode;
	}

	public void setVesselCode(String vesselCode) {
		this.vesselCode = vesselCode;
	}

	public String getVesselName() {
		return vesselName;
	}

	public void setVesselName(String vesselName) {
		this.vesselName = vesselName;
	}


	public String getVesselDescription() {
		return vesselDescription;
	}

	public void setVesselDescription(String vesselDescription) {
		this.vesselDescription = vesselDescription;
	}

	public String getVesselEmail() {
		return vesselEmail;
	}

	public void setVesselEmail(String vesselEmail) {
		this.vesselEmail = vesselEmail;
	}	
	


	
/*	
	public String getVesselType() {
		return vesselType;
	}

	public void setVesselType(String vesselType) {
		this.vesselType = vesselType;
	}

	public String getVesselStatus() {
		return vesselStatus;
	}

	public void setVesselStatus(String vesselStatus) {
		this.vesselStatus = vesselStatus;
	}

	public String getVesselFlag() {
		return vesselFlag;
	}

	public void setVesselFlag(String vesselFlag) {
		this.vesselFlag = vesselFlag;
	}
	
	public String getPortOfRegistry() {
		return portOfRegistry;
	}

	public void setPortOfRegistry(String portOfRegistry) {
		this.portOfRegistry = portOfRegistry;
	}

	public String getOwnerId() {
		return ownerId;
	}

	public void setOwnerId(String ownerId) {
		this.ownerId = ownerId;
	}
*/
	
	
	
	

	public String getVesselCallSign() {
		return vesselCallSign;
	}

	public void setVesselCallSign(String vesselCallSign) {
		this.vesselCallSign = vesselCallSign;
	}

	public String getClassNotation() {
		return classNotation;
	}

	public void setClassNotation(String classNotation) {
		this.classNotation = classNotation;
	}

	public String getClassName() {
		return className;
	}

	public void setClassName(String className) {
		this.className = className;
	}

	public int getInmarsatSatcomNumber() {
		return inmarsatSatcomNumber;
	}

	public void setInmarsatSatcomNumber(int inmarsatSatcomNumber) {
		this.inmarsatSatcomNumber = inmarsatSatcomNumber;
	}

	public String getVesselBhp() {
		return vesselBhp;
	}

	public void setVesselBhp(String vesselBhp) {
		this.vesselBhp = vesselBhp;
	}

	public String getServiceSpeed() {
		return serviceSpeed;
	}

	public void setServiceSpeed(String serviceSpeed) {
		this.serviceSpeed = serviceSpeed;
	}

	public String getVesselDwt() {
		return vesselDwt;
	}

	public void setVesselDwt(String vesselDwt) {
		this.vesselDwt = vesselDwt;
	}

	public String getEngineNumber() {
		return engineNumber;
	}

	public void setEngineNumber(String engineNumber) {
		this.engineNumber = engineNumber;
	}

	public float getVesselLength() {
		return vesselLength;
	}

	public void setVesselLength(float vesselLength) {
		this.vesselLength = vesselLength;
	}

	public String getModelNumber() {
		return modelNumber;
	}

	public void setModelNumber(String modelNumber) {
		this.modelNumber = modelNumber;
	}

	public int getCrewStrength() {
		return crewStrength;
	}

	public void setCrewStrength(int crewStrength) {
		this.crewStrength = crewStrength;
	}

	public String getHullNumber() {
		return hullNumber;
	}

	public void setHullNumber(String hullNumber) {
		this.hullNumber = hullNumber;
	}

	public String getOperator() {
		return operator;
	}
	
	public void setOperator(String operator) {
		this.operator = operator;
	}

	
	public Date getPreDryDockDate() {
		return preDryDockDate;
	}

	public void setPreDryDockDate(Date preDryDockDate) {
		this.preDryDockDate = preDryDockDate;
	}

	public String getShipBuilder() {
		return shipBuilder;
	}

	public void setShipBuilder(String shipBuilder) {
		this.shipBuilder = shipBuilder;
	}

	public int getBuiltYear() {
		return builtYear;
	}

	public void setBuiltYear(int builtYear) {
		this.builtYear = builtYear;
	}

	public String getMainEngineMake() {
		return mainEngineMake;
	}

	public void setMainEngineMake(String mainEngineMake) {
		this.mainEngineMake = mainEngineMake;
	}

	public float getGrossTonnage() {
		return grossTonnage;
	}

	public void setGrossTonnage(float grossTonnage) {
		this.grossTonnage = grossTonnage;
	}

	public float getNetTonnage() {
		return netTonnage;
	}

	public void setNetTonnage(float netTonnage) {
		this.netTonnage = netTonnage;
	}

	public int getEngineStroke() {
		return engineStroke;
	}

	public void setEngineStroke(int engineStroke) {
		this.engineStroke = engineStroke;
	}

	public String getLicenseStatus() {
		return licenseStatus;
	}

	public void setLicenseStatus(String licenseStatus) {
		this.licenseStatus = licenseStatus;
	}

	public String getRegisteredAddress() {
		return registeredAddress;
	}

	public void setRegisteredAddress(String registeredAddress) {
		this.registeredAddress = registeredAddress;
	}

	public String getImoNo() {
		return imoNo;
	}

	public void setImoNo(String imoNo) {
		this.imoNo = imoNo;
	}

	
	public Date getInsertTime() {
		return insertTime;
	}

	public void setInsertTime(Date insertTime) {
		this.insertTime = insertTime;
	}

	public int getInsertedBy() {
		return insertedBy;
	}

	public void setInsertedBy(int insertedBy) {
		this.insertedBy = insertedBy;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public int getUpdateBy() {
		return updateBy;
	}

	public void setUpdateBy(int updateBy) {
		this.updateBy = updateBy;
	}

	public String getSyncRequired() {
		return syncRequired;
	}

	public void setSyncRequired(String syncRequired) {
		this.syncRequired = syncRequired;
	}

	public String getOfficialNumber() {
		return officialNumber;
	}

	public void setOfficialNumber(String officialNumber) {
		this.officialNumber = officialNumber;
	}

	public String getAttachment() {
		return attachment;
	}

	public void setAttachment(String attachment) {
		this.attachment = attachment;
	}

	public Fleet getFleet() {
		return fleet;
	}

	public void setFleet(Fleet fleet) {
		this.fleet = fleet;
	}
	

	/*
	 * @OneToOne
	 * 
	 * @JoinColumn(name = "RECORD_STATUS", insertable = false, updatable = false)
	 * private Status status;
	 */

	/*@OneToOne
	@JoinColumn(name = "VESSEL_TYPE", insertable = false, updatable = false)
	private VesselType veselType;
*/
	/*@OneToOne
	@JoinColumn(name = "ENGINE_TYPE", insertable = false, updatable = false)
	private EngineType engneType;
*/
	/*?
	@OneToOne
	@JoinColumn(name = "PORT_OF_REGISTRY", insertable = false, updatable = false)
	private Port port;;
*/

	
	
	
	
	
}