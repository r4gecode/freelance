package in.ind.mds.repo.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "TB_PMS_COMPONENT")

public class Component implements Serializable 
{
	/**
	 * 
	 */
	private static final long serialVersionUID = -7865762256871719153L;

	@Id
	@Column(name = "ID", nullable = false, unique = true)
	private String id;

	@ManyToOne
	@JoinColumn(name="VESSEL_ID")
	private Vessel vessel;
	
	@Column(name = "COMPONENT_NAME")
	private String componentName;

	@Column(name = "CODE")
	private String code;

	@Column(name = "COMPONENT_TYPE")
	private String componentType;

	@Column(name = "MAKE")
	private String make;

	@Column(name = "SFI_CODE")
	private String sfiCode;

	@Column(name = "CAPACITY")
	private String capacity;

	@Column(name = "INITIAL_RUNNING_HOURS")
	private int initialRunningHours;

	@Column(name = "REMARKS")
	private String remarks;

	@Column(name = "MFG_YEAR")
	private int mfgYear;

	@Column(name = "MFG_CONTACT")
	private String mfgContact;

	@Column(name = "DRAW_NUMBER")
	private int drawNumber;

	@Column(name = "CLASS_COMP_CODE")
	private int classCompCode;

	@Column(name = "MAKER")
	private String maker;

	@Column(name = "CRITICAL_INDI")
	private String criticalIndi;
	
	@Column(name = "MODEL_NUMBER")
	private String modelNumber;
	
	@Column(name = "SERIAL_NUMBER")
	private String serialNumber;

	@ManyToOne
	@JoinColumn(name="PARENT_ID")
	private Component component;
	
	@Column(name = "CLASS_COMPONENT")
	private String classComponent;

	@Column(name = "OIL_CONSUMPTION")
	private String oilConsumption;
	
	@Column(name = "ATTACHMENT")
	private String attachment;
	
	@ManyToOne
	@JoinColumn(name="GROUP_ID")
	private ComponentMain componentMain;

	@ManyToOne
	@JoinColumn(name="SPARE_PARTS")
	private Inventory inventory;
	
	
	/************running hours*******************/
	@Column(name="RH_REQUIRED")
	private String rHRequired;
	
	@Column(name = "RUNNING_HOURS")
	private float runningHours;
	
	@Column(name = "TOTAL_RH")
	private float totalRH;
	
	@Column(name = "AVG_RH")
	private float avgRH;

	@Column(name = "LAST_RH_ENTRY_DATE")
	private Date lastRHEntryDate;
	
	@Column(name = "COMMENTS")
	private String comments;
	
	@Column(name = "TOTAL_NOD_COMPONENT_RUN")
	private int totalNODComponentRun;
	
	@Column(name="CR_REQUIRED")
	private String cRRequired;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="CR_START_DATE")
	private Date cRStartDate;
	

//	@JsonIgnore
//	@ManyToMany(fetch = FetchType.LAZY,
//    cascade = {
//        CascadeType.PERSIST,
//        CascadeType.MERGE
//    },
//    mappedBy = "components")
//	private Set<RunningHour> rHList = new HashSet<>();

	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "INSERT_TIME")
	private Date insertTime;

	@Column(name = "INSERTED_BY")
	private int insertedBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "UPDATE_TIME")
	private Date updateTime;

	@Column(name = "UPDATED_BY")
	private int updatedBy;
	
	@Column(name = "SYNC_REQUIRED")
	private String syncRequired;
	
	@ManyToOne
	@JoinColumn(name="RECORD_STATUS")
	private Status status;

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the vessel
	 */
	public Vessel getVessel() {
		return vessel;
	}

	/**
	 * @param vessel the vessel to set
	 */
	public void setVessel(Vessel vessel) {
		this.vessel = vessel;
	}

	/**
	 * @return the componentName
	 */
	public String getComponentName() {
		return componentName;
	}

	/**
	 * @param componentName the componentName to set
	 */
	public void setComponentName(String componentName) {
		this.componentName = componentName;
	}

	/**
	 * @return the code
	 */
	public String getCode() {
		return code;
	}

	/**
	 * @param code the code to set
	 */
	public void setCode(String code) {
		this.code = code;
	}

	/**
	 * @return the componentType
	 */
	public String getComponentType() {
		return componentType;
	}

	/**
	 * @param componentType the componentType to set
	 */
	public void setComponentType(String componentType) {
		this.componentType = componentType;
	}

	/**
	 * @return the make
	 */
	public String getMake() {
		return make;
	}

	/**
	 * @param make the make to set
	 */
	public void setMake(String make) {
		this.make = make;
	}

	/**
	 * @return the sfiCode
	 */
	public String getSfiCode() {
		return sfiCode;
	}

	/**
	 * @param sfiCode the sfiCode to set
	 */
	public void setSfiCode(String sfiCode) {
		this.sfiCode = sfiCode;
	}

	/**
	 * @return the capacity
	 */
	public String getCapacity() {
		return capacity;
	}

	/**
	 * @param capacity the capacity to set
	 */
	public void setCapacity(String capacity) {
		this.capacity = capacity;
	}

	/**
	 * @return the initialRunningHours
	 */
	public int getInitialRunningHours() {
		return initialRunningHours;
	}

	/**
	 * @param initialRunningHours the initialRunningHours to set
	 */
	public void setInitialRunningHours(int initialRunningHours) {
		this.initialRunningHours = initialRunningHours;
	}

	/**
	 * @return the remarks
	 */
	public String getRemarks() {
		return remarks;
	}

	/**
	 * @param remarks the remarks to set
	 */
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	/**
	 * @return the mfgYear
	 */
	public int getMfgYear() {
		return mfgYear;
	}

	/**
	 * @param mfgYear the mfgYear to set
	 */
	public void setMfgYear(int mfgYear) {
		this.mfgYear = mfgYear;
	}

	/**
	 * @return the mfgContact
	 */
	public String getMfgContact() {
		return mfgContact;
	}

	/**
	 * @param mfgContact the mfgContact to set
	 */
	public void setMfgContact(String mfgContact) {
		this.mfgContact = mfgContact;
	}

	/**
	 * @return the drawNumber
	 */
	public int getDrawNumber() {
		return drawNumber;
	}

	/**
	 * @param drawNumber the drawNumber to set
	 */
	public void setDrawNumber(int drawNumber) {
		this.drawNumber = drawNumber;
	}

	/**
	 * @return the classCompCode
	 */
	public int getClassCompCode() {
		return classCompCode;
	}

	/**
	 * @param classCompCode the classCompCode to set
	 */
	public void setClassCompCode(int classCompCode) {
		this.classCompCode = classCompCode;
	}

	/**
	 * @return the maker
	 */
	public String getMaker() {
		return maker;
	}

	/**
	 * @param maker the maker to set
	 */
	public void setMaker(String maker) {
		this.maker = maker;
	}

	/**
	 * @return the criticalIndi
	 */
	public String getCriticalIndi() {
		return criticalIndi;
	}

	/**
	 * @param criticalIndi the criticalIndi to set
	 */
	public void setCriticalIndi(String criticalIndi) {
		this.criticalIndi = criticalIndi;
	}

	/**
	 * @return the modelNumber
	 */
	public String getModelNumber() {
		return modelNumber;
	}

	/**
	 * @param modelNumber the modelNumber to set
	 */
	public void setModelNumber(String modelNumber) {
		this.modelNumber = modelNumber;
	}

	/**
	 * @return the serialNumber
	 */
	public String getSerialNumber() {
		return serialNumber;
	}

	/**
	 * @param serialNumber the serialNumber to set
	 */
	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}

	/**
	 * @return the component
	 */
	public Component getComponent() {
		return component;
	}

	/**
	 * @param component the component to set
	 */
	public void setComponent(Component component) {
		this.component = component;
	}

	/**
	 * @return the classComponent
	 */
	public String getClassComponent() {
		return classComponent;
	}

	/**
	 * @param classComponent the classComponent to set
	 */
	public void setClassComponent(String classComponent) {
		this.classComponent = classComponent;
	}

	/**
	 * @return the oilConsumption
	 */
	public String getOilConsumption() {
		return oilConsumption;
	}

	/**
	 * @param oilConsumption the oilConsumption to set
	 */
	public void setOilConsumption(String oilConsumption) {
		this.oilConsumption = oilConsumption;
	}

	/**
	 * @return the attachment
	 */
	public String getAttachment() {
		return attachment;
	}

	/**
	 * @param attachment the attachment to set
	 */
	public void setAttachment(String attachment) {
		this.attachment = attachment;
	}

	/**
	 * @return the componentMain
	 */
	public ComponentMain getComponentMain() {
		return componentMain;
	}

	/**
	 * @param componentMain the componentMain to set
	 */
	public void setComponentMain(ComponentMain componentMain) {
		this.componentMain = componentMain;
	}

	/**
	 * @return the inventory
	 */
	public Inventory getInventory() {
		return inventory;
	}

	/**
	 * @param inventory the inventory to set
	 */
	public void setInventory(Inventory inventory) {
		this.inventory = inventory;
	}

	/**
	 * @return the rHRequired
	 */
	public String getrHRequired() {
		return rHRequired;
	}

	/**
	 * @param rHRequired the rHRequired to set
	 */
	public void setrHRequired(String rHRequired) {
		this.rHRequired = rHRequired;
	}

	/**
	 * @return the runningHours
	 */
	public float getRunningHours() {
		return runningHours;
	}

	/**
	 * @param runningHours the runningHours to set
	 */
	public void setRunningHours(float runningHours) {
		this.runningHours = runningHours;
	}

	/**
	 * @return the totalRH
	 */
	public float getTotalRH() {
		return totalRH;
	}

	/**
	 * @param totalRH the totalRH to set
	 */
	public void setTotalRH(float totalRH) {
		this.totalRH = totalRH;
	}

	/**
	 * @return the avgRH
	 */
	public float getAvgRH() {
		return avgRH;
	}

	/**
	 * @param avgRH the avgRH to set
	 */
	public void setAvgRH(float avgRH) {
		this.avgRH = avgRH;
	}

	/**
	 * @return the lastRHEntryDate
	 */
	public Date getLastRHEntryDate() {
		return lastRHEntryDate;
	}

	/**
	 * @param lastRHEntryDate the lastRHEntryDate to set
	 */
	public void setLastRHEntryDate(Date lastRHEntryDate) {
		this.lastRHEntryDate = lastRHEntryDate;
	}

	/**
	 * @return the comments
	 */
	public String getComments() {
		return comments;
	}

	/**
	 * @param comments the comments to set
	 */
	public void setComments(String comments) {
		this.comments = comments;
	}

	/**
	 * @return the totalNODComponentRun
	 */
	public int getTotalNODComponentRun() {
		return totalNODComponentRun;
	}

	/**
	 * @param totalNODComponentRun the totalNODComponentRun to set
	 */
	public void setTotalNODComponentRun(int totalNODComponentRun) {
		this.totalNODComponentRun = totalNODComponentRun;
	}

	/**
	 * @return the cRRequired
	 */
	public String getcRRequired() {
		return cRRequired;
	}

	/**
	 * @param cRRequired the cRRequired to set
	 */
	public void setcRRequired(String cRRequired) {
		this.cRRequired = cRRequired;
	}

	/**
	 * @return the cRStartDate
	 */
	public Date getcRStartDate() {
		return cRStartDate;
	}

	/**
	 * @param cRStartDate the cRStartDate to set
	 */
	public void setcRStartDate(Date cRStartDate) {
		this.cRStartDate = cRStartDate;
	}

	/**
	 * @return the insertTime
	 */
	public Date getInsertTime() {
		return insertTime;
	}

	/**
	 * @param insertTime the insertTime to set
	 */
	public void setInsertTime(Date insertTime) {
		this.insertTime = insertTime;
	}

	/**
	 * @return the insertedBy
	 */
	public int getInsertedBy() {
		return insertedBy;
	}

	/**
	 * @param insertedBy the insertedBy to set
	 */
	public void setInsertedBy(int insertedBy) {
		this.insertedBy = insertedBy;
	}

	/**
	 * @return the updateTime
	 */
	public Date getUpdateTime() {
		return updateTime;
	}

	/**
	 * @param updateTime the updateTime to set
	 */
	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	/**
	 * @return the updatedBy
	 */
	public int getUpdatedBy() {
		return updatedBy;
	}

	/**
	 * @param updatedBy the updatedBy to set
	 */
	public void setUpdatedBy(int updatedBy) {
		this.updatedBy = updatedBy;
	}

	/**
	 * @return the syncRequired
	 */
	public String getSyncRequired() {
		return syncRequired;
	}

	/**
	 * @param syncRequired the syncRequired to set
	 */
	public void setSyncRequired(String syncRequired) {
		this.syncRequired = syncRequired;
	}

	/**
	 * @return the status
	 */
	public Status getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(Status status) {
		this.status = status;
	}

}
