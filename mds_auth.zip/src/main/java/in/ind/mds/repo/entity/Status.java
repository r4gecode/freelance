package in.ind.mds.repo.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "TB_STATUS")
public class Status implements Serializable 
{

	/**
	 * 
	 */
	private static final long serialVersionUID = -4546606184649635000L;

	@Id
	@Column(name = "ID", nullable = false, unique = true)
	private String id;

	@Column(name = "STATUS_NAME")
	private String statusName;

	@Column(name = "STATUS_DESC")
	private String statusDesc;

	@Column(name = "SYNC_REQUIRED")
	private String syncRequired;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getStatusName() {
		return statusName;
	}

	public void setStatusName(String statusName) {
		this.statusName = statusName;
	}

	public String getStatusDesc() {
		return statusDesc;
	}

	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}

	public String getSyncRequired() {
		return syncRequired;
	}

	public void setSyncRequired(String syncRequired) {
		this.syncRequired = syncRequired;
	}

	
}
