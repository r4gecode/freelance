package in.ind.mds.repo.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "TB_ROLE")
public class Role implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 9073145092946251060L;

	@Id
	@Column(name = "ID", nullable = false, unique = true)
	private String id;

	@Column(name = "ROLE_NAME")
	private String roleName;

	@Column(name = "ROLE_TYPE")
	private String roleType;

	@Column(name = "ROLE_CODE")
	private String roleCode;
	
	@Column(name = "SEQUENCE_NUMBER")
	private Integer sequenceNumber;
	
	@ManyToOne
	@JoinColumn(name="DEPARTMENT")
	private Department department;
	
	@Column(name = "EQUIVALENT_ROLE")
	private String equivalentRole;
	
	@Column(name = "LOGIN_ACCOUNT")
	private String loginAccount;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "INSERT_TIME")
	private Date insertTime;

	@Column(name = "INSERTED_BY")
	private int insertedBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "UPDATE_TIME")
	private Date updateTime;

	@Column(name = "UPDATED_BY")
	private int updatedBy;
	

	@Column(name = "SYNC_REQUIRED")
	private String syncRequired;
	
	@ManyToOne
	@JoinColumn(name="RECORD_STATUS")
	private Status status;
	
	

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	public Date getInsertTime() {
		return insertTime;
	}

	public void setInsertTime(Date insertTime) {
		this.insertTime = insertTime;
	}

	public int getInsertedBy() {
		return insertedBy;
	}

	public void setInsertedBy(int insertedBy) {
		this.insertedBy = insertedBy;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public int getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(int updatedBy) {
		this.updatedBy = updatedBy;
	}

	public String getSyncRequired() {
		return syncRequired;
	}

	public void setSyncRequired(String syncRequired) {
		this.syncRequired = syncRequired;
	}

	public String getRoleType() {
		return roleType;
	}

	public void setRoleType(String roleType) {
		this.roleType = roleType;
	}

	public String getRoleCode() {
		return roleCode;
	}

	public void setRoleCode(String roleCode) {
		this.roleCode = roleCode;
	}

	public Integer getSequenceNumber() {
		return sequenceNumber;
	}

	public void setSequenceNumber(Integer sequenceNumber) {
		this.sequenceNumber = sequenceNumber;
	}

	public Department getDepartment() {
		return department;
	}

	public void setDepartment(Department department) {
		this.department = department;
	}

	public String getEquivalentRole() {
		return equivalentRole;
	}

	public void setEquivalentRole(String equivalentRole) {
		this.equivalentRole = equivalentRole;
	}

	public String getLoginAccount() {
		return loginAccount;
	}

	public void setLoginAccount(String loginAccount) {
		this.loginAccount = loginAccount;
	}
	
	
	
}