package in.ind.mds.repo.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "TB_SYNC_DATA")
public class SyncData implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6934886756839955420L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID")
	private int id;

	@Column(name = "VESSEL_ID")
	private String vesselId;

	@Column(name = "ENTITY_CLASS_NAME")
	private String entityClassName;

	@Column(name = "ACTIONS")
	private String action;

	@Column(name = "ACTION_DATA")
	private String syncData;

	@Column(name = "FLEET_WIDE_SYNC")
	private String fleetWideSync;

	@Column(name = "ORIGIN")
	private String origin;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "UTC_TIME")
	private Date utcTime;

	@Column(name = "SYNC_MODULE")
	private String syncModule;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "INSERT_TIME")
	private Date insertTime;

	@Column(name = "INSERTED_BY")
	private int insertedBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "UPDATE_TIME")
	private Date updateTime;

	@Column(name = "UPDATED_BY")
	private int updatedBy;

	public SyncData() {
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getVesselId() {
		return vesselId;
	}

	public void setVesselId(String vesselId) {
		this.vesselId = vesselId;
	}

	public String getEntityClassName() {
		return entityClassName;
	}

	public void setEntityClassName(String entityClassName) {
		this.entityClassName = entityClassName;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getSyncData() {
		return syncData;
	}

	public void setSyncData(String syncData) {
		this.syncData = syncData;
	}

	public String getFleetWideSync() {
		return fleetWideSync;
	}

	public void setFleetWideSync(String fleetWideSync) {
		this.fleetWideSync = fleetWideSync;
	}

	public String getOrigin() {
		return origin;
	}

	public void setOrigin(String origin) {
		this.origin = origin;
	}

	public Date getUtcTime() {
		return utcTime;
	}

	public void setUtcTime(Date utcTime) {
		this.utcTime = utcTime;
	}

	public String getSyncModule() {
		return syncModule;
	}

	public void setSyncModule(String syncModule) {
		this.syncModule = syncModule;
	}

	public Date getInsertTime() {
		return insertTime;
	}

	public void setInsertTime(Date insertTime) {
		this.insertTime = insertTime;
	}

	public int getInsertedBy() {
		return insertedBy;
	}

	public void setInsertedBy(int insertedBy) {
		this.insertedBy = insertedBy;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public int getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(int updatedBy) {
		this.updatedBy = updatedBy;
	}

}
