/**
 * 
 */
package in.ind.mds.repo.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * @author mds-arockia
 *
 */
@Entity
@Table(name = "TB_PMS_INVENTORY_CATALOG")
public class InventoryCatalog implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 11748897534548L;
	
	
	@Id
	@Column(name = "ID", unique = true, nullable = false)
	private String id;
	
	@ManyToOne
	@JoinColumn(name = "INVENTORY_CTGY_ID")
	private InventoryMain inventoryCtgy;
	
	@ManyToOne
	@JoinColumn(name = "COMPONENT_GROUP_ID")
	private ComponentMain componentGroup;
	
	@ManyToOne
	@JoinColumn(name = "FlEET_ID")
	private Fleet fleet;
	
	@ManyToOne
	@JoinColumn(name = "VESSEL_ID")
	private Vessel vessel;
	
	@ManyToOne
	@JoinColumn(name = "COMPONENT_ID")
	private Component component;
	
	@Column(name = "INVENTORY_NAME")
	private String inventoryName;
	
	@Column(name = "INVENTORY_CODE")
	private String inventoryCode;
	
	@ManyToOne
	@JoinColumn(name = "UOM")
	private Uom uom;
	
	@Column(name = "MAKE")
	private String make;
	
	@Column(name = "PART_NUMBER")
	private String partNumber;
	
	@Column(name = "DRAW_NUMBER")
	private String drawNumber;
	
	@Column(name = "MODEL_NUMBER")
	private String modelNumber;
	
	@Column(name = "POSITION_NUMBER")
	private String positionNumber;
	
	@Column(name = "SERIAL_NUMBER")
	private String serialNumber;
	
	@ManyToOne
	@JoinColumn(name = "LOCATIONS_ON_BOARD_ID")
	private LocOnboard locOnboard;
	
	@Column(name = "CRITICAL_INDI")
	private String criticalIndi;
	
	@Column(name = "EXPIRY_DATE")
	private Date expiryDate;

	@Column(name = "REMARKS")
	private String remarks;

	@Column(name = "ATTACHEMENT")
	private String attachement;

	@Column(name = "REORDER_LEVEL")
	private Float reOrderLevel;

	@Column(name = "REORDER_QTY")
	private Float reOrderQty;

	@Column(name = "MAX_QTY")
	private Float maxQty;

	@Column(name = "INSERT_TIME")
	private Date insertTime;

	@Column(name = "INSERTED_BY")
	private Integer insertedBy;

	@Column(name = "UPDATE_TIME")
	private Date updateTime;

	@Column(name = "UPDATED_BY")
	private Integer updatedBy;

	@ManyToOne
	@JoinColumn(name = "RECORD_STATUS")
	private Status status;

	@Column(name = "SYNC_REQUIRED")
	private String syncRequired;

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the inventoryCtgy
	 */
	public InventoryMain getInventoryCtgy() {
		return inventoryCtgy;
	}

	/**
	 * @param inventoryCtgy the inventoryCtgy to set
	 */
	public void setInventoryCtgy(InventoryMain inventoryCtgy) {
		this.inventoryCtgy = inventoryCtgy;
	}

	/**
	 * @return the componentGroup
	 */
	public ComponentMain getComponentGroup() {
		return componentGroup;
	}

	/**
	 * @param componentGroup the componentGroup to set
	 */
	public void setComponentGroup(ComponentMain componentGroup) {
		this.componentGroup = componentGroup;
	}

	/**
	 * @return the fleet
	 */
	public Fleet getFleet() {
		return fleet;
	}

	/**
	 * @param fleet the fleet to set
	 */
	public void setFleet(Fleet fleet) {
		this.fleet = fleet;
	}

	/**
	 * @return the vessel
	 */
	public Vessel getVessel() {
		return vessel;
	}

	/**
	 * @param vessel the vessel to set
	 */
	public void setVessel(Vessel vessel) {
		this.vessel = vessel;
	}

	/**
	 * @return the component
	 */
	public Component getComponent() {
		return component;
	}

	/**
	 * @param component the component to set
	 */
	public void setComponent(Component component) {
		this.component = component;
	}

	/**
	 * @return the inventoryName
	 */
	public String getInventoryName() {
		return inventoryName;
	}

	/**
	 * @param inventoryName the inventoryName to set
	 */
	public void setInventoryName(String inventoryName) {
		this.inventoryName = inventoryName;
	}

	/**
	 * @return the inventoryCode
	 */
	public String getInventoryCode() {
		return inventoryCode;
	}

	/**
	 * @param inventoryCode the inventoryCode to set
	 */
	public void setInventoryCode(String inventoryCode) {
		this.inventoryCode = inventoryCode;
	}

	/**
	 * @return the uom
	 */
	public Uom getUom() {
		return uom;
	}

	/**
	 * @param uom the uom to set
	 */
	public void setUom(Uom uom) {
		this.uom = uom;
	}

	/**
	 * @return the make
	 */
	public String getMake() {
		return make;
	}

	/**
	 * @param make the make to set
	 */
	public void setMake(String make) {
		this.make = make;
	}

	/**
	 * @return the partNumber
	 */
	public String getPartNumber() {
		return partNumber;
	}

	/**
	 * @param partNumber the partNumber to set
	 */
	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}

	/**
	 * @return the drawNumber
	 */
	public String getDrawNumber() {
		return drawNumber;
	}

	/**
	 * @param drawNumber the drawNumber to set
	 */
	public void setDrawNumber(String drawNumber) {
		this.drawNumber = drawNumber;
	}

	/**
	 * @return the modelNumber
	 */
	public String getModelNumber() {
		return modelNumber;
	}

	/**
	 * @param modelNumber the modelNumber to set
	 */
	public void setModelNumber(String modelNumber) {
		this.modelNumber = modelNumber;
	}

	/**
	 * @return the positionNumber
	 */
	public String getPositionNumber() {
		return positionNumber;
	}

	/**
	 * @param positionNumber the positionNumber to set
	 */
	public void setPositionNumber(String positionNumber) {
		this.positionNumber = positionNumber;
	}

	/**
	 * @return the serialNumber
	 */
	public String getSerialNumber() {
		return serialNumber;
	}

	/**
	 * @param serialNumber the serialNumber to set
	 */
	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}

	/**
	 * @return the locOnboard
	 */
	public LocOnboard getLocOnboard() {
		return locOnboard;
	}

	/**
	 * @param locOnboard the locOnboard to set
	 */
	public void setLocOnboard(LocOnboard locOnboard) {
		this.locOnboard = locOnboard;
	}

	/**
	 * @return the criticalIndi
	 */
	public String getCriticalIndi() {
		return criticalIndi;
	}

	/**
	 * @param criticalIndi the criticalIndi to set
	 */
	public void setCriticalIndi(String criticalIndi) {
		this.criticalIndi = criticalIndi;
	}

	/**
	 * @return the expiryDate
	 */
	public Date getExpiryDate() {
		return expiryDate;
	}

	/**
	 * @param expiryDate the expiryDate to set
	 */
	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}

	/**
	 * @return the remarks
	 */
	public String getRemarks() {
		return remarks;
	}

	/**
	 * @param remarks the remarks to set
	 */
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	/**
	 * @return the attachement
	 */
	public String getAttachement() {
		return attachement;
	}

	/**
	 * @param attachement the attachement to set
	 */
	public void setAttachement(String attachement) {
		this.attachement = attachement;
	}

	/**
	 * @return the reOrderLevel
	 */
	public Float getReOrderLevel() {
		return reOrderLevel;
	}

	/**
	 * @param reOrderLevel the reOrderLevel to set
	 */
	public void setReOrderLevel(Float reOrderLevel) {
		this.reOrderLevel = reOrderLevel;
	}

	/**
	 * @return the reOrderQty
	 */
	public Float getReOrderQty() {
		return reOrderQty;
	}

	/**
	 * @param reOrderQty the reOrderQty to set
	 */
	public void setReOrderQty(Float reOrderQty) {
		this.reOrderQty = reOrderQty;
	}

	/**
	 * @return the maxQty
	 */
	public Float getMaxQty() {
		return maxQty;
	}

	/**
	 * @param maxQty the maxQty to set
	 */
	public void setMaxQty(Float maxQty) {
		this.maxQty = maxQty;
	}

	/**
	 * @return the insertTime
	 */
	public Date getInsertTime() {
		return insertTime;
	}

	/**
	 * @param insertTime the insertTime to set
	 */
	public void setInsertTime(Date insertTime) {
		this.insertTime = insertTime;
	}

	/**
	 * @return the insertedBy
	 */
	public Integer getInsertedBy() {
		return insertedBy;
	}

	/**
	 * @param insertedBy the insertedBy to set
	 */
	public void setInsertedBy(Integer insertedBy) {
		this.insertedBy = insertedBy;
	}

	/**
	 * @return the updateTime
	 */
	public Date getUpdateTime() {
		return updateTime;
	}

	/**
	 * @param updateTime the updateTime to set
	 */
	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	/**
	 * @return the updatedBy
	 */
	public Integer getUpdatedBy() {
		return updatedBy;
	}

	/**
	 * @param updatedBy the updatedBy to set
	 */
	public void setUpdatedBy(Integer updatedBy) {
		this.updatedBy = updatedBy;
	}

	/**
	 * @return the status
	 */
	public Status getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(Status status) {
		this.status = status;
	}

	/**
	 * @return the syncRequired
	 */
	public String getSyncRequired() {
		return syncRequired;
	}

	/**
	 * @param syncRequired the syncRequired to set
	 */
	public void setSyncRequired(String syncRequired) {
		this.syncRequired = syncRequired;
	}

}
