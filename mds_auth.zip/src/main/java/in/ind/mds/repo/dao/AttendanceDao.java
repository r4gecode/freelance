/**
 * 
 */
package in.ind.mds.repo.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import in.ind.mds.dto.AttendanceDto;
import in.ind.mds.repo.entity.Attendance;
import in.ind.mds.repo.entity.Status;

/**
 * @author shalini
 *
 */
public interface AttendanceDao extends JpaRepository<Attendance, String>{

	Attendance save(Attendance attendance);

	Attendance saveAndFlush(Attendance attendance);

	Attendance findByIdAndStatusNot(String id, Status softDeleteStatus);

	List<Attendance> findByIdInAndStatusNot(List<String> attendanceIds, Status softDeleteStatus);

	
	
	@Modifying
	@Transactional
	@Query(value = "SELECT * FROM TB_ATTENDANCE WHERE RECORD_STATUS != 2", nativeQuery = true)
	List<Attendance> findAllAttendance();

	List<Attendance> findByRecordIdAndAttendanceOriginAndStatusNot(String attendanceRecId, String attendanceOrigin,
			Status softDeleteStatus);

	List<AttendanceDto> findByRecordIdAndStatusNot(String attendanceRecId, Status softDeleteStatus);

	//void saveAll(List<Attendance> existingAttendanceList);


}
