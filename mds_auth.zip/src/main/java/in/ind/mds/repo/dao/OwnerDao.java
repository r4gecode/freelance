package in.ind.mds.repo.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import in.ind.mds.repo.entity.Owner;
import in.ind.mds.repo.entity.Status;

public interface OwnerDao extends JpaRepository<Owner, String> {

	Owner findByIdAndStatusNot(String ownerId, Status status);
	
	List<Owner> findByIdInAndStatusNot(List<String> ownerIds, Status status);

	Owner findByOwnerNameAndStatusNot(String ownerName, Status status);
	
	Owner findByOwnerNameAndStatusNotAndIdNot(String ownerName, Status status, String ownerId);

	Owner findByIdAndOwnerNameAndStatusNot(String ownerId, String ownerName, Status status);
	
	@Modifying
	@Transactional
	@Query(value = "SELECT * FROM TB_OWNER WHERE RECORD_STATUS != 2", nativeQuery = true)
	List<Owner> findAllOwners();

}
