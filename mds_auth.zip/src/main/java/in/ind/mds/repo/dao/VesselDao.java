package in.ind.mds.repo.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import in.ind.mds.repo.entity.Fleet;
import in.ind.mds.repo.entity.Status;
import in.ind.mds.repo.entity.Vessel;

public interface VesselDao extends JpaRepository<Vessel, String> {

	Vessel findByIdAndStatusNot(String vesselId, Status status);
	
	List<Vessel> findByIdInAndStatusNot(List<String> vesselIds, Status status);

	Vessel findByVesselNameAndStatusNot(String vesselName, Status status);

	Vessel findByImoNoAndStatusNot(String vesselImoNo, Status status);
	

	@Query(value = "SELECT * FROM TB_VESSEL WHERE ( VESSEL_CODE = ?1 OR VESSEL_NAME= ?2 ) AND RECORD_STATUS != 2", nativeQuery = true)
	List<Vessel> uniqueCheckForAdd(String vesselCode, String vesselName);
	
	@Query(value = "SELECT * FROM TB_VESSEL WHERE (VESSEL_CODE = ?1 OR VESSEL_NAME= ?2) AND RECORD_STATUS != 2 AND ID != ?3", nativeQuery = true)
	List<Vessel> uniqueCheckForUpdate(String vesselCode, String vesselName, String vesselId);
	
	@Modifying
	@Transactional
	@Query(value = "SELECT * FROM TB_VESSEL WHERE RECORD_STATUS != 2", nativeQuery = true)
	List<Vessel> findAllVessel();
	
	List<Vessel> findByFleetAndStatusNot(Fleet fleet, Status status);
	
}
