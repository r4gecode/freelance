package in.ind.mds.repo.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "TB_SYNC_EVENT")
public class SyncEvent implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1787517726761966863L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID")
	private int id;

	@Column(name = "SYNC_PACKET_NO")
	private int syncPacketNo;

	@Column(name = "SYNC_TYPE")
	private String syncType;

	@Column(name = "FROM_SEQ")
	private int fromSeq;

	@Column(name = "TO_SEQ")
	private int toSeq;

	@Column(name = "SYNC_STATUS")
	private String syncStatus;

	@Column(name = "SYNC_MODE")
	private String syncMode;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "SYNC_COMPLETION_TIME")
	private Date syncCompletionTime;

	@Column(name = "SENDER_ID")
	private String senderId;

	@Column(name = "RECEIVER_ID")
	private String receiverId;

	@Column(name = "SYNC_ERROR_DESC")
	private String syncErrorDesc;

	@Column(name = "SYNC_FILE_NAME")
	private String syncFileName;

	@Column(name = "EXPORT_COUNT")
	private int exportCount;

	@Column(name = "DB_VERSION")
	private String dbVersion;

	@Column(name = "CONFIRMED_SEQ_NO")
	private int confirmedSeqNo;

	@Column(name = "CONFIRMED_PACKET_NO")
	private int confirmedPacketNo;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getSyncPacketNo() {
		return syncPacketNo;
	}

	public void setSyncPacketNo(int syncPacketNo) {
		this.syncPacketNo = syncPacketNo;
	}

	public String getSyncType() {
		return syncType;
	}

	public void setSyncType(String syncType) {
		this.syncType = syncType;
	}

	public int getFromSeq() {
		return fromSeq;
	}

	public void setFromSeq(int fromSeq) {
		this.fromSeq = fromSeq;
	}

	public int getToSeq() {
		return toSeq;
	}

	public void setToSeq(int toSeq) {
		this.toSeq = toSeq;
	}

	public String getSyncStatus() {
		return syncStatus;
	}

	public void setSyncStatus(String syncStatus) {
		this.syncStatus = syncStatus;
	}

	public String getSyncMode() {
		return syncMode;
	}

	public void setSyncMode(String syncMode) {
		this.syncMode = syncMode;
	}

	public Date getSyncCompletionTime() {
		return syncCompletionTime;
	}

	public void setSyncCompletionTime(Date syncCompletionTime) {
		this.syncCompletionTime = syncCompletionTime;
	}

	public String getSenderId() {
		return senderId;
	}

	public void setSenderId(String senderId) {
		this.senderId = senderId;
	}

	public String getReceiverId() {
		return receiverId;
	}

	public void setReceiverId(String receiverId) {
		this.receiverId = receiverId;
	}

	public String getSyncErrorDesc() {
		return syncErrorDesc;
	}

	public void setSyncErrorDesc(String syncErrorDesc) {
		this.syncErrorDesc = syncErrorDesc;
	}

	public String getSyncFileName() {
		return syncFileName;
	}

	public void setSyncFileName(String syncFileName) {
		this.syncFileName = syncFileName;
	}

	public int getExportCount() {
		return exportCount;
	}

	public void setExportCount(int exportCount) {
		this.exportCount = exportCount;
	}

	public String getDbVersion() {
		return dbVersion;
	}

	public void setDbVersion(String dbVersion) {
		this.dbVersion = dbVersion;
	}

	public int getConfirmedSeqNo() {
		return confirmedSeqNo;
	}

	public void setConfirmedSeqNo(int confirmedSeqNo) {
		this.confirmedSeqNo = confirmedSeqNo;
	}

	public int getConfirmedPacketNo() {
		return confirmedPacketNo;
	}

	public void setConfirmedPacketNo(int confirmedPacketNo) {
		this.confirmedPacketNo = confirmedPacketNo;
	}

}
