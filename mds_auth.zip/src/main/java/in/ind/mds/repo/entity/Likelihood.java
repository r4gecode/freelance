/**
 * 
 */
package in.ind.mds.repo.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * @author shalini
 *
 */
@Entity
@Table(name="TB_LIKELIHOOD")
public class Likelihood implements Serializable{
	private static final long serialVersionUID = 1678989856248L;
	
	@Id
	@Column(name="ID",nullable=false,unique=true)
	private String id;
	
	@Column(name="ITEM_NUMBER",nullable=false,unique=true)
	private int itemNumber;
	
	@Column(name="TYPE_OF_LIKELIHOOD", nullable=false , unique=true)
	private String typeOfLikelihood;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "INSERT_TIME")
	private Date insertTime;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "UPDATE_TIME")
	private Date updateTime;

	@Column(name = "SYNC_REQUIRED")
	private String syncRequired;

	@ManyToOne
	@JoinColumn(name="RECORD_STATUS")
	private Status status;
	
	@ManyToOne
	@JoinColumn(name="INSERTED_BY")
	private User insertedBy;
	
	@ManyToOne
	@JoinColumn(name="UPDATED_BY")
	private User updatedBy;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public int getItemNumber() {
		return itemNumber;
	}

	public void setItemNumber(int itemNumber) {
		this.itemNumber = itemNumber;
	}

	public String getTypeOfLikelihood() {
		return typeOfLikelihood;
	}

	public void setTypeOfLikelihood(String typeOfLikelihood) {
		this.typeOfLikelihood = typeOfLikelihood;
	}

	public Date getInsertTime() {
		return insertTime;
	}

	public void setInsertTime(Date insertTime) {
		this.insertTime = insertTime;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public String getSyncRequired() {
		return syncRequired;
	}

	public void setSyncRequired(String syncRequired) {
		this.syncRequired = syncRequired;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	public User getInsertedBy() {
		return insertedBy;
	}

	public void setInsertedBy(User insertedBy) {
		this.insertedBy = insertedBy;
	}

	public User getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(User updatedBy) {
		this.updatedBy = updatedBy;
	}

	
	
}
