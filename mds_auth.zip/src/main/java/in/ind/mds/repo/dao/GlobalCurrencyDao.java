/**
 * 
 */
package in.ind.mds.repo.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import in.ind.mds.repo.entity.GlobalCurrency;

/**
 * @author mds-arockia
 *
 */
public interface GlobalCurrencyDao extends JpaRepository<GlobalCurrency, Integer>{

}
