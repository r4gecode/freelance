package in.ind.mds.repo.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import in.ind.mds.repo.entity.Role;
import in.ind.mds.repo.entity.Status;

public interface RoleDao extends JpaRepository<Role, String> {

	Role findByRoleNameAndStatusNot(String roleName, Status status);

	Role findByIdAndRoleNameAndStatusNot(String roleId, String roleName, Status status);

	Role findByIdAndStatusNot(String roleId, Status status);
	
	List<Role> findByIdInAndStatusNot(List<String> roleId, Status status);


	@Query(value = "SELECT * FROM TB_ROLE WHERE ( ROLE_NAME=?1 OR ROLE_CODE=?2 OR SEQUENCE_NUMBER=?3 ) AND RECORD_STATUS !=2", nativeQuery = true)
	List<Role> uniqueCheckForAdd(String roleName, String roleCode,Integer sequenceNumber);

//	@Query(value = "SELECT * FROM TB_ROLE WHERE ROLE_NAME=?1 AND RECORD_STATUS !=2 AND ID != ?4 OR ROLE_CODE=?2 AND RECORD_STATUS !=2 AND ID != ?4 OR SEQUENCE_NUMBER=?3 AND RECORD_STATUS !=2 AND ID != ?4", nativeQuery = true)
//	List<Role> updateUniqueCheck(String roleName, String roleCode, Integer sequenceNumber,String roleId);

	@Query(value = "SELECT * FROM TB_ROLE WHERE (ROLE_NAME=?1 OR ROLE_CODE=?2 OR SEQUENCE_NUMBER=?3) AND RECORD_STATUS !=2 AND ID != ?4 ", nativeQuery = true)
	List<Role> uniqueCheckForUpdate(String roleName, String roleCode, Integer sequenceNumber,String roleId);

	
	@Modifying
	@Transactional
	@Query(value = "SELECT * FROM TB_ROLE WHERE RECORD_STATUS != 2", nativeQuery = true)
	List<Role> findAllRole();

}
