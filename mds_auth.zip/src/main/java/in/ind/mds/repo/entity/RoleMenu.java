package in.ind.mds.repo.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "TB_ROLE_MENU")

public class RoleMenu implements Serializable 
{
	/**
	 * 
	 */
	private static final long serialVersionUID = -149570585421382389L;

	@Id
	@Column(name = "ID", nullable = false, unique = true)
	private String id;

	/*@Column(name = "ROLE_ID")
	private String roleId;

	@Column(name = "MENU_ID")
	private String menuId;
*/
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "INSERT_TIME")
	private Date insertTime;

	@Column(name = "INSERTED_BY")
	private Integer insertedBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "UPDATE_TIME")
	private Date updateTime;

	@Column(name = "UPDATED_BY")
	private Integer updatedBy;
	
	@Column(name = "SYNC_REQUIRED")
	private String syncRequired;

	@ManyToOne
	@JoinColumn(name="ROLE_ID")
	private Role role;
	
	@ManyToOne
	@JoinColumn(name="MENU_ID")
	private Menu menu;
	
	@Column(name = "ADD_ACCESS")
	private String addAccess;
	
	@Column(name = "UPD_ACCESS")
	private String updAccess;
	
	@Column(name = "DEL_ACCESS")
	private String delAccess;
	
	@Column(name = "VIEW_ACCESS")
	private String viewAccess;
	
	@Column(name = "EMAIL_ACCESS")
	private String emailAccess;
	
	@ManyToOne
	@JoinColumn(name="RECORD_STATUS")
	private Status status;
	

	public Role getRole() {
		return role;
	}

	public void setRole(Role role) {
		this.role = role;
	}

	public Menu getMenu() {
		return menu;
	}

	public void setMenu(Menu menu) {
		this.menu = menu;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

/*	public String getRoleId() {
		return roleId;
	}

	public void setRoleId(String roleId) {
		this.roleId = roleId;
	}

	public String getMenuId() {
		return menuId;
	}

	public void setMenuId(String menuId) {
		this.menuId = menuId;
	}
*/
	public Date getInsertTime() {
		return insertTime;
	}

	public void setInsertTime(Date insertTime) {
		this.insertTime = insertTime;
	}

	public Integer getInsertedBy() {
		return insertedBy;
	}

	public void setInsertedBy(Integer insertedBy) {
		this.insertedBy = insertedBy;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public Integer getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(Integer updatedBy) {
		this.updatedBy = updatedBy;
	}

	public String getSyncRequired() {
		return syncRequired;
	}

	public void setSyncRequired(String syncRequired) {
		this.syncRequired = syncRequired;
	}

	public String getAddAccess() {
		return addAccess;
	}

	public void setAddAccess(String addAccess) {
		this.addAccess = addAccess;
	}

	public String getUpdAccess() {
		return updAccess;
	}

	public void setUpdAccess(String updAccess) {
		this.updAccess = updAccess;
	}

	public String getDelAccess() {
		return delAccess;
	}

	public void setDelAccess(String delAccess) {
		this.delAccess = delAccess;
	}

	public String getViewAccess() {
		return viewAccess;
	}

	public void setViewAccess(String viewAccess) {
		this.viewAccess = viewAccess;
	}

	public String getEmailAccess() {
		return emailAccess;
	}

	public void setEmailAccess(String emailAccess) {
		this.emailAccess = emailAccess;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	/*@OneToOne
	@JoinColumn(name = "MENU_ID", insertable = false, updatable = false)
	private Menu menu;
	*/
	
	

	
	/*public Menu getMenu() {
		return menu;
	}

	public void setMenu(Menu menu) {
		this.menu = menu;
	}
*/
	
	
	
}