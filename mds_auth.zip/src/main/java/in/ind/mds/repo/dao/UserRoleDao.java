package in.ind.mds.repo.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;
import in.ind.mds.repo.entity.Status;
import in.ind.mds.repo.entity.User;
import in.ind.mds.repo.entity.UserRole;

public interface UserRoleDao extends JpaRepository<UserRole, String> {

	UserRole findByRoleIdAndStatusNot(final String roleId, final Status status);

	UserRole findByRoleIdAndUserIdAndStatusNot(final String roleId, final String userId, final Status status);
	
	UserRole findByIdAndStatusNot(final String userRoleId, final Status status);

	List<UserRole> findByIdInAndStatusNot(List<String> userIds, Status status);

	@Modifying
	@Transactional
	@Query(value = "SELECT * FROM TB_USER_ROLE WHERE RECORD_STATUS != 2", nativeQuery = true)
	List<UserRole> findAllUserRole();
	
	UserRole findByUserIdAndStatusNot(final String userId, final Status status);
	
	UserRole findByUser(final User user);
}
