package in.ind.mds.repo.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import in.ind.mds.repo.entity.Component;
import in.ind.mds.repo.entity.Status;
import in.ind.mds.repo.entity.Vessel;

public interface ComponentDao extends JpaRepository<Component, String> {

	Component findBySfiCodeAndStatusNot(String sfiCode, Status status);

	Component findByComponentNameAndComponentTypeAndStatusNot(String componentName, String componentType, Status status);
	
	Component findByIdAndStatusNot(String componentId,Status status);
	
	List<Component> findByIdInAndStatusNot(List<String> componentId,Status status);
	
	@Query(value = "SELECT * FROM TB_PMS_COMPONENT WHERE ( COMPONENT_NAME = ?1 OR CODE = ?2 OR SFI_CODE = ?3) AND RECORD_STATUS != 2", nativeQuery = true)
	List<Component> uniqueCheckForAdd(String componentName, String code, String sfiCode);
	
	@Query(value="SELECT * FROM TB_PMS_COMPONENT WHERE (COMPONENT_NAME = ?1 OR CODE = ?2 OR SFI_CODE = ?3) AND RECORD_STATUS != 2 AND ID != ?4", nativeQuery = true)
	List<Component> uniqueCheckForUpdate(String componentName, String code, String sfiCode, String id);
	
	 @Modifying
		@Transactional
		@Query(value = "SELECT * FROM TB_PMS_COMPONENT WHERE RECORD_STATUS != 2", nativeQuery = true)
		List<Component> findAllComponent();
	 
	 List<Component> findByVessel(Vessel vessel);
	 
	 List<Component> findByRHRequiredAndCRRequiredNot(String rHstatus, String cRStatus);
	 
	 List<Component> findByCRRequired(String cRstatus);
	 
}
