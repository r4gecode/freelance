/**
 * 
 */
package in.ind.mds.repo.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import in.ind.mds.repo.entity.ManningAgent;
import in.ind.mds.repo.entity.Status;

/**
 * @author Hinaya
 *
 */
public interface ManningAgentDao extends JpaRepository<ManningAgent, String>{

	ManningAgent findByIdAndStatusNot(String manningAgentId, Status softDeleteStatus);

	@Query(value="SELECT * FROM TB_MANNING_AGENT WHERE (AGENT_NAME =?1) AND RECORD_STATUS !=2", nativeQuery=true)
	List<ManningAgent> uniqueCheckForAdd(String agentName);

	@Modifying
	@Transactional
	@Query(value = "SELECT * FROM TB_MANNING_AGENT WHERE RECORD_STATUS != 2", nativeQuery = true)
	List<ManningAgent> findAllManningAgent();

	List<ManningAgent> findByIdInAndStatusNot(List<String> ids, Status softDeleteStatus);
	
	@Query(value="SELECT * FROM TB_MANNING_AGENT WHERE (AGENT_NAME =?1 ) AND RECORD_STATUS !=2 AND ID!=?2", nativeQuery=true)	
	List<ManningAgent> uniqueCheckForUpdate(String agentName, String id);

	

}
