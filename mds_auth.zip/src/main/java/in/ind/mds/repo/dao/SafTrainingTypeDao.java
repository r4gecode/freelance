/**
 * 
 */
package in.ind.mds.repo.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import in.ind.mds.repo.entity.SafTrainingType;
import in.ind.mds.repo.entity.Status;

/**
 * @author shalini
 *
 */
public interface SafTrainingTypeDao extends JpaRepository<SafTrainingType, String>{
	List<SafTrainingType> findByTrainingTypeNameAndStatusNot(String TrainingType, Status status);

	List<SafTrainingType> findByTrainingTypeNameAndStatusNotAndIdNot(String TrainingType, Status status, String id);
	
	SafTrainingType findByIdAndStatusNot(String id, Status status);
	
	List<SafTrainingType> findByIdInAndStatusNot(List<String> id, Status status);
	
	@Modifying
	@Transactional
	@Query(value = "SELECT * FROM TB_SAF_TRAINING_TYPE WHERE RECORD_STATUS != 2", nativeQuery = true)
	List<SafTrainingType> findAllSafTrainingType();
	
}
