/**
 * 
 */
package in.ind.mds.repo.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import in.ind.mds.repo.entity.InventoryCatalog;
import in.ind.mds.repo.entity.InventoryItem;
import in.ind.mds.repo.entity.Status;

/**
 * @author mds-arockia
 *
 */
public interface InventoryItemDao extends JpaRepository<InventoryItem, String>{
	
	List<InventoryItem> findByInvCatalogAndStatusNot(InventoryCatalog inventoryCatalog, Status status);

	InventoryItem findByIdAndStatusNot(String id, Status status);
	
	List<InventoryItem> findByIdInAndStatusNot(List<String> ids, Status status);
	
	@Modifying
	@Transactional
	@Query(value = "SELECT * FROM TB_PMS_INVENTORY_ITEM WHERE RECORD_STATUS != 2", nativeQuery = true)
	List<InventoryItem> findAllInventoryItem();
}
