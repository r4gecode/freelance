package in.ind.mds.repo.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import in.ind.mds.repo.entity.ExceptionLog;

public interface ExceptionLogDao extends JpaRepository<ExceptionLog, Integer>{

}
