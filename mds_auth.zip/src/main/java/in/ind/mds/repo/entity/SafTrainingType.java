/**
 * 
 */
package in.ind.mds.repo.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * @author shalini
 *
 */
@Entity
@Table(name="TB_SAF_TRAINING_TYPE")
public class SafTrainingType implements Serializable{
	private static final long serialVersionUID = 11748789857148L;
@Id
@Column(name="ID",nullable=false,unique=true)
private String id;

@Column(name="TRAINING_TYPE_NAME",nullable=false)
private String trainingTypeName;

@Temporal(TemporalType.TIMESTAMP)
@Column(name = "INSERT_TIME",nullable=false)
private Date insertTime;

@Temporal(TemporalType.TIMESTAMP)
@Column(name = "UPDATE_TIME")
private Date updateTime;

@Column(name = "SYNC_REQUIRED")
private String syncRequired;

@ManyToOne
@JoinColumn(name="INSERTED_BY")
private User insertedBy;

@ManyToOne
@JoinColumn(name="UPDATED_BY")
private User updatedBy;

@ManyToOne
@JoinColumn(name="RECORD_STATUS")
private Status status;

public String getId() {
	return id;
}

public void setId(String id) {
	this.id = id;
}

public String getTrainingTypeName() {
	return trainingTypeName;
}

public void setTrainingTypeName(String trainingTypeName) {
	this.trainingTypeName = trainingTypeName;
}

public Date getInsertTime() {
	return insertTime;
}

public void setInsertTime(Date insertTime) {
	this.insertTime = insertTime;
}

public Date getUpdateTime() {
	return updateTime;
}

public void setUpdateTime(Date updateTime) {
	this.updateTime = updateTime;
}

public String getSyncRequired() {
	return syncRequired;
}

public void setSyncRequired(String syncRequired) {
	this.syncRequired = syncRequired;
}

public User getInsertedBy() {
	return insertedBy;
}

public void setInsertedBy(User insertedBy) {
	this.insertedBy = insertedBy;
}

public User getUpdatedBy() {
	return updatedBy;
}

public void setUpdatedBy(User updatedBy) {
	this.updatedBy = updatedBy;
}

public Status getStatus() {
	return status;
}

public void setStatus(Status status) {
	this.status = status;
}


}
