/**
 * 
 */
package in.ind.mds.repo.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * @author shalini
 *
 */
@Entity
@Table(name="TB_CREW_WORK_EXP")
public class CrewWorkExp implements Serializable{
	private static final long serialVersionUID = -3502039187676202977L;
	
	@Id
	@Column(name = "ID", nullable = false, unique = true)
	private String id;
	
	@Column(name="CURRENT_COMPANY")
	private String currentCompany;

	@Column(name="COMPANY_NAME",nullable=false)
	private String companyName;
	
	@Column(name="VESSEL_NAME")
	private String vesselName;
	
	@Column(name="FLAG")
	private String flag;
	
	@Column(name="GRT")
	private String grt;
	
	@Column(name="BHP")
	private String bhp;
	
	@Column(name="NRT")
	private String nrt;
	
	@Column(name="DWT")
	private String dwt;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="SIGN_ON")
	private Date signOn;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="SIGN_OFF")
	private Date signOff;
	
	@Column(name="YEARS")
	private int years;
	
	@Column(name="MONTHS")
	private int months;
	
	@Column(name="DAYS")
	private int days;
	
	@Column(name="MT_DAYS")
	private int mtDays;
	
	@Column(name="BASIC_SALARY")
	private int basicSalary;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "INSERT_TIME")
	private Date insertTime;


	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "UPDATE_TIME")
	private Date updateTime;

	@Column(name = "SYNC_REQUIRED")
	private String syncRequired;

	@OneToOne
	@JoinColumn(name = "RECORD_STATUS")
	private Status status;
	
	
	@ManyToOne
	@JoinColumn(name="STAFF_ID")
	private Staff staff;
	
	@ManyToOne
	@JoinColumn(name="VESSEL_TYPE")
	private VesselType vesselType;
	
	@ManyToOne
	@JoinColumn(name="ROLE")
	private Role role;
	
	@ManyToOne
	@JoinColumn(name="ENGAGE_PORT")
	private Port engagePort;
	
	@ManyToOne
	@JoinColumn(name="INSERTED_BY")
	private User insertedBy;
	
	@ManyToOne
	@JoinColumn(name="UPDATED_BY")
	private User updatedBy;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCurrentCompany() {
		return currentCompany;
	}

	public void setCurrentCompany(String currentCompany) {
		this.currentCompany = currentCompany;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getVesselName() {
		return vesselName;
	}

	public void setVesselName(String vesselName) {
		this.vesselName = vesselName;
	}

	public String getFlag() {
		return flag;
	}

	public void setFlag(String flag) {
		this.flag = flag;
	}

	public String getGrt() {
		return grt;
	}

	public void setGrt(String grt) {
		this.grt = grt;
	}

	public String getBhp() {
		return bhp;
	}

	public void setBhp(String bhp) {
		this.bhp = bhp;
	}

	public String getNrt() {
		return nrt;
	}

	public void setNrt(String nrt) {
		this.nrt = nrt;
	}

	public String getDwt() {
		return dwt;
	}

	public void setDwt(String dwt) {
		this.dwt = dwt;
	}

	public Date getSignOn() {
		return signOn;
	}

	public void setSignOn(Date signOn) {
		this.signOn = signOn;
	}

	

	public Date getSignOff() {
		return signOff;
	}

	public void setSignOff(Date signOff) {
		this.signOff = signOff;
	}

	public int getYears() {
		return years;
	}

	public void setYears(int years) {
		this.years = years;
	}

	public int getMonths() {
		return months;
	}

	public void setMonths(int months) {
		this.months = months;
	}

	public int getDays() {
		return days;
	}

	public void setDays(int days) {
		this.days = days;
	}

	public int getMtDays() {
		return mtDays;
	}

	public void setMtDays(int mtDays) {
		this.mtDays = mtDays;
	}

	public int getBasicSalary() {
		return basicSalary;
	}

	public void setBasicSalary(int basicSalary) {
		this.basicSalary = basicSalary;
	}

	public Date getInsertTime() {
		return insertTime;
	}

	public void setInsertTime(Date insertTime) {
		this.insertTime = insertTime;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public String getSyncRequired() {
		return syncRequired;
	}

	public void setSyncRequired(String syncRequired) {
		this.syncRequired = syncRequired;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	public Staff getStaff() {
		return staff;
	}

	public void setStaff(Staff staff) {
		this.staff = staff;
	}



	public VesselType getVesselType() {
		return vesselType;
	}

	public void setVesselType(VesselType vesselType) {
		this.vesselType = vesselType;
	}

	public Role getRole() {
		return role;
	}

	public void setRole(Role role) {
		this.role = role;
	}

	public Port getEngagePort() {
		return engagePort;
	}

	public void setEngagePort(Port engagePort) {
		this.engagePort = engagePort;
	}

	public User getInsertedBy() {
		return insertedBy;
	}

	public void setInsertedBy(User insertedBy) {
		this.insertedBy = insertedBy;
	}

	public User getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(User updatedBy) {
		this.updatedBy = updatedBy;
	} 
	
}
