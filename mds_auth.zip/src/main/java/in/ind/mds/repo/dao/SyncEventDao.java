package in.ind.mds.repo.dao;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import in.ind.mds.repo.entity.SyncEvent;

public interface SyncEventDao extends JpaRepository<SyncEvent, Integer> {

	SyncEvent getById(final int id);

	List<SyncEvent> getBySenderId(final String senderId);

	List<SyncEvent> getByReceiverId(final String receiverId);

	List<SyncEvent> findByReceiverId(final String receiverId);

	@Query(value = "select coalesce(max(syncPacketNo),0)+1 from SyncEvent where receiverId = :receiverId")
	int calculatePacketNo(@Param("receiverId") final String receiverId);

	@Query(value = "select min(id) as from_seq, max(id) as to_seq from SyncData where vesselId=:receiverId "
			+ "and id > (select coalesce(max(toSeq),0) from SyncEvent where receiverId=:receiverId and syncStatus=:status)")
	List<Object> fromSeqToSeqEvent(@Param("receiverId") final String receiverId, @Param("status") final String status);

	@Query(value = "select e from SyncEvent e where syncCompletionTime between :currentDateStartTime and :currentDateEndTime")
	List<SyncEvent> exportData(@Param("currentDateStartTime") final LocalDateTime currentDateStartTime,
			@Param("currentDateEndTime") final LocalDateTime currentDateEndTime);

}
