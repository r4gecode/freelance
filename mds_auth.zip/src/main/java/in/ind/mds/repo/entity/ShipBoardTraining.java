/**
 * 
 */
package in.ind.mds.repo.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * @author dharani
 *
 */

@Entity
@Table(name="TB_SHIPBOARD_TRAINING ")
public class ShipBoardTraining implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 18746782378444L;
	
	@Id
	@Column(name = "ID", nullable = false, unique = true)
	private String id;
	
	@ManyToOne
	@JoinColumn(name = "FLEET_ID")
	private Fleet fleet;
	
	@ManyToOne
	@JoinColumn(name="VESSEL_ID")
	private Vessel vessel;
	
	@ManyToOne
	@JoinColumn(name="CONDUCTED_BY")
	private Staff conductedBy;
	

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CONDUCTED_DATE")
	private Date conductedDate;
	
	@Column(name="TOPIC")
	private String topic;
	
	@Column(name="START_TIME")
	private Date startTime;
	
	@Column(name="END_TIME")
	private Date endTime;
	
	@Column(name="TOTAL_HOURS")
	private Float totalHours;
	
	@Column(name="SHIP_COMMENTS")
	private String shipComments;
	
	@Column(name = "SYNC_REQUIRED")
	private String syncRequired;
	
	
	
	@ManyToOne
	@JoinColumn(name = "RECORD_STATUS")
	private Status status;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "INSERT_TIME")
	private Date insertTime;

	@ManyToOne
	@JoinColumn(name = "INSERTED_BY")
	private User insertedBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "UPDATE_TIME")
	private Date updateTime;

	@ManyToOne
	@JoinColumn(name = "UPDATED_BY")
	private User updatedBy;
	
	@ManyToOne
	@JoinColumn(name="TYPE_OF_TRAINING")
	private SafTrainingType typeOfTraining;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Fleet getFleet() {
		return fleet;
	}

	public void setFleet(Fleet fleet) {
		this.fleet = fleet;
	}

	public Vessel getVessel() {
		return vessel;
	}

	public void setVessel(Vessel vessel) {
		this.vessel = vessel;
	}

	public Staff getConductedBy() {
		return conductedBy;
	}

	public void setConductedBy(Staff conductedBy) {
		this.conductedBy = conductedBy;
	}

	public String getTopic() {
		return topic;
	}

	public void setTopic(String topic) {
		this.topic = topic;
	}

	public Date getStartTime() {
		return startTime;
	}

	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}

	public Date getEndTime() {
		return endTime;
	}

	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}

	public Float getTotalHours() {
		return totalHours;
	}

	public void setTotalHours(Float totalHours) {
		this.totalHours = totalHours;
	}

	public String getShipComments() {
		return shipComments;
	}

	public void setShipComments(String shipComments) {
		this.shipComments = shipComments;
	}

	public String getSyncRequired() {
		return syncRequired;
	}

	public void setSyncRequired(String syncRequired) {
		this.syncRequired = syncRequired;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	public Date getInsertTime() {
		return insertTime;
	}

	public void setInsertTime(Date insertTime) {
		this.insertTime = insertTime;
	}

	public User getInsertedBy() {
		return insertedBy;
	}

	public void setInsertedBy(User insertedBy) {
		this.insertedBy = insertedBy;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public User getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(User updatedBy) {
		this.updatedBy = updatedBy;
	}

	public SafTrainingType getTypeOfTraining() {
		return typeOfTraining;
	}

	public void setTypeOfTraining(SafTrainingType typeOfTraining) {
		this.typeOfTraining = typeOfTraining;
	}
	
	
	
	

}
