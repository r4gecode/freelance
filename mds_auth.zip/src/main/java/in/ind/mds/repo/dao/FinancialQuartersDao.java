/**
 * 
 */
package in.ind.mds.repo.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import in.ind.mds.repo.entity.FinancialQuarters;
import in.ind.mds.repo.entity.FinancialYear;
import in.ind.mds.repo.entity.Status;

/**
 * @author mds-arockia
 *
 */
public interface FinancialQuartersDao extends JpaRepository<FinancialQuarters, String>{
	
	List<FinancialQuarters> findByFinancialYearInAndStatusNot(List<FinancialYear> financialYearList, Status status);
	
	List<FinancialQuarters> findByFinancialYearAndStatusNot(FinancialYear financialYear, Status status);

}
