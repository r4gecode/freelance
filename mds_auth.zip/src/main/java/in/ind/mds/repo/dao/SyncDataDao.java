package in.ind.mds.repo.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import in.ind.mds.repo.entity.SyncData;

public interface SyncDataDao extends JpaRepository<SyncData, Integer> {

	SyncData getById(final int id);

	List<SyncData> getByVesselId(final String vesselId);
	
	//int maxSequencData(String reciverId);

	@Query(value = "select d from SyncData d where d.id >=:minSeqNo and d.id <=:maxSeqNo ")
	List<SyncData> retrieveSyncData(int minSeqNo, int maxSeqNo);

	//List<SyncData> generateDataWithTimeAndMaxSeq(String reciverId, int maxSeqNo, Date date);

}
