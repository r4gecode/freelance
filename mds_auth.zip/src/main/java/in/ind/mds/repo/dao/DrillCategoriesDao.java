/**
 * 
 */
package in.ind.mds.repo.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import in.ind.mds.repo.entity.DrillCategories;
import in.ind.mds.repo.entity.Status;

/**
 * @author dharani
 *
 */
public interface DrillCategoriesDao extends JpaRepository<DrillCategories, String>{
	
	DrillCategories findByDrillCtgyNameAndStatusNot(String drillCtgyName, Status status);

	DrillCategories findByDrillCtgyNameAndStatusNotAndIdNot(String drillCatgName, Status status, String drillId);
	
	DrillCategories findByIdAndDrillCtgyNameAndStatusNot(String drillId, String drillCatgName, Status status);

	DrillCategories findByIdAndStatusNot(String drillId, Status status);
	
	List<DrillCategories> findByIdInAndStatusNot(List<String> drillIds, Status status);
	
	@Modifying
	@Transactional
	@Query(value = "SELECT * FROM TB_DRILL_CATEGORIES WHERE RECORD_STATUS != 2", nativeQuery = true)
	List<DrillCategories> findAllDrillCategories();

}
