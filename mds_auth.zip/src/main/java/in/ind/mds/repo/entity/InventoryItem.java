/**
 * 
 */
package in.ind.mds.repo.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * @author mds-arockia
 *
 */
@Entity
@Table(name = "TB_PMS_INVENTORY_ITEM")
public class InventoryItem implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 117488936284548L;
	
	@Id
	@Column(name = "ID", nullable = false, unique = true)
	private String id;
	
	@ManyToOne
	@JoinColumn(name = "INV_CATALOG_ID")
	private InventoryCatalog invCatalog; 
	
	@ManyToOne
	@JoinColumn(name = "FlEET_ID")
	private Fleet fleet;
	
	@ManyToOne
	@JoinColumn(name = "VESSEL_ID")
	private Vessel vessel;
	
	@Column(name = "CURR_QTY")
	private Float currQty;
	
	@Column(name = "AVG_PRICE")
	private BigDecimal avgPrice;
	
	@Column(name ="LATEST_PRICE")
	private BigDecimal latestPrice;
	
	@Column(name = "TOTAL_PRICE")
	private BigDecimal totalPrice;
	
	@Column(name = "INSERT_TIME")
	private Date insertTime;
	
	@Column(name = "INSERTED_BY")
	private Integer insertedBy;
	
	@Column(name = "UPDATE_TIME")
	private Date updateTime;
	
	@Column(name = "UPDATED_BY")
	private Integer updatedBy;
	
	@ManyToOne
	@JoinColumn(name = "RECORD_STATUS")
	private Status status;

	@Column(name = "SYNC_REQUIRED")
	private String syncRequired;
	
	@Column(name ="FLEET_WIDE_COMMON_INVENTORY")
	private String fwcInventory;

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the invCatalog
	 */
	public InventoryCatalog getInvCatalog() {
		return invCatalog;
	}

	/**
	 * @param invCatalog the invCatalog to set
	 */
	public void setInvCatalog(InventoryCatalog invCatalog) {
		this.invCatalog = invCatalog;
	}

	/**
	 * @return the fleet
	 */
	public Fleet getFleet() {
		return fleet;
	}

	/**
	 * @param fleet the fleet to set
	 */
	public void setFleet(Fleet fleet) {
		this.fleet = fleet;
	}

	/**
	 * @return the vessel
	 */
	public Vessel getVessel() {
		return vessel;
	}

	/**
	 * @param vessel the vessel to set
	 */
	public void setVessel(Vessel vessel) {
		this.vessel = vessel;
	}

	/**
	 * @return the currQty
	 */
	public Float getCurrQty() {
		return currQty;
	}

	/**
	 * @param currQty the currQty to set
	 */
	public void setCurrQty(Float currQty) {
		this.currQty = currQty;
	}

	/**
	 * @return the avgPrice
	 */
	public BigDecimal getAvgPrice() {
		return avgPrice;
	}

	/**
	 * @param avgPrice the avgPrice to set
	 */
	public void setAvgPrice(BigDecimal avgPrice) {
		this.avgPrice = avgPrice;
	}

	/**
	 * @return the latestPrice
	 */
	public BigDecimal getLatestPrice() {
		return latestPrice;
	}

	/**
	 * @param latestPrice the latestPrice to set
	 */
	public void setLatestPrice(BigDecimal latestPrice) {
		this.latestPrice = latestPrice;
	}

	/**
	 * @return the totalPrice
	 */
	public BigDecimal getTotalPrice() {
		return totalPrice;
	}

	/**
	 * @param totalPrice the totalPrice to set
	 */
	public void setTotalPrice(BigDecimal totalPrice) {
		this.totalPrice = totalPrice;
	}

	/**
	 * @return the insertTime
	 */
	public Date getInsertTime() {
		return insertTime;
	}

	/**
	 * @param insertTime the insertTime to set
	 */
	public void setInsertTime(Date insertTime) {
		this.insertTime = insertTime;
	}

	/**
	 * @return the insertedBy
	 */
	public Integer getInsertedBy() {
		return insertedBy;
	}

	/**
	 * @param insertedBy the insertedBy to set
	 */
	public void setInsertedBy(Integer insertedBy) {
		this.insertedBy = insertedBy;
	}

	/**
	 * @return the updateTime
	 */
	public Date getUpdateTime() {
		return updateTime;
	}

	/**
	 * @param updateTime the updateTime to set
	 */
	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	/**
	 * @return the updatedBy
	 */
	public Integer getUpdatedBy() {
		return updatedBy;
	}

	/**
	 * @param updatedBy the updatedBy to set
	 */
	public void setUpdatedBy(Integer updatedBy) {
		this.updatedBy = updatedBy;
	}

	/**
	 * @return the status
	 */
	public Status getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(Status status) {
		this.status = status;
	}

	/**
	 * @return the syncRequired
	 */
	public String getSyncRequired() {
		return syncRequired;
	}

	/**
	 * @param syncRequired the syncRequired to set
	 */
	public void setSyncRequired(String syncRequired) {
		this.syncRequired = syncRequired;
	}

	/**
	 * @return the fwcInventory
	 */
	public String getFwcInventory() {
		return fwcInventory;
	}

	/**
	 * @param fwcInventory the fwcInventory to set
	 */
	public void setFwcInventory(String fwcInventory) {
		this.fwcInventory = fwcInventory;
	}
	
}
