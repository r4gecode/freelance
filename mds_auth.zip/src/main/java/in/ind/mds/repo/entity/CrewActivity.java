/**
 * 
 */
package in.ind.mds.repo.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * @author dharani
 *
 */

@Entity
@Table(name="TB_CREW_ACTIVITY")
public class CrewActivity  implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 12344321456L;
	

	@Id
	@Column(name = "ID", nullable = false, unique = true)
	private String id;
	
	@Column(name="ACTIVITY")
	private String activity;
	
	@Column(name="FROM_DATE")
	private Date fromDate;
	
	
	@Column(name="TO_DATE")
	private Date toDate;
	
	
	@Column(name="YEARS")
	private Integer years;
	
	@Column(name="MONTHS")
	private Integer months;
	
	@Column(name="DAYS")
	private Integer days;
	
	
	@Column(name="REMARKS")
	private String remarks;
	
	
	@Column(name="SYNC_REQUIRED")
	private String syncRequired;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "INSERT_TIME")
	private Date insertTime;	
	
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "UPDATE_TIME")
	private Date updateTime;

	@OneToOne
	@JoinColumn(name = "STAFF_ID", nullable = false)
	private Staff staff;
	
	
	@OneToOne
	@JoinColumn(name="VESSEL_ID",nullable = false)
	private Vessel vessel;
	
	@OneToOne
	@JoinColumn(name="ROLE",nullable = false)
	private Role role;
	
	@ManyToOne
	@JoinColumn(name = "RECORD_STATUS")
	private Status status;
	
	
	@ManyToOne
	@JoinColumn(name = "INSERTED_BY")
	private User insertedBy;
	
	@ManyToOne
	@JoinColumn(name = "UPDATED_BY")
	private User updatedBy;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getActivity() {
		return activity;
	}

	public void setActivity(String activity) {
		this.activity = activity;
	}

	public Date getFromDate() {
		return fromDate;
	}

	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}

	public Date getToDate() {
		return toDate;
	}

	public void setToDate(Date toDate) {
		this.toDate = toDate;
	}

	public Integer getYears() {
		return years;
	}

	public void setYears(Integer years) {
		this.years = years;
	}

	public Integer getMonths() {
		return months;
	}

	public void setMonths(Integer months) {
		this.months = months;
	}

	public Integer getDays() {
		return days;
	}

	public void setDays(Integer days) {
		this.days = days;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getSyncRequired() {
		return syncRequired;
	}

	public void setSyncRequired(String syncRequired) {
		this.syncRequired = syncRequired;
	}

	public Date getInsertTime() {
		return insertTime;
	}

	public void setInsertTime(Date insertTime) {
		this.insertTime = insertTime;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public Staff getStaff() {
		return staff;
	}

	public void setStaff(Staff staff) {
		this.staff = staff;
	}

	public Vessel getVessel() {
		return vessel;
	}

	public void setVessel(Vessel vessel) {
		this.vessel = vessel;
	}

	public Role getRole() {
		return role;
	}

	public void setRole(Role role) {
		this.role = role;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	public User getInsertedBy() {
		return insertedBy;
	}

	public void setInsertedBy(User insertedBy) {
		this.insertedBy = insertedBy;
	}

	public User getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(User updatedBy) {
		this.updatedBy = updatedBy;
	}
	
	

}
