/**
 * 
 */
package in.ind.mds.repo.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * @author mds_kiruthika
 *
 */
@Entity
@Table(name="TB_TRAVEL_DOCUMENT")
public class TravelDocument implements Serializable {
	
	private static final long serialVersionUID = 1156093413124583664L;

	
	@Id
	@Column(name = "ID", nullable = false, unique = true)
	private String id;
	
	@Column(name="DOCUMENT_TYPE",nullable=false)
	private String documentType;

	@Column(name="DOCUMENT_NUMBER",nullable=false)
	private String documentNumber;
	
	@Column(name="PLACE_OF_ISSUE",nullable=false)
	private String placeOfIssue;
	
	@Column(name="ISSUED_BY",nullable=false)
	private String issuedBy;
	
	@Column(name = "SYNC_REQUIRED")
	private String syncRequired;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "INSERT_TIME")
	private Date insertTime;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "UPDATE_TIME")
	private Date updateTime;
	
	@ManyToOne
	@JoinColumn(name="STAFF_ID")
	Staff staff;
	
	@ManyToOne
	@JoinColumn(name="RECORD_STATUS")
	private Status status;
	
	@ManyToOne
	@JoinColumn(name="COUNTRY")
	private Country country;
	
	
	@ManyToOne
	@JoinColumn(name="INSERTED_BY")
	private User insertedBy;
	
	
	@ManyToOne
	@JoinColumn(name="UPDATED_BY")
	private User updatedBy;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getDocumentType() {
		return documentType;
	}

	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}

	public String getDocumentNumber() {
		return documentNumber;
	}

	public void setDocumentNumber(String documentNumber) {
		this.documentNumber = documentNumber;
	}

	public String getPlaceOfIssue() {
		return placeOfIssue;
	}

	public void setPlaceOfIssue(String placeOfIssue) {
		this.placeOfIssue = placeOfIssue;
	}

	public String getIssuedBy() {
		return issuedBy;
	}

	public void setIssuedBy(String issuedBy) {
		this.issuedBy = issuedBy;
	}

	public String getSyncRequired() {
		return syncRequired;
	}

	public void setSyncRequired(String syncRequired) {
		this.syncRequired = syncRequired;
	}

	public Date getInsertTime() {
		return insertTime;
	}

	public void setInsertTime(Date insertTime) {
		this.insertTime = insertTime;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public Staff getStaff() {
		return staff;
	}

	public void setStaff(Staff staff) {
		this.staff = staff;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	public Country getCountry() {
		return country;
	}

	public void setCountry(Country country) {
		this.country = country;
	}

	
	public User getInsertedBy() {
		return insertedBy;
	}

	public void setInsertedBy(User insertedBy) {
		this.insertedBy = insertedBy;
	}

	public User getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(User updatedBy) {
		this.updatedBy = updatedBy;
	}

	
	

}
