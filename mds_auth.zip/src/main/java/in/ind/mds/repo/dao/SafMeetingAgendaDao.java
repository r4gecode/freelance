/**
 * 
 */
package in.ind.mds.repo.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;


import in.ind.mds.repo.entity.SafMeetingAgenda;
import in.ind.mds.repo.entity.Status;

/**
 * @author Hinaya
 *
 */
public interface SafMeetingAgendaDao extends JpaRepository<SafMeetingAgenda, String>{
	
	
	SafMeetingAgenda findByIdAndStatusNot(String id, Status softDeleteStatus);
	
	List<SafMeetingAgenda> findByIdInAndStatusNot(List<String> ids, Status status);

	@Modifying
	@Transactional
	@Query(value = "SELECT * FROM TB_SAF_MEETING_AGENDA WHERE RECORD_STATUS != 2", nativeQuery = true)
	List<SafMeetingAgenda> findAllSafMeetingAgenda();

	SafMeetingAgenda findByAgendaNameAndStatusNot(String agendaName, Status Status);

	SafMeetingAgenda findByAgendaNameAndStatusNotAndIdNot(String agendaName, Status softDeleteStatus, String id);

}
