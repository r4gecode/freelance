/**
 * 
 */
package in.ind.mds.repo.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * @author mds_kiruthika
 *
 */

@Entity
@Table(name="TB_ATTACHMENT")
public class Attachment implements Serializable {
	
	private static final long serialVersionUID = 1156093904768583664L;

	
	@Id
	@Column(name = "ID", nullable = false, unique = true)
	private String id;
	
	@Column(name = "RECORD_ID")
	private String recordId;
	
	@Column(name="ATTACHMENT_ORIGIN",nullable=false)
	private String attachmentOrigin;
	
	@Column(name="ATTACHMENT_TYPE",nullable=false)
	private String attachmentType;
	
	@Column(name="ATTACHMENT_PATH",nullable=false)
	private String attachmentPath;
	
	@Column(name = "SYNC_REQUIRED")
	private String syncRequired;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "INSERT_TIME")
	private Date insertTime;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "UPDATE_TIME")
	private Date updateTime;
	
	@ManyToOne
	@JoinColumn(name="RECORD_STATUS")
	private Status status;
	
	@ManyToOne
	@JoinColumn(name="INSERTED_BY")
	private User insertedBy;
	
	
	@ManyToOne
	@JoinColumn(name="UPDATED_BY")
	private User updatedBy;


	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the recordId
	 */
	public String getRecordId() {
		return recordId;
	}

	/**
	 * @param recordId the recordId to set
	 */
	public void setRecordId(String recordId) {
		this.recordId = recordId;
	}

	/**
	 * @return the attachmentOrigin
	 */
	public String getAttachmentOrigin() {
		return attachmentOrigin;
	}

	/**
	 * @param attachmentOrigin the attachmentOrigin to set
	 */
	public void setAttachmentOrigin(String attachmentOrigin) {
		this.attachmentOrigin = attachmentOrigin;
	}

	public String getAttachmentType() {
		return attachmentType;
	}

	public void setAttachmentType(String attachmentType) {
		this.attachmentType = attachmentType;
	}

	public String getAttachmentPath() {
		return attachmentPath;
	}

	public void setAttachmentPath(String attachmentPath) {
		this.attachmentPath = attachmentPath;
	}

	public String getSyncRequired() {
		return syncRequired;
	}

	public void setSyncRequired(String syncRequired) {
		this.syncRequired = syncRequired;
	}

	public Date getInsertTime() {
		return insertTime;
	}

	public void setInsertTime(Date insertTime) {
		this.insertTime = insertTime;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	public User getInsertedBy() {
		return insertedBy;
	}

	public void setInsertedBy(User insertedBy) {
		this.insertedBy = insertedBy;
	}

	public User getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(User updatedBy) {
		this.updatedBy = updatedBy;
	}

	
	
	

}
