package in.ind.mds.repo.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import in.ind.mds.repo.entity.Address;
import in.ind.mds.repo.entity.Status;

public interface AddressDao extends JpaRepository<Address, String> {

	Address findByIdAndStatusNot(String addressId, Status status);
	
	List<Address> findByIdInAndStatusNot(List<String> addressIds, Status status);

	Address findByAddressTypeAndStatusNot(String addressType, Status status);

	Address findByPostalCodeAndCountryAndStatusNot(String postalCode, String country, Status status);
	
	@Modifying
	@Transactional
	@Query(value = "SELECT * FROM TB_ADDRESS WHERE RECORD_STATUS != 2", nativeQuery = true)
	List<Address> findAllAddress();

}
