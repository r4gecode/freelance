package in.ind.mds.repo.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import in.ind.mds.repo.entity.Port;
import in.ind.mds.repo.entity.Status;

public interface PortDao extends JpaRepository<Port, String> {

	Port findByPortNameAndStatusNot(String portName, Status status);

	Port findByPortNameAndStatusNotAndIdNot(String portName, Status status, String portId);
	
	Port findByIdAndStatusNot(String portId, Status status);
	
	List<Port> findByIdInAndStatusNot(List<String> portIds, Status status);
	
	@Modifying
	@Transactional
	@Query(value = "SELECT * FROM TB_PORT WHERE RECORD_STATUS != 2", nativeQuery = true)
	List<Port> findAllPort();
	
//	@Modifying
//	@Transactional
//	@Query(value = "UPDATE TB_PORT SET RECORD_STATUS=:statusNo WHERE ID=:portId", nativeQuery = true)
//	void softDelete(@Param(value = "statusNo") final int statusNo, @Param(value = "portId") final String portId);

}
