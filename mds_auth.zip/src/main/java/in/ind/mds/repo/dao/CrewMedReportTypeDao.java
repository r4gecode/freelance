/**
 * 
 */
package in.ind.mds.repo.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import in.ind.mds.repo.entity.CrewMedReportType;
import in.ind.mds.repo.entity.Status;

/**
 * @author mds-arockia
 *
 */
public interface CrewMedReportTypeDao extends JpaRepository<CrewMedReportType, String>{
	
	List<CrewMedReportType> findByNameAndStatusNot(String name, Status status);
	
	List<CrewMedReportType> findByNameAndStatusNotAndIdNot(String name, Status status, String id);
	
	CrewMedReportType findByIdAndStatusNot(String id, Status status);
	
	List<CrewMedReportType> findByIdInAndStatusNot(List<String> ids, Status status);
	
	@Modifying
	@Transactional
	@Query(value = "SELECT * FROM TB_CREW_MED_REPORT_TYPE WHERE RECORD_STATUS != 2", nativeQuery = true)
	List<CrewMedReportType> findAllCrewMedReportType();
}
