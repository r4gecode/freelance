package in.ind.mds.repo.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "TB_USER")
public class User implements Serializable {

	/** 
	 * 
	 */
	private static final long serialVersionUID = -3502039122676202977L;

	@Id
	@Column(name = "ID", nullable = false, unique = true)
	private String id;

	@Column(name = "USER_LOGIN_ID")
	private String userLoginId;

	@Column(name = "USER_PWD")
	private String password;

	@Column(name = "USER_TITLE")
	private Integer userTitle;

	@Column(name = "USER_TYPE")
	private String userType;

	@Column(name = "USER_NAME")
	private String userName;

	@Column(name = "USER_SHORT_NAME")
	private String userShortName;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "USER_VALID_TO")
	private Date userValidTo;

/*	@Column(name = "RECORD_STATUS")
	private String userStatus;
*/
	@Column(name = "USER_STATUS_REMARKS")
	private String userStatusRemark;

	@Column(name = "USER_LOCKED_FLAG")
	private String userLockedFlag;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "INSERT_TIME")
	private Date insertTime;

	@Column(name = "INSERTED_BY")
	private Integer insertedBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "UPDATE_TIME")
	private Date updateTime;
	
	@Column(name = "UPDATED_BY")
	private Integer updatedBy;




	@Column(name = "SYNC_REQUIRED")
	private String syncRequired;

	@OneToOne
	@JoinColumn(name = "RECORD_STATUS")
	private Status status;

	/*
	 * @OneToOne
	 * 
	 * @JoinColumn(name = "USER_TYPE", insertable = false, updatable = false)
	 * private UserRole userRole;
	 */

	
	public User() {
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getUserLoginId() {
		return userLoginId;
	}

	public void setUserLoginId(String userLoginId) {
		this.userLoginId = userLoginId;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Integer getUserTitle() {
		return userTitle;
	}

	public void setUserTitle(Integer userTitle) {
		this.userTitle = userTitle;
	}

	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}

	public String getUserName() {
		return userName;
	}

	public String getPassword() {
		return password;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserShortName() {
		return userShortName;
	}

	public void setUserShortName(String userShortName) {
		this.userShortName = userShortName;
	}

	public Date getUserValidTo() {
		return userValidTo;
	}

	public void setUserValidTo(Date userValidTo) {
		this.userValidTo = userValidTo;
	}

	/*public String getUserStatus() {
		return userStatus;
	}

	public void setUserStatus(String userStatus) {
		this.userStatus = userStatus;
	}
*/
	public String getUserStatusRemark() {
		return userStatusRemark;
	}

	public void setUserStatusRemark(String userStatusRemark) {
		this.userStatusRemark = userStatusRemark;
	}

	public String getUserLockedFlag() {
		return userLockedFlag;
	}

	public void setUserLockedFlag(String userLockedFlag) {
		this.userLockedFlag = userLockedFlag;
	}

	public Date getInsertTime() {
		return insertTime;
	}

	public void setInsertTime(Date insertTime) {
		this.insertTime = insertTime;
	}

	public Integer getInsertedBy() {
		return insertedBy;
	}

	public void setInsertedBy(Integer insertedBy) {
		this.insertedBy = insertedBy;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}
	
	public Integer getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(Integer updatedBy) {
		this.updatedBy = updatedBy;
	}

	public String getSyncRequired() {
		return syncRequired;
	}

	public void setSyncRequired(String syncRequired) {
		this.syncRequired = syncRequired;
	}

}