/**
 * 
 */
package in.ind.mds.repo.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import in.ind.mds.repo.entity.Staff;
import in.ind.mds.repo.entity.Status;
import in.ind.mds.repo.entity.TravelDocument;

/**
 * @author mds_kiruthika
 *
 */
public interface TravelDocumentDao  extends JpaRepository<TravelDocument, String> {
	
	TravelDocument findByIdAndStatusNot(String travelDocumentId, Status status);
	
	List<TravelDocument> findByDocumentNumberAndStatusNotAndIdNot(String documentNumber, Status status, String docId);
	
	List<TravelDocument> findByIdInAndStatusNot(List<String> travelDocumentIds,Status status);
	
	/*@Query(value = "SELECT * FROM TB_TRAVEL_DOCUMENT WHERE (DOCUMENT_TYPE = ?1 OR DOCUMENT_NUMBER= ?2 ) AND RECORD_STATUS != 2", nativeQuery = true)
	List<TravelDocument> uniqueCheckforAdd(String documnetType, String documentNuber);
	
	@Query(value = "SELECT * FROM TB_TRAVEL_DOCUMENT WHERE (DOCUMENT_TYPE = ?1 OR DOCUMENT_NUMBER= ?2) AND RECORD_STATUS != 2 ", nativeQuery = true)
	List<TravelDocument> uniqueCheckForUpdate(String documnetType, String documentNuber);*/
	

	@Modifying
	@Transactional
	@Query(value = "SELECT * FROM TB_TRAVEL_DOCUMENT WHERE RECORD_STATUS != 2", nativeQuery = true)
	List<TravelDocument> findAllTravelDoc();
	
	List<TravelDocument> findByStaffAndStatusNot(Staff staff, Status status);

}
