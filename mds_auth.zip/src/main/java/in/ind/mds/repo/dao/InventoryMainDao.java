package in.ind.mds.repo.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import in.ind.mds.repo.entity.InventoryMain;
import in.ind.mds.repo.entity.Status;

public interface InventoryMainDao extends JpaRepository<InventoryMain, String> {

	InventoryMain findByCtgyNameAndStatusNot(final String ctgyName, final Status status);

	InventoryMain findByCtgyCodeAndCtgyNameAndStatusNot(final String ctgyCode, final String ctgyName, final Status status);
	
	InventoryMain findByIdAndStatusNot(final String ctgyId, final Status status);
	
	@Modifying
	@Transactional
	@Query(value = "SELECT * FROM TB_PMS_INVENTORY_MAIN WHERE RECORD_STATUS != 2", nativeQuery = true)
	List<InventoryMain> findAllInventoryMain();

}
