package in.ind.mds.repo.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "TB_PMS_INVENTORY")
public class Inventory implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6111459026630292085L;

	@Id
	@Column(name = "ID", nullable = false, unique = true)
	private String id;

	
	@Column(name = "INVENTORY_NAME")
	private String inventoryName;

	@Column(name = "INVENTORY_CODE")
	private String inventoryCode;


	@Column(name = "UOM")
	private float measure;

	@Column(name = "MAKE")
	private String make;

	@Column(name = "PART_NUMBER")
	private String partNumber;

	@Column(name = "DRAW_NUMBER")
	private String drawNumber;

	@Column(name = "MODEL_NUMBER")
	private String modelNumber;

	@Column(name = "POSITION_NUMBER")
	private String positionNumber;

	@Column(name = "SERIAL_NUMBER")
	private String serialNumber;

	
	@Column(name = "CRITICAL_INDI")
	private String criticalIndi;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "EXPIRY_DATE")
	private Date expiryDate;

	@Column(name = "REMARKS")
	private String remarks;

	@Column(name = "ATTACHMENT")
	private String attachment;

	@Column(name = "REORDER_LEVEL")
	private float reorderLevel;

	@Column(name = "REORDER_QTY")
	private float reorderQty;

	@Column(name = "MAX_QTY")
	private float maxQty;

	@Column(name = "CURR_QTY")
	private float curQty;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "INSERT_TIME")
	private Date insertTime;

	@Column(name = "INSERTED_BY")
	private int insertedBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "UPDATE_TIME")
	private Date updateTime;

	@Column(name = "UPDATED_BY")
	private int updatedBy;

	@Column(name = "SYNC_REQUIRED")
	private String syncRequired;
	

	@OneToOne
	@JoinColumn(name="COMPONENT_GROUP")
	private Component component;
	
	@OneToOne
	@JoinColumn(name="COMPONENT_NAME")
	private ComponentMain componentMain;
	
	
	/*(name = "VESSEL_ID")
	private String vesselId;

	@Column(name = "INVENTORY_CTGY_ID")
	private String inventoryCtgyId;
	
	@Column(name = "LOCATIONS_ON_BOARD_ID")
	private String locationsOnBoardId;

	@Column(name = "RECORD_STATUS")
	private String recordStatus;*/

	
	
	
	@OneToOne
	@JoinColumn(name="INVENTORY_CTGY_ID")
	private InventoryMain inventoryMain;


	@OneToOne
	@JoinColumn(name="LOCATIONS_ON_BOARD_ID")
	private LocOnboard locOnboard;
	
	@OneToOne
	@JoinColumn(name="VESSEL_ID")
	private Vessel vessel;


	@OneToOne
	@JoinColumn(name="RECORD_STATUS")
	private Status status;

	

	public Component getComponent() {
		return component;
	}

	public void setComponent(Component component) {
		this.component = component;
	}

	public ComponentMain getComponentMain() {
		return componentMain;
	}

	public void setComponentMain(ComponentMain componentMain) {
		this.componentMain = componentMain;
	}

	public InventoryMain getInventoryMain() {
		return inventoryMain;
	}

	public void setInventoryMain(InventoryMain inventoryMain) {
		this.inventoryMain = inventoryMain;
	}

	public LocOnboard getLocOnboard() {
		return locOnboard;
	}

	public void setLocOnboard(LocOnboard locOnboard) {
		this.locOnboard = locOnboard;
	}

	public Vessel getVessel() {
		return vessel;
	}

	public void setVessel(Vessel vessel) {
		this.vessel = vessel;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	public String getSyncRequired() {
		return syncRequired;
	}

	public void setSyncRequired(String syncRequired) {
		this.syncRequired = syncRequired;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}


	public String getInventoryName() {
		return inventoryName;
	}

	public void setInventoryName(String inventoryName) {
		this.inventoryName = inventoryName;
	}

	public String getInventoryCode() {
		return inventoryCode;
	}

	public void setInventoryCode(String inventoryCode) {
		this.inventoryCode = inventoryCode;
	}


	public float getMeasure() {
		return measure;
	}

	public void setMeasure(float measure) {
		this.measure = measure;
	}

	public String getMake() {
		return make;
	}

	public void setMake(String make) {
		this.make = make;
	}

	public String getPartNumber() {
		return partNumber;
	}

	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}

	public String getDrawNumber() {
		return drawNumber;
	}

	public void setDrawNumber(String drawNumber) {
		this.drawNumber = drawNumber;
	}

	public String getModelNumber() {
		return modelNumber;
	}

	public void setModelNumber(String modelNumber) {
		this.modelNumber = modelNumber;
	}

	public String getPositionNumber() {
		return positionNumber;
	}

	public void setPositionNumber(String positionNumber) {
		this.positionNumber = positionNumber;
	}

	public String getSerialNumber() {
		return serialNumber;
	}

	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}

	
	public String getCriticalIndi() {
		return criticalIndi;
	}

	public void setCriticalIndi(String criticalIndi) {
		this.criticalIndi = criticalIndi;
	}

	public Date getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getAttachment() {
		return attachment;
	}

	public void setAttachment(String attachment) {
		this.attachment = attachment;
	}

	public float getReorderLevel() {
		return reorderLevel;
	}

	public void setReorderLevel(float reorderLevel) {
		this.reorderLevel = reorderLevel;
	}

	public float getReorderQty() {
		return reorderQty;
	}

	public void setReorderQty(float reorderQty) {
		this.reorderQty = reorderQty;
	}

	public float getMaxQty() {
		return maxQty;
	}

	public void setMaxQty(float maxQty) {
		this.maxQty = maxQty;
	}

	public float getCurQty() {
		return curQty;
	}

	public void setCurQty(float curQty) {
		this.curQty = curQty;
	}

	public Date getInsertTime() {
		return insertTime;
	}

	public void setInsertTime(Date insertTime) {
		this.insertTime = insertTime;
	}

	public int getInsertedBy() {
		return insertedBy;
	}

	public void setInsertedBy(int insertedBy) {
		this.insertedBy = insertedBy;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public int getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(int updatedBy) {
		this.updatedBy = updatedBy;
	}

/*	@OneToOne
	@JoinColumn(name = "STATUS", insertable = false, updatable = false)
	private Status inventorStatus;
	
	@OneToOne
	@JoinColumn(name= "VESSEL_ID",insertable=false,updatable=false)
	private Vessel vessel;
	
	@OneToOne
	@JoinColumn(name= "INVENTORY_CTGY_ID",insertable=false,updatable=false)
	private InventoryMain inventoryMain; 	
*/	

	
	
	
}