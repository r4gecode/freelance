/**
 * 
 */
package in.ind.mds.repo.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * @author mds_kiruthika
 *
 */

@Entity
@Table(name="TB_STAFF")
public class Staff implements Serializable{

	private static final long serialVersionUID = 1156093412721513664L;
	
	@Id
	@Column(name = "ID", nullable = false, unique = true)
	private String id;
	
	@Column(name="STAFF_TYPE",nullable=false)
	private String staffType;
	
	@Column(name="STAFF_CODE",nullable=false)
	private String staffCode;
	
	@Column(name="FIRST_NAME", nullable=false)
	private String firstName;
	
	@Column(name="LAST_NAME")
	private String lastName;
	
	@Column(name="FULL_NAME")
	private String fullName;
	
	@Column(name="PASSPORT_NUMBER", nullable=false)
	private String passportNumber;
	
	@Column(name="DOB")
	private String dob;
	
	@Column(name="AGE")
	private int age;
	
	@Column(name="GENDER")
	private char gender;
	
	@Column(name="MARITAL_STATUS")
	private String maritalStatus;
	
	@Column(name="PLACE_OF_BIRTH")
	private String placeOfBirth;
	
	@Column(name="HEIGHT")
	private long height;
	
	@Column(name="WEIGHT")
	private long weight;
	
	@Column(name="PHONE")
	private String phone;
	
	@Column(name="MOBILE")
	private String mobile;
	
	@Column(name="EMAIL")
	private String email;
	
	@Column(name="FAX")
	private String fax;
	
	@Column(name="CITY")
	private String city;
	
	@Column(name="RELIGION")
	private String religion;
	
	@Column(name="QUALIFICATION")
	private String qualification;
	
	@Column(name="PRESENT_ADDRESS")
	private String presentAddress;
	
	@Column(name="HOME_ADDRESS")
	private String homeAddress;
	
	@Column(name="REMARKS")
	private String remarks;
	
	@Column(name="HAS_LOGIN")
	private char hasLogin;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column (name="JOIN_DATE")
	private Date joinDate;
	
	@Column (name="BLOOD_GROUP")
	private String bloodGroup;
	
	@Column(name = "SYNC_REQUIRED")
	private String syncRequired;
	
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "INSERT_TIME")
	private Date insertTime;


	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "UPDATE_TIME")
	private Date updateTime;

	
	@ManyToOne
	@JoinColumn(name="COUNTRY")
	private Country country;
	
	@ManyToOne
	@JoinColumn(name="COMPANY_NAME")
	private Company companyName;
	
	@ManyToOne
	@JoinColumn(name="STAFF_ROLE")
	private Role role;
	
	@ManyToOne
	@JoinColumn(name="NATIONALITY")
	private Nationality nationality;
	
	@ManyToOne
	@JoinColumn(name="RECORD_STATUS")
	private Status status;
	
	@ManyToOne
	@JoinColumn(name="STAFF_STATUS")
	private Status staffStatus;
	
	@ManyToOne
	@JoinColumn(name="LOGIN_USER_ID")
	private User loginUser;
	
	@ManyToOne
	@JoinColumn(name="INSERTED_BY")
	private User insertedBy;
	
	
	@ManyToOne
	@JoinColumn(name="UPDATED_BY")
	private User updatedBy;
	
	
//	@ManyToOne
//	@JoinColumn(name="STAFF_PIC_ATTACH_ID")
//	private Attachment staffPicAttachID;
//
//	@ManyToOne
//	@JoinColumn(name="ATTACHMENT_ID")
//	private Attachment attachmentID;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getStaffType() {
		return staffType;
	}

	public void setStaffType(String staffType) {
		this.staffType = staffType;
	}

	public String getStaffCode() {
		return staffCode;
	}

	public void setStaffCode(String staffCode) {
		this.staffCode = staffCode;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getPassportNumber() {
		return passportNumber;
	}

	public void setPassportNumber(String passportNumber) {
		this.passportNumber = passportNumber;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public char getGender() {
		return gender;
	}

	public void setGender(char gender) {
		this.gender = gender;
	}

	public String getMaritalStatus() {
		return maritalStatus;
	}

	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}

	public String getPlaceOfBirth() {
		return placeOfBirth;
	}

	public void setPlaceOfBirth(String placeOfBirth) {
		this.placeOfBirth = placeOfBirth;
	}

	public long getHeight() {
		return height;
	}

	public void setHeight(long height) {
		this.height = height;
	}

	public long getWeight() {
		return weight;
	}

	public void setWeight(long weight) {
		this.weight = weight;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getFax() {
		return fax;
	}

	public void setFax(String fax) {
		this.fax = fax;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getReligion() {
		return religion;
	}

	public void setReligion(String religion) {
		this.religion = religion;
	}

	public String getQualification() {
		return qualification;
	}

	public void setQualification(String qualification) {
		this.qualification = qualification;
	}

	public String getPresentAddress() {
		return presentAddress;
	}

	public void setPresentAddress(String presentAddress) {
		this.presentAddress = presentAddress;
	}

	public String getHomeAddress() {
		return homeAddress;
	}

	public void setHomeAddress(String homeAddress) {
		this.homeAddress = homeAddress;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public char getHasLogin() {
		return hasLogin;
	}

	public void setHasLogin(char hasLogin) {
		this.hasLogin = hasLogin;
	}

	public Date getJoinDate() {
		return joinDate;
	}

	public void setJoinDate(Date joinDate) {
		this.joinDate = joinDate;
	}

	public String getBloodGroup() {
		return bloodGroup;
	}

	public void setBloodGroup(String bloodGroup) {
		this.bloodGroup = bloodGroup;
	}

	public String getSyncRequired() {
		return syncRequired;
	}

	public void setSyncRequired(String syncRequired) {
		this.syncRequired = syncRequired;
	}

	public Date getInsertTime() {
		return insertTime;
	}

	public void setInsertTime(Date insertTime) {
		this.insertTime = insertTime;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public Country getCountry() {
		return country;
	}

	public void setCountry(Country country) {
		this.country = country;
	}

	public Company getCompanyName() {
		return companyName;
	}

	public void setCompanyName(Company companyName) {
		this.companyName = companyName;
	}

	public Role getRole() {
		return role;
	}

	public void setRole(Role role) {
		this.role = role;
	}

	public Nationality getNationality() {
		return nationality;
	}

	public void setNationality(Nationality nationality) {
		this.nationality = nationality;
	}

	

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	public Status getStaffStatus() {
		return staffStatus;
	}

	public void setStaffStatus(Status staffStatus) {
		this.staffStatus = staffStatus;
	}

	public User getLoginUser() {
		return loginUser;
	}

	public void setLoginUser(User loginUser) {
		this.loginUser = loginUser;
	}

	public User getInsertedBy() {
		return insertedBy;
	}

	public void setInsertedBy(User insertedBy) {
		this.insertedBy = insertedBy;
	}

	public User getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(User updatedBy) {
		this.updatedBy = updatedBy;
	}

}
