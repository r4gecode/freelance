/**
 * 
 */
package in.ind.mds.repo.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * @author mds-arockia
 *
 */
@Entity
@Table(name = "TB_PMS_ACTIVITY_TYPE")
public class ActivityType implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 117478938284548L;
	
	@Id
	@Column(name = "ID", nullable = false, unique = true)
	private String id;
	
	@Column(name = "ACTIVITY_NAME")
	private String activityName;
	
	@Column(name = "DIRECTION")
	private String direction;
	
	@Column(name = "INSERT_TIME")
	private Date insertTime;
	
	@Column(name = "INSERTED_BY")
	private Integer insertedBy;
	
	@Column(name = "UPDATE_TIME")
	private Date updateTime;
	
	@Column(name = "UPDATED_BY")
	private Integer updatedBy;
	
	@ManyToOne
	@JoinColumn(name = "RECORD_STATUS")
	private Status status;

	@Column(name = "SYNC_REQUIRED")
	private String syncRequired;

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the activityName
	 */
	public String getActivityName() {
		return activityName;
	}

	/**
	 * @param activityName the activityName to set
	 */
	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}

	/**
	 * @return the direction
	 */
	public String getDirection() {
		return direction;
	}

	/**
	 * @param direction the direction to set
	 */
	public void setDirection(String direction) {
		this.direction = direction;
	}

	/**
	 * @return the insertTime
	 */
	public Date getInsertTime() {
		return insertTime;
	}

	/**
	 * @param insertTime the insertTime to set
	 */
	public void setInsertTime(Date insertTime) {
		this.insertTime = insertTime;
	}

	/**
	 * @return the insertedBy
	 */
	public Integer getInsertedBy() {
		return insertedBy;
	}

	/**
	 * @param insertedBy the insertedBy to set
	 */
	public void setInsertedBy(Integer insertedBy) {
		this.insertedBy = insertedBy;
	}

	/**
	 * @return the updateTime
	 */
	public Date getUpdateTime() {
		return updateTime;
	}

	/**
	 * @param updateTime the updateTime to set
	 */
	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	/**
	 * @return the updatedBy
	 */
	public Integer getUpdatedBy() {
		return updatedBy;
	}

	/**
	 * @param updatedBy the updatedBy to set
	 */
	public void setUpdatedBy(Integer updatedBy) {
		this.updatedBy = updatedBy;
	}

	/**
	 * @return the status
	 */
	public Status getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(Status status) {
		this.status = status;
	}

	/**
	 * @return the syncRequired
	 */
	public String getSyncRequired() {
		return syncRequired;
	}

	/**
	 * @param syncRequired the syncRequired to set
	 */
	public void setSyncRequired(String syncRequired) {
		this.syncRequired = syncRequired;
	}
	
}
