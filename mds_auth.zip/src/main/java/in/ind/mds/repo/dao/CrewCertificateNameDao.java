/**
 * 
 */
package in.ind.mds.repo.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import in.ind.mds.repo.entity.CrewCertificateName;
import in.ind.mds.repo.entity.Status;

/**
 * @author mds_kiruthika
 *
 */
public interface CrewCertificateNameDao extends JpaRepository<CrewCertificateName, String> {
	
	CrewCertificateName findByIdAndStatusNot(String certificateID, Status status);
	
	List<CrewCertificateName> findByIdInAndStatusNot(List<String> certificateID, Status status);
	
	CrewCertificateName findByCertificateNameAndStatusNot(String certificateName, Status status);
	
	CrewCertificateName findByCertificateNameAndStatusNotAndIdNot(String certificateName, Status status, String certificateID);
	
	@Modifying
	@Transactional
	@Query(value = "SELECT * FROM TB_CREW_CERTIFICATE_NAME WHERE RECORD_STATUS != 2", nativeQuery = true)
	List<CrewCertificateName> findAllCrewCertificate();
}
