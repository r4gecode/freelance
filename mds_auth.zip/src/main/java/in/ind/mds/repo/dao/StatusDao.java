package in.ind.mds.repo.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import in.ind.mds.repo.entity.Status;

public interface StatusDao extends JpaRepository<Status, String> {

	Status findByStatusName(final String statusName);

	Status findByStatusNameAndStatusDesc(final String statusName, final String statusDesc);
	
	List<Status> findAll();
	
	Optional<Status> findById(final String statusId);

}
