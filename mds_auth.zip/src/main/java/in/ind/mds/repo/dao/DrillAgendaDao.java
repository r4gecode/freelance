/**
 * 
 */
package in.ind.mds.repo.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;


import in.ind.mds.repo.entity.DrillAgenda;
import in.ind.mds.repo.entity.DrillScheduler;
import in.ind.mds.repo.entity.Status;

/**
 * @author Hinaya
 *
 */
public interface DrillAgendaDao extends JpaRepository<DrillAgenda, String>{
	
	List<DrillAgenda> findByDrillSchedulerAndStatusNot(DrillScheduler drillScheduler, Status status);

	List<DrillAgenda> findByIdInAndStatusNot(List<String> ids, Status status);


}
