package in.ind.mds.repo.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import in.ind.mds.repo.entity.Port;
import in.ind.mds.repo.entity.SafetyCategory;
import in.ind.mds.repo.entity.Status;

public interface SftyDrillCatDao extends JpaRepository<SafetyCategory, String>{
	
	SafetyCategory findByCatgName(final String catgName);

	Optional<SafetyCategory> findById(final String id);
	
	@Modifying
	@Transactional
	@Query(value = "SELECT * FROM TB_SAFETY_CATEGORY WHERE RECORD_STATUS = 1", nativeQuery = true)
	List<Port> findAllSftyCatNme();
	
	@Modifying
	@Transactional
	@Query(value = "UPDATE TB_SAFETY_CATEGORY SET RECORD_STATUS=:statusNo WHERE ID=:catgId", nativeQuery = true)
	void softDelete(@Param(value = "statusNo") final int statusNo, @Param(value = "catgId") final String catgId);

	List<SafetyCategory> findByIdInAndStatusNot(List<String> catIds, Status status);

}
