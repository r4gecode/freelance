/**
 * 
 */
package in.ind.mds.repo.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * @author Hinaya
 *
 */
@Entity
@Table(name = "TB_DRILL_SCHEDULER")
public class DrillScheduler implements Serializable {
	
	

	private static final long serialVersionUID = 1123456823448L;
	
	@Id
	@Column(name = "ID", nullable = false, unique = true)
	private String id;
	
	@Column(name = "DRILL_NUMBER")
	private String drillNumber;
	
	@Column(name = "DRILL_NAME")
	private String drillName;
	
	@Column(name = "DRILL_PROCEDURE")
	private String procedure;
	
	@Column(name = "FREQUENCY")
	private int frequency;
	
	@Column(name = "FREQUENCY_TYPE")
	private String frequencyType;
	
	@Column(name = "LAST_DONE_DATE")
	private Date lastDoneDate;
	
	@Column(name = "NEXT_DUE_DATE")
	private Date nextDueDate;
	
	@Column(name = "SYNC_REQUIRED")
	private String syncRequired;
	
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "INSERT_TIME")
	private Date insertTime;	
	
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "UPDATE_TIME")
	private Date updateTime;

	@ManyToOne
	@JoinColumn(name = "RECORD_STATUS")
	private Status status;
	
	@ManyToOne
	@JoinColumn(name = "INSERTED_BY")
	private User insertedBy;
	
	@ManyToOne
	@JoinColumn(name = "UPDATED_BY")
	private User updatedBy;
	
	@ManyToOne
	@JoinColumn(name = "DRILL_CATEGORY_ID")
	private DrillCategories drillCategories;

	@ManyToOne
	@JoinColumn(name = "FLEET_ID")
	private Fleet fleet;
	
	@ManyToOne
	@JoinColumn(name = "VESSEL_ID")
	private Vessel vessel;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getDrillNumber() {
		return drillNumber;
	}

	public void setDrillNumber(String drillNumber) {
		this.drillNumber = drillNumber;
	}

	

	public int getFrequency() {
		return frequency;
	}

	public void setFrequency(int frequency) {
		this.frequency = frequency;
	}

	public String getFrequencyType() {
		return frequencyType;
	}

	public void setFrequencyType(String frequencyType) {
		this.frequencyType = frequencyType;
	}

	public Date getLastDoneDate() {
		return lastDoneDate;
	}

	public void setLastDoneDate(Date lastDoneDate) {
		this.lastDoneDate = lastDoneDate;
	}

	public Date getNextDueDate() {
		return nextDueDate;
	}

	public void setNextDueDate(Date nextDueDate) {
		this.nextDueDate = nextDueDate;
	}

	public String getSyncRequired() {
		return syncRequired;
	}

	public void setSyncRequired(String syncRequired) {
		this.syncRequired = syncRequired;
	}

	public String getDrillName() {
		return drillName;
	}

	public void setDrillName(String drillName) {
		this.drillName = drillName;
	}

	public Date getInsertTime() {
		return insertTime;
	}

	public void setInsertTime(Date insertTime) {
		this.insertTime = insertTime;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	public User getInsertedBy() {
		return insertedBy;
	}

	public void setInsertedBy(User insertedBy) {
		this.insertedBy = insertedBy;
	}

	public User getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(User updatedBy) {
		this.updatedBy = updatedBy;
	}

	public DrillCategories getDrillCategories() {
		return drillCategories;
	}

	public void setDrillCategories(DrillCategories drillCategories) {
		this.drillCategories = drillCategories;
	}

	public Fleet getFleet() {
		return fleet;
	}

	public void setFleet(Fleet fleet) {
		this.fleet = fleet;
	}

	public Vessel getVessel() {
		return vessel;
	}

	public void setVessel(Vessel vessel) {
		this.vessel = vessel;
	}

	public String getProcedure() {
		return procedure;
	}

	public void setProcedure(String procedure) {
		this.procedure = procedure;
	}
	
	
	
	
	
	

}
