/**
 * 
 */
package in.ind.mds.repo.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import in.ind.mds.repo.entity.Fleet;
import in.ind.mds.repo.entity.Status;

/**
 * @author mds-arockia
 *
 */
public interface FleetDao extends JpaRepository<Fleet, String>{

	Fleet findByIdAndStatusNot(String fleetId, Status status);
	
	List<Fleet> findByIdInAndStatusNot(List<String> fleetId, Status status);
	
	Fleet findByFleetNameAndStatusNot(String fleetName, Status status);
	
	Fleet findByFleetNameAndStatusNotAndIdNot(String fleetName, Status status, String fleetId);
	
	@Modifying
	@Transactional
	@Query(value = "SELECT * FROM TB_FLEET_DETAILS WHERE RECORD_STATUS != 2", nativeQuery = true)
	List<Fleet> findAllFleet();

}
