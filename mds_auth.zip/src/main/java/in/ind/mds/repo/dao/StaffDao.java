/**
 * 
 */
package in.ind.mds.repo.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import in.ind.mds.repo.entity.Staff;
import in.ind.mds.repo.entity.Status;

/**
 * @author mds_kiruthika
 *
 */
public interface StaffDao extends JpaRepository<Staff, String> {
	
	Staff findByIdAndStatusNot(String staffId, Status status);
	
	List<Staff> findByIdInAndStatusNot(List<String> staffIds,Status status);
	
	Staff findByPassportNumberAndStatusNot(String passportNo,Status status);
	
	@Query(value="SELECT * FROM TB_STAFF WHERE (STAFF_CODE =?1 OR PASSPORT_NUMBER=?2) AND RECORD_STATUS !=2", nativeQuery=true)
	List<Staff> uniqueCheckForAdd(String staffCode,String passportNumber);
	
	@Query(value="SELECT * FROM TB_STAFF WHERE (STAFF_CODE =?1 OR PASSPORT_NUMBER =?3) AND RECORD_STATUS !=2 AND ID!=?2", nativeQuery=true)
	List<Staff> uniqueCheckForUpdate(String staffCode , String staffId,String passportNumber);
	
	@Modifying
	@Transactional
	@Query(value = "SELECT * FROM TB_STAFF WHERE RECORD_STATUS != 2", nativeQuery = true)
	List<Staff> findAllStaff();

}
