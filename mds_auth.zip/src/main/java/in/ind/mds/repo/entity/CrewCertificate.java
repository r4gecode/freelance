/**
 * 
 */
package in.ind.mds.repo.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * @author shalini
 *
 */
@Entity
@Table(name="TB_CREW_CERTIFICATE")
public class CrewCertificate implements Serializable{
	private static final long serialVersionUID = 1174889856248L;
	@Id
	@Column(name="ID",nullable=false,unique=true)
	private String id;
	
	@Column(name="CERT_NO")
	private String certNo;
	
	@Column(name="ISSUED_AT")
	private String issuedAt;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="ISSUED_DATE")
	private Date issuedDate;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="EXPIRY_DATE")
	private Date expiryDate;
	
	@Column(name="ISSUED_BY")
	private String issuedBy;
	
	@Column(name="REMARKS")
	private String remarks;
	
	@Column(name="ACTIVE_STATUS")
	private String activeStatus;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "INSERT_TIME")
	private Date insertTime;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "UPDATE_TIME")
	private Date updateTime;

	@Column(name = "SYNC_REQUIRED")
	private String syncRequired;

	@ManyToOne
	@JoinColumn(name="RECORD_STATUS")
	private Status status;
	
	@ManyToOne
	@JoinColumn(name="STAFF_ID",nullable=false)
	private Staff staff;
	
	@ManyToOne
	@JoinColumn(name="CERTIFICATE_TYPE_ID",nullable=false)
	private CrewCertificateType crewCertificateType;
	
	@ManyToOne
	@JoinColumn(name="CERT_NAME_ID")
	private CrewCertificateName crewCertificateName;
	
	@ManyToOne
	@JoinColumn(name="CERT_CAPACITY_ID")
	private  CrewCertifCapacity crewCertificateCapacity;
	
	@ManyToOne
	@JoinColumn(name="INSERTED_BY")
	private User insertedBy;
	
	@ManyToOne
	@JoinColumn(name="UPDATED_BY")
	private User updatedBy;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCertNo() {
		return certNo;
	}

	public void setCertNo(String certNo) {
		this.certNo = certNo;
	}

	public String getIssuedAt() {
		return issuedAt;
	}

	public void setIssuedAt(String issuedAt) {
		this.issuedAt = issuedAt;
	}

	public Date getIssuedDate() {
		return issuedDate;
	}

	public void setIssuedDate(Date issuedDate) {
		this.issuedDate = issuedDate;
	}

	public Date getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}

	public String getIssuedBy() {
		return issuedBy;
	}

	public void setIssuedBy(String issuedBy) {
		this.issuedBy = issuedBy;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getActiveStatus() {
		return activeStatus;
	}

	public void setActiveStatus(String activeStatus) {
		this.activeStatus = activeStatus;
	}

	public Date getInsertTime() {
		return insertTime;
	}

	public void setInsertTime(Date insertTime) {
		this.insertTime = insertTime;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public String getSyncRequired() {
		return syncRequired;
	}

	public void setSyncRequired(String syncRequired) {
		this.syncRequired = syncRequired;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	public Staff getStaff() {
		return staff;
	}

	public void setStaff(Staff staff) {
		this.staff = staff;
	}

	
	public CrewCertificateType getCrewCertificateType() {
		return crewCertificateType;
	}

	public void setCrewCertificateType(CrewCertificateType crewCertificateType) {
		this.crewCertificateType = crewCertificateType;
	}

	public CrewCertificateName getCrewCertificateName() {
		return crewCertificateName;
	}

	public void setCrewCertificateName(CrewCertificateName crewCertificateName) {
		this.crewCertificateName = crewCertificateName;
	}

	public CrewCertifCapacity getCrewCertificateCapacity() {
		return crewCertificateCapacity;
	}

	public void setCrewCertificateCapacity(CrewCertifCapacity crewCertificateCapacity) {
		this.crewCertificateCapacity = crewCertificateCapacity;
	}

	public User getInsertedBy() {
		return insertedBy;
	}

	public void setInsertedBy(User insertedBy) {
		this.insertedBy = insertedBy;
	}

	public User getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(User updatedBy) {
		this.updatedBy = updatedBy;
	}
}
