/**
 * 
 */
package in.ind.mds.repo.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * @author shalini
 *
 */
@Entity
@Table(name="TB_DRILL_COMPLETION")
public class DrillCompletion implements Serializable{
	private static final long serialVersionUID = 7683456824248L;
	
	@Id
	@Column(name = "ID", nullable = false, unique = true)
	private String id;
	
	@Column(name="JOB_STATUS")
	private String jobStatus;
	
	@Column(name="CARRIED_OUT_DATE")
	private Date carriedOutDate;
	
	@Column(name="CARRIED_OUT_AT")
	private String carriedOutAt;
	
	@Column(name="DRILL_COMPLETION_REMARKS")
	private String drillComplRemark;
	
	@Column(name="START_TIME")
	private Date startDate;
	
	
	@Column(name="END_TIME")
	private Date endTime;
	
	@Column(name="TOTAL_HOURS")
	private float totalHours;
	
	@ManyToOne
	@JoinColumn(name="DRILL_SCHEDULER_ID")
	private DrillScheduler drillScheduler;
	
	@ManyToOne
	@JoinColumn(name="DRILL_SUPERVISED_BY")
	private Role drillSupervisedBy;
	
	@ManyToOne
	@JoinColumn(name="PORT")
	private Port port;
	
	@Column(name = "SYNC_REQUIRED")
	private String syncRequired;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "INSERT_TIME")
	private Date insertTime;	
	
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "UPDATE_TIME")
	private Date updateTime;
	
	@ManyToOne
	@JoinColumn(name = "RECORD_STATUS")
	private Status status;
	
	@ManyToOne
	@JoinColumn(name = "INSERTED_BY")
	private User insertedBy;
	
	@ManyToOne
	@JoinColumn(name = "UPDATED_BY")
	private User updatedBy;
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getJobStatus() {
		return jobStatus;
	}

	public void setJobStatus(String jobStatus) {
		this.jobStatus = jobStatus;
	}

	public Date getCarriedOutDate() {
		return carriedOutDate;
	}

	public void setCarriedOutDate(Date carriedOutDate) {
		this.carriedOutDate = carriedOutDate;
	}

	public String getCarriedOutAt() {
		return carriedOutAt;
	}

	public void setCarriedOutAt(String carriedOutAt) {
		this.carriedOutAt = carriedOutAt;
	}

	public String getDrillComplRemark() {
		return drillComplRemark;
	}

	public void setDrillComplRemark(String drillComplRemark) {
		this.drillComplRemark = drillComplRemark;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndTime() {
		return endTime;
	}

	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}

	public float getTotalHours() {
		return totalHours;
	}

	public void setTotalHours(float totalHours) {
		this.totalHours = totalHours;
	}

	public DrillScheduler getDrillScheduler() {
		return drillScheduler;
	}

	public void setDrillScheduler(DrillScheduler drillScheduler) {
		this.drillScheduler = drillScheduler;
	}

	public Role getDrillSupervisedBy() {
		return drillSupervisedBy;
	}

	public void setDrillSupervisedBy(Role drillSupervisedBy) {
		this.drillSupervisedBy = drillSupervisedBy;
	}

	public Port getPort() {
		return port;
	}

	public void setPort(Port port) {
		this.port = port;
	}

	public String getSyncRequired() {
		return syncRequired;
	}

	public void setSyncRequired(String syncRequired) {
		this.syncRequired = syncRequired;
	}

	public Date getInsertTime() {
		return insertTime;
	}

	public void setInsertTime(Date insertTime) {
		this.insertTime = insertTime;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	public User getInsertedBy() {
		return insertedBy;
	}

	public void setInsertedBy(User insertedBy) {
		this.insertedBy = insertedBy;
	}

	public User getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(User updatedBy) {
		this.updatedBy = updatedBy;
	}


}
