/**
 * 
 */
package in.ind.mds.repo.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import in.ind.mds.repo.entity.CrewContract;
import in.ind.mds.repo.entity.Staff;
import in.ind.mds.repo.entity.Status;

/**
 * @author mds-arockia
 *
 */
public interface CrewContractDao extends JpaRepository<CrewContract, String>{

	List<CrewContract> findByStaffAndStatusNot(Staff staff, Status status);

	List<CrewContract> findByIdInAndStatusNot(List<String> ids, Status status);
	
}
