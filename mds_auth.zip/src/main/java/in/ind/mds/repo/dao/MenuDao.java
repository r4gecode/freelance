package in.ind.mds.repo.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import in.ind.mds.repo.entity.Menu;
import in.ind.mds.repo.entity.Status;

public interface MenuDao extends JpaRepository<Menu, String> {

	Menu findByMenuCodeAndStatusNot(String menuCode, Status status);

	Menu findByMenuDescAndMenuUrlAndStatusNot(String menuDesc, String menuUrl, Status status);
	
	Menu findByIdAndStatusNot(String menuId, Status status);
	
	List<Menu> findByIdInAndStatusNot(List<String> menuIds, Status status);
	
	@Query(value="SELECT * FROM TB_MENU WHERE ( MENU_DESC=?1 OR MENU_CODE=?2) AND  RECORD_STATUS != 2", nativeQuery = true)
	List<Menu> uniqueCheckForAdd(String menuDesc, String menuCode);
	
	@Query(value="SELECT * FROM TB_MENU WHERE (MENU_DESC=?1 OR MENU_CODE=?2) AND  RECORD_STATUS != 2 AND ID !=?3 ", nativeQuery = true)
	List<Menu> uniqueCheckForUpdate(String menuDesc, String menuCode, String menuId);
	
	@Modifying
	@Transactional
	@Query(value = "SELECT * FROM TB_MENU WHERE RECORD_STATUS != 2", nativeQuery = true)
	List<Menu> findAllMenu();

}
