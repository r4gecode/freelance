/**
 * 
 */
package in.ind.mds.repo.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * @author Hinaya
 *
 */
@Entity
@Table(name = "TB_CREW_CONTRACT")
public class CrewContract implements Serializable {

	private static final long serialVersionUID = 1124689417621513664L;
	
	@Id
	@Column(name = "ID", nullable = false, unique = true)
	private String id;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "START_DATE", nullable = false )
	private Date startDate;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "END_DATE")
	private Date endDate;
	
	@Column(name = "COMMENTS")
	private String comments;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "STANDBY_FROM")
	private Date standByFrom;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "STANDBY_TO")
	private Date standByTo;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "ACTUAL_SIGN_ON_DATE")
	private Date actualSignOnDate;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "EXPECTED_SIGN_OFF_DATE")
	private Date expectedSignOffDate;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "ACTUAL_SIGN_OFF_DATE")
	private Date actualSignOffDate;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "SIGN_OFF_STANDBY_FROM")
	private Date signOffStandByFrom;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "SIGN_OFF_STANDBY_TO")
	private Date signOffStandByTo;
	
	@Column(name = "SYNC_REQUIRED")
	private String syncRequired;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "INSERT_TIME")
	private Date insertTime;	
		
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "UPDATE_TIME")
	private Date updateTime;
	
	@ManyToOne
	@JoinColumn(name = "STAFF_ID", nullable = false)
	private Staff staff;
	
	@ManyToOne
	@JoinColumn(name = "ROLE")
	private Role role;
	
	@ManyToOne
	@JoinColumn(name = "RECORD_STATUS")
	private Status status;
	
	@ManyToOne
	@JoinColumn(name = "INSERTED_BY")
	private User insertedBy;
	
	@ManyToOne
	@JoinColumn(name = "UPDATED_BY")
	private User updatedBy;

	@ManyToOne
	@JoinColumn(name = "SIGN_ON_PORT")
	private Port signOnPort;
	
	@ManyToOne
	@JoinColumn(name = "SIGN_OFF_PORT")
	private Port signOffPort;
	
	@ManyToOne
	@JoinColumn(name = "SIGNED_TO_VESSEL")
	private Vessel vessel;
	
	@ManyToOne
	@JoinColumn(name = "SIGN_OFF_REASON")
	private SignOffReason SignOffReason;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	/**
	 * @return the standByFrom
	 */
	public Date getStandByFrom() {
		return standByFrom;
	}

	/**
	 * @param standByFrom the standByFrom to set
	 */
	public void setStandByFrom(Date standByFrom) {
		this.standByFrom = standByFrom;
	}

	/**
	 * @return the standByTo
	 */
	public Date getStandByTo() {
		return standByTo;
	}

	/**
	 * @param standByTo the standByTo to set
	 */
	public void setStandByTo(Date standByTo) {
		this.standByTo = standByTo;
	}

	/**
	 * @return the actualSignOnDate
	 */
	public Date getActualSignOnDate() {
		return actualSignOnDate;
	}

	/**
	 * @param actualSignOnDate the actualSignOnDate to set
	 */
	public void setActualSignOnDate(Date actualSignOnDate) {
		this.actualSignOnDate = actualSignOnDate;
	}

	/**
	 * @return the expectedSignOffDate
	 */
	public Date getExpectedSignOffDate() {
		return expectedSignOffDate;
	}

	/**
	 * @param expectedSignOffDate the expectedSignOffDate to set
	 */
	public void setExpectedSignOffDate(Date expectedSignOffDate) {
		this.expectedSignOffDate = expectedSignOffDate;
	}

	/**
	 * @return the actualSignOffDate
	 */
	public Date getActualSignOffDate() {
		return actualSignOffDate;
	}

	/**
	 * @param actualSignOffDate the actualSignOffDate to set
	 */
	public void setActualSignOffDate(Date actualSignOffDate) {
		this.actualSignOffDate = actualSignOffDate;
	}

	/**
	 * @return the signOffStandByFrom
	 */
	public Date getSignOffStandByFrom() {
		return signOffStandByFrom;
	}

	/**
	 * @param signOffStandByFrom the signOffStandByFrom to set
	 */
	public void setSignOffStandByFrom(Date signOffStandByFrom) {
		this.signOffStandByFrom = signOffStandByFrom;
	}

	/**
	 * @return the signOffStandByTo
	 */
	public Date getSignOffStandByTo() {
		return signOffStandByTo;
	}

	/**
	 * @param signOffStandByTo the signOffStandByTo to set
	 */
	public void setSignOffStandByTo(Date signOffStandByTo) {
		this.signOffStandByTo = signOffStandByTo;
	}

	/**
	 * @return the syncRequired
	 */
	public String getSyncRequired() {
		return syncRequired;
	}

	/**
	 * @param syncRequired the syncRequired to set
	 */
	public void setSyncRequired(String syncRequired) {
		this.syncRequired = syncRequired;
	}

	/**
	 * @return the insertTime
	 */
	public Date getInsertTime() {
		return insertTime;
	}

	/**
	 * @param insertTime the insertTime to set
	 */
	public void setInsertTime(Date insertTime) {
		this.insertTime = insertTime;
	}

	/**
	 * @return the updateTime
	 */
	public Date getUpdateTime() {
		return updateTime;
	}

	/**
	 * @param updateTime the updateTime to set
	 */
	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	/**
	 * @return the staff
	 */
	public Staff getStaff() {
		return staff;
	}

	/**
	 * @param staff the staff to set
	 */
	public void setStaff(Staff staff) {
		this.staff = staff;
	}

	/**
	 * @return the role
	 */
	public Role getRole() {
		return role;
	}

	/**
	 * @param role the role to set
	 */
	public void setRole(Role role) {
		this.role = role;
	}

	/**
	 * @return the status
	 */
	public Status getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(Status status) {
		this.status = status;
	}

	/**
	 * @return the insertedBy
	 */
	public User getInsertedBy() {
		return insertedBy;
	}

	/**
	 * @param insertedBy the insertedBy to set
	 */
	public void setInsertedBy(User insertedBy) {
		this.insertedBy = insertedBy;
	}

	/**
	 * @return the updatedBy
	 */
	public User getUpdatedBy() {
		return updatedBy;
	}

	/**
	 * @param updatedBy the updatedBy to set
	 */
	public void setUpdatedBy(User updatedBy) {
		this.updatedBy = updatedBy;
	}

	/**
	 * @return the signOnPort
	 */
	public Port getSignOnPort() {
		return signOnPort;
	}

	/**
	 * @param signOnPort the signOnPort to set
	 */
	public void setSignOnPort(Port signOnPort) {
		this.signOnPort = signOnPort;
	}

	/**
	 * @return the signOffPort
	 */
	public Port getSignOffPort() {
		return signOffPort;
	}

	/**
	 * @param signOffPort the signOffPort to set
	 */
	public void setSignOffPort(Port signOffPort) {
		this.signOffPort = signOffPort;
	}

	/**
	 * @return the vessel
	 */
	public Vessel getVessel() {
		return vessel;
	}

	/**
	 * @param vessel the vessel to set
	 */
	public void setVessel(Vessel vessel) {
		this.vessel = vessel;
	}

	/**
	 * @return the signOffReason
	 */
	public SignOffReason getSignOffReason() {
		return SignOffReason;
	}

	/**
	 * @param signOffReason the signOffReason to set
	 */
	public void setSignOffReason(SignOffReason signOffReason) {
		SignOffReason = signOffReason;
	}

}
