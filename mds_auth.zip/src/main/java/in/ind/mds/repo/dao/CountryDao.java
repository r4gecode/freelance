package in.ind.mds.repo.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import in.ind.mds.repo.entity.Country;
import in.ind.mds.repo.entity.Status;

public interface CountryDao extends JpaRepository<Country, String>  
{

	Country findByIdAndStatusNot(String countryId, Status status);
	
	List<Country> findByIdInAndStatusNot(List<String> countryIds, Status status);

	Country findByCountryNameAndStatusNot(String countryName, Status status);

	Country findByCountryNameAndCountryCodeAndStatusNot(String countryName,String countryCode, Status status);


	@Query(value="SELECT * FROM TB_COUNTRY WHERE ( COUNTRY_NAME = ?1 OR COUNTRY_CODE=?2) AND RECORD_STATUS !=2", nativeQuery = true)
	List<Country> uniqueCheckForAdd(String countryName,String countryCode);
	
	@Query(value="SELECT * FROM TB_COUNTRY WHERE (COUNTRY_NAME = ?1 OR COUNTRY_CODE=?2) AND RECORD_STATUS !=2  AND ID != ?3 ", nativeQuery = true)
	List<Country> uniqueCheckForUpdate(String countryName, String countryCode,  String countryId);
	
	@Modifying
	@Transactional
	@Query(value = "SELECT * FROM TB_COUNTRY WHERE RECORD_STATUS != 2", nativeQuery = true)
	List<Country> findAllCountry();
}

