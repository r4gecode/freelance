/**
 * 
 */
package in.ind.mds.repo.entity;

import java.io.Serializable;
import java.util.Date;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * @author mds-arockia
 *
 */
@Entity
@Table(name = "TB_COMPANY_DETAILS")
public class Company implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1174889756248L;

	@Id
	@Column(name = "ID", nullable = false, unique = true)
	private String id;
	
	@ManyToOne
	@JoinColumn(name = "PARENT_COMPANY")
	private Company parentCompany;
	
	@Column(name = "COMPANY_NAME")
	private String companyName;
	
	@Column(name = "CITY")
	private String city;
	
	@ManyToOne
	@JoinColumn(name = "COUNTRY")
	private Country country;
	
	@Column(name = "FAX")
	private String fax;
	
	@Column(name = "COMPANY_ADDRESS")
	private String companyAddress;
	
	@Column(name = "PHONE_NUMBER")
	private String phoneNumber;
	
	@Column(name = "COMPANY_LOGO")
	private String companyLogo;
	
	@Column(name = "COMPANY_INFORMATION")
	private String companyInformation;
	
	@Column(name = "LICENSE_ACTIVE")
	private String licenseActive;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "INSERT_TIME")
	private Date insertTime;

	@Column(name = "INSERTED_BY")
	private int insertedBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "UPDATE_TIME")
	private Date updateTime;

	@Column(name = "UPDATED_BY")
	private int updatedBy;

	@Column(name = "SYNC_REQUIRED")
	private String syncRequired;

	@ManyToOne
	@JoinColumn(name="RECORD_STATUS")
	private Status status;
	
	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the parentCompany
	 */
	/**
	 * @return the companyName
	 */
	public String getCompanyName() {
		return companyName;
	}

	/**
	 * @return the parentCompany
	 */
	public Company getParentCompany() {
		return parentCompany;
	}

	/**
	 * @param parentCompany the parentCompany to set
	 */
	public void setParentCompany(Company parentCompany) {
		this.parentCompany = parentCompany;
	}

	/**
	 * @param companyName the companyName to set
	 */
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	/**
	 * @return the city
	 */
	public String getCity() {
		return city;
	}

	/**
	 * @param city the city to set
	 */
	public void setCity(String city) {
		this.city = city;
	}

	/**
	 * @return the country
	 */
	public Country getCountry() {
		return country;
	}

	/**
	 * @param country the country to set
	 */
	public void setCountry(Country country) {
		this.country = country;
	}

	/**
	 * @return the fax
	 */
	public String getFax() {
		return fax;
	}

	/**
	 * @param fax the fax to set
	 */
	public void setFax(String fax) {
		this.fax = fax;
	}

	/**
	 * @return the companyAddress
	 */
	public String getCompanyAddress() {
		return companyAddress;
	}

	/**
	 * @param companyAddress the companyAddress to set
	 */
	public void setCompanyAddress(String companyAddress) {
		this.companyAddress = companyAddress;
	}

	/**
	 * @return the phoneNumber
	 */
	public String getPhoneNumber() {
		return phoneNumber;
	}

	/**
	 * @param phoneNumber the phoneNumber to set
	 */
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	/**
	 * @return the companyLogo
	 */
	public String getCompanyLogo() {
		return companyLogo;
	}

	/**
	 * @param companyLogo the companyLogo to set
	 */
	public void setCompanyLogo(String companyLogo) {
		this.companyLogo = companyLogo;
	}

	/**
	 * @return the companyInformation
	 */
	public String getCompanyInformation() {
		return companyInformation;
	}

	/**
	 * @param companyInformation the companyInformation to set
	 */
	public void setCompanyInformation(String companyInformation) {
		this.companyInformation = companyInformation;
	}

	/**
	 * @return the licenseActive
	 */
	public String getLicenseActive() {
		return licenseActive;
	}

	/**
	 * @param licenseActive the licenseActive to set
	 */
	public void setLicenseActive(String licenseActive) {
		this.licenseActive = licenseActive;
	}

	/**
	 * @return the insertTime
	 */
	public Date getInsertTime() {
		return insertTime;
	}

	/**
	 * @param insertTime the insertTime to set
	 */
	public void setInsertTime(Date insertTime) {
		this.insertTime = insertTime;
	}

	/**
	 * @return the insertedBy
	 */
	public int getInsertedBy() {
		return insertedBy;
	}

	/**
	 * @param insertedBy the insertedBy to set
	 */
	public void setInsertedBy(int insertedBy) {
		this.insertedBy = insertedBy;
	}

	/**
	 * @return the updateTime
	 */
	public Date getUpdateTime() {
		return updateTime;
	}

	/**
	 * @param updateTime the updateTime to set
	 */
	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	/**
	 * @return the updatedBy
	 */
	public int getUpdatedBy() {
		return updatedBy;
	}

	/**
	 * @param updatedBy the updatedBy to set
	 */
	public void setUpdatedBy(int updatedBy) {
		this.updatedBy = updatedBy;
	}

	/**
	 * @return the syncRequired
	 */
	public String getSyncRequired() {
		return syncRequired;
	}

	/**
	 * @param syncRequired the syncRequired to set
	 */
	public void setSyncRequired(String syncRequired) {
		this.syncRequired = syncRequired;
	}

	/**
	 * @return the status
	 */
	public Status getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(Status status) {
		this.status = status;
	}
	
}
