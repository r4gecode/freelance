/**
 * 
 */
package in.ind.mds.repo.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import in.ind.mds.repo.entity.CrewTraining;
import in.ind.mds.repo.entity.Staff;
import in.ind.mds.repo.entity.Status;

/**
 * @author mds-arockia
 *
 */
public interface CrewTrainingDao extends JpaRepository<CrewTraining, String>{
	
	List<CrewTraining> findByStaffAndStatusNot(Staff staff, Status status);

	List<CrewTraining> findByIdInAndStatusNot(List<String> ids, Status status);

}
