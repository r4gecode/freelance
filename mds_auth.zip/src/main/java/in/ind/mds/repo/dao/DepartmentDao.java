/**
 * 
 */
package in.ind.mds.repo.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import in.ind.mds.repo.entity.Department;
import in.ind.mds.repo.entity.Status;

/**
 * @author mds-arockia
 *
 */
public interface DepartmentDao extends JpaRepository<Department, String>{
	
	Department findByIdAndStatusNot(String departmentId, Status status);
	
	List<Department> findByIdInAndStatusNot(List<String> departmentIds, Status status);
	
	Department findByDepartmentNameAndStatusNot(String departmentName, Status status);
	
	Department findByDepartmentNameAndStatusNotAndIdNot(String departmentName, Status status, String departmentId);
	
	@Modifying
	@Transactional
	@Query(value = "SELECT * FROM TB_DEPARTMENT WHERE RECORD_STATUS != 2", nativeQuery = true)
	List<Department> findAllDepartment();

}
