package in.ind.mds.repo.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import in.ind.mds.repo.entity.SignOffReason;
import in.ind.mds.repo.entity.Status;

public interface SignOffReasonDao  extends JpaRepository<SignOffReason, String>{

	SignOffReason findBySignOffReasonAndStatusNot(String signOffReason, Status status);

	SignOffReason findBySignOffReasonAndStatusNotAndIdNot(String signOffReason, Status status, String id);

	SignOffReason findByIdAndStatusNot(String id, Status status);

	List<SignOffReason> findByIdInAndStatusNot(List<String> ids, Status status);

	@Modifying
	@Transactional
	@Query(value = "SELECT * FROM TB_CREW_SIGN_OFF_REASON WHERE RECORD_STATUS != 2", nativeQuery = true)
	List<SignOffReason> findAllSignOffReason();



}
