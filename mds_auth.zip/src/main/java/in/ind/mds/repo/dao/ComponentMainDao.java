package in.ind.mds.repo.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import in.ind.mds.repo.entity.ComponentMain;
import in.ind.mds.repo.entity.Status;

public interface ComponentMainDao extends JpaRepository<ComponentMain, String> {

	ComponentMain findByGroupCodeAndStatusNot(String groupCode, Status status);

	ComponentMain findByGroupNameAndGroupCodeAndStatusNot(String groupName, String groupCode, Status status);
	
	@Query(value = "SELECT * FROM TB_PMS_COMPONENT_MAIN WHERE ( GROUP_NAME = ?1 OR GROUP_CODE = ?2) AND RECORD_STATUS != 2 ", nativeQuery = true)
	List<ComponentMain> uniqueCheckForAdd(String groupName, String groupCode);
	
	@Query(value = "SELECT * FROM TB_PMS_COMPONENT_MAIN WHERE (GROUP_NAME = ?1 OR GROUP_CODE = ?2) AND RECORD_STATUS != 2 AND ID != ?3", nativeQuery = true)
	List<ComponentMain> uniqueCheckForUpdate(String groupName, String groupCode, String id);
	
	ComponentMain findByIdAndStatusNot(String groupId, Status status);
	
	List<ComponentMain> findByIdInAndStatusNot(List<String> groupId, Status status);
	
	@Modifying
	@Transactional
	@Query(value = "SELECT * FROM TB_PMS_COMPONENT_MAIN WHERE RECORD_STATUS != 2", nativeQuery = true)
	List<ComponentMain> findAllComponentMain();

}
