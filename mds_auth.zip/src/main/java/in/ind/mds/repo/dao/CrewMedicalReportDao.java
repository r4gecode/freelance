/**
 * 
 */
package in.ind.mds.repo.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import in.ind.mds.repo.entity.CrewMedicalReport;
import in.ind.mds.repo.entity.Staff;
import in.ind.mds.repo.entity.Status;

/**
 * @author mds-arockia
 *
 */
public interface CrewMedicalReportDao extends JpaRepository<CrewMedicalReport, String>{
	
	List<CrewMedicalReport> findByStaffAndStatusNot(Staff staff, Status status);

	List<CrewMedicalReport> findByIdInAndStatusNot(List<String> ids, Status status);

}
