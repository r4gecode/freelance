/**
 * 
 */
package in.ind.mds.repo.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * @author mds-arockia
 *
 */
@Entity
@Table(name = "TB_SCHEDULED_JOB")
public class ScheduledJob implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1174889946248L;

	@Id
	@Column(name = "ID", nullable = false, unique = true)
	private String id;
	
	@ManyToOne
	@JoinColumn(name = "FLEET_ID")
	private Fleet fleet;
	
	@ManyToOne
	@JoinColumn(name="VESSEL_ID")
	private Vessel vessel;
	
	@Column(name= "JOB_CODE")
	private String jobCode;
	
	@Column(name= "JOB_NAME")
	private String jobName;
	
	@ManyToOne
	@JoinColumn(name= "JOB_CATEGORY_ID")
	private JobCategory jobCategory;
	
	@Column(name= "JOB_PROCEDURE")
	private String jobProcedure;
	
	@ManyToOne
	@JoinColumn(name= "COMPONENT_ID")
	private Component component;
	
	@ManyToOne
	@JoinColumn(name= "RESPONSIBILITY")
	private Role role;
	
	@Column(name= "CRITICAL_JOB_INDI")
	private String criticalJobIndi;
	
	@Column(name= "FROM_FREQUENCY")
	private int fromFrequency; 
	
	@Column(name= "TO_FREQUENCY")
	private int toFrequency;
	
	@Column(name= "FREQUENCY_TYPE")
	private String frequencyType;
	
	@Column(name= "TOTAL_RH")
	private float totalRH;
	
	@Column(name= "AVG_RH")
	private float avgRunningHour;
	
	@Column(name= "LAST_DONE_DATE")
	private Date lastDoneDate;
	
	@Column(name= "NEXT_DUE_DATE")
	private Date nextDueDate;
	
	@Column(name= "RESCHEDULED_DUE_DATE")
	private Date rescheduledDueDate;
	
	@Column(name = "RH_AT_LAST_COMPLETION")
	private float rhAtLastCompletion;
	
	@Column(name = "RH_FROM_LAST_COMPLETION")
	private float rhFromLastCompletion;
	
	@Column(name = "TOTAL_NUM_DAYS_COMPONENT_RUN")
	private int totalNODComponentRun;
	
	@ManyToOne
	@JoinColumn(name= "RECORD_STATUS")
	private Status status;
	
	@Column(name= "SYNC_REQUIRED")
	private String syncRequired;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "INSERT_TIME")
	private Date insertTime;

	@ManyToOne
	@JoinColumn(name = "INSERTED_BY")
	private User insertedBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "UPDATE_TIME")
	private Date updateTime;

	@ManyToOne
	@JoinColumn(name = "UPDATED_BY")
	private User updatedBy;

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the fleet
	 */
	public Fleet getFleet() {
		return fleet;
	}

	/**
	 * @param fleet the fleet to set
	 */
	public void setFleet(Fleet fleet) {
		this.fleet = fleet;
	}

	/**
	 * @return the vessel
	 */
	public Vessel getVessel() {
		return vessel;
	}

	/**
	 * @param vessel the vessel to set
	 */
	public void setVessel(Vessel vessel) {
		this.vessel = vessel;
	}

	/**
	 * @return the jobCode
	 */
	public String getJobCode() {
		return jobCode;
	}

	/**
	 * @param jobCode the jobCode to set
	 */
	public void setJobCode(String jobCode) {
		this.jobCode = jobCode;
	}

	/**
	 * @return the jobName
	 */
	public String getJobName() {
		return jobName;
	}

	/**
	 * @param jobName the jobName to set
	 */
	public void setJobName(String jobName) {
		this.jobName = jobName;
	}

	/**
	 * @return the jobCategory
	 */
	public JobCategory getJobCategory() {
		return jobCategory;
	}

	/**
	 * @param jobCategory the jobCategory to set
	 */
	public void setJobCategory(JobCategory jobCategory) {
		this.jobCategory = jobCategory;
	}

	/**
	 * @return the jobProcedure
	 */
	public String getJobProcedure() {
		return jobProcedure;
	}

	/**
	 * @param jobProcedure the jobProcedure to set
	 */
	public void setJobProcedure(String jobProcedure) {
		this.jobProcedure = jobProcedure;
	}

	/**
	 * @return the component
	 */
	public Component getComponent() {
		return component;
	}

	/**
	 * @param component the component to set
	 */
	public void setComponent(Component component) {
		this.component = component;
	}

	/**
	 * @return the role
	 */
	public Role getRole() {
		return role;
	}

	/**
	 * @param role the role to set
	 */
	public void setRole(Role role) {
		this.role = role;
	}

	/**
	 * @return the criticalJobIndi
	 */
	public String getCriticalJobIndi() {
		return criticalJobIndi;
	}

	/**
	 * @param criticalJobIndi the criticalJobIndi to set
	 */
	public void setCriticalJobIndi(String criticalJobIndi) {
		this.criticalJobIndi = criticalJobIndi;
	}

	/**
	 * @return the fromFrequency
	 */
	public int getFromFrequency() {
		return fromFrequency;
	}

	/**
	 * @param fromFrequency the fromFrequency to set
	 */
	public void setFromFrequency(int fromFrequency) {
		this.fromFrequency = fromFrequency;
	}

	/**
	 * @return the toFrequency
	 */
	public int getToFrequency() {
		return toFrequency;
	}

	/**
	 * @param toFrequency the toFrequency to set
	 */
	public void setToFrequency(int toFrequency) {
		this.toFrequency = toFrequency;
	}

	/**
	 * @return the frequencyType
	 */
	public String getFrequencyType() {
		return frequencyType;
	}

	/**
	 * @param frequencyType the frequencyType to set
	 */
	public void setFrequencyType(String frequencyType) {
		this.frequencyType = frequencyType;
	}

	/**
	 * @return the totalRH
	 */
	public float getTotalRH() {
		return totalRH;
	}

	/**
	 * @param totalRH the totalRH to set
	 */
	public void setTotalRH(float totalRH) {
		this.totalRH = totalRH;
	}

	/**
	 * @return the avgRunningHour
	 */
	public float getAvgRunningHour() {
		return avgRunningHour;
	}

	/**
	 * @param avgRunningHour the avgRunningHour to set
	 */
	public void setAvgRunningHour(float avgRunningHour) {
		this.avgRunningHour = avgRunningHour;
	}

	/**
	 * @return the lastDoneDate
	 */
	public Date getLastDoneDate() {
		return lastDoneDate;
	}

	/**
	 * @param lastDoneDate the lastDoneDate to set
	 */
	public void setLastDoneDate(Date lastDoneDate) {
		this.lastDoneDate = lastDoneDate;
	}

	/**
	 * @return the nextDueDate
	 */
	public Date getNextDueDate() {
		return nextDueDate;
	}

	/**
	 * @param nextDueDate the nextDueDate to set
	 */
	public void setNextDueDate(Date nextDueDate) {
		this.nextDueDate = nextDueDate;
	}

	/**
	 * @return the rescheduledDueDate
	 */
	public Date getRescheduledDueDate() {
		return rescheduledDueDate;
	}

	/**
	 * @param rescheduledDueDate the rescheduledDueDate to set
	 */
	public void setRescheduledDueDate(Date rescheduledDueDate) {
		this.rescheduledDueDate = rescheduledDueDate;
	}

	/**
	 * @return the rhAtLastCompletion
	 */
	public float getRhAtLastCompletion() {
		return rhAtLastCompletion;
	}

	/**
	 * @param rhAtLastCompletion the rhAtLastCompletion to set
	 */
	public void setRhAtLastCompletion(float rhAtLastCompletion) {
		this.rhAtLastCompletion = rhAtLastCompletion;
	}

	/**
	 * @return the rhFromLastCompletion
	 */
	public float getRhFromLastCompletion() {
		return rhFromLastCompletion;
	}

	/**
	 * @param rhFromLastCompletion the rhFromLastCompletion to set
	 */
	public void setRhFromLastCompletion(float rhFromLastCompletion) {
		this.rhFromLastCompletion = rhFromLastCompletion;
	}

	/**
	 * @return the totalNODComponentRun
	 */
	public int getTotalNODComponentRun() {
		return totalNODComponentRun;
	}

	/**
	 * @param totalNODComponentRun the totalNODComponentRun to set
	 */
	public void setTotalNODComponentRun(int totalNODComponentRun) {
		this.totalNODComponentRun = totalNODComponentRun;
	}

	/**
	 * @return the status
	 */
	public Status getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(Status status) {
		this.status = status;
	}

	/**
	 * @return the syncRequired
	 */
	public String getSyncRequired() {
		return syncRequired;
	}

	/**
	 * @param syncRequired the syncRequired to set
	 */
	public void setSyncRequired(String syncRequired) {
		this.syncRequired = syncRequired;
	}

	/**
	 * @return the insertTime
	 */
	public Date getInsertTime() {
		return insertTime;
	}

	/**
	 * @param insertTime the insertTime to set
	 */
	public void setInsertTime(Date insertTime) {
		this.insertTime = insertTime;
	}

	/**
	 * @return the insertedBy
	 */
	public User getInsertedBy() {
		return insertedBy;
	}

	/**
	 * @param insertedBy the insertedBy to set
	 */
	public void setInsertedBy(User insertedBy) {
		this.insertedBy = insertedBy;
	}

	/**
	 * @return the updateTime
	 */
	public Date getUpdateTime() {
		return updateTime;
	}

	/**
	 * @param updateTime the updateTime to set
	 */
	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	/**
	 * @return the updatedBy
	 */
	public User getUpdatedBy() {
		return updatedBy;
	}

	/**
	 * @param updatedBy the updatedBy to set
	 */
	public void setUpdatedBy(User updatedBy) {
		this.updatedBy = updatedBy;
	}

}
