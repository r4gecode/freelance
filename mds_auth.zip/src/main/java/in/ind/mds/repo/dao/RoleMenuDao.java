package in.ind.mds.repo.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import in.ind.mds.repo.entity.Menu;
import in.ind.mds.repo.entity.Role;
import in.ind.mds.repo.entity.RoleMenu;
import in.ind.mds.repo.entity.Status;

public interface RoleMenuDao extends JpaRepository<RoleMenu, String> {

	List<RoleMenu> findByMenuAndStatusNot(Menu menu, Status status);
	
	RoleMenu findByIdAndStatusNot(String roleMenuId, Status status);
	
	List<RoleMenu> findByIdInAndStatusNot(List<String> roleMenuIds, Status status);

	RoleMenu findByIdAndMenuAndStatusNot(String roleMenuId, Menu menu, Status status);

	@Modifying
	@Transactional
	@Query(value = "SELECT * FROM TB_ROLE_MENU WHERE RECORD_STATUS != 2", nativeQuery = true)
	List<RoleMenu> findAllRoleMenu();
	
	List<RoleMenu> findByRole(Role role);
}
