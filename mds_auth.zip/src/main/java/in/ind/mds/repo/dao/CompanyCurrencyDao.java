/**
 * 
 */
package in.ind.mds.repo.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import in.ind.mds.repo.entity.Company;
import in.ind.mds.repo.entity.CompanyCurrency;
import in.ind.mds.repo.entity.GlobalCurrency;
import in.ind.mds.repo.entity.Status;

/**
 * @author mds-arockia
 *
 */
public interface CompanyCurrencyDao extends JpaRepository<CompanyCurrency, String>{

	public List<CompanyCurrency> findByIdInAndStatusNot(List<String> companyCurrencyIds, Status status);
	
	public List<CompanyCurrency> findByCurrencyAndStatusNot(String id, Status status);
	
	public List<CompanyCurrency> findByCompanyAndStatusNotAndCurrencyNot(Company company, Status status, GlobalCurrency globalCurrency);
	
	public List<CompanyCurrency> findByCompanyAndStatusNot(Company company, Status status);
	
	public List<CompanyCurrency> findBaseCurrencyByCompanyAndStatusNot(Company company, Status status);
}
