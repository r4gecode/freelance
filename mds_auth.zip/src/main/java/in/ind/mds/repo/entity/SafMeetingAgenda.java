/**
 * 
 */
package in.ind.mds.repo.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * @author Hinaya
 *
 */
@Entity
@Table(name = "TB_SAF_MEETING_AGENDA")
public class SafMeetingAgenda implements Serializable {
	
	private static final long serialVersionUID = 1233287824548L;
	
	@Id
	@Column(name = "ID", nullable = false, unique = true)
	private String id;
	
	@Column(name = "SEQUENCE_NUM",nullable = false)
	private String sequenceNum;
	
	@Column(name = "AGENDA_NAME",nullable = false)
	private String agendaName;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "INSERT_TIME")
	private Date insertTime;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "UPDATE_TIME")
	private Date updateTime;

	@Column(name = "SYNC_REQUIRED")
	private String syncRequired;

	@ManyToOne
	@JoinColumn(name="RECORD_STATUS")
	private Status status;

	@ManyToOne
	@JoinColumn(name="INSERTED_BY")
	private User insertedBy;
	
	@ManyToOne
	@JoinColumn(name="UPDATED_BY")
	private User updatedBy;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getSequenceNum() {
		return sequenceNum;
	}

	public void setSequenceNum(String sequenceNum) {
		this.sequenceNum = sequenceNum;
	}

	public String getAgendaName() {
		return agendaName;
	}

	public void setAgendaName(String agendaName) {
		this.agendaName = agendaName;
	}

	public Date getInsertTime() {
		return insertTime;
	}

	public void setInsertTime(Date insertTime) {
		this.insertTime = insertTime;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public String getSyncRequired() {
		return syncRequired;
	}

	public void setSyncRequired(String syncRequired) {
		this.syncRequired = syncRequired;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	public User getInsertedBy() {
		return insertedBy;
	}

	public void setInsertedBy(User insertedBy) {
		this.insertedBy = insertedBy;
	}

	public User getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(User updatedBy) {
		this.updatedBy = updatedBy;
	}

	

}
