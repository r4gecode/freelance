package in.ind.mds.repo.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import in.ind.mds.repo.entity.LocOnboard;
import in.ind.mds.repo.entity.Status;

public interface LocOnboardDao extends JpaRepository<LocOnboard, String> {

	LocOnboard findByLocationNameAndStatusNot(String locationName, Status status);

	LocOnboard findByLocationNameAndStatusNotAndIdNot(String locationName, Status status, String locationId);
	
	LocOnboard findByIdAndLocationNameAndStatusNot(String locationId, String locationName, Status status);

	LocOnboard findByIdAndStatusNot(String locationId, Status status);
	
	List<LocOnboard> findByIdInAndStatusNot(List<String> locationIds, Status status);
	
	@Modifying
	@Transactional
	@Query(value = "SELECT * FROM TB_PMS_LOC_ONBOARD WHERE RECORD_STATUS != 2", nativeQuery = true)
	List<LocOnboard> findAllLocOnboard();
}
