/**
 * 
 */
package in.ind.mds.repo.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import in.ind.mds.repo.entity.Hazards;
import in.ind.mds.repo.entity.Operation;
import in.ind.mds.repo.entity.Status;

/**
 * @author dharani
 *
 */
public interface HazardsDao extends JpaRepository<Hazards, String>{
	
	List<Hazards>findByOperationIdAndStatusNot(Operation operation,Status status);
	
	List<Hazards>findByIdInAndStatusNot(List<String> hazardsIds,Status status);
	
	Hazards findByIdAndStatusNot(String id,Status status);

	

	@Modifying
	@Transactional
	@Query(value = "SELECT * FROM TB_HAZARDS WHERE RECORD_STATUS != 2", nativeQuery = true)
	List<Hazards> findAll();
}
