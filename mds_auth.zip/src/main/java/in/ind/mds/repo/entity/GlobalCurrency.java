/**
 * 
 */
package in.ind.mds.repo.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author mds-arockia
 *
 */
@Entity
@Table(name = "TB_GLOBAL_CURRENCY")
public class GlobalCurrency implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1188975093456248L;
	@Id
	@Column(name = "ID", nullable = false, unique = true)
	private Integer id;
	
	@Column(name = "CURRENCY_CODE")
	private String currencyCode;
	
	@Column(name = "CURRENCY")
	private String currency;

	/**
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Integer id) {
		this.id = id;
	}

	/**
	 * @return the currencyCode
	 */
	public String getCurrencyCode() {
		return currencyCode;
	}

	/**
	 * @param currencyCode the currencyCode to set
	 */
	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}

	/**
	 * @return the currency
	 */
	public String getCurrency() {
		return currency;
	}

	/**
	 * @param currency the currency to set
	 */
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	
}
