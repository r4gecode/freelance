/**
 * 
 */
package in.ind.mds.repo.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import in.ind.mds.repo.entity.Severity;

import in.ind.mds.repo.entity.Status;

/**
 * @author Hinaya
 *
 */
public interface SeverityDao extends JpaRepository<Severity, String>{

	Severity findByItemNumberAndStatusNot(String itemNumber, Status softDeleteStatus);

	Severity findByItemNumberAndStatusNotAndIdNot(String itemNumber, Status softDeleteStatus, String id);

	Severity findByIdAndStatusNot(String id, Status softDeleteStatus);

	List<Severity> findByIdInAndStatusNot(List<String> ids, Status softDeleteStatus);

	@Modifying
	@Transactional
	@Query(value = "SELECT * FROM TB_SEVERITY WHERE RECORD_STATUS != 2", nativeQuery = true)
	List<Severity> findAllSeverity();

	@Query(value="SELECT * FROM TB_SEVERITY WHERE (ITEM_NUMBER =?1 OR TYPE_OF_SEVERITY=?2) AND RECORD_STATUS !=2", nativeQuery=true)
	List<Severity> uniqueCheckForAdd(String itemNumber, String typeOfSeverity);

	@Query(value="SELECT * FROM TB_SEVERITY WHERE (ITEM_NUMBER =?1 OR TYPE_OF_SEVERITY =?3) AND RECORD_STATUS !=2 AND ID!=?2", nativeQuery=true)
	List<Severity> uniqueCheckForUpdate(String itemNumber, String id, String typeOfSeverity);
	
	

}
