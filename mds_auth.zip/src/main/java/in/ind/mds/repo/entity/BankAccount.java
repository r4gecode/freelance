/**
 * 
 */
package in.ind.mds.repo.entity;

import java.io.Serializable;
import java.util.Date;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * @author Hinaya
 *
 */
@Entity
@Table(name="TB_BANK_ACCOUNT")
public class BankAccount implements Serializable{
	
	private static final long serialVersionUID = 1123456824248L;
	
	@Id
	@Column(name = "ID", nullable = false, unique = true)
	private String id;
	
	@Column(name = "ACCOUNT_HOLDER_NAME")
	private String accountHolderName;
	
	@Column(name = "ACCOUNT_NUMBER")
	private String accountNumber;
	
	@Column(name = "ACCOUNT_TYPE")
	private String accountType;
	
	@Column(name = "IBAN")
	private String iban;
	
	@Column(name = "BRANCH_NAME")
	private String branchName;
	
	@Column(name  ="BRANCH_CITY")
	private String branchCity;
	
	@Column(name = "ADDRESS")
	private String address;
	
	@Column(name = "SWIFT_CODE")
	private String swiftCode;
	
	@Column(name = "IIFSC_CODE")
	private String iifscCode;
	
	@Column(name = "REMARKS")
	private String remarks;
	
	@Column(name = "SYNC_REQUIRED")
	private String syncRequired;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "INSERT_TIME")
	private Date insertTime;	
	
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "UPDATE_TIME")
	private Date updateTime;

	
	@OneToOne
	@JoinColumn(name = "STAFF_ID", nullable = false)
	private Staff staff;
	
	@ManyToOne
	@JoinColumn(name = "BANK_ID", nullable = false)
	private BankDetails bankdetails;
	
	@ManyToOne
	@JoinColumn(name = "COUNTRY_ID")
	private Country country;
	
	@ManyToOne
	@JoinColumn(name = "RECORD_STATUS")
	private Status status;
	
	@ManyToOne
	@JoinColumn(name = "INSERTED_BY")
	private User insertedBy;
	
	@ManyToOne
	@JoinColumn(name = "UPDATED_BY")
	private User updatedBy;
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getAccountHolderName() {
		return accountHolderName;
	}

	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public String getIban() {
		return iban;
	}

	public void setIban(String iban) {
		this.iban = iban;
	}

	public String getBranchName() {
		return branchName;
	}

	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}

	public String getBranchCity() {
		return branchCity;
	}

	public void setBranchCity(String branchCity) {
		this.branchCity = branchCity;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getSwiftCode() {
		return swiftCode;
	}

	public void setSwiftCode(String swiftCode) {
		this.swiftCode = swiftCode;
	}

	public String getIifscCode() {
		return iifscCode;
	}

	public void setIifscCode(String iifscCode) {
		this.iifscCode = iifscCode;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getSyncRequired() {
		return syncRequired;
	}

	public void setSyncRequired(String syncRequired) {
		this.syncRequired = syncRequired;
	}

	public Date getInsertTime() {
		return insertTime;
	}

	public void setInsertTime(Date insertTime) {
		this.insertTime = insertTime;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public Staff getStaff() {
		return staff;
	}

	public void setStaff(Staff staff) {
		this.staff = staff;
	}

	public BankDetails getBankdetails() {
		return bankdetails;
	}

	public void setBankdetails(BankDetails bankdetails) {
		this.bankdetails = bankdetails;
	}

	public Country getCountry() {
		return country;
	}

	public void setCountry(Country country) {
		this.country = country;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	public User getInsertedBy() {
		return insertedBy;
	}

	public void setInsertedBy(User insertedBy) {
		this.insertedBy = insertedBy;
	}

	public User getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(User updatedBy) {
		this.updatedBy = updatedBy;
	}

		
	

}
