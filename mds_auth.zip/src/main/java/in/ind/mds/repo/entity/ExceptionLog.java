package in.ind.mds.repo.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name ="TB_EXCEPTION_LOG")
public class ExceptionLog implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer id;
	
	@Column(name="EXCEPTION_TRACE")
	private String exceptionTrace;
	
	@Column(name="MODULE")
	private String module;
	
	@Column(name="INSERT_TIME")
	private Date insertTime;

	@Column(name="INSERTED_BY")
	private Integer insertedBy;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getExceptionTrace() {
		return exceptionTrace;
	}

	public void setExceptionTrace(String exceptionTrace) {
		this.exceptionTrace = exceptionTrace;
	}

	public String getModule() {
		return module;
	}

	public void setModule(String module) {
		this.module = module;
	}

	public Date getInsertTime() {
		return insertTime;
	}

	public void setInsertTime(Date insertTime) {
		this.insertTime = insertTime;
	}

	

	/**
	 * @return the insertedBy
	 */
	public Integer getInsertedBy() {
		return insertedBy;
	}

	/**
	 * @param insertedBy the insertedBy to set
	 */
	public void setInsertedBy(Integer insertedBy) {
		this.insertedBy = insertedBy;
	}

	public ExceptionLog(String exceptionTrace, String module, Date insertTime, Integer insertedBy) {
		super();
		this.exceptionTrace = exceptionTrace;
		this.module = module;
		this.insertTime = insertTime;
		this.insertedBy = insertedBy;
	}
	
	public ExceptionLog() {
		// TODO Auto-generated constructor stub
	}
}
