/**
 * 
 */
package in.ind.mds.repo.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import in.ind.mds.repo.entity.RunningHour;
import in.ind.mds.repo.entity.Status;

/**
 * @author mds-arockia
 *
 */
public interface RunningHourDao extends JpaRepository<RunningHour, String>{

	RunningHour findByIdAndStatusNot(String id, Status status);
}
