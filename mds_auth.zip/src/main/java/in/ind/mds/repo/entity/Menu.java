package in.ind.mds.repo.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "TB_MENU")

public class Menu implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1267858055808335678L;

	@Id
	@Column(name = "ID", nullable = false, unique = true)
	private String id;

	@Column(name = "MENU_TYPE")
	private String menuType;

	@Column(name = "MENU_CODE")
	private String menuCode;

	@Column(name = "MENU_DESC")
	private String menuDesc;

	@Column(name = "MENU_URL")
	private String menuUrl;

	
	@Column(name = "MENU_SEQ_NO")
	private int menuSeqNo;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "INSERT_TIME")
	private Date insertTime;

	@Column(name = "INSERTED_BY")
	private int insertedBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "UPDATE_TIME")
	private Date updateTime;

	@Column(name = "UPDATED_BY")
	private int updatedBy;
	
	@Column(name = "SYNC_REQUIRED")
	private String syncRequired;
	
	/*@Column(name="RECORD_STATUS")
	private String recordStatus;
	
	@Column(name = "MENU_PARENT_ID")
	private String menuParentId;*/


	@ManyToOne
	@JoinColumn(name="RECORD_STATUS")
	private Status status;

	
	@ManyToOne
	@JoinColumn(name="MENU_PARENT_ID")
	private Menu menu;

	
	
	
	
	


	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	public Menu getMenu() {
		return menu;
	}

	public void setMenu(Menu menu) {
		this.menu = menu;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getMenuType() {
		return menuType;
	}

	public void setMenuType(String menuType) {
		this.menuType = menuType;
	}

	public String getMenuCode() {
		return menuCode;
	}

	public void setMenuCode(String menuCode) {
		this.menuCode = menuCode;
	}

	public String getMenuDesc() {
		return menuDesc;
	}

	public void setMenuDesc(String menuDesc) {
		this.menuDesc = menuDesc;
	}

	public String getMenuUrl() {
		return menuUrl;
	}

	public void setMenuUrl(String menuUrl) {
		this.menuUrl = menuUrl;
	}

		public int getMenuSeqNo() {
		return menuSeqNo;
	}

	public void setMenuSeqNo(int menuSeqNo) {
		this.menuSeqNo = menuSeqNo;
	}

	public Date getInsertTime() {
		return insertTime;
	}

	public void setInsertTime(Date insertTime) {
		this.insertTime = insertTime;
	}

	public int getInsertedBy() {
		return insertedBy;
	}

	public void setInsertedBy(int insertedBy) {
		this.insertedBy = insertedBy;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public int getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(int updatedBy) {
		this.updatedBy = updatedBy;
	}

	public String getSyncRequired() {
		return syncRequired;
	}

	public void setSyncRequired(String syncRequired) {
		this.syncRequired = syncRequired;
	}




}