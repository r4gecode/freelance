/**
 * 
 */
package in.ind.mds.repo.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import in.ind.mds.repo.entity.Company;
import in.ind.mds.repo.entity.Status;

/**
 * @author mds-arockia
 *
 */
public interface CompanyDao extends JpaRepository<Company, String>{

	Company findByIdAndStatusNot(String companyId, Status status);
	
	List<Company> findByIdInAndStatusNot(List<String> companyId, Status status);
	
	Company findByCompanyNameAndStatusNot(String companyName, Status status);
	
	Company findByCompanyNameAndStatusNotAndIdNot(String companyName, Status status, String companyId);
	
	 @Modifying
		@Transactional
		@Query(value = "SELECT * FROM TB_COMPANY_DETAILS WHERE RECORD_STATUS != 2", nativeQuery = true)
		List<Company> findAllCompany();
	
}
