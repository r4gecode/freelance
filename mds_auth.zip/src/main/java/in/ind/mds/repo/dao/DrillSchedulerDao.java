/**
 * 
 */
package in.ind.mds.repo.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;


import in.ind.mds.repo.entity.DrillScheduler;

import in.ind.mds.repo.entity.Status;

/**
 * @author Hinaya
 *
 */
public interface DrillSchedulerDao extends JpaRepository<DrillScheduler, String> {
	
	DrillScheduler findByIdAndStatusNot(String drillSchedulerId, Status status);
	
	@Modifying
	@Transactional
	@Query(value = "SELECT * FROM TB_DRILL_SCHEDULER WHERE RECORD_STATUS != 2", nativeQuery = true)
	List<DrillScheduler> findAllDrillScheduler();

	@Query(value="SELECT * FROM TB_DRILL_SCHEDULER WHERE (DRILL_NAME =?1 OR FREQUENCY=?2) AND RECORD_STATUS !=2", nativeQuery=true)
	List<DrillScheduler> uniqueCheckForAdd(String drillName, int frequency);

	List<DrillScheduler> findByIdInAndStatusNot(List<String> drillSchedulerIds, Status softDeleteStatus);

	
}
