package in.ind.mds.repo.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import in.ind.mds.repo.entity.UserAudit;

public interface UserAuditDao extends JpaRepository<UserAudit, String> {

	UserAudit findByUserIp(final String userIp);

	UserAudit findByUserIdAndId(final String userId, final String auditId);

	Optional<UserAudit> findById(final String auditId);
	
}
