/**
 * 
 */
package in.ind.mds.repo.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import in.ind.mds.repo.entity.Attachment;
import in.ind.mds.repo.entity.Status;


/**
 * @author mds_kiruthika
 *
 */
public interface AttachmentDao extends JpaRepository<Attachment, String>{
	
	List<Attachment> findByRecordIdAndAttachmentOriginAndAttachmentTypeAndStatusNot(String recordId, String attachmentOrigin, String attachmentType, Status status);
	
	List<Attachment> findByRecordIdAndAttachmentOriginAndStatusNot(String recordId, String attachmentOrigin, Status status);
	
	List<Attachment> findByAttachmentPathInAndStatusNot(List<String> attachmentPathList, Status status);
	
}
