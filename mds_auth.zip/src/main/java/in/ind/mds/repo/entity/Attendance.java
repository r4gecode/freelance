/**
 * 
 */
package in.ind.mds.repo.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * @author shalini
 *
 */
@Entity
@Table(name="TB_ATTENDANCE")
public class Attendance implements Serializable{
	
	private static final long serialVersionUID = 11748899653328L;

	@Id
	@Column(name = "ID", nullable = false, unique = true)
	private String id;
	 
	@Column(name="RECORD_ID",nullable=false)
	private String recordId;
	
	@Column(name="ATTENDANCE_ORIGIN",nullable=false)
	private String attendanceOrigin;
	
	@ManyToOne
	@JoinColumn(name="STAFF_ID")
	private Staff staff;
	

	@ManyToOne
	@JoinColumn(name= "RECORD_STATUS")
	private Status status;
	
	@Column(name= "SYNC_REQUIRED")
	private String syncRequired;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "INSERT_TIME")
	private Date insertTime;

	@ManyToOne
	@JoinColumn(name = "INSERTED_BY")
	private User insertedBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "UPDATE_TIME")
	private Date updateTime;

	@ManyToOne
	@JoinColumn(name = "UPDATED_BY")
	private User updatedBy;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getRecordId() {
		return recordId;
	}

	public void setRecordId(String recordId) {
		this.recordId = recordId;
	}

	
	public String getAttendanceOrigin() {
		return attendanceOrigin;
	}

	public void setAttendanceOrigin(String attendanceOrigin) {
		this.attendanceOrigin = attendanceOrigin;
	}

	public Staff getStaff() {
		return staff;
	}

	public void setStaff(Staff staff) {
		this.staff = staff;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	public String getSyncRequired() {
		return syncRequired;
	}

	public void setSyncRequired(String syncRequired) {
		this.syncRequired = syncRequired;
	}

	public Date getInsertTime() {
		return insertTime;
	}

	public void setInsertTime(Date insertTime) {
		this.insertTime = insertTime;
	}

	public User getInsertedBy() {
		return insertedBy;
	}

	public void setInsertedBy(User insertedBy) {
		this.insertedBy = insertedBy;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public User getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(User updatedBy) {
		this.updatedBy = updatedBy;
	}
}
