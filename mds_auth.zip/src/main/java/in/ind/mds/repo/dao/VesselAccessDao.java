/**
 * 
 */
package in.ind.mds.repo.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import in.ind.mds.repo.entity.User;
import in.ind.mds.repo.entity.VesselAccess;

/**
 * @author mds-arockia
 *
 */
public interface VesselAccessDao extends JpaRepository<VesselAccess, String>{

	public List<VesselAccess> findByUser(User user);
	
	public List<VesselAccess> findVesselByUser(User user);
	
}
