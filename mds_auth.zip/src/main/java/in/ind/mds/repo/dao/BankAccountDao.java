/**
 * 
 */
package in.ind.mds.repo.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import in.ind.mds.repo.entity.BankAccount;
import in.ind.mds.repo.entity.Staff;
import in.ind.mds.repo.entity.Status;

/**
 * @author mds-arockia
 *
 */
public interface BankAccountDao extends JpaRepository<BankAccount, String>{
	
	List<BankAccount> findByStaffAndStatusNot(Staff staff, Status status);

	List<BankAccount> findByIdInAndStatusNot(List<String> ids, Status status);
}
