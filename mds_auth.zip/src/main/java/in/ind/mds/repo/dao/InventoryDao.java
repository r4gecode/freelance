package in.ind.mds.repo.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import in.ind.mds.repo.entity.Inventory;
import in.ind.mds.repo.entity.Status;

public interface InventoryDao extends JpaRepository<Inventory, String> {

	Inventory findByInventoryNameAndStatusNot(final String inventoryName, final Status status);

	Inventory findByInventoryCodeAndInventoryNameAndStatusNot(final String inventoryCode, final String inventoryName, final Status status);
	
	Inventory findByIdAndStatusNot(final String inventoryId, final Status status);
	
	@Modifying
	@Transactional
	@Query(value = "SELECT * FROM TB_PMS_INVENTORY WHERE RECORD_STATUS != 2", nativeQuery = true)
	List<Inventory> findAllInventory();

}
