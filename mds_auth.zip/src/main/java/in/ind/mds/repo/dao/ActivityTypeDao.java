/**
 * 
 */
package in.ind.mds.repo.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import in.ind.mds.repo.entity.ActivityType;
import in.ind.mds.repo.entity.Status;

/**
 * @author mds-arockia
 *
 */
public interface ActivityTypeDao extends JpaRepository<ActivityType, String>{
	
	ActivityType findByActivityNameAndStatusNot(String activityName, Status status);
	
	ActivityType findByActivityNameAndStatusNotAndIdNot(String activityName, Status status, String id);
	
	ActivityType findByIdAndStatusNot(String id, Status status);
	
	List<ActivityType> findByIdInAndStatusNot(List<String> ids, Status status);

	@Modifying
	@Transactional
	@Query(value = "SELECT * FROM TB_PMS_ACTIVITY_TYPE WHERE RECORD_STATUS != 2", nativeQuery = true)
	List<ActivityType> findAllActivityType();
}
