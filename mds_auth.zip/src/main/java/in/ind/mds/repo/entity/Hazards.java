/**
 * 
 */
package in.ind.mds.repo.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * @author dharani
 *
 */

@Entity
@Table(name="TB_HAZARDS")
public class Hazards implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1389357556828L;

	@Id
	@Column(name = "ID", nullable = false, unique = true)
	private String id;
	
	@ManyToOne
	@JoinColumn(name="OPERATION_ID")
	private Operation operationId;
	
	@Column(name="SI_NO")
	private Integer siNo;
	
	@Column(name="HAZARDS ")
	private String harzards;
	
	
	@Column(name="IMPACT_OR_CONSEQUENCES")
	private String impactOrConsequences;
	
	
	@Column(name="EXISTING_CONTROL_MEASURES ")
	private String existingControlMeasures;
	
	@Column(name="ADDITIONAL_MEASURES")
	private String additionalMeasures;
	
	@Column(name="FOLLOW_UP")
	private String followUp;
	
	@Column(name = "SYNC_REQUIRED")
	private String syncRequired;
	
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "INSERT_TIME")
	private Date insertTime;


	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "UPDATE_TIME")
	private Date updateTime;

	
	@ManyToOne
	@JoinColumn(name="INSERTED_BY")
	private User insertedBy;
	
	
	@ManyToOne
	@JoinColumn(name="UPDATED_BY")
	private User updatedBy;
	
	
	@ManyToOne
	@JoinColumn(name="RECORD_STATUS")
	private Status status;



	public String getId() {
		return id;
	}


	public void setId(String id) {
		this.id = id;
	}


	public Operation getOperationId() {
		return operationId;
	}


	public void setOperationId(Operation operationId) {
		this.operationId = operationId;
	}


	public Integer getSiNo() {
		return siNo;
	}


	public void setSiNo(Integer siNo) {
		this.siNo = siNo;
	}


	public String getHarzards() {
		return harzards;
	}


	public void setHarzards(String harzards) {
		this.harzards = harzards;
	}


	public String getImpactOrConsequences() {
		return impactOrConsequences;
	}


	public void setImpactOrConsequences(String impactOrConsequences) {
		this.impactOrConsequences = impactOrConsequences;
	}


	public String getExistingControlMeasures() {
		return existingControlMeasures;
	}


	public void setExistingControlMeasures(String existingControlMeasures) {
		this.existingControlMeasures = existingControlMeasures;
	}


	public String getAdditionalMeasures() {
		return additionalMeasures;
	}


	public void setAdditionalMeasures(String additionalMeasures) {
		this.additionalMeasures = additionalMeasures;
	}


	public String getFollowUp() {
		return followUp;
	}


	public void setFollowUp(String followUp) {
		this.followUp = followUp;
	}


	public String getSyncRequired() {
		return syncRequired;
	}


	public void setSyncRequired(String syncRequired) {
		this.syncRequired = syncRequired;
	}


	public Date getInsertTime() {
		return insertTime;
	}


	public void setInsertTime(Date insertTime) {
		this.insertTime = insertTime;
	}


	public Date getUpdateTime() {
		return updateTime;
	}


	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}


	public User getInsertedBy() {
		return insertedBy;
	}


	public void setInsertedBy(User insertedBy) {
		this.insertedBy = insertedBy;
	}


	public User getUpdatedBy() {
		return updatedBy;
	}


	public void setUpdatedBy(User updatedBy) {
		this.updatedBy = updatedBy;
	}


	public Status getStatus() {
		return status;
	}


	public void setStatus(Status status) {
		this.status = status;
	}
    
	
	

}
